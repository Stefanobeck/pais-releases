"""
Router per la gestione delle integrazioni Bot (Telegram).
"""

import json
import logging
from typing import List
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from pathlib import Path

from integrations import bot_telegram
from services.chat_service import ChatService
from backend_config import settings
from backend_config.auth_pro import require_pro_or_trial

# Gate PRO-only: Bot Telegram integration richiede pro/free_trial.
router = APIRouter(prefix="/api/bots", tags=["Bots"], dependencies=[Depends(require_pro_or_trial)])
logger = logging.getLogger("PAIS.bots")

CONFIG_PATH = Path(__file__).parent.parent / "backend_config" / "bots_config.json"

# Dependency per ottenere ChatService (lo prendiamo dal router interrogate)
from routers.interrogate import get_chat_service
from routers.vision import get_vision_service
from routers.manipulate import get_manipulate_service
from services.vision_service import VisionService
from services.manipulate_service import ManipulateService

class TelegramConfig(BaseModel):
    enabled: bool
    token: str
    allowed_chat_ids: List[int]
    model: str = "gemma4:e4b"
    lang: str = "en"

class BotsConfig(BaseModel):
    telegram: TelegramConfig

def load_config() -> dict:
    if not CONFIG_PATH.exists():
        return {
            "telegram": {"enabled": False, "token": "", "allowed_chat_ids": [], "model": "gemma4:e4b", "lang": "en"}
        }
    with open(CONFIG_PATH, 'r') as f:
        config = json.load(f)
    # Migrazione: rimuovi vecchia sezione whatsapp se presente
    config.pop("whatsapp", None)
    # Migrazione se manca lang
    if "lang" not in config.get("telegram", {}):
        config["telegram"]["lang"] = "en"
    return config

def save_config(config: dict):
    # Mai salvare whatsapp anche se arriva (cleanup migration)
    config.pop("whatsapp", None)
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=4)

@router.get("/config", response_model=BotsConfig)
async def get_config():
    return load_config()

@router.post("/config")
async def update_config(config: BotsConfig):
    save_config(config.model_dump())
    return {"success": True}

@router.get("/status")
async def get_status():
    return {
        "telegram": {
            "running": bot_telegram.is_running()
        }
    }

@router.post("/telegram/toggle")
async def toggle_telegram(
    enable: bool,
    chat_service: ChatService = Depends(get_chat_service),
    vision_service: VisionService = Depends(get_vision_service),
    manipulate_service: ManipulateService = Depends(get_manipulate_service)
):
    config = load_config()

    if enable:
        if not config["telegram"]["token"]:
            raise HTTPException(status_code=400, detail="Token Telegram mancante")

        bot_telegram.set_chat_service(chat_service)
        bot_telegram.set_vision_service(vision_service)
        bot_telegram.set_manipulate_service(manipulate_service)
        try:
            # Use the model currently active in settings for consistency
            current_model = getattr(settings, "CHAT_MODEL", config["telegram"]["model"])

            await bot_telegram.start_bot(
                token=config["telegram"]["token"],
                allowed_chat_ids=config["telegram"]["allowed_chat_ids"],
                model=current_model,
                lang=config["telegram"]["lang"]
            )
            config["telegram"]["enabled"] = True
        except Exception as e:
            import traceback
            print(f"FAILED TO START TELEGRAM BOT: {str(e)}")
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"Errore avvio Telegram: {str(e)}")
    else:
        await bot_telegram.stop_bot()
        config["telegram"]["enabled"] = False

    save_config(config)
    return {"success": True, "running": bot_telegram.is_running()}
