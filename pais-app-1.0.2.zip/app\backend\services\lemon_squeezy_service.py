"""
Lemon Squeezy License Service — env-gated wrapper around the Lemon Squeezy
licenses API + webhook signature verification.

OVERVIEW
========
Lemon Squeezy is a Merchant-of-Record (MoR) that handles checkout, taxes and
license-key issuance. PAIS uses it to:

  1. Activate a license key on a specific device instance
     (`POST /v1/licenses/activate`).
  2. Validate a previously-activated key, periodically or on demand
     (`POST /v1/licenses/validate`).
  3. Deactivate an instance, freeing the seat for re-use on another machine
     (`POST /v1/licenses/deactivate`).
  4. Receive webhook notifications when a subscription is paid / refunded /
     cancelled, so PAIS can revoke PRO access without polling.

This module is ENV-GATED: when `LEMON_SQUEEZY_API_KEY` is empty (default
state on dev machines and on first install), `is_configured()` returns
False and callers should fall back to whatever dummy behaviour they want
(today: `routers/account._classify_dummy`). No real HTTP calls are made
until env vars are populated.

PRODUCTION SETUP (when LS credentials arrive)
=============================================
  1. Create a store at https://app.lemonsqueezy.com
  2. Create a product (subscription or one-time) that issues license keys
  3. Set environment variables on the PAIS host:
       - LEMON_SQUEEZY_API_KEY        # store API key from LS dashboard
       - LEMON_SQUEEZY_STORE_ID       # numeric store id (for filtering)
       - LEMON_SQUEEZY_WEBHOOK_SECRET # HMAC secret for webhook signing
       - LEMON_SQUEEZY_API_URL        # optional, default https://api.lemonsqueezy.com/v1
  4. Create a webhook in LS dashboard pointing to
       https://<PAIS_BACKEND_HOST>/api/account/webhook/lemon-squeezy
     Select events: subscription_payment_success, subscription_payment_failed,
     subscription_cancelled, subscription_expired, order_refunded,
     license_key_created, license_key_updated.

API DOCS
========
  - https://docs.lemonsqueezy.com/api/license-api
  - https://docs.lemonsqueezy.com/help/webhooks

KEY EDGE CASES
==============
- `license_status='inactive'` -> never activated, validate returns valid=False
- `license_status='disabled'` -> manually revoked in LS dashboard
- `license_status='expired'` -> reached expires_at; treat as PRO ended
- HTTP 404 -> license_key does not exist in this store
- HTTP 403 -> wrong store API key for this license
- Network timeout -> retry once, then return valid=False with error_message
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import httpx

logger = logging.getLogger("PAIS.LemonSqueezy")


# ─── env reading (lazy, so settings can be updated mid-process for tests) ─────

def _env(name: str, default: str = "") -> str:
    """Read env var, stripping whitespace."""
    return (os.environ.get(name, default) or "").strip()


def is_configured() -> bool:
    """True iff Lemon Squeezy is set up to handle real API calls.

    When False, callers must fall back to a dummy / offline classifier
    (see routers/account._classify_dummy)."""
    return bool(_env("LEMON_SQUEEZY_API_KEY"))


def _api_base() -> str:
    return _env("LEMON_SQUEEZY_API_URL", "https://api.lemonsqueezy.com/v1").rstrip("/")


def _api_key() -> str:
    return _env("LEMON_SQUEEZY_API_KEY")


def _webhook_secret() -> str:
    return _env("LEMON_SQUEEZY_WEBHOOK_SECRET")


def _http_headers() -> dict:
    """Default headers for LS API. The Accept header is required by the
    JSON:API contract; without it LS may return text/html error pages."""
    return {
        "Authorization": f"Bearer {_api_key()}",
        "Accept": "application/vnd.api+json",
        "Content-Type": "application/x-www-form-urlencoded",
    }


# ─── result type ──────────────────────────────────────────────────────────────

@dataclass
class LicenseValidationResult:
    """Outcome of an activate/validate call.

    Always populated. On failure, `valid=False` and `error_message`
    explains what went wrong; the other fields stay at their default.
    """
    valid: bool = False
    license_status: str = ""          # "active" | "inactive" | "disabled" | "expired"
    expires_at: Optional[datetime] = None
    customer_email: Optional[str] = None
    customer_name: Optional[str] = None
    instance_id: Optional[str] = None
    instance_name: Optional[str] = None
    activation_limit: Optional[int] = None
    activation_usage: Optional[int] = None
    error_message: Optional[str] = None
    raw: dict = field(default_factory=dict)  # full response for debugging


# ─── helpers ──────────────────────────────────────────────────────────────────

def _parse_datetime(iso_string: Optional[str]) -> Optional[datetime]:
    """Parse an ISO 8601 string into a tz-aware datetime. LS returns
    e.g. '2026-12-31T23:59:59.000000Z' — Python's fromisoformat in 3.10
    handles the trailing Z poorly, so we normalize first."""
    if not iso_string:
        return None
    try:
        normalized = iso_string.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalized)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _result_from_response(payload: dict) -> LicenseValidationResult:
    """Map a successful LS /licenses/activate or /licenses/validate response
    body to a LicenseValidationResult."""
    lk = payload.get("license_key") or {}
    inst = payload.get("instance") or {}
    meta = payload.get("meta") or {}

    status = (lk.get("status") or "").lower()
    valid = bool(payload.get("activated") or payload.get("valid")) and status == "active"

    return LicenseValidationResult(
        valid=valid,
        license_status=status,
        expires_at=_parse_datetime(lk.get("expires_at")),
        customer_email=meta.get("customer_email") or lk.get("customer_email"),
        customer_name=meta.get("customer_name") or lk.get("customer_name"),
        instance_id=inst.get("id"),
        instance_name=inst.get("name"),
        activation_limit=lk.get("activation_limit"),
        activation_usage=lk.get("activation_usage"),
        raw=payload,
    )


def _failure(reason: str, raw: Optional[dict] = None) -> LicenseValidationResult:
    """Construct a failure result with a human-readable reason."""
    return LicenseValidationResult(
        valid=False,
        error_message=reason,
        raw=raw or {},
    )


# ─── public API ───────────────────────────────────────────────────────────────

def activate_license(license_key: str, instance_name: str, timeout: float = 10.0) -> LicenseValidationResult:
    """Activate a license key on a device instance.

    `instance_name` should uniquely identify the device — e.g. the
    hardware fingerprint from identity_service. LS will refuse to
    activate beyond the configured activation_limit (typically 1 for
    single-seat licenses), letting us prevent license sharing.

    Returns a result where `instance_id` is set on success — store it
    in user_settings so future validate/deactivate calls can reference
    this specific activation.
    """
    if not is_configured():
        return _failure("Lemon Squeezy is not configured (LEMON_SQUEEZY_API_KEY missing)")

    if not license_key or not instance_name:
        return _failure("license_key and instance_name are required")

    url = f"{_api_base()}/licenses/activate"
    data = {"license_key": license_key.strip(), "instance_name": instance_name.strip()}

    try:
        with httpx.Client(timeout=timeout) as c:
            resp = c.post(url, data=data, headers=_http_headers())
    except httpx.RequestError as e:
        logger.error("Lemon Squeezy activate network error: %s", e)
        return _failure(f"Network error contacting Lemon Squeezy: {e}")

    if resp.status_code >= 400:
        logger.warning("Lemon Squeezy activate HTTP %s: %s", resp.status_code, resp.text[:500])
        # LS error payload usually has {"error": "..."} or {"errors": [{...}]}
        try:
            body = resp.json()
            msg = body.get("error") or (body.get("errors") or [{}])[0].get("detail") or resp.text
        except Exception:
            msg = resp.text or f"HTTP {resp.status_code}"
        return _failure(f"Lemon Squeezy error: {msg}", raw={"status": resp.status_code})

    try:
        return _result_from_response(resp.json())
    except Exception as e:
        logger.error("Lemon Squeezy activate response parse failed: %s", e)
        return _failure(f"Invalid response from Lemon Squeezy: {e}")


def validate_license(
    license_key: str,
    instance_id: Optional[str] = None,
    timeout: float = 10.0,
) -> LicenseValidationResult:
    """Validate a previously activated license. Use periodically (e.g. once
    per day) to detect refunds / manual revocations / subscription expiry.

    `instance_id` is optional but recommended — without it, LS only checks
    that the key exists and is active, not that it's been activated on
    THIS device. With it, LS also verifies the instance is still bound.
    """
    if not is_configured():
        return _failure("Lemon Squeezy is not configured (LEMON_SQUEEZY_API_KEY missing)")

    if not license_key:
        return _failure("license_key is required")

    url = f"{_api_base()}/licenses/validate"
    data: dict = {"license_key": license_key.strip()}
    if instance_id:
        data["instance_id"] = instance_id.strip()

    try:
        with httpx.Client(timeout=timeout) as c:
            resp = c.post(url, data=data, headers=_http_headers())
    except httpx.RequestError as e:
        logger.error("Lemon Squeezy validate network error: %s", e)
        return _failure(f"Network error contacting Lemon Squeezy: {e}")

    if resp.status_code >= 400:
        logger.warning("Lemon Squeezy validate HTTP %s: %s", resp.status_code, resp.text[:500])
        try:
            body = resp.json()
            msg = body.get("error") or (body.get("errors") or [{}])[0].get("detail") or resp.text
        except Exception:
            msg = resp.text or f"HTTP {resp.status_code}"
        return _failure(f"Lemon Squeezy error: {msg}", raw={"status": resp.status_code})

    try:
        return _result_from_response(resp.json())
    except Exception as e:
        logger.error("Lemon Squeezy validate response parse failed: %s", e)
        return _failure(f"Invalid response from Lemon Squeezy: {e}")


def deactivate_license(license_key: str, instance_id: str, timeout: float = 10.0) -> bool:
    """Free a seat by deactivating a specific instance. Returns True on
    success. Use on uninstall (best-effort, fire-and-forget) or when the
    user wants to move PAIS to another machine."""
    if not is_configured():
        return False

    if not license_key or not instance_id:
        return False

    url = f"{_api_base()}/licenses/deactivate"
    data = {"license_key": license_key.strip(), "instance_id": instance_id.strip()}

    try:
        with httpx.Client(timeout=timeout) as c:
            resp = c.post(url, data=data, headers=_http_headers())
    except httpx.RequestError as e:
        logger.error("Lemon Squeezy deactivate network error: %s", e)
        return False

    if resp.status_code >= 400:
        logger.warning("Lemon Squeezy deactivate HTTP %s: %s", resp.status_code, resp.text[:500])
        return False

    try:
        body = resp.json()
        return bool(body.get("deactivated"))
    except Exception:
        return False


def verify_webhook_signature(body: bytes, signature_header: str) -> bool:
    """Verify a Lemon Squeezy webhook signature using HMAC-SHA256.

    LS sends the signature in the `X-Signature` header as the hex digest
    of HMAC-SHA256 over the raw request body using the shared
    LEMON_SQUEEZY_WEBHOOK_SECRET.

    Returns False (rejecting the request) if:
      - webhook secret is not configured
      - signature header is empty or malformed
      - computed signature does not match (using constant-time compare)
    """
    secret = _webhook_secret()
    if not secret:
        return False
    if not signature_header:
        return False

    try:
        expected = hmac.new(
            secret.encode("utf-8"),
            body,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, signature_header.strip())
    except Exception as e:
        logger.error("Webhook signature verification crashed: %s", e)
        return False


# ─── webhook event helpers ────────────────────────────────────────────────────

REVOKE_EVENTS = {
    "subscription_cancelled",
    "subscription_expired",
    "subscription_payment_failed",
    "order_refunded",
    "license_key_revoked",
    "license_key_updated",  # may flip status to disabled
}

REACTIVATE_EVENTS = {
    "subscription_payment_success",
    "subscription_resumed",
    "subscription_unpaused",
    "license_key_created",
}


def event_is_revoke(event_name: str) -> bool:
    return (event_name or "").lower() in REVOKE_EVENTS


def event_is_reactivate(event_name: str) -> bool:
    return (event_name or "").lower() in REACTIVATE_EVENTS
