"""
bot_telegram.py — Telegram Bot Integration for PAI Premium
"""

import logging
import asyncio
import uuid
import re
import html
from typing import Optional, List, Dict
from pathlib import Path
from telegram import Update, BotCommand, constants
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# Import PAI Services
from services.chat_service import ChatService
from services.vision_service import VisionService
from services.manipulate_service import ManipulateService
from backend_config import settings

logger = logging.getLogger("PAIS.telegram")

# Global state
_bot_token: Optional[str] = None
_allowed_chat_ids: List[int] = []
_application = None
_chat_service: Optional[ChatService] = None
_vision_service: Optional[VisionService] = None
_manipulate_service: Optional[ManipulateService] = None
# Fallback solo se settings.CHAT_MODEL non è disponibile all'avvio del bot.
# In pratica il bot usa SEMPRE settings.CHAT_MODEL (override di Interrogate dal desktop)
# a meno che l'utente non abbia configurato un override per-bot in Settings → Bot.
_model_name: str = "gemma4:e4b"
_bot_lang: str = "en"

# Anonimyze mode flag per-chat. Set by /anon or /deanon commands; consumed by the
# next document upload, then cleared. Keeps UX simple: user types the command,
# bot prompts for the file, user attaches it.
_anonimyze_modes: Dict[int, str] = {}  # chat_id -> "anonymize" | "deanonymize"

def set_chat_service(service: ChatService):
    global _chat_service
    _chat_service = service

def set_vision_service(service: VisionService):
    global _vision_service
    _vision_service = service

def set_manipulate_service(service: ManipulateService):
    global _manipulate_service
    _manipulate_service = service

def check_chat(update: Update) -> bool:
    # PRO gate (defense-in-depth) — the Telegram bot is a PRO feature. The
    # primary gate is the toggle endpoint + auto-resume tier check, but if the
    # trial expires WHILE the bot is polling we stop honouring messages here
    # too (single chokepoint: every handler calls check_chat first).
    try:
        from services.user_settings_service import compute_effective_tier
        if (compute_effective_tier() or {}).get("effective_tier") not in ("pro", "free_trial"):
            logger.info("Telegram: ignoring message — PRO licence required (tier lapsed)")
            return False
    except Exception:
        # Fail-open on tier-check errors: a transient service glitch must not
        # silently kill a legitimately-licensed user's bot.
        pass

    chat_id = update.effective_chat.id
    user_id = update.effective_user.id

    if not _allowed_chat_ids:
        return False
        
    if chat_id in _allowed_chat_ids or user_id in _allowed_chat_ids:
        return True
        
    logger.warning(f"Telegram: Blocked unauthorized chat/user: {chat_id}/{user_id}")
    return False

def format_for_telegram(text: str) -> str:
    """
    Converts standard AI Markdown to Telegram-compatible HTML.
    Supports: Bold (**), Italic (*), Code blocks (```), Inline code (`), and Lists.
    """
    # 1. Escape HTML special characters first to avoid conflicts
    t = html.escape(text)

    # 2. Convert code blocks: ```code``` -> <pre>code</pre>
    t = re.sub(r'```(?:[a-zA-Z0-9]+)?\n?(.*?)```', r'<pre>\1</pre>', t, flags=re.DOTALL)

    # 3. Convert inline code: `code` -> <code>code</code>
    t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)

    # 4. Convert Bold: **text** -> <b>text</b>
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)

    # 5. Convert Italic: *text* -> <i>text</i> (excluding inside tags)
    t = re.sub(r'\*([^*]+)\*', r'<i>\1</i>', t)

    # 6. Cleanup common issues with lists or double escapes
    return t.strip()

async def keep_typing(chat):
    """Loop to keep the 'typing...' status alive on Telegram"""
    try:
        while True:
            await chat.send_action(action=constants.ChatAction.TYPING)
            await asyncio.sleep(4)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        logger.debug(f"Typing loop stopped: {e}")

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles images using the VISION module"""
    if not check_chat(update): return

    if not _vision_service:
        await update.message.reply_text("⚠️ VISION service is currently unavailable.")
        return

    typing_task = None
    try:
        await update.message.chat.send_action(action=constants.ChatAction.UPLOAD_PHOTO)
        photo_file = await update.message.photo[-1].get_file()
        
        filename = f"tg_vision_{uuid.uuid4().hex[:8]}.jpg"
        file_path = settings.UPLOAD_DIR / filename
        await photo_file.download_to_drive(custom_path=str(file_path))

        caption = update.message.caption or "Describe this image in detail."
        session_id = f"telegram_vision_{update.effective_chat.id}"
        
        await update.message.reply_text("👁️ Analyzing image... please wait.")
        
        # Start persistent typing status
        typing_task = asyncio.create_task(keep_typing(update.message.chat))

        # Set configured language for the service
        _vision_service.set_language(_bot_lang)

        # upload_image performs analysis and returns the description
        result = await _vision_service.upload_image(file_path=str(file_path), filename=filename, session_id=session_id)

        # Stop typing status
        if typing_task: 
            typing_task.cancel()
            typing_task = None

        if result.get("status") == "success":
            description = result.get("description", "")
            # Format and send
            formatted_text = format_for_telegram(description)
            await update.message.reply_text(formatted_text, parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text(f"⚠️ Error: {result.get('message', 'Could not analyze the image.')}")

    except Exception as e:
        if typing_task: typing_task.cancel()
        logger.error(f"Telegram Vision error: {e}")
        await update.message.reply_text(f"❌ Image analysis error: {str(e)}")

async def handle_anon(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set the chat in 'anonymize' mode — the next file upload will be anonymized."""
    if not check_chat(update): return
    chat_id = update.effective_chat.id
    _anonimyze_modes[chat_id] = "anonymize"
    allowed = "xlsx, xls, csv, pdf, docx, txt, md"
    msg_it = (
        "🔒 *Anonymize Mode attivato*\n\n"
        "Inviami il file da anonimizzare adesso.\n"
        f"Formati supportati: `{allowed}`\n\n"
        "Riceverai il file anonimizzato come allegato. La mappa PII è salvata "
        "nel vault locale del progetto, così puoi deanonimizzare in seguito."
    )
    msg_en = (
        "🔒 *Anonymize Mode active*\n\n"
        "Send me the file to anonymize.\n"
        f"Supported formats: `{allowed}`\n\n"
        "You'll receive the anonymized file as an attachment. The PII map is "
        "stored in the project's local vault so you can de-anonymize it later."
    )
    await update.message.reply_text(msg_it if _bot_lang == "it" else msg_en, parse_mode=constants.ParseMode.MARKDOWN)


async def handle_deanon(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set the chat in 'deanonymize' mode — the next file upload will be decrypted
    using the project's default PII vault.
    """
    if not check_chat(update): return
    chat_id = update.effective_chat.id
    _anonimyze_modes[chat_id] = "deanonymize"
    msg_it = (
        "🔓 *Deanonymize Mode attivato*\n\n"
        "Inviami un file precedentemente anonimizzato (con placeholder tipo `[DFT-PERS-1]`).\n"
        "Userò il vault del progetto per ripristinare i dati originali."
    )
    msg_en = (
        "🔓 *Deanonymize Mode active*\n\n"
        "Send me a previously anonymized file (with placeholders like `[DFT-PERS-1]`).\n"
        "I'll use the project's vault to restore the original data."
    )
    await update.message.reply_text(msg_it if _bot_lang == "it" else msg_en, parse_mode=constants.ParseMode.MARKDOWN)


async def _run_anonimyze_on_file(update: Update, upload_path: Path, filename: str, mode: str):
    """Stage file in anonimyze_service then consume process_file_stream to completion.
    Streams progress as Telegram messages and replies with the output file.
    """
    from services.anonimyze_service import anonimyze_service, ANONYMIZE_SUPPORTED_EXT
    from backend_config.project_manager import project_manager

    ext = upload_path.suffix.lower()
    if ext not in ANONYMIZE_SUPPORTED_EXT:
        allowed = ", ".join(s.lstrip(".") for s in ANONYMIZE_SUPPORTED_EXT)
        await update.message.reply_text(f"⚠️ Format '{ext}' not supported by Anonimyze. Allowed: {allowed}.")
        return

    session_id = f"telegram_{update.effective_chat.id}"
    anonimyze_service.set_language(_bot_lang)

    # Stage: anonimyze processes from `uploads/anonimyze/<filename>`. We move the
    # tg_doc_*.ext file to that location with the original Telegram filename so the
    # output naming is preserved (e.g. "report_ANON_1234567.docx" not "tg_doc_xxx_ANON_...").
    anonimyze_uploads = project_manager.get_path("uploads") / "anonimyze"
    anonimyze_uploads.mkdir(parents=True, exist_ok=True)
    target = anonimyze_uploads / filename
    try:
        if str(upload_path) != str(target):
            import shutil
            shutil.copy2(str(upload_path), str(target))
    except Exception as e:
        logger.error(f"copy to anonimyze uploads failed: {e}")
        await update.message.reply_text(f"❌ Stage error: {e}")
        return

    await anonimyze_service.upload_file(str(target), filename, session_id, mode=("anonymize" if mode == "anonymize" else "deanonymize"))

    # Inform user that processing started (single message — no progress flooding)
    busy_msg_it = "🔄 Anonimizzazione in corso..." if mode == "anonymize" else "🔓 Deanonimizzazione in corso..."
    busy_msg_en = "🔄 Anonymizing..." if mode == "anonymize" else "🔓 Deanonymizing..."
    await update.message.reply_text(busy_msg_it if _bot_lang == "it" else busy_msg_en)

    # Consume the stream — collect the final DONE marker
    out_name = None
    last_error = None
    try:
        async for chunk in anonimyze_service.process_file_stream(
            session_id=session_id,
            filename=filename,
            mode=("anonymize" if mode == "anonymize" else "deanonymize"),
            cloud_ready=True,
        ):
            chunk = (chunk or "").strip()
            if not chunk:
                continue
            if chunk.startswith("DONE:"):
                out_name = chunk[len("DONE:"):].strip()
            elif chunk.startswith("❌"):
                last_error = chunk
    except Exception as e:
        logger.error(f"anonimyze process stream error: {e}")
        await update.message.reply_text(f"❌ Processing error: {e}")
        return

    if not out_name:
        msg = last_error or "Unknown error during processing."
        await update.message.reply_text(f"❌ {msg}")
        return

    # Locate the produced file: anonymize → output/Anonymized/, deanonymize → output/Deanonimyzed/
    sub = "Anonymized" if mode == "anonymize" else "Deanonimyzed"
    out_path = project_manager.get_path("output") / sub / out_name
    if not out_path.exists():
        await update.message.reply_text(f"❌ Output file missing on disk: {out_name}")
        return

    # Send the anonymized/deanonymized file back to the user
    try:
        with open(out_path, "rb") as f:
            caption_it = ("✅ File anonimizzato. La mappa PII è salvata nel vault locale."
                          if mode == "anonymize"
                          else "✅ File deanonimizzato dal vault locale.")
            caption_en = ("✅ Anonymized file. PII map saved in the local vault."
                          if mode == "anonymize"
                          else "✅ File de-anonymized from the local vault.")
            await update.message.reply_document(
                document=f,
                filename=out_name,
                caption=(caption_it if _bot_lang == "it" else caption_en),
            )
    except Exception as e:
        logger.error(f"reply_document failed: {e}")
        await update.message.reply_text(f"❌ Could not send the file: {e}")


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles documents (INTERROGATE / MANIPULATE / ANONIMYZE).
    Routing priority:
      1. If chat is in /anon or /deanon mode → route to Anonimyze pipeline
      2. Else, by extension: xlsx/xls/csv → MANIPULATE; pdf/docx/txt/srt → INTERROGATE
    """
    if not check_chat(update): return

    doc = update.message.document
    filename = doc.file_name
    ext = Path(filename).suffix.lower()
    chat_id = update.effective_chat.id

    # ANONIMYZE branch — takes priority over default routing when /anon or /deanon
    # was sent in this chat. Mode flag is one-shot: cleared after the file is processed.
    anon_mode = _anonimyze_modes.pop(chat_id, None)
    if anon_mode in ("anonymize", "deanonymize"):
        try:
            await update.message.chat.send_action(action=constants.ChatAction.UPLOAD_DOCUMENT)
            doc_file = await doc.get_file()
            from backend_config.project_manager import project_manager
            tmp_dir = project_manager.get_path("uploads") / "anonimyze"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            local_path = tmp_dir / filename  # use original filename for clean output names
            await doc_file.download_to_drive(custom_path=str(local_path))
            await _run_anonimyze_on_file(update, local_path, filename, anon_mode)
        except Exception as e:
            logger.error(f"Telegram Anonimyze error: {e}")
            await update.message.reply_text(f"❌ Anonimyze error: {e}")
        return

    is_manipulate = ext in ['.xlsx', '.xls', '.csv']
    is_interrogate = ext in ['.pdf', '.docx', '.txt', '.srt']

    if not is_manipulate and not is_interrogate:
        await update.message.reply_text(f"⚠️ Format '{ext}' is not supported for automatic analysis.")
        return

    try:
        await update.message.chat.send_action(action=constants.ChatAction.UPLOAD_DOCUMENT)
        doc_file = await doc.get_file()

        local_filename = f"tg_doc_{uuid.uuid4().hex[:8]}{ext}"
        from backend_config.project_manager import project_manager

        if is_manipulate:
            upload_path = project_manager.get_path("uploads") / "manipulate" / local_filename
        else:
            upload_path = project_manager.get_path("uploads") / "interrogate" / local_filename

        upload_path.parent.mkdir(parents=True, exist_ok=True)
        await doc_file.download_to_drive(custom_path=str(upload_path))

        # --- MANIPULATE CASE ---
        if is_manipulate:
            if not _manipulate_service:
                await update.message.reply_text("⚠️ MANIPULATE service is unavailable.")
                return
            
            session_id = f"telegram_manipulate_{update.effective_chat.id}"
            await update.message.reply_text(f"📊 Processing spreadsheet '{filename}'...")
            
            _manipulate_service.set_language(_bot_lang)
            res = await _manipulate_service.upload_file(str(upload_path), filename, session_id)
            if res.get("status") == "error":
                await update.message.reply_text(f"❌ Upload error: {res.get('message')}")
                return
                
            mem_res = await _manipulate_service.memorize_files(session_id)
            if mem_res.get("status") == "success":
                await update.message.reply_text(f"✅ '{filename}' stored in database. You can now ask questions about the data or request charts/transformations.")
            else:
                await update.message.reply_text(f"❌ Storage error: {mem_res.get('message')}")

        # --- INTERROGATE CASE ---
        else:
            if not _chat_service:
                await update.message.reply_text("⚠️ INTERROGATE service is unavailable.")
                return
                
            session_id = f"telegram_{update.effective_chat.id}"
            await update.message.reply_text(f"📄 Reading document '{filename}'...")
            
            _chat_service.set_language(_bot_lang)
            res = await _chat_service.upload_file(str(upload_path), filename, session_id)
            if res.get("status") == "success":
                await update.message.reply_text(f"✅ '{filename}' indexed successfully. I'm ready to answer questions about it.")
            else:
                await update.message.reply_text(f"❌ Indexing error: {res.get('message')}")

    except Exception as e:
        logger.error(f"Telegram Document error: {e}")
        await update.message.reply_text(f"❌ File upload error: {str(e)}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not check_chat(update): return

    text = update.message.text if update.message.text else update.message.caption
    if not text: return

    # Check for manual reset commands in text
    reset_keywords = ["new session", "reset", "clear", "pulisci", "nuova sessione"]
    if any(k in text.lower() for k in reset_keywords):
        await handle_clear(update, context)
        return

    # In groups, check for mention
    is_group = update.effective_chat.type in ("group", "supergroup")
    if is_group:
        bot_username = (await context.bot.get_me()).username
        if f"@{bot_username}" not in text: return
        text = text.replace(f"@{bot_username}", "").strip()

    typing_task = None
    try:
        # Start persistent typing status
        typing_task = asyncio.create_task(keep_typing(update.message.chat))

        session_id = f"telegram_{update.effective_chat.id}"

        # Read per-bot overrides from user_settings.json (model/profile/lang).
        # If not set, fall back to: bot's startup lang + desktop CHAT_MODEL/CHAT_PROFILE.
        try:
            from services.system_service import system_service
            overrides = system_service.get_telegram_overrides()
        except Exception:
            overrides = {"model": None, "profile": None, "lang": None}

        # Set effective language (override > bot startup default)
        _chat_service.set_language(overrides.get("lang") or _bot_lang)

        full_response = ""
        async for chunk in _chat_service.send_message(
            message=text,
            session_id=session_id,
            use_rag=True,
            force_model=overrides.get("model"),
            force_profile=overrides.get("profile"),
        ):
            full_response += chunk

        # Stop typing status
        if typing_task: 
            typing_task.cancel()
            typing_task = None

        if full_response:
            clean_response = re.sub(r'<think>.*?</think>', '', full_response, flags=re.DOTALL).strip()
            if not clean_response: clean_response = full_response
            
            # Format and send
            formatted_text = format_for_telegram(clean_response)
            await update.message.reply_text(formatted_text, parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text("⚠️ Sorry, I couldn't generate a response.")

    except Exception as e:
        if typing_task: typing_task.cancel()
        logger.error(f"Telegram AI error: {e}")
        await update.message.reply_text(f"❌ Processing error: {str(e)}")

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not check_chat(update):
        await update.message.reply_text("⛔ Unauthorized access.")
        return
    
    welcome_msg = (
        "🤖 **Welcome to PAIS**\n\n"
        "I am your Private Intelligence Assistant. I can analyze documents, images, and data locally and securely.\n\n"
        "🚀 **What I can do:**\n"
        "• 💬 **Chat**: Ask me anything or talk about your uploaded docs.\n"
        "• 📄 **Documents**: Send me PDF, DOCX, TXT, or SRT files to index them.\n"
        "• 👁️ **Vision**: Send me a photo and I will describe or analyze it.\n"
        "• 📊 **Data**: Send me XLSX or CSV files for SQL analysis and charts.\n"
        "• 🔒 **Anonymize**: Use /anon then send a file (xlsx/csv/pdf/docx/txt) — I'll redact PII and send it back.\n"
        "• 🔓 **De-anonymize**: Use /deanon then send a previously anonymized file — I'll restore the originals from the local vault.\n\n"
        "🛠️ **Commands:**\n"
        "/anon - Anonymize the next file you send.\n"
        "/deanon - De-anonymize the next file using the local PII vault.\n"
        "/clear - Reset history and delete all session files.\n"
        "/status - Check currently active files in memory.\n"
        "/help - Show this help message again.\n\n"
        "Just send me a message or a file to start!"
    )
    # Using legacy Markdown for this hardcoded welcome as it's simple
    await update.message.reply_text(welcome_msg, parse_mode=constants.ParseMode.MARKDOWN)

async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await handle_start(update, context)

async def handle_clear(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clears all sessions associated with this chat"""
    if not check_chat(update): return
    
    chat_id = update.effective_chat.id
    
    # 1. Clear INTERROGATE
    if _chat_service:
        _chat_service.clear_session(f"telegram_{chat_id}")
    
    # 2. Clear VISION
    if _vision_service:
        _vision_service.clear_session(f"telegram_vision_{chat_id}")
        
    # 3. Clear MANIPULATE
    if _manipulate_service:
        _manipulate_service.clear_session(f"telegram_manipulate_{chat_id}")
        
    await update.message.reply_text("🧹 **Session Reset Successful**\nAll history and uploaded files have been cleared. Ready for a new task!", parse_mode=constants.ParseMode.MARKDOWN)

async def handle_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Checks the status of the current session"""
    if not check_chat(update): return
    
    chat_id = update.effective_chat.id
    status_msg = "📂 **Current Session Status**\n\n"
    
    # Interrogate Files
    files = _chat_service.get_uploaded_files(f"telegram_{chat_id}") if _chat_service else []
    if files:
        status_msg += "📄 **Documents (INTERROGATE):**\n"
        for f in files:
            status_msg += f"- {f['name']} ({f.get('ref', 'N/A')})\n"
    else:
        status_msg += "📄 No documents indexed.\n"
        
    # Manipulate Files
    m_files = _manipulate_service.get_uploaded_files(f"telegram_manipulate_{chat_id}") if _manipulate_service else []
    if m_files:
        status_msg += "\n📊 **Data Sheets (MANIPULATE):**\n"
        for f in m_files:
            status_msg += f"- {f['name']} ({len(f.get('tables', []))} tables)\n"
    else:
        status_msg += "\n📊 No spreadsheets loaded.\n"

    await update.message.reply_text(status_msg, parse_mode=constants.ParseMode.MARKDOWN)

async def start_bot(token: str, allowed_chat_ids: List[int], model: str = "gemma4:e4b", lang: str = "en"):
    global _application, _bot_token, _allowed_chat_ids, _model_name, _bot_lang

    if not token: raise ValueError("Missing Token")
    
    _bot_token = token
    _allowed_chat_ids = allowed_chat_ids
    _model_name = model
    _bot_lang = lang

    try:
        _application = ApplicationBuilder().token(_bot_token).build()
        
        # Set Menu Commands
        commands = [
            BotCommand("start", "Welcome and introduction"),
            BotCommand("clear", "Reset session and delete files"),
            BotCommand("status", "Check active files in memory"),
            BotCommand("anon", "Anonymize a file (xlsx/csv/pdf/docx/txt)"),
            BotCommand("deanon", "De-anonymize a file using the local PII vault"),
            BotCommand("help", "Show help and capabilities")
        ]
        await _application.bot.set_my_commands(commands)

        # Handlers
        _application.add_handler(CommandHandler("start", handle_start))
        _application.add_handler(CommandHandler("help", handle_help))
        _application.add_handler(CommandHandler("clear", handle_clear))
        _application.add_handler(CommandHandler("status", handle_status))
        _application.add_handler(CommandHandler("anon", handle_anon))
        _application.add_handler(CommandHandler("deanon", handle_deanon))
        
        _application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
        _application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
        _application.add_handler(MessageHandler(filters.Document.ALL, handle_document))

        logger.info(f"🚀 Starting Telegram bot (Lang: {lang})...")
        await _application.initialize()
        await _application.start()
        await _application.updater.start_polling()
        logger.info("✅ Telegram bot is polling")
        
    except Exception as e:
        logger.error(f"CRITICAL TELEGRAM ERROR: {str(e)}")
        raise e

async def stop_bot():
    global _application
    if _application:
        if _application.updater:
            await _application.updater.stop()
        await _application.stop()
        await _application.shutdown()
        _application = None
        logger.info("Telegram bot stopped")

def is_running() -> bool:
    return _application is not None
