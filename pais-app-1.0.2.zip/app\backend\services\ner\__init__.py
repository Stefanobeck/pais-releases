"""
NER Engine package — pluggable backends per riconoscimento PII.

Architettura:
- `base.NerEngine` definisce l'interfaccia astratta.
- `onnx_engine.OnnxPiiNerEngine` implementazione default (multilang-pii-ner-ONNX, MIT).
- `presidio_recognizer.PiiNerRecognizer` adatta NerEngine a Presidio EntityRecognizer.
- `factory.get_ner_engine()` entry-point unico.
"""
from .base import NerEngine, NerSpan
from .factory import get_ner_engine
from .presidio_recognizer import PiiNerRecognizer

__all__ = ["NerEngine", "NerSpan", "get_ner_engine", "PiiNerRecognizer"]
