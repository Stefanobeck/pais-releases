"""
Anonimyze Router - API Endpoints for ANONIMYZE Module
"""
import os
import shutil
import time
import uuid
import logging
import json
from typing import List, Dict, Optional
from pathlib import Path
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from backend_config.settings import BASE_DIR
from backend_config.project_manager import project_manager
from backend_config.auth_pro import require_pro_or_trial
from services.anonimyze_service import anonimyze_service, SUPPORTED_LANGUAGES, SUPPORTED_COUNTRIES, ANONYMIZE_SUPPORTED_EXT

logger = logging.getLogger(__name__)
# Gate PRO-only: tutti gli endpoint ANONIMYZE richiedono pro/free_trial.
router = APIRouter(dependencies=[Depends(require_pro_or_trial)])

class ProcessRequest(BaseModel):
    session_id: str
    filename: str
    mode: str = "anonymize"
    cloud_ready: bool = True
    selected_columns: Optional[List[str]] = None
    locale_hint: Optional[str] = None  # "auto", "it", "en", "fr", "de" — override lingua NER
    country: Optional[str] = None  # "auto", "IT", "DE", "FR", "UK", "US", "NEUTRAL" — override jurisdiction

class ClearRequest(BaseModel):
    session_id: str

@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None),
    mode: str = Form("anonymize"),
    lang: str = Form("it")
):
    """Upload file for anonymization staging."""
    try:
        # Reject unsupported extensions BEFORE writing to disk.
        # Anonimyze processa solo testo strutturato/non-strutturato; un .flac/.mp3/.zip/.exe
        # passava attraverso il pipeline e veniva copiato nel folder Anonymized senza
        # alcuna anonimizzazione → confusione per l'utente + spazio sprecato.
        ext = ("." + file.filename.rsplit(".", 1)[-1].lower()) if "." in file.filename else ""
        if ext not in ANONYMIZE_SUPPORTED_EXT:
            allowed = ", ".join(s.lstrip(".") for s in ANONYMIZE_SUPPORTED_EXT)
            raise HTTPException(
                status_code=415,
                detail=f"UNSUPPORTED_EXTENSION:{ext or 'no-ext'}|allowed={allowed}",
            )

        session_id = session_id or str(uuid.uuid4())
        anonimyze_service.set_language(lang)

        # Create project-specific upload dir
        upload_dir = project_manager.get_path("uploads") / "anonimyze"
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_path = upload_dir / file.filename
        content = await file.read()
        with open(file_path, "wb") as buffer:
            buffer.write(content)
            
        result = await anonimyze_service.upload_file(
            file_path=str(file_path),
            filename=file.filename,
            session_id=session_id,
            mode=mode
        )
        
        return {
            "filename": file.filename,
            "session_id": session_id,
            "status": result["status"],
            "message": result["message"]
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Anonimyze upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/process")
async def process_file(request: ProcessRequest):
    """Process a staged file with streaming progress."""
    try:
        # Override lingua NER se specificata
        if request.locale_hint and request.locale_hint != "auto" and request.locale_hint in SUPPORTED_LANGUAGES:
            anonimyze_service.lang = request.locale_hint
            logger.info(f"🌐 Locale override: {request.locale_hint.upper()}")

        # Override country (jurisdiction) se specificata
        if request.country and request.country.lower() != "auto":
            anonimyze_service.set_country(request.country)
            logger.info(f"🏳️  Country override: {request.country.upper()}")
        else:
            anonimyze_service.set_country(None)  # auto-detect

        async def generate():
            async for chunk in anonimyze_service.process_file_stream(
                session_id=request.session_id,
                filename=request.filename,
                mode=request.mode,
                cloud_ready=request.cloud_ready,
                selected_columns=request.selected_columns
            ):
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no"
            }
        )
    except Exception as e:
        logger.error(f"Anonimyze process error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/files")
async def get_files(session_id: str = Query(...)):
    """Get staged and processed files."""
    return anonimyze_service.get_files(session_id)

@router.get("/columns")
async def get_columns(filename: str = Query(...)):
    """Get columns for tabular files."""
    try:
        cols = anonimyze_service.get_columns(filename)
        return {"columns": cols}
    except Exception as e:
        logger.error(f"Anonimyze get columns error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/clear")
async def clear_session(request: ClearRequest):
    """Clear session files."""
    anonimyze_service.clear_session(request.session_id)
    return {"status": "success", "message": "Sessione pulita."}


# ─── Interactive review workflow (Analyze → Review → Apply) ────────────────
# Mirrors the PDF Toolkit "PECETTE" pattern. The user uploads a PDF/DOCX/TXT/MD,
# we run analyze() and return the detected entities WITHOUT touching the file.
# The frontend shows a checkbox review; on Apply the backend applies only the
# selected entities and persists the vault mapping for later deanonymization.

ANON_JOB_TIMEOUT_SECONDS = 3600  # 1h


def _anon_jobs_dir() -> Path:
    p = project_manager.get_path("temp") / "anonimyze_jobs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _cleanup_stale_anon_jobs() -> None:
    """Remove orphan job directories older than the timeout."""
    try:
        d = _anon_jobs_dir()
        cutoff = time.time() - ANON_JOB_TIMEOUT_SECONDS
        for p in d.iterdir():
            try:
                if p.stat().st_mtime < cutoff:
                    if p.is_dir():
                        shutil.rmtree(p, ignore_errors=True)
                    else:
                        p.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


@router.post("/analyze")
async def anonimyze_analyze(
    file: UploadFile = File(...),
    locale_hint: Optional[str] = Form(None),
    country: Optional[str] = Form(None),
):
    """Step 1 of the review workflow: detect PII entities in a PDF/DOCX/TXT/MD
    file and return them grouped for human review. NO substitution is applied;
    the file and the analysis are cached server-side under a job_id that the
    client passes back to /apply.

    Returns: { job_id, file_kind, detected_lang, detected_country, entities }.
    """
    try:
        # Validate extension against the review-capable set (PDF/DOCX/TXT/MD).
        # Excel/CSV files still use the existing /process endpoint with the
        # legacy Manual columns workflow.
        ext = ("." + file.filename.rsplit(".", 1)[-1].lower()) if "." in file.filename else ""
        allowed_exts = anonimyze_service.SUPPORTED_TEXT_REVIEW_EXT
        if ext not in allowed_exts:
            allowed = ", ".join(sorted(s.lstrip(".") for s in allowed_exts))
            raise HTTPException(
                status_code=415,
                detail=f"UNSUPPORTED_EXTENSION:{ext or 'no-ext'}|allowed={allowed}",
            )

        _cleanup_stale_anon_jobs()
        job_id = uuid.uuid4().hex[:16]
        job_dir = _anon_jobs_dir() / job_id
        job_dir.mkdir(parents=True, exist_ok=True)

        input_path = job_dir / file.filename
        content = await file.read()
        with open(input_path, "wb") as buf:
            buf.write(content)

        result = await anonimyze_service.analyze_text_file(
            input_path=input_path,
            country=country,
            locale=locale_hint,
        )

        # Persist the full analysis (text + grouped entities with their raw
        # spans) so /apply can rebuild substitutions accurately.
        with open(job_dir / "analysis.json", "w", encoding="utf-8") as f:
            json.dump({
                "original_filename": file.filename,
                "file_kind": result["file_kind"],
                "detected_lang": result["detected_lang"],
                "detected_country": result["detected_country"],
                "text": result["text"],
                "entities": result["entities"],
            }, f, ensure_ascii=False)

        # Return a slimmed-down entity list to the UI (no _raw_spans, those
        # stay server-side).
        return {
            "success": True,
            "job_id": job_id,
            "file_kind": result["file_kind"],
            "detected_lang": result["detected_lang"],
            "detected_country": result["detected_country"],
            "entities": [
                {
                    "id": e["id"],
                    "type": e["type"],
                    "text": e["text"],
                    "occurrences_count": e["occurrences_count"],
                    "sample_context": e["sample_context"],
                    "sample_pre": e.get("sample_pre", ""),
                    "sample_match": e.get("sample_match", e["text"]),
                    "sample_post": e.get("sample_post", ""),
                    "max_score": e.get("max_score", 0.0),
                }
                for e in result["entities"]
            ],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Anonimyze analyze error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


class AnonimyzeApplyRequest(BaseModel):
    job_id: str
    selected_entity_ids: List[str]
    sanitize: bool = False


@router.post("/apply")
async def anonimyze_apply(req: AnonimyzeApplyRequest):
    """Step 2 of the review workflow: apply substitutions only on the entities
    selected by the user during review. The output file is saved in
    `output/Anonymized/` and the vault mapping is persisted (so the user can
    deanonymize the file later). The job cache is cleaned up afterwards.

    Returns: { filename, applied_count }.
    """
    try:
        job_dir = _anon_jobs_dir() / req.job_id
        analysis_path = job_dir / "analysis.json"
        if not analysis_path.exists():
            raise HTTPException(status_code=404, detail="Job not found or expired. Re-run Analyze.")

        with open(analysis_path, "r", encoding="utf-8") as f:
            cached = json.load(f)

        input_path = job_dir / cached["original_filename"]
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Input file missing. Re-run Analyze.")

        output_dir = project_manager.get_path("output") / "Anonymized"
        result = await anonimyze_service.apply_text_anonymization_filtered(
            input_path=input_path,
            output_dir=output_dir,
            original_text=cached["text"],
            entities=cached["entities"],
            selected_ids=req.selected_entity_ids,
            file_kind=cached["file_kind"],
            detected_lang=cached.get("detected_lang", "it"),
            sanitize=req.sanitize,
        )

        # Cleanup the job directory now that we're done.
        try:
            shutil.rmtree(job_dir, ignore_errors=True)
        except Exception:
            pass

        return {"success": True, **result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Anonimyze apply error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
