"""Targeted test for the suggestions revision: generate suggestions for the
3 areas problematic in the nightly stress test (Technical Easy / Operations
Easy / Finance Easy) and check that the new EXECUTABILITY RULES are obeyed.

Outputs both the raw suggestions and a verdict on each banned pattern.
"""
from __future__ import annotations
import asyncio, json, re, sys, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))
if hasattr(sys.stdout, "reconfigure"):
    try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore
    except Exception: pass


# Patterns we DON'T want to see in the new suggestions
BANNED_PATTERNS = {
    "duplicate_check": re.compile(r"\b(duplicat[oi]|duplicate)\b", re.I),
    "null_check":      re.compile(r"\b(null|valori mancanti|missing)\b", re.I),
    "validity_check":  re.compile(r"\b(verifica\s+(?:che|i\s+valori|la\s+validit))|valid(?:ity)?\s+check\b", re.I),
    "stock_assumption":re.compile(r"\b(stock\s*minim|sotto\s+(?:il\s+)?minimo|inventory\s+below|min[._]?threshold|scort[ea])\b", re.I),
    "what_if":         re.compile(r"\b(simul|what-?if|predict[ie]?|forecast)\b", re.I),
    "mom_yoy":         re.compile(r"\b(MoM|YoY|CAGR|crescita\s+(?:mensile|annual))\b", re.I),
}


async def run():
    from services.manipulate_service import ManipulateService

    test_file = Path(__file__).resolve().parents[3] / "stress_test_input.xlsx"
    if not test_file.exists():
        print(f"!! input not found: {test_file}", flush=True)
        return 1

    manipulate = ManipulateService()
    session_id = f"suggtest-{uuid.uuid4().hex[:8]}"
    fname = test_file.name

    print(f"file:    {test_file.name}", flush=True)
    print(f"model:   {manipulate.models.get('engineering_model','?')} (drives suggestions)", flush=True)
    print(f"session: {session_id}", flush=True)
    print()

    up = await manipulate.upload_file(str(test_file), fname, session_id, mode="Export to Sheet")
    if up.get("status") not in ("staged", "success"):
        print(f"upload failed: {up}"); return 2
    mem = await manipulate.memorize_files(session_id, mode="Export to Sheet")
    if mem.get("status") != "success":
        print(f"memorize failed: {mem}"); return 2

    targets = [
        ("Technical & R&D",      "Easy", "expect: COUNT DISTINCT / distributions, no duplicate/null checks"),
        ("Operations & Logistics","Easy", "expect: totals/rankings/Date-intervals, no Stock assumption"),
        ("Finance & Accounting", "Easy", "expect: totals by Centro_Costo/Voce, no MoM/YoY unless Date"),
    ]

    results = []
    for area, level, expectation in targets:
        print(f"=" * 90, flush=True)
        print(f"AREA: {area}  LEVEL: {level}", flush=True)
        print(f"      {expectation}", flush=True)
        print(flush=True)
        try:
            suggs = await manipulate.get_smart_suggestions(
                session_id=session_id, mode="Export to Sheet",
                level=level, area=area, lang="it",
            )
        except Exception as e:
            print(f"  ERROR: {e}", flush=True)
            continue
        for i, s in enumerate(suggs, 1):
            print(f"  [{i}] {s}", flush=True)
        print(flush=True)
        # Verdict per pattern bannato
        violations = []
        for s in suggs:
            for name, pat in BANNED_PATTERNS.items():
                if pat.search(s):
                    violations.append((name, s[:120]))
        if violations:
            print(f"  ❌ VIOLATIONS detected ({len(violations)}):", flush=True)
            for v in violations:
                print(f"      {v[0]}: {v[1]}", flush=True)
        else:
            print(f"  ✅ Clean — no banned patterns detected", flush=True)
        results.append({
            "area": area, "level": level,
            "suggestions": suggs,
            "violations": violations,
        })

    try: manipulate.clear_session(session_id)
    except Exception: pass

    out_path = Path("test_runs/suggestions_test/result.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"saved: {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(run()))
