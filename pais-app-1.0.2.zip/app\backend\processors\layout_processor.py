import cv2
import numpy as np
import onnxruntime as ort
import logging
import requests
import os
from pathlib import Path
from typing import List, Dict

logger = logging.getLogger(__name__)

class LayoutProcessor:
    def __init__(self):
        from backend_config.settings import settings
        # Usa il percorso assoluto dalla configurazione dell'app
        self.model_dir = Path(settings.BASE_DIR) / "models" / "layout"
        self.model_path = self.model_dir / "pp_doc_layout_v3.onnx"
        
        # Download automatico se manca
        if not self.model_path.exists():
            self._download_model()
            
        if not self.model_path.exists():
            logger.warning("Layout model unavailable, falling back to Full Page mode.")
            self.session = None
        else:
            try:
                self.session = ort.InferenceSession(str(self.model_path))
            except Exception as e:
                logger.error(f"Layout model load error: {e}")
                self.session = None

    def _download_model(self):
        logger.info(f"Layout: model missing at {self.model_path}. Starting download...")
        try:
            self.model_dir.mkdir(parents=True, exist_ok=True)
            url = "https://huggingface.co/alex-dinh/PP-DocLayoutV3-ONNX/resolve/main/PP-DocLayoutV3.onnx"
            logger.info(f"Layout: Fetching {url}")
            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(self.model_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
            
            if self.model_path.exists() and self.model_path.stat().st_size > 0:
                logger.info(f"Layout: Download complete! Size: {self.model_path.stat().st_size} bytes")
            else:
                logger.error("Layout: Downloaded file is empty or missing.")

        except Exception as e:
            logger.error(f"Layout: Critical error during download: {str(e)}")
            if self.model_path.exists():
                os.remove(self.model_path)
            raise e

    def _preprocess(self, img, target_size=(800, 800)):
        """Prepara l'immagine per il modello ONNX (800x800, normalizzata)"""
        h, w = img.shape[:2]
        # Resize non-proporzionale come richiesto dal modello
        resized_img = cv2.resize(img, target_size, interpolation=cv2.INTER_LINEAR)
        
        # BGR to RGB
        rgb_img = cv2.cvtColor(resized_img, cv2.COLOR_BGR2RGB)
        
        # Normalizzazione (ImageNet)
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        
        input_data = (rgb_img.astype(np.float32) / 255.0 - mean) / std
        
        # HWC to CHW
        input_data = input_data.transpose(2, 0, 1)
        # Add batch dimension
        input_data = np.expand_dims(input_data, axis=0)
        
        scale_h = h / target_size[0]
        scale_w = w / target_size[1]
        
        return input_data, scale_h, scale_w

    def segment_layout(self, image_path: str) -> List[Dict]:
        """
        Analizza il layout dell'immagine e restituisce una lista di regioni.
        Ogni regione ha: 'label' (text/table/figure), 'bbox' (x1, y1, x2, y2).
        """
        if not self.session:
            # Caricamento immagine per ottenere le dimensioni per il dummy fallback
            img = cv2.imread(image_path)
            if img is None: return []
            return [{"label": "text", "bbox": [0, 0, img.shape[1], img.shape[0]]}]

        img = cv2.imread(image_path)
        if img is None: return []
        
        try:
            input_data, scale_h, scale_w = self._preprocess(img)
            
            # Input del modello DocLayoutV3
            # In0: target_size (es. [800, 800])
            # In1: image (1, 3, 800, 800)
            # In2: scale_factors (1, 2)
            input_names = [i.name for i in self.session.get_inputs()]
            
            # Nota: Alcune versioni di PP-DocLayoutV3 ONNX potrebbero avere nomi input diversi.
            # Qui usiamo la struttura standard di alex-dinh
            onnx_inputs = {
                input_names[0]: np.array([[800, 800]], dtype=np.float32),
                input_names[1]: input_data,
                input_names[2]: np.array([[1/scale_h, 1/scale_w]], dtype=np.float32) # Scala inversa per riportare i box alle dimensioni originali
            }
            
            outputs = self.session.run(None, onnx_inputs)
            predictions = outputs[0] # [N, 7] -> [cls, conf, x1, y1, x2, y2, read_order]
            
            # Mappa classi PP-DocLayoutV3 semantica
            # 0: doc_title, 1: paragraph_title, 4: text, 13: image, 23: table
            label_map = {
                0: "title", 1: "heading", 2: "text", 3: "text", 
                4: "text", 5: "text", 6: "text", 7: "text", 
                8: "text", 9: "text", 10: "text", 11: "text", 
                12: "text", 13: "figure", 14: "figure", 15: "heading", 
                16: "figure", 17: "figure", 18: "figure", 19: "equation", 
                20: "equation", 21: "text", 22: "text", 23: "table", 24: "text"
            }
            
            results = []
            # Filtro confidenza e ordinamento per read_order (indice 6)
            mask = predictions[:, 1] > 0.4
            valid_preds = predictions[mask]
            
            # Ordina per read_order
            sorted_preds = valid_preds[valid_preds[:, 6].argsort()]
            
            for pred in sorted_preds:
                cls_id = int(pred[0])
                # Se l'ID è ignoto, usiamo "text" come fallback invece di scartare
                label = label_map.get(cls_id, "text")
                
                # Coordinate già scalate dal modello grazie all'input scale_factors
                # ma verifichiamo i limiti dell'immagine originale
                x1, y1, x2, y2 = pred[2:6]
                
                # Clipping per sicurezza
                x1 = max(0, int(x1))
                y1 = max(0, int(y1))
                x2 = min(img.shape[1], int(x2))
                y2 = min(img.shape[0], int(y2))
                
                results.append({
                    "label": label,
                    "bbox": [x1, y1, x2, y2]
                })
            
            if not results:
                return [{"label": "text", "bbox": [0, 0, img.shape[1], img.shape[0]]}]
                
            return results

        except Exception as e:
            logger.error(f"Errore durante l'inferenza layout: {e}")
            return [{"label": "text", "bbox": [0, 0, img.shape[1], img.shape[0]]}]
