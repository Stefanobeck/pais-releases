"""
Vision Module - Chat API Routes per PAI Premium
Supporta:
- Upload immagini e video
- Chat streaming con RAG visivo
- Thumbnail per video
- Background analysis per video
"""
import os
import uuid
import asyncio
import base64
import datetime
from typing import List, Optional, Dict
from fastapi import APIRouter, UploadFile, File, HTTPException, WebSocket, Form, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from pathlib import Path
import json
import logging

from backend_config.settings import BASE_DIR
from backend_config.project_manager import project_manager
from services.vision_service import VisionService

logger = logging.getLogger(__name__)

router = APIRouter()

# Service instance (initialized lazily per project)
_vision_service = None


def get_vision_service():
    """Ottieni VisionService con path ChromaDB per progetto."""
    global _vision_service
    chroma_path = str(project_manager.get_path("db")) if project_manager.active_project_path else str(BASE_DIR / "chroma_db")
    if _vision_service is None or _vision_service._chroma_path != chroma_path:
        _vision_service = VisionService(persist_directory=chroma_path)
        _vision_service._chroma_path = chroma_path
    return _vision_service


# Request/Response Models
class VisionUploadResponse(BaseModel):
    """File upload response model."""
    filename: str
    status: str
    message: str
    ref: Optional[str] = None
    thumbnail: Optional[str] = None
    session_id: str
    analysis_complete: bool = False


class StreamChatRequest(BaseModel):
    """Stream chat request model."""
    message: str
    session_id: Optional[str] = None
    use_rag: bool = True
    lang: str = "it"


class ChatResponse(BaseModel):
    """Chat response model."""
    response: str
    session_id: str
    model: str


class FileListResponse(BaseModel):
    """File list response model."""
    files: List[Dict]
    session_id: str


# API Routes
@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...), 
    session_id: Optional[str] = Form(None),
    lang: str = Form("it")
):
    """
    Upload immagine o video per analisi.
    """
    try:
        session_id = session_id or str(uuid.uuid4())
        
        # Aggiorna lingua
        get_vision_service().set_language(lang)

        logger.info(f"📥 Vision Upload: filename={file.filename}, session_id={session_id}")

        # Salva file
        upload_dir = project_manager.get_path("uploads") / "vision" if project_manager.active_project_path else BASE_DIR / "uploads" / "vision"
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_path = upload_dir / file.filename
        content = await file.read()
        with open(file_path, "wb") as buffer:
            buffer.write(content)

        # Determina tipo file
        ext = Path(file.filename).suffix.lower()
        image_exts = {'.jpg', '.jpeg', '.png', '.webp'}

        if ext in image_exts:
            # Immagine: analisi immediata
            result = await get_vision_service().upload_image(
                file_path=str(file_path),
                filename=file.filename,
                session_id=session_id
            )
            
            return VisionUploadResponse(
                filename=file.filename,
                status=result['status'],
                message=result.get('message', ''),
                ref=result.get('ref'),
                thumbnail=result.get('thumbnail'),
                session_id=session_id,
                analysis_complete=True
            )
            
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Formato non supportato: {ext}. Usa solo immagini (JPG, PNG, WEBP)."
            )
            
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat/stream")
async def send_chat_message_stream(request: StreamChatRequest, fastapi_request: Request):
    """
    Send a message to the AI and get a streaming response.
    Returns SSE (Server-Sent Events) stream.

    Cooperative cancellation: se il client (browser/webview) chiude la fetch
    via AbortController, un task in background rileva il disconnect e setta
    `stop_state['cancelled'] = True`. Il vision_service e l'OllamaClient
    fermano lo stream entro 1 chunk.
    """
    session_id = request.session_id or str(uuid.uuid4())
    logger.info(f"💬 Vision stream request: session_id={session_id}, message={request.message[:50]}...")

    # Aggiorna lingua
    get_vision_service().set_language(request.lang)

    # Stop state condiviso: il polling task lo aggiorna, il sync stop_check
    # callback (che Ollama invoca tra un chunk e l'altro) lo legge.
    stop_state = {"cancelled": False}

    async def _watch_disconnect():
        """Task in background che fa polling sulla connessione del client.
        Quando il client chiude (AbortController, chiusura tab, crash), Ollama
        deve fermarsi al prossimo chunk."""
        try:
            while not stop_state["cancelled"]:
                if await fastapi_request.is_disconnected():
                    stop_state["cancelled"] = True
                    logger.info(f"Vision stream: client disconnected, stop signal set (session {session_id})")
                    break
                await asyncio.sleep(0.2)
        except asyncio.CancelledError:
            pass

    def stop_check() -> bool:
        return stop_state["cancelled"]

    async def generate():
        """Generator per SSE stream."""
        watch_task = asyncio.create_task(_watch_disconnect())
        try:
            async for chunk in get_vision_service().send_message(
                message=request.message,
                session_id=session_id,
                use_rag=request.use_rag,
                stop_check_callback=stop_check,
            ):
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"

            yield f"data: {json.dumps({'done': True, 'session_id': session_id})}\n\n"

        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        finally:
            stop_state["cancelled"] = True
            watch_task.cancel()
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


@router.post("/chat", response_model=ChatResponse)
async def send_chat_message(request: StreamChatRequest):
    """
    Send a message and get complete response (non-streaming).
    """
    session_id = request.session_id or str(uuid.uuid4())
    
    try:
        full_response = ""
        async for chunk in get_vision_service().send_message(
            message=request.message,
            session_id=session_id,
            use_rag=request.use_rag
        ):
            full_response += chunk
        
        return ChatResponse(
            response=full_response,
            session_id=session_id,
            model='qwen3-vl:4b'
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/files", response_model=FileListResponse)
async def get_uploaded_files(session_id: str):
    """
    Get list of uploaded files for a session.
    """
    files = get_vision_service().get_uploaded_files(session_id)
    return FileListResponse(
        files=files,
        session_id=session_id
    )


@router.delete("/upload/{filename}")
async def remove_document(filename: str, session_id: str):
    """
    Remove a document from the session.
    """
    try:
        get_vision_service().remove_file(filename, session_id)
        return {"status": "success", "message": f"File {filename} removed"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class HistoryResponse(BaseModel):
    history: List[Dict]
    session_id: str

@router.get("/history/{session_id}", response_model=HistoryResponse)
async def get_history(session_id: str):
    """Ottieni storia conversazione."""
    history = get_vision_service().sessions.get(session_id, [])
    return HistoryResponse(
        history=history,
        session_id=session_id
    )

@router.delete("/history/{session_id}")
async def clear_chat_history(session_id: str):
    """
    Clear chat history for a session.
    """
    try:
        get_vision_service().clear_session(session_id)
        return {"status": "success", "message": "History cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/settings")
async def get_settings():
    """Restituisce il modello vision attivo."""
    from backend_config import settings as app_settings
    return {
        "model": app_settings.VISION_MODEL,
        "model_type": "Vision",
        "video_model": app_settings.VIDEO_MODEL,
        "ctx": app_settings.VISION_CTX
    }


@router.get("/models_catalog")
async def get_models_catalog():
    """Catalog dei modelli per VISION: canonical da profiles.json
    (gemma4:e4b mandatory condiviso con INTERROGATE, qwen3-vl:4b opzionale)
    + custom utente. Single source of truth per il picker frontend.
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import get_vision_catalog
        return await get_vision_catalog(system_service)
    except Exception as e:
        logger.error(f"vision models_catalog failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class VisionCustomModelRequest(BaseModel):
    model_id: str


@router.post("/custom_model")
async def add_custom_model(req: VisionCustomModelRequest):
    """Add a user-installed Ollama model to the Vision picker.
    Must already be installed via /api/system/install (only registers it).
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import add_module_custom_model
        return await add_module_custom_model(system_service, "vision", req.model_id)
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"vision add_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/custom_model/{model_id:path}")
async def remove_custom_model(model_id: str):
    """Remove a custom model from the Vision picker. Does NOT uninstall the
    model from Ollama (use DELETE /api/system/model for that).
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import remove_module_custom_model
        return await remove_module_custom_model(system_service, "vision", model_id)
    except LookupError as le:
        raise HTTPException(status_code=404, detail=str(le))
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"vision remove_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/installed-models")
async def get_vision_installed_models():
    """Lista DIRETTAMENTE da Ollama tutti i modelli installati.

    Diverso da `/api/system/status` che filtra solo modelli dichiarati nelle
    liste `required_ollama_models` + `optional_ollama_models` del system_service:
    se l'utente fa `ollama pull <qualunque-modello>` manualmente fuori dal
    catalog, quel modello non appare in /system/status. Questo endpoint torna
    TUTTO quello che Ollama ha sul disco — coerente con la marketplace policy
    "l'utente sceglie cosa usare, l'app non filtra".
    """
    try:
        from services.system_service import system_service
        client = system_service.get_ollama_client()
        info = await client.list()
        installed_ids = []
        if hasattr(info, 'models'):
            for m in info.models:
                installed_ids.append(getattr(m, 'model', getattr(m, 'name', '')))
        elif isinstance(info, dict) and 'models' in info:
            for m in info['models']:
                if isinstance(m, dict):
                    installed_ids.append(m.get('name') or m.get('model', ''))
                else:
                    installed_ids.append(getattr(m, 'model', getattr(m, 'name', '')))

        installed_clean = [mid for mid in installed_ids if mid]
        return {"status": "success", "models": sorted(set(installed_clean))}
    except Exception as e:
        logger.error(f"Failed to list installed models from Ollama: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/settings/model")
async def set_vision_model(model: str):
    """Switcha il modello vision attivo a runtime.

    Marketplace policy: l'utente può selezionare QUALUNQUE modello Ollama
    installato — anche al di fuori delle famiglie vision canoniche (qwen3-vl,
    gemma4, medgemma, llava, minicpm, llama-vision...). Se il modello non
    supporta l'analisi immagini, Ollama restituirà un errore al primo prompt
    e l'utente capirà che ha scelto la famiglia sbagliata. La UI mostra già
    il "family hint" come avviso preventivo nel catalog e nel picker.
    Logghiamo le scelte fuori dalle famiglie note come INFO per debug.
    """
    known_vision_prefixes = ('qwen3-vl', 'gemma4', 'medgemma', 'llava', 'minicpm', 'llama3.2-vision')
    if not any(model.lower().startswith(p) for p in known_vision_prefixes):
        logger.info(
            f"🎨 Vision model set to '{model}' (outside known vision families "
            f"{known_vision_prefixes}); inference may fail if non-multimodal."
        )
    from backend_config.settings import settings
    settings.VISION_MODEL = model
    logger.info(f"🎨 Vision model switched to: {model}")
    return {"status": "success", "model": model}


@router.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """
    WebSocket endpoint for real-time bidirectional chat.
    """
    await websocket.accept()
    
    try:
        while True:
            data = await websocket.receive_text()
            
            try:
                request = json.loads(data)
                message = request.get('message', '')
                use_rag = request.get('use_rag', True)
            except:
                message = data
                use_rag = True
            
            async for chunk in get_vision_service().send_message(
                message=message,
                session_id=session_id,
                use_rag=use_rag
            ):
                await websocket.send_text(chunk)
            
            await websocket.send_json({"type": "end", "session_id": session_id})

    except Exception as e:
        logger.error(f"WebSocket error: {e}")


@router.post("/send-to-interrogate")
async def send_vision_message_to_interrogate(
    content: str = Form(...),
    source_hint: str = Form("Vision_Reply"),
    lang: str = Form("it"),
):
    """Salva il contenuto di un messaggio AI di Vision come .txt e lo
    indicizza in INTERROGATE come file `is_generated=True` (così appare
    con icona occhio per l'ispezione).

    Pattern simile a `/api/utility/send-to-interrogate` ma riceve testo
    diretto invece di un file su disco. Caso d'uso: ho fatto analizzare
    una foto a Vision e voglio trasformare la sua risposta in un
    documento ricercabile/citabile in Interrogate.
    """
    if not content or not content.strip():
        raise HTTPException(status_code=400, detail="Empty content")
    try:
        from backend_config.project_manager import project_manager
        from services.chat_service import ChatService

        # Strip thinking tags se presenti — non serve nell'archivio Interrogate
        import re as _re
        clean = _re.sub(r'<think>[\s\S]*?</think>', '', content).strip()
        if not clean:
            raise HTTPException(status_code=400, detail="Content empty after stripping thinking tags")

        # Sanitize source_hint per filename (Windows-safe + max 40 char)
        safe_hint = _re.sub(r'[^\w\-]', '_', source_hint)[:40].strip('_') or "Vision_Reply"
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        txt_filename = f"{safe_hint}_{ts}.txt"

        # Scrivi nel solito uploads/interrogate/ (stessa cartella usata da
        # auto_ocr_pdf e dall'upload regular di Interrogate, così view/open
        # endpoint trovano il file senza aggiunte di path).
        uploads_dir = project_manager.get_path("uploads") / "interrogate"
        uploads_dir.mkdir(parents=True, exist_ok=True)
        txt_path = uploads_dir / txt_filename
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(clean)

        # Registra in INTERROGATE con is_generated=True → appare con icona occhio
        from routers.interrogate import get_chat_service as _get_chat_service
        # Usa la session_id del progetto attivo (short_id) — stesso meccanismo
        # del pulsante /utility/send-to-interrogate.
        session_id = project_manager.get_short_id()
        if not session_id:
            raise HTTPException(status_code=400, detail="Nessun progetto attivo trovato")

        _get_chat_service().set_language(lang)
        result = await _get_chat_service().upload_file(
            file_path=str(txt_path),
            filename=txt_filename,
            session_id=session_id,
            is_generated=True,
        )
        if result.get('status') != 'success':
            raise Exception(f"Errore indicizzazione RAG: {result.get('message')}")

        logger.info(f"✅ Vision reply indexed in INTERROGATE: {txt_filename} (session {session_id})")
        return {
            "success": True,
            "message": f"Risposta inviata a INTERROGATE come '{txt_filename}'",
            "filename": txt_filename,
            "session_id": session_id,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"send_vision_message_to_interrogate error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/prompt-library")
async def get_vision_prompt_library(lang: str = "it"):
    """Prompt Library per VISION, categorizzata per area di analisi visiva.

    Carica prompts_library_vision_<lang>.json. Fallback IT se la lingua
    richiesta non esiste. Pattern identico a /api/interrogate/prompt-library
    ma con un set di prompt dedicato a foto/video (descrizione, OCR,
    persone/volti, oggetti/brand, marketing, analisi tecnica, video,
    confronto multipla).
    """
    try:
        config_dir = Path(__file__).parent.parent / "backend_config"
        lib_path = config_dir / f"prompts_library_vision_{lang}.json"

        if not lib_path.exists():
            lib_path = config_dir / "prompts_library_vision_it.json"

        with open(lib_path, 'r', encoding='utf-8') as f:
            library = json.load(f)

        return {
            "status": "success",
            "library": library,
            "lang": lang,
        }
    except Exception as e:
        logger.error(f"Vision prompt library error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
