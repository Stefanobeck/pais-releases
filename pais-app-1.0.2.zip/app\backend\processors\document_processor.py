"""
Document Processor - RAG Pipeline per PAI Premium
Gestisce ingestione, chunking e retrieval di documenti per il modulo INTERROGATE.
"""
import os
import time
import json
import re
import zipfile
# Hardenizzato contro XXE / billion-laughs: defusedxml espone le stesse API
# (parse, fromstring, iterparse) ma rifiuta entità esterne ed entità nidificate.
# tostring (serializzazione di un tree già costruito in memoria) è benigno e
# resta dallo stdlib, perché defusedxml non lo riesporta.
import defusedxml.ElementTree as ET
from xml.etree.ElementTree import tostring as _safe_tostring  # noqa: E402
ET.tostring = _safe_tostring
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import logging
import asyncio

import pypdf
import markdown2
import chromadb
from chromadb.config import Settings
import ollama
from ollama import AsyncClient
from rank_bm25 import BM25L
import nltk
from nltk.tokenize import word_tokenize

# Download NLTK tokenizer (only once)
try:
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    nltk.download('punkt_tab', quiet=True)

logger = logging.getLogger(__name__)


class BM25Manager:
    """Gestisce l'indice BM25 per keyword search."""

    def __init__(self):
        # Indice BM25: source -> (BM25L instance, tokenized corpus, documents list)
        self.indices: Dict[str, tuple] = {}
        # Master list per query cross-document
        self._master_corpus: List[List[str]] = []  # Tokenized
        self._master_docs: List[str] = []  # Original text
        self._master_metadata: List[Dict] = []
        self._bm25: Optional[BM25L] = None
        self._doc_to_source: Dict[int, str] = {}  # index -> source mapping

    def add_documents(self, source: str, documents: List[str], metadatas: List[Dict]):
        """Aggiunge documenti all'indice BM25 per una sorgente."""
        tokenized = [self._tokenize(doc) for doc in documents]

        if source in self.indices:
            old_bm25, old_corpus, old_docs = self.indices[source]
            # Merge existing with new
            merged_corpus = old_corpus + tokenized
            merged_docs = old_docs + documents
            merged_meta = self._get_metadata_for_source(source) + metadatas
            new_bm25 = BM25L(merged_corpus)
            self.indices[source] = (new_bm25, merged_corpus, merged_docs)
            self._update_metadata(source, merged_meta)
        else:
            bm25 = BM25L(tokenized)
            self.indices[source] = (bm25, tokenized, documents)
            self._store_metadata(source, metadatas)

        # Rebuild master index
        self._rebuild_master()

    def _tokenize(self, text: str) -> List[str]:
        """Tokenizza testo per BM25."""
        return word_tokenize(text.lower())

    def _store_metadata(self, source: str, metadatas: List[Dict]):
        """Salva metadati per sorgente."""
        if not hasattr(self, '_metadata_store'):
            self._metadata_store: Dict[str, List[Dict]] = {}
        self._metadata_store[source] = metadatas

    def _get_metadata_for_source(self, source: str) -> List[Dict]:
        """Ottiene metadati per sorgente."""
        if not hasattr(self, '_metadata_store'):
            self._metadata_store = {}
        return self._metadata_store.get(source, [])

    def _update_metadata(self, source: str, metadatas: List[Dict]):
        """Aggiorna metadati per sorgente."""
        self._store_metadata(source, metadatas)

    def _rebuild_master(self):
        """Ricostruisce l'indice master cross-document."""
        self._master_corpus = []
        self._master_docs = []
        self._master_metadata = []
        self._doc_to_source = {}

        idx = 0
        for source, (bm25, corpus, docs) in self.indices.items():
            meta_list = self._get_metadata_for_source(source)
            for i, doc in enumerate(corpus):
                self._master_corpus.append(doc)
                self._master_docs.append(docs[i])
                self._master_metadata.append(meta_list[i] if i < len(meta_list) else {"source": source})
                self._doc_to_source[idx] = source
                idx += 1

        self._bm25 = BM25L(self._master_corpus) if self._master_corpus else None

    def search(self, query: str, top_k: int = 20, source_filter: Optional[List[str]] = None) -> List[Dict]:
        """
        Cerca documenti con BM25.

        Returns:
            Lista di {"text": str, "score": float, "metadata": dict}
        """
        if not self._bm25 or not self._master_corpus:
            return []

        query_tokens = self._tokenize(query)
        scores = self._bm25.get_scores(query_tokens)

        # Se c'è un filtro per sorgente, maschera i risultati
        if source_filter:
            filtered_scores = []
            for idx, score in enumerate(scores):
                src = self._doc_to_source.get(idx)
                if src in source_filter:
                    filtered_scores.append((idx, score))
        else:
            filtered_scores = list(enumerate(scores))

        # Ordina per score decrescente
        filtered_scores.sort(key=lambda x: x[1], reverse=True)

        results = []
        for idx, score in filtered_scores[:top_k]:
            if score > 0:
                results.append({
                    "text": self._master_docs[idx],  # Testo originale, non tokenizzato
                    "score": float(score),
                    "metadata": self._master_metadata[idx]
                })

        return results

    def get_all_sources(self) -> List[str]:
        """Ottiene lista di tutte le sorgenti indicizzate."""
        return list(self.indices.keys())


class ChromaManager:
    """Gestione connessione ChromaDB - ISTANZA PER PROGETTO (no singleton)."""

    def __init__(self, persist_directory: Optional[str] = None):
        self.persist_directory = persist_directory
        settings = Settings()
        if persist_directory:
            settings.is_persistent = True
            settings.persist_directory = persist_directory
        self._client = chromadb.Client(settings)
        from backend_config.settings import settings as app_settings
        self._ollama_client = AsyncClient(host=app_settings.OLLAMA_HOST_URL)

    @property
    def client(self):
        return self._client

    def close(self):
        if self._client:
            self._client.stop()
            self._client = None

    async def get_embedding(self, text: str, model: str = None) -> Optional[List[float]]:
        """Genera embedding singolo usando Ollama (legacy, usato da query())."""
        try:
            from backend_config.settings import settings as app_settings
            model = model or app_settings.EMBEDDING_MODEL
            response = await self._ollama_client.embeddings(
                model=model,
                prompt=text,
                options={"num_ctx": app_settings.EMBEDDING_CTX}
            )
            return response.get('embedding')
        except Exception as e:
            logger.error(f"Errore embedding: {e}")
            return None

    async def get_embeddings_batch(self, texts: List[str], model: str = None) -> List[Optional[List[float]]]:
        """Genera embedding per un batch di testi in una singola chiamata HTTP (endpoint /api/embed)."""
        try:
            from backend_config.settings import settings as app_settings
            model = model or app_settings.EMBEDDING_MODEL
            response = await self._ollama_client.embed(
                model=model,
                input=texts,
                options={"num_ctx": app_settings.EMBEDDING_CTX}
            )
            return response.embeddings
        except Exception as e:
            logger.error(f"Errore batch embedding: {e}")
            return [None] * len(texts)


class DocumentProcessor:
    """
    Pipeline RAG per gestione documenti.
    Supporta: PDF, DOCX, PPTX, XML (HL7, FatturaPA, Akoma Ntoso), JSON, MD, TXT e formati codice.
    """

    # Plain-text formats accettati esplicitamente da Interrogate / Anonimyze.
    # Per estensioni NON in lista, c'e' comunque un fallback "decoder-sniff"
    # (vedi `_looks_like_text()` piu' avanti) che tenta una decodifica UTF-8/
    # latin-1 sui primi 8 KB e accetta se il contenuto e' "leggibile" — questo
    # copre i casi che l'utente non si aspetta di dover pre-elencare
    # (es. .toml, .env, .lock, .makefile, ecc.). Policy: tratta-come-testo
    # silenziosamente se decodificabile, rifiuta solo se davvero binary.
    TEXT_EXTENSIONS = {
        # Plain text / docs
        '.txt', '.md', '.markdown', '.rst', '.tex', '.org', '.adoc',
        '.html', '.htm', '.xhtml',
        '.srt', '.vtt',                                    # subtitles
        '.log',                                            # logs
        # Config (human-editable)
        '.ini', '.cfg', '.conf', '.config', '.properties',
        '.toml', '.yaml', '.yml', '.env',
        # Code (source) — scoperto un avvocato a volte vuole ingestare
        # repo / script per ricerca / Q&A; non c'e' motivo tecnico per
        # rifiutarli, sono comunque plain text.
        '.py', '.pyi', '.pyw',
        '.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx',
        '.java', '.kt', '.kts', '.scala', '.groovy',
        '.c', '.h', '.cpp', '.hpp', '.cc', '.hh', '.cxx', '.hxx',
        '.cs', '.fs', '.vb',
        '.go', '.rs', '.swift',
        '.rb', '.php', '.pl', '.pm',
        '.r', '.jl', '.lua', '.dart', '.ex', '.exs',
        # Shell / batch
        '.sh', '.bash', '.zsh', '.fish',
        '.bat', '.cmd', '.ps1', '.psm1',
        # Data tabulare semplice
        '.csv', '.tsv', '.tab',
        # Web
        '.css', '.scss', '.sass', '.less',
        '.sql',
        # Build / project
        '.gradle', '.cmake', '.dockerfile', '.gitignore', '.gitattributes',
        '.editorconfig', '.lock', '.makefile',
    }

    def __init__(self, collection_name: str = "pai_docs", persist_directory: Optional[str] = None, lang: str = "it"):
        self.chroma = ChromaManager(persist_directory)
        self.collection_name = collection_name
        self.collection = self.chroma.client.get_or_create_collection(name=collection_name)
        from backend_config.settings import settings
        self.client = ollama.AsyncClient(host=settings.OLLAMA_HOST_URL)
        self.lang = lang
        self.prompts = self._load_prompts()

        # BM25 Index for hybrid search
        self.bm25 = BM25Manager()
    
    def _load_prompts(self) -> Dict:
        """Carica prompt da configurazione."""
        # Path default per PAI Premium
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_chat.json"
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(self.lang, data.get('it', {}))
        except:
            return self._get_default_prompts()
    
    def _get_default_prompts(self) -> Dict:
        """Prompt di default se il file non esiste."""
        return {
            "rag": {
                "system_prompt": "You are PAI - Private Artificial Intelligence Suite. You have access to the files listed in the CURRENT INVENTORY below.\n\nCURRENT INVENTORY (Mapping ID -> Filename):\n{files_list}\n\nCRITICAL INSTRUCTIONS:\n1. Each context block starts with \"=== DOCUMENT CONTENT OF [File X] ===\". This indicates that the following text belongs EXACTLY to that inventory file.\n2. If the user asks about \"File X\", you must read the content under the corresponding header.\n3. Never say \"I can't find File X\" if it is present in the inventory and context. Trust the [File X] tags.\n4. Use real filenames when answering, but be aware that the user may refer to them as File 1, 2, etc.",
                "user_prompt_template": "AVAILABLE CONTEXT:\n{context_text}\n\nUSER QUESTION:\n{user_message}",
                "file_list_injection": "\n\n--- SUMMARY OF AVAILABLE FILES (METADATA) ---\nThe system confirms that the following files are currently uploaded: {list_str}.\nIf the user asks for a list or what files are present, use EXCLUSIVELY this list.",
                "no_files_context": "No files uploaded."
            }
        }
    
    def set_language(self, lang: str):
        """Cambia lingua per i prompt."""
        self.lang = lang
        self.prompts = self._load_prompts()
    
    def refresh_collection(self):
        """Ricollega la collezione al progetto attivo."""
        try:
            self.collection = self.chroma.client.get_or_create_collection(name=self.collection_name)
            logger.info(f"Collection '{self.collection_name}' refreshed")
        except Exception as e:
            logger.error(f"Errore refresh collection: {e}")

    def _with_collection_retry(self, fn):
        """Esegue fn() (operazione ChromaDB) con retry difensivo su stale collection.

        Bug noto: dopo project switch, cleanup test, o ChromaDB reset, l'oggetto
        `self.collection` può puntare a una collection cancellata (errore
        'Collection [UUID] does not exist'). In quel caso facciamo refresh
        (get_or_create_collection lo ricrea/ricollega) e riproviamo una volta.
        Tutte le altre eccezioni passano invariate.
        """
        try:
            return fn()
        except Exception as e:
            msg = str(e)
            if "does not exist" in msg and "Collection" in msg:
                logger.warning(f"Stale ChromaDB collection — refreshing and retrying. Err: {msg[:200]}")
                self.refresh_collection()
                return fn()
            raise
    
    async def ingest_file(self, file_path: str, filename: str, ref_id: str = "") -> Tuple[bool, str]:
        """
        Legge, chunkizza e indicizza un file.
        
        Args:
            file_path: Percorso completo del file
            filename: Nome del file
            ref_id: ID riferimento (opzionale, default: collection_name)
        
        Returns:
            (successo, messaggio)
        """
        text = ""
        ext = os.path.splitext(file_path)[1].lower()
        # Immagini embedded dell'ultimo PDF processato → usato per offrire
        # l'arricchimento OCR opt-in in INTERROGATE. Reset a ogni file.
        self._last_pdf_image_count = 0

        try:
            logger.info(f"Inizio lettura file: {filename} (ext: {ext})")
            
            # PDF
            if ext == '.pdf':
                reader = pypdf.PdfReader(file_path)
                for page_num, page in enumerate(reader.pages, 1):
                    page_text = page.extract_text()
                    if page_text:
                        text += f"\n[PAGE:{page_num}]\n" + page_text + "\n"

                # Fallback 1 — PDF completamente scansionato (zero testo)
                if not text.strip():
                    logger.warning(f"PDF '{filename}' scansionato (zero testo)")
                    return False, "ERROR_PDF_IMAGE_ONLY"

                # Fallback 2 — PDF misto: testo sparso (form scansionati con pochi campi digitali)
                # Soglia: < 150 chars/pagina + almeno 1 immagine embedded → meglio OCR l'intera pagina
                total_pages = len(reader.pages)
                chars_per_page = len(text.strip()) / max(total_pages, 1)
                if chars_per_page < 150:
                    total_images = sum(len(page.images) for page in reader.pages)
                    if total_images > 0:
                        logger.warning(
                            f"PDF '{filename}' misto: {len(text.strip())} chars totali "
                            f"({chars_per_page:.0f}/pag), {total_images} immagini → OCR"
                        )
                        return False, "ERROR_PDF_IMAGE_ONLY"

                # PDF con testo nativo sufficiente: contiamo le immagini embedded.
                # Il testo nativo prosegue verso l'indicizzazione; il conteggio serve
                # a OFFRIRE (opt-in) l'arricchimento OCR di tabelle/figure che pypdf
                # non estrae — invece di scartarle in silenzio.
                try:
                    self._last_pdf_image_count = sum(len(p.images) for p in reader.pages)
                except Exception:
                    self._last_pdf_image_count = 0

            # DOCX
            elif ext == '.docx':
                text = self._extract_docx_text(file_path)
                # Se vuoto, controlla se contiene immagini embedded → OCR flow
                if not text.strip():
                    try:
                        with zipfile.ZipFile(file_path) as z:
                            has_images = any(
                                name.startswith('word/media/') and
                                Path(name).suffix.lower() in {'.png','.jpg','.jpeg','.bmp','.tiff','.tif','.gif','.webp','.emf','.wmf'}
                                for name in z.namelist()
                            )
                        if has_images:
                            logger.warning(f"DOCX '{filename}' contains only images — triggering OCR")
                            return False, "ERROR_DOCX_IMAGE_ONLY"
                    except Exception as e:
                        logger.warning(f"Could not inspect DOCX media for {filename}: {e}")
            
            # PPTX → testo nativo + tabelle markdown + OCR su immagini embedded
            elif ext == '.pptx':
                text = await self._extract_pptx_text(file_path)
            
            # HL7 v2 (pipe-delimited)
            elif ext in ['.hl7', '.hl7v2']:
                hl7_chunks = self._parse_hl7_v2(file_path)
                if hl7_chunks:
                    logger.info(f"HL7 v2 rilevato ({filename}). {len(hl7_chunks)} segmenti.")
                    return await self.ingest_prechunked_data(hl7_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()

            # X12 EDI / EDIFACT
            elif ext in ['.edi', '.x12']:
                edi_chunks = self._parse_edi_file(file_path)
                if edi_chunks:
                    logger.info(f"EDI rilevato ({filename}). {len(edi_chunks)} transazioni.")
                    return await self.ingest_prechunked_data(edi_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()

            # Email
            elif ext == '.eml':
                email_chunks = self._parse_email_file(file_path)
                if email_chunks:
                    logger.info(f"Email rilevata ({filename}).")
                    return await self.ingest_prechunked_data(email_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()

            # ODT
            elif ext == '.odt':
                text = self._extract_odt_text(file_path)

            # RTF
            elif ext == '.rtf':
                text = self._extract_rtf_text(file_path)

            # XBRL
            elif ext in ['.xbrl']:
                xbrl_chunks = self._parse_xbrl(file_path)
                if xbrl_chunks:
                    logger.info(f"XBRL rilevato ({filename}). {len(xbrl_chunks)} fact.")
                    return await self.ingest_prechunked_data(xbrl_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()

            # XML — universal normalization pipeline.
            # FHIR XML and XBRL keep their specialized parsers (they encode
            # resource-level / financial-fact semantics that benefit from
            # per-resource chunking). Every other XML — HL7/C-CDA, FatturaPA,
            # Akoma Ntoso, SVG, RSS, generic — is converted to a hierarchical
            # text representation by `xml_normalizer.build_xml_text_for_rag()`
            # and then fed to the general chunker, just like a PDF/DOCX.
            elif ext == '.xml':
                fhir_chunks = self._parse_fhir_xml(file_path)
                if fhir_chunks:
                    logger.info(f"HL7 FHIR XML rilevato ({filename}). {len(fhir_chunks)} risorse.")
                    return await self.ingest_prechunked_data(fhir_chunks, filename, ref_id or self.collection_name)
                xbrl_chunks = self._parse_xbrl(file_path)
                if xbrl_chunks:
                    logger.info(f"XBRL rilevato ({filename}). {len(xbrl_chunks)} fact.")
                    return await self.ingest_prechunked_data(xbrl_chunks, filename, ref_id or self.collection_name)

                # Universal walker — works on any XML schema. The output is
                # plain text (Markdown headers + indented bullets) so the
                # generic chunker below splits it into normal-sized chunks.
                # A domain prologue is prepended for known namespaces (HL7,
                # FatturaPA) so the first chunk always carries the document's
                # core identity (patient name, invoice number, ...).
                try:
                    from processors.xml_normalizer import build_xml_text_for_rag
                    text = build_xml_text_for_rag(file_path)
                    if text and text.strip():
                        logger.info(f"XML universal normalizer ({filename}). {len(text)} chars of text produced.")
                    else:
                        raise ValueError("normalizer produced empty text")
                except Exception as norm_err:
                    logger.warning(f"XML normalizer failed for {filename}, falling back to raw read: {norm_err}")
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            text = f.read()
                    except UnicodeDecodeError:
                        with open(file_path, 'r', encoding='latin-1') as f:
                            text = f.read()
            
            # JSON (FHIR o generico)
            elif ext == '.json':
                # Prova prima FHIR JSON parser
                fhir_chunks = self._parse_fhir_json(file_path)
                if fhir_chunks:
                    logger.info(f"HL7 FHIR JSON rilevato ({filename}). {len(fhir_chunks)} risorse.")
                    return await self.ingest_prechunked_data(fhir_chunks, filename, ref_id or self.collection_name)
                # Fallback a JSON generico
                json_chunks = self._extract_json_logical_chunks(file_path)
                if json_chunks:
                    logger.info(f"JSON strutturato rilevato ({filename}). {len(json_chunks)} oggetti.")
                    return await self.ingest_prechunked_data(json_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
            
            # Markdown
            elif ext in ['.md', '.markdown']:
                md_chunks = self._extract_markdown_logical_chunks(file_path)
                if md_chunks:
                    logger.info(f"Markdown strutturato rilevato ({filename}). {len(md_chunks)} sezioni.")
                    return await self.ingest_prechunked_data(md_chunks, filename, ref_id or self.collection_name)
                else:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
            
            # Text & Code (whitelist esplicita)
            elif ext in self.TEXT_EXTENSIONS:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read()
                except UnicodeDecodeError:
                    with open(file_path, 'r', encoding='latin-1') as f:
                        text = f.read()

            # Fallback "decoder-sniff": l'estensione non e' nota ma il file
            # potrebbe comunque essere testo (es. .toml, .env, .makefile,
            # file senza estensione, formati custom). Proviamo a leggere il
            # contenuto: se decodifica come UTF-8 o latin-1 e la maggioranza
            # dei caratteri e' "leggibile" (printable o whitespace), trattalo
            # come plain text. Altrimenti rifiutalo come binary.
            elif self._looks_like_text(file_path):
                logger.info(f"Formato {ext} non in whitelist ma riconosciuto come testo via sniff: {filename}")
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read()
                except UnicodeDecodeError:
                    with open(file_path, 'r', encoding='latin-1') as f:
                        text = f.read()

            else:
                return False, f"Formato {ext} non supportato."
            
            if not text or not text.strip():
                return False, "Nessun testo rilevato (File vuoto o protetto?)."
            
            return await self.ingest_text(text, filename, ref_id or self.collection_name)

        except Exception as e:
            logger.error(f"Errore ingestion {filename}: {e}")
            return False, str(e)

    def extract_plain_text(self, file_path: str) -> Optional[str]:
        """Return the clean full text of a document straight from the ORIGINAL
        file — no RAG chunking, no 150-char overlap, original line structure
        preserved.

        Compare Mode uses this so the redline / diff sees the TRUE document
        instead of the chunk reconstruction (which concatenates overlapping
        chunks → duplicated fragments and a garbled word-diff). Returns None for
        formats not handled here, so the caller can fall back to the chunk path.

        Sync by design (callers are sync). PPTX and scanned PDFs are already
        stored as generated `.txt` at upload time, so they land in the
        plain-text branch and are read cleanly.
        """
        try:
            if not file_path or not os.path.exists(file_path):
                return None
            ext = os.path.splitext(file_path)[1].lower()
            text = ""
            if ext == '.pdf':
                reader = pypdf.PdfReader(file_path)
                # No [PAGE:N] markers here (unlike ingest): keep the text clean
                # for a faithful word-level diff.
                text = "\n".join(p.extract_text() or "" for p in reader.pages)
            elif ext == '.docx':
                text = self._extract_docx_text(file_path)
            elif ext == '.odt':
                text = self._extract_odt_text(file_path)
            elif ext == '.rtf':
                text = self._extract_rtf_text(file_path)
            elif ext in self.TEXT_EXTENSIONS or self._looks_like_text(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read()
                except UnicodeDecodeError:
                    with open(file_path, 'r', encoding='latin-1') as f:
                        text = f.read()
            else:
                return None
            text = (text or "").strip()
            return text or None
        except Exception as e:
            logger.warning(f"[extract_plain_text] failed for {file_path}: {e}")
            return None

    @staticmethod
    def _looks_like_text(file_path: str, sample_size: int = 8192) -> bool:
        """Sniff euristico: il file e' plain text decodificabile?

        Legge i primi `sample_size` byte e:
          1. Rifiuta immediato se trova NUL bytes (signature di binari).
          2. Prova decode UTF-8, poi latin-1; rifiuta se entrambe falliscono.
          3. Accetta se >= 95% dei caratteri sono printable o whitespace
             standard (\\t \\n \\r). Caratteri di controllo non standard
             contano come "non leggibili".

        Usato come fallback dopo TEXT_EXTENSIONS: copre estensioni rare
        (.toml/.env/.makefile/.properties/file senza estensione) senza
        richiedere whitelist esaustiva. Costo: ~1 read() di 8 KB."""
        try:
            with open(file_path, "rb") as f:
                sample = f.read(sample_size)
        except OSError:
            return False
        if not sample:
            return False
        # Binary signature: NUL byte in primi 8 KB e' praticamente diagnostico
        # (UTF-16 ha NUL per ASCII chars ma noi non lo supportiamo qui — se
        # serve, l'utente puo' convertirlo).
        if b"\x00" in sample:
            return False
        # Decoding
        try:
            text = sample.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text = sample.decode("latin-1")
            except UnicodeDecodeError:
                return False
        if not text:
            return False
        # Printable ratio
        readable = sum(
            1 for c in text
            if c.isprintable() or c in ("\t", "\n", "\r")
        )
        return readable / len(text) >= 0.95

    def _extract_docx_text(self, file_path: str) -> str:
        """Estrae testo da DOCX."""
        try:
            if not os.path.exists(file_path):
                return ""
            
            if os.path.getsize(file_path) == 0:
                return ""
            
            if not zipfile.is_zipfile(file_path):
                return ""
            
            paragraphs = []
            with zipfile.ZipFile(file_path) as z:
                xml_content = z.read('word/document.xml')
                tree = ET.fromstring(xml_content)
                namespace = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                
                for paragraph in tree.findall('.//w:p', namespace):
                    texts = []
                    for node in paragraph.findall('.//w:t', namespace):
                        if node.text:
                            texts.append(node.text)
                    if texts:
                        paragraphs.append("".join(texts))
            
            return "\n".join(paragraphs)
        except Exception as e:
            logger.error(f"Errore estrazione DOCX: {e}")
            return ""
    
    async def _extract_pptx_text(self, file_path: str) -> str:
        """Estrae testo da PPTX trattandolo come "PDF con immagini":

        - Testo nativo (titoli, textbox, contenuti) catturato via python-pptx
        - **Tabelle** convertite in formato Markdown (header + righe con `|`)
        - **Immagini embedded** passate a glm-ocr (OCR_processor.process_image)
          per estrarne testo/tabelle/formule. Il modello restituisce già
          markdown grazie al system prompt OCR_SYSTEM_PROMPT.
        - **Note del relatore** in coda alla slide come [NOTE]: ...
        - Marker `--- SLIDE N ---` per ancoraggio nelle citazioni AI

        Costo: OCR è ~3-8s per immagine. Una PPTX con 30 slide × 2 immagini
        può richiedere 1-3 minuti. È accettabile come tradeoff per i casi
        d'uso reali (presentazioni con loghi, schemi, screenshot).
        """
        import tempfile
        try:
            from pptx import Presentation
            from pptx.enum.shapes import MSO_SHAPE_TYPE
        except Exception as e:
            logger.error(f"python-pptx import failed: {e}")
            return ""

        try:
            prs = Presentation(file_path)
        except Exception as e:
            logger.error(f"Errore apertura PPTX: {e}")
            return ""

        # Lazy-import dell'OCR processor: evitiamo import circolare al top
        ocr = None
        try:
            from processors.ocr_processor import OCRImgPDFProcessor
            ocr = OCRImgPDFProcessor()
        except Exception as e:
            logger.warning(f"OCR processor non disponibile, le immagini PPTX non saranno trascritte: {e}")

        def _table_to_markdown(table) -> str:
            """Converte una tabella PPTX in markdown table (header + righe)."""
            rows = list(table.rows)
            if not rows:
                return ""
            # Prima riga = header
            header_cells = [c.text.strip().replace("\n", " ") or " " for c in rows[0].cells]
            md = ["| " + " | ".join(header_cells) + " |"]
            md.append("| " + " | ".join(["---"] * len(header_cells)) + " |")
            for row in rows[1:]:
                cells = [c.text.strip().replace("\n", " ") or " " for c in row.cells]
                # Pad/truncate per matchare l'header (le tabelle PPTX possono avere celle merge)
                if len(cells) < len(header_cells):
                    cells += [" "] * (len(header_cells) - len(cells))
                md.append("| " + " | ".join(cells[:len(header_cells)]) + " |")
            return "\n".join(md)

        async def _ocr_image_blob(blob: bytes, ext: str) -> str:
            """Salva il blob in un file temporaneo e lo passa a glm-ocr."""
            if not ocr:
                return ""
            try:
                ext_norm = ext.lower().lstrip(".") or "png"
                if ext_norm not in ("png", "jpg", "jpeg", "bmp", "tiff", "tif", "webp", "gif"):
                    # Formati non supportati da glm-ocr (es. emf/wmf): skip
                    return ""
                with tempfile.NamedTemporaryFile(suffix=f".{ext_norm}", delete=False) as tmp:
                    tmp.write(blob)
                    tmp_path = tmp.name
                try:
                    success, result_text = await ocr.process_image(tmp_path, model="glm-ocr:latest")
                    return result_text.strip() if success else ""
                finally:
                    try: Path(tmp_path).unlink()
                    except Exception: pass
            except Exception as e:
                logger.warning(f"OCR su immagine PPTX fallito: {e}")
                return ""

        full_text = []

        for i, slide in enumerate(prs.slides):
            slide_parts = [f"--- SLIDE {i+1} ---"]

            for shape in slide.shapes:
                # 1. Tabelle → markdown
                try:
                    if shape.has_table:
                        md = _table_to_markdown(shape.table)
                        if md:
                            slide_parts.append(md)
                        continue
                except Exception:
                    pass

                # 2. Immagini → OCR via glm-ocr
                try:
                    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                        blob = shape.image.blob
                        ext = shape.image.ext if hasattr(shape.image, "ext") else "png"
                        ocr_text = await _ocr_image_blob(blob, ext)
                        if ocr_text:
                            slide_parts.append(f"[IMMAGINE OCR]:\n{ocr_text}")
                        continue
                except Exception as e:
                    logger.debug(f"Skip image shape on slide {i+1}: {e}")

                # 3. Testo (titoli, textbox, contenuti, SmartArt)
                if hasattr(shape, "text") and shape.text.strip():
                    slide_parts.append(shape.text.strip())

            # 4. Note del relatore
            try:
                if slide.has_notes_slide:
                    notes = slide.notes_slide.notes_text_frame.text.strip()
                    if notes:
                        slide_parts.append(f"[NOTE]: {notes}")
            except Exception:
                pass

            full_text.append("\n".join(slide_parts))

        return "\n\n".join(full_text)
    
    def _extract_xml_logical_chunks(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Universal XML Parser: HL7/C-CDA, FatturaPA, Akoma Ntoso.
        """
        try:
            with open(file_path, 'rb') as f:
                header = f.read(1000).decode('utf-8', errors='ignore')
            
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            ns_uri = ""
            if '}' in root.tag:
                ns_uri = root.tag.split('}')[0].strip('{')
            
            # HL7/C-CDA
            if ns_uri == "urn:hl7-org:v3" or "urn:hl7-org:v3" in header:
                return self._parse_xml_hl7(root, ns_uri or "urn:hl7-org:v3")
            
            # FatturaPA
            if "ivaservizi.agenziaentrate.gov.it" in ns_uri or "FatturaElettronica" in root.tag:
                return self._parse_xml_fatturapa(root, ns_uri)
            
            # Akoma Ntoso
            if "akomantoso.org" in ns_uri:
                return self._parse_xml_akomantoso(root, ns_uri)
            
            # Fallback
            logger.info(f"XML generico rilevato. Flattening.")
            return self._parse_xml_flattening(root)
        
        except Exception as e:
            logger.warning(f"Errore XML parser: {e}")
            return []
    
    def _parse_xml_hl7(self, root, ns_uri: str) -> List[Dict[str, Any]]:
        """Parser HL7/C-CDA → human-readable prose chunks.

        Output is plain prose (NOT XML serialized). Each chunk is one of:
        - patient_header  → recordTarget + custodian
        - document_meta   → title, effectiveTime, author, encompassingEncounter
        - section         → one per <section>, narrative + flattened entries
        - clinical_event  → loose observation/encounter/procedure/etc not in any section
                            (extra-section heuristic, kept for sparse documents)
        """
        ns = {'hl7': ns_uri}
        chunks: List[Dict[str, Any]] = []

        # 1) PATIENT HEADER — recordTarget + custodian.
        rt = root.find('.//hl7:recordTarget/hl7:patientRole', ns)
        if rt is not None:
            patient_text = self._cda_extract_patient_header(rt, ns)
            custodian = root.find('.//hl7:custodian', ns)
            if custodian is not None:
                cust_text = self._cda_extract_custodian(custodian, ns)
                if cust_text:
                    patient_text = patient_text + "\n\n" + cust_text
            if patient_text.strip():
                chunks.append({
                    "content": patient_text,
                    "metadata": {"tipo": "patient_header", "domain": "clinical"}
                })

        # 2) DOCUMENT META — title, effectiveTime, author, encompassingEncounter.
        meta_text = self._cda_extract_document_meta(root, ns)
        if meta_text.strip():
            chunks.append({
                "content": meta_text,
                "metadata": {"tipo": "document_meta", "domain": "clinical"}
            })

        # 3) SECTION chunks — one or MORE per <section>. Large sections (e.g.
        # Synthea "Diagnostic Results" can be 80K+ chars) are split into
        # ~2K-char sub-chunks so they fit a typical LLM context window.
        sections_seen = set()
        section_count = 0
        for section in root.findall('.//hl7:section', ns):
            sub_chunks = self._cda_extract_section(section, ns)
            if not sub_chunks:
                continue
            # Dedupe by section title (case-insensitive).
            section_title = sub_chunks[0][1] if sub_chunks else "Untitled"
            dedupe_key = (section_title or "untitled").lower()
            if dedupe_key in sections_seen:
                continue
            sections_seen.add(dedupe_key)
            section_count += 1
            for body, sec_title in sub_chunks:
                if not body or not body.strip():
                    continue
                chunks.append({
                    "content": body,
                    "metadata": {"tipo": "section", "section": sec_title or "Untitled", "domain": "clinical"}
                })

        # 4) CLINICAL EVENTS — only if very few sections were found, fall back to
        #    extracting loose clinical entries directly. Avoids duplication when
        #    sections already capture everything (the common case for C-CDA).
        if section_count < 2:
            tag_logici = ['hl7:observation', 'hl7:encounter', 'hl7:procedure',
                          'hl7:substanceAdministration', 'hl7:act']
            for tag in tag_logici:
                for nodo in root.findall(f'.//{tag}', ns):
                    content = self._cda_text_of_node(nodo, ns, max_depth=4)
                    if not content.strip():
                        continue
                    eff = nodo.find('.//hl7:effectiveTime', ns)
                    date_val = (eff.get('value') if eff is not None else "") or "unknown"
                    chunks.append({
                        "content": content,
                        "metadata": {"tipo": tag.split(':')[-1], "data": date_val, "domain": "clinical"}
                    })

        return chunks

    # ─── HL7/C-CDA prose extraction helpers ────────────────────────────────────
    # All helpers return plain text prose (not XML). They expect `ns` to be a
    # dict mapping the prefix `'hl7'` to the document's namespace URI. They
    # tolerate missing nodes gracefully — a CDA document is often partial.

    @staticmethod
    def _cda_format_date(value: str) -> str:
        """HL7 timestamps are like '20260307171138' or '20260307' — slice to
        ISO date when possible. Pass-through anything that doesn't match.
        """
        if not value:
            return ""
        v = value.strip()
        if len(v) >= 8 and v[:8].isdigit():
            return f"{v[:4]}-{v[4:6]}-{v[6:8]}"
        return v

    def _cda_text_of_node(self, node, ns: dict, max_depth: int = 3, _depth: int = 0) -> str:
        """Render a CDA node as compact prose `key: value | key: value | ...`.

        Walks attributes (displayName, value, code, unit, extension, root) and
        recurses into children up to `max_depth`. Skips templateId roots and
        nullFlavor-only nodes which add noise without information.
        """
        if node is None or _depth > max_depth:
            return ""
        parts: List[str] = []
        local = node.tag.split('}')[-1] if '}' in node.tag else node.tag

        # Useful attribute set: caller cares about semantic content, not XML schema noise.
        for attr in ('displayName', 'value', 'code', 'unit', 'extension'):
            v = node.get(attr)
            if v:
                parts.append(f"{attr}={v}")

        # Inline text node content (rare in CDA structured data, but possible).
        if node.text and node.text.strip():
            parts.append(node.text.strip())

        head = ': '.join([local, ' | '.join(parts)]) if parts else local

        # Recurse into children. Skip purely structural nodes (templateId, id with no extension).
        child_parts: List[str] = []
        for child in node:
            child_local = child.tag.split('}')[-1] if '}' in child.tag else child.tag
            if child_local in ('templateId',):
                continue
            child_text = self._cda_text_of_node(child, ns, max_depth=max_depth, _depth=_depth + 1)
            if child_text:
                child_parts.append(child_text)
        if child_parts:
            return head + ' { ' + ' | '.join(child_parts) + ' }' if parts else head + ' { ' + ' | '.join(child_parts) + ' }'
        return head if parts else ""

    def _cda_extract_patient_header(self, patient_role, ns: dict) -> str:
        """Extract the patient demographic block as readable lines.

        Output example (real values from Synthea sample):
            Patient: Cyrstal592 Rita460 Labadie908
            Sex: Female (administrativeGenderCode=F)
            Date of birth: 1954-12-18
            Address: 491 Luettgen Approach Suite 97, Leominster, Massachusetts 01420
            Race: white | Ethnicity: non-hispanic
            Language: en-US
        """
        lines: List[str] = []

        # Patient name — concatenate all <given> + <family> children of <name>.
        patient = patient_role.find('hl7:patient', ns)
        if patient is not None:
            name_node = patient.find('hl7:name', ns)
            if name_node is not None:
                givens = [g.text.strip() for g in name_node.findall('hl7:given', ns) if g.text]
                families = [f.text.strip() for f in name_node.findall('hl7:family', ns) if f.text]
                full_name = ' '.join(givens + families).strip()
                if full_name:
                    lines.append(f"Patient: {full_name}")

            # Sex.
            gender = patient.find('hl7:administrativeGenderCode', ns)
            if gender is not None:
                disp = gender.get('displayName') or ""
                code = gender.get('code') or ""
                sex_pretty = {"M": "Male", "F": "Female", "U": "Unknown"}.get(code, disp or code)
                if sex_pretty or code:
                    lines.append(f"Sex: {sex_pretty}" + (f" (administrativeGenderCode={code})" if code else ""))

            # Date of birth.
            birth = patient.find('hl7:birthTime', ns)
            if birth is not None and birth.get('value'):
                lines.append(f"Date of birth: {self._cda_format_date(birth.get('value'))}")

            # Race / Ethnicity (optional, common in US C-CDA).
            race = patient.find('hl7:raceCode', ns)
            ethnic = patient.find('hl7:ethnicGroupCode', ns)
            race_eth: List[str] = []
            if race is not None and race.get('displayName'):
                race_eth.append(f"Race: {race.get('displayName')}")
            if ethnic is not None and ethnic.get('displayName'):
                race_eth.append(f"Ethnicity: {ethnic.get('displayName')}")
            if race_eth:
                lines.append(' | '.join(race_eth))

            # Language.
            lang = patient.find('.//hl7:languageCommunication/hl7:languageCode', ns)
            if lang is not None and lang.get('code'):
                lines.append(f"Language: {lang.get('code')}")

        # Address (from patientRole, not patient).
        addr = patient_role.find('hl7:addr', ns)
        if addr is not None:
            street = ' '.join(s.text.strip() for s in addr.findall('hl7:streetAddressLine', ns) if s.text)
            city = (addr.findtext('hl7:city', default='', namespaces=ns) or '').strip()
            state = (addr.findtext('hl7:state', default='', namespaces=ns) or '').strip()
            postal = (addr.findtext('hl7:postalCode', default='', namespaces=ns) or '').strip()
            country = (addr.findtext('hl7:country', default='', namespaces=ns) or '').strip()
            parts = [p for p in [street, city, state, postal, country] if p]
            if parts:
                lines.append(f"Address: {', '.join(parts)}")

        # Telecom (phone/email if present and not nullFlavored).
        tels: List[str] = []
        for tel in patient_role.findall('hl7:telecom', ns):
            if tel.get('nullFlavor'):
                continue
            v = tel.get('value')
            use = tel.get('use')
            if v:
                tels.append(f"{v}" + (f" ({use})" if use else ""))
        if tels:
            lines.append("Contact: " + " | ".join(tels))

        return "\n".join(lines)

    def _cda_extract_custodian(self, custodian, ns: dict) -> str:
        """Extract the document custodian organization as one-line prose."""
        org = custodian.find('.//hl7:representedCustodianOrganization', ns)
        if org is None:
            return ""
        parts: List[str] = []
        name = (org.findtext('hl7:name', default='', namespaces=ns) or '').strip()
        if name:
            parts.append(f"Custodian: {name}")
        addr = org.find('hl7:addr', ns)
        if addr is not None:
            street = ' '.join(s.text.strip() for s in addr.findall('hl7:streetAddressLine', ns) if s.text)
            city = (addr.findtext('hl7:city', default='', namespaces=ns) or '').strip()
            state = (addr.findtext('hl7:state', default='', namespaces=ns) or '').strip()
            postal = (addr.findtext('hl7:postalCode', default='', namespaces=ns) or '').strip()
            addr_parts = [p for p in [street, city, state, postal] if p]
            if addr_parts:
                parts.append("Address: " + ", ".join(addr_parts))
        return " | ".join(parts)

    def _cda_extract_document_meta(self, root, ns: dict) -> str:
        """Extract title, effective date, author, encompassingEncounter."""
        lines: List[str] = []
        title = root.findtext('hl7:title', default='', namespaces=ns)
        if title and title.strip():
            lines.append(f"Document title: {title.strip()}")

        eff = root.find('hl7:effectiveTime', ns)
        if eff is not None and eff.get('value'):
            lines.append(f"Document date: {self._cda_format_date(eff.get('value'))}")

        # Author — first one only, as documents typically have a single author block.
        author = root.find('hl7:author', ns)
        if author is not None:
            au_lines: List[str] = []
            au_time = author.find('hl7:time', ns)
            if au_time is not None and au_time.get('value'):
                au_lines.append(f"Authored on {self._cda_format_date(au_time.get('value'))}")
            org = author.find('.//hl7:representedOrganization/hl7:name', ns)
            if org is not None and org.text and org.text.strip():
                au_lines.append(f"by {org.text.strip()}")
            device = author.find('.//hl7:assignedAuthoringDevice/hl7:softwareName', ns)
            if device is not None and device.text and device.text.strip():
                au_lines.append(f"(software: {device.text.strip()})")
            if au_lines:
                lines.append("Author: " + " ".join(au_lines))

        # Encompassing encounter (optional but informative when present).
        enc = root.find('.//hl7:componentOf/hl7:encompassingEncounter', ns)
        if enc is not None:
            enc_lines: List[str] = []
            enc_time = enc.find('hl7:effectiveTime', ns)
            if enc_time is not None:
                low = enc_time.findtext('hl7:low/@value', default='', namespaces=ns) if False else None  # findtext doesn't support attrs
                low_node = enc_time.find('hl7:low', ns)
                if low_node is not None and low_node.get('value'):
                    enc_lines.append(f"from {self._cda_format_date(low_node.get('value'))}")
                hi_node = enc_time.find('hl7:high', ns)
                if hi_node is not None and hi_node.get('value'):
                    enc_lines.append(f"to {self._cda_format_date(hi_node.get('value'))}")
            loc = enc.find('.//hl7:location/hl7:healthCareFacility/hl7:location/hl7:name', ns)
            if loc is not None and loc.text and loc.text.strip():
                enc_lines.append(f"at {loc.text.strip()}")
            if enc_lines:
                lines.append("Encounter: " + " ".join(enc_lines))

        # Confidentiality (HL7-coded, occasionally relevant for legal review).
        conf = root.find('hl7:confidentialityCode', ns)
        if conf is not None and conf.get('code'):
            lines.append(f"Confidentiality: {conf.get('code')}")

        return "\n".join(lines)

    # Soft target for a single section sub-chunk. Sections that go over this
    # get split into multiple chunks to stay well within typical LLM context
    # windows (8K-32K tokens, where 1 token ≈ 4 chars in EN/IT). A Synthea
    # C-CDA "Diagnostic Results" section can easily reach 80K+ chars in one
    # blob — if we keep it as one chunk, Ollama truncates the whole RAG
    # context and the model effectively sees nothing.
    _CDA_SECTION_MAX_CHARS = 2000

    def _cda_extract_section(self, section, ns: dict) -> List[Tuple[str, str]]:
        """Extract one CDA <section> as a list of (content, title) sub-chunks.

        - Title comes from <title> or, fallback, from <code>/@displayName.
        - Body combines:
            * the <text> narrative as plain text (HL7's human-readable rendering),
              preserving line breaks so each row of a tabular narrative stays
              on its own line — this is what enables clean sub-chunking.
            * a flattened list of <entry> children with their key clinical bits.
        - Sub-chunks of ~2K chars each. Each sub-chunk repeats the section
          title so retrieval that picks only chunk N still gets the context.
        - Returns [] when both narrative and entries are empty.
        """
        # Title.
        title_node = section.find('hl7:title', ns)
        title = (title_node.text.strip() if (title_node is not None and title_node.text) else "")
        if not title:
            code = section.find('hl7:code', ns)
            if code is not None:
                title = (code.get('displayName') or code.get('code') or "").strip()
        title = title or "Untitled"

        # Narrative <text>. Preserve newlines (each <tr>/<p> in the HL7 text
        # becomes a line break), normalise only horizontal whitespace.
        narrative_lines: List[str] = []
        text_node = section.find('hl7:text', ns)
        if text_node is not None:
            try:
                raw = _safe_tostring(text_node, encoding='unicode', method='text')
                # Collapse runs of spaces/tabs, keep \n structure.
                raw = re.sub(r'[ \t\xa0]+', ' ', raw)
                # Compress runs of blank lines.
                raw = re.sub(r'\n[ \t]*\n+', '\n', raw)
                narrative_lines = [ln.strip() for ln in raw.split('\n') if ln.strip()]
            except Exception:
                narrative_lines = []

        # Structured <entry> children — one bullet per child, rendered as prose.
        entry_lines: List[str] = []
        for entry in section.findall('hl7:entry', ns):
            for child in entry:
                rendered = self._cda_text_of_node(child, ns, max_depth=4)
                if rendered.strip():
                    entry_lines.append("- " + rendered)

        if not narrative_lines and not entry_lines:
            return []

        # Build a list of (label, lines) blocks to chunk together.
        blocks: List[Tuple[str, List[str]]] = []
        if narrative_lines:
            blocks.append(("Narrative", narrative_lines))
        if entry_lines:
            blocks.append(("Structured entries", entry_lines))

        return self._cda_pack_section_chunks(title, blocks)

    def _cda_pack_section_chunks(
        self,
        title: str,
        blocks: List[Tuple[str, List[str]]],
    ) -> List[Tuple[str, str]]:
        """Pack labelled line-blocks into ~_CDA_SECTION_MAX_CHARS chunks.

        Each chunk is self-contained: starts with the section title (and a
        "part N/M" suffix if multi-chunked) so the LLM doesn't need any
        sibling chunk to know what it is looking at. Continuation chunks
        reprint the inner block label too (e.g. "Narrative (continued)").
        """
        # Flatten with separators so we can stream lines into chunks.
        flat: List[Tuple[str, str]] = []  # (block_label, line)
        for label, lines in blocks:
            for ln in lines:
                flat.append((label, ln))

        max_chars = self._CDA_SECTION_MAX_CHARS
        chunks_data: List[List[Tuple[str, str]]] = [[]]
        cur_size = 0
        for label, line in flat:
            line_size = len(line) + 1  # +1 for the newline
            if cur_size + line_size > max_chars and chunks_data[-1]:
                chunks_data.append([])
                cur_size = 0
            chunks_data[-1].append((label, line))
            cur_size += line_size

        # Drop empty trailing list (defensive).
        chunks_data = [c for c in chunks_data if c]
        total = len(chunks_data)

        out: List[Tuple[str, str]] = []
        for i, group in enumerate(chunks_data):
            header = f"Section: {title}" if total == 1 else f"Section: {title} (part {i+1}/{total})"
            # Render: group lines by block label, preserving order.
            rendered_blocks: List[str] = []
            current_label: Optional[str] = None
            current_lines: List[str] = []
            for label, line in group:
                if label != current_label:
                    if current_label is not None and current_lines:
                        suffix = " (continued)" if i > 0 and rendered_blocks == [] else ""
                        rendered_blocks.append(f"{current_label}{suffix}:\n" + "\n".join(current_lines))
                    current_label = label
                    current_lines = [line]
                else:
                    current_lines.append(line)
            if current_label is not None and current_lines:
                suffix = " (continued)" if i > 0 and not rendered_blocks else ""
                rendered_blocks.append(f"{current_label}{suffix}:\n" + "\n".join(current_lines))

            content = header + "\n\n" + "\n\n".join(rendered_blocks)
            out.append((content, title))
        return out
    
    def _parse_xml_fatturapa(self, root, ns_uri: str) -> List[Dict[str, Any]]:
        """Parser FatturaPA."""
        ns = {'p': ns_uri} if ns_uri else {}
        chunks = []
        
        generali = root.find('.//DatiGeneraliDocumento', ns)
        info_base = ""
        if generali is not None:
            info_base = ET.tostring(generali, encoding='unicode', method='xml')
            chunks.append({"content": info_base, "metadata": {"tipo": "DatiGenerali", "domain": "financial"}})
        
        for riga in root.findall('.//DettaglioLinee', ns):
            testo_riga = ET.tostring(riga, encoding='unicode', method='xml')
            chunks.append({
                "content": f"CONTESTO FATTURA:\n{info_base}\n\nRIGA SERVIZIO:\n{testo_riga}",
                "metadata": {"tipo": "RigaFattura", "domain": "financial"}
            })
        
        for pag in root.findall('.//DatiPagamento', ns):
            chunks.append({
                "content": ET.tostring(pag, encoding='unicode', method='xml'),
                "metadata": {"tipo": "DatiPagamento", "domain": "financial"}
            })
        
        return chunks
    
    def _parse_xml_akomantoso(self, root, ns_uri: str) -> List[Dict[str, Any]]:
        """Parser Akoma Ntoso."""
        ns = {'a': ns_uri}
        chunks = []
        
        for art in root.findall('.//a:article', ns):
            art_num = art.get('num', 'Senza Numero')
            testo_art = ET.tostring(art, encoding='unicode', method='xml')
            
            commi = art.findall('.//a:clause', ns)
            if len(testo_art) > 3000 and commi:
                for i, comma in enumerate(commi):
                    chunks.append({
                        "content": f"ARTICOLO {art_num} (Comma {i+1}):\n{ET.tostring(comma, encoding='unicode', method='xml')}",
                        "metadata": {"tipo": "Articolo_Comma", "art": art_num, "domain": "legal"}
                    })
            else:
                chunks.append({
                    "content": f"ARTICOLO {art_num}:\n{testo_art}",
                    "metadata": {"tipo": "Articolo_Completo", "art": art_num, "domain": "legal"}
                })
        
        return chunks
    
    def _parse_xml_flattening(self, root) -> List[Dict[str, Any]]:
        """Fallback XML flattening."""
        flat_data = []
        
        def traverse(node, path=""):
            current_path = f"{path}.{node.tag.split('}')[-1]}" if path else node.tag.split('}')[-1]
            if node.text and node.text.strip():
                flat_data.append(f"{current_path}: {node.text.strip()}")
            for attr, val in node.attrib.items():
                flat_data.append(f"{current_path}[@{attr}]: {val}")
            for child in node:
                traverse(child, current_path)
        
        traverse(root)
        content = "\n".join(flat_data)
        MAX_CHARS = 3000
        
        return [
            {"content": content[i:i+MAX_CHARS], "metadata": {"tipo": "flattened_xml", "part": i//MAX_CHARS}}
            for i in range(0, len(content), MAX_CHARS)
        ]
    
    def _extract_json_logical_chunks(self, file_path: str) -> List[Dict[str, Any]]:
        """JSON logical chunking."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                data = json.load(f)
            
            chunks = []
            MAX_JSON_CHARS = 3000
            
            if isinstance(data, list):
                for i, item in enumerate(data):
                    text = json.dumps(item, indent=2, ensure_ascii=False)
                    if len(text) > MAX_JSON_CHARS:
                        parts = [text[j:j+MAX_JSON_CHARS] for j in range(0, len(text), MAX_JSON_CHARS)]
                        for k, p in enumerate(parts):
                            chunks.append({"content": p, "metadata": {"index": i, "part": k, "type": "json_list_item"}})
                    else:
                        chunks.append({"content": text, "metadata": {"index": i, "type": "json_list_item"}})
            
            elif isinstance(data, dict):
                for key, value in data.items():
                    text = f'"{key}": ' + json.dumps(value, indent=2, ensure_ascii=False)
                    if len(text) > MAX_JSON_CHARS:
                        parts = [text[j:j+MAX_JSON_CHARS] for j in range(0, len(text), MAX_JSON_CHARS)]
                        for k, p in enumerate(parts):
                            chunks.append({"content": p, "metadata": {"key": key, "part": k, "type": "json_object_key"}})
                    else:
                        chunks.append({"content": text, "metadata": {"key": key, "type": "json_object_key"}})
            
            return chunks
        except Exception as e:
            logger.warning(f"Errore parsing JSON: {e}")
            return []
    
    def _extract_markdown_logical_chunks(self, file_path: str) -> List[Dict[str, Any]]:
        """Markdown header-based chunking."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            parts = re.split(r'(^#+\s+.*$)', content, flags=re.MULTILINE)
            
            chunks = []
            current_header = "Intro"
            MAX_MD_CHARS = 3000
            
            for part in parts:
                if not part.strip():
                    continue
                
                if part.strip().startswith('#'):
                    current_header = part.strip()
                    continue
                
                text_with_context = f"{current_header}\n\n{part.strip()}"
                
                if len(text_with_context) > MAX_MD_CHARS:
                    sub_parts = text_with_context.split('\n\n')
                    temp_chunk = ""
                    for sp in sub_parts:
                        if len(temp_chunk) + len(sp) < MAX_MD_CHARS:
                            temp_chunk += sp + "\n\n"
                        else:
                            if temp_chunk:
                                chunks.append({"content": temp_chunk.strip(), "metadata": {"section": current_header}})
                            temp_chunk = f"{current_header} (cont...)\n\n" + sp + "\n\n"
                    if temp_chunk:
                        chunks.append({"content": temp_chunk.strip(), "metadata": {"section": current_header}})
                else:
                    chunks.append({"content": text_with_context, "metadata": {"section": current_header}})
            
            return chunks
        except Exception as e:
            logger.warning(f"Errore parsing Markdown: {e}")
            return []
    
    async def ingest_prechunked_data(self, data_list: List[Dict[str, Any]], source_name: str, ref_id: str = "") -> Tuple[bool, str]:
        """Indicizza chunk già pronti con embedding paralleli a batch."""
        EMBED_BATCH_SIZE = 64
        MAX_CONCURRENT   = 3
        CHROMA_MAX_BATCH = 5000

        try:
            if not self.collection:
                return False, "Nessuna collezione attiva."

            contents = [item['content'] for item in data_list]
            raw_metas = [item.get('metadata', {}) for item in data_list]
            total_chunks = len(contents)

            # Batch embedding parallelo — embedd testo CON prefisso posizionale,
            # ma salva testo SENZA prefisso in ChromaDB (contesto LLM rimane pulito)
            prefixed_for_embed = [
                self._positional_prefix(i, total_chunks) + c
                for i, c in enumerate(contents)
            ]
            semaphore = asyncio.Semaphore(MAX_CONCURRENT)
            batches = [prefixed_for_embed[i:i+EMBED_BATCH_SIZE] for i in range(0, len(prefixed_for_embed), EMBED_BATCH_SIZE)]

            async def embed_batch(batch):
                async with semaphore:
                    return await self.chroma.get_embeddings_batch(batch)

            batch_results = await asyncio.gather(*[embed_batch(b) for b in batches])
            all_embeddings = [emb for batch in batch_results for emb in batch]

            # Filtra chunk con embedding fallito
            ts = int(time.time())
            ids, documents, embeddings, metadatas = [], [], [], []
            for i, (content, emb, meta) in enumerate(zip(contents, all_embeddings, raw_metas)):
                if emb is None:
                    logger.warning(f"Salto chunk {i} di {source_name}: embedding fallito.")
                    continue
                ids.append(f"{source_name}_{ts}_{i}")
                documents.append(content)
                embeddings.append(emb)
                full_meta = {"source": source_name, "ref": ref_id, "chunk_id": i, "total_chunks": total_chunks, "ingestion_type": "logical_chunking"}
                full_meta.update(meta)
                metadatas.append(full_meta)

            if not documents:
                return False, "Nessun nodo logico valido."

            # Insert ChromaDB a batch (evita il limite di 5461)
            for start in range(0, len(documents), CHROMA_MAX_BATCH):
                end = start + CHROMA_MAX_BATCH
                _s, _e = start, end  # capture for closure
                self._with_collection_retry(lambda s=_s, e=_e: self.collection.add(
                    ids=ids[s:e],
                    documents=documents[s:e],
                    embeddings=embeddings[s:e],
                    metadatas=metadatas[s:e],
                ))

            self.bm25.add_documents(source_name, documents, metadatas)
            return True, f"Indicizzati {len(documents)} nodi logici per {source_name}."

        except Exception as e:
            logger.error(f"Errore ingestion prechunked: {e}")
            return False, str(e)
    
    async def ingest_text(self, text: str, source_name: str, ref_id: str = "") -> Tuple[bool, str]:
        """
        Indicizza testo arbitrario con embedding paralleli a batch.

        Args:
            text: Testo da indicizzare
            source_name: Nome sorgente (filename)
            ref_id: ID riferimento

        Returns:
            (successo, messaggio)
        """
        EMBED_BATCH_SIZE = 64
        MAX_CONCURRENT   = 3
        CHROMA_MAX_BATCH = 5000

        try:
            chunks = self._create_chunks(text)
            total_chunks = len(chunks)
            logger.info(f"Creati {total_chunks} frammenti per '{source_name}'")

            if not chunks:
                return False, "Nessun chunk creato."

            # Batch embedding parallelo — embedd testo CON prefisso posizionale,
            # ma salva testo SENZA prefisso in ChromaDB (contesto LLM rimane pulito)
            prefixed_for_embed = [
                self._positional_prefix(i, total_chunks) + chunk
                for i, chunk in enumerate(chunks)
            ]
            semaphore = asyncio.Semaphore(MAX_CONCURRENT)
            batches = [prefixed_for_embed[i:i+EMBED_BATCH_SIZE] for i in range(0, len(prefixed_for_embed), EMBED_BATCH_SIZE)]

            async def embed_batch(batch):
                async with semaphore:
                    return await self.chroma.get_embeddings_batch(batch)

            batch_results = await asyncio.gather(*[embed_batch(b) for b in batches])
            all_embeddings = [emb for batch in batch_results for emb in batch]

            # Filtra chunk con embedding fallito
            ts = int(time.time())
            ids, documents, embeddings, metadatas = [], [], [], []
            for i, (chunk, emb) in enumerate(zip(chunks, all_embeddings)):
                if emb is None:
                    logger.warning(f"Salto chunk {i} di {source_name}: embedding fallito.")
                    continue
                ids.append(f"{source_name}_{ts}_{i}")
                documents.append(chunk)
                embeddings.append(emb)
                # Estrai numeri di pagina dai marker [PAGE:N] presenti nel chunk
                page_matches = re.findall(r'\[PAGE:(\d+)\]', chunk)
                page_start = int(page_matches[0]) if page_matches else 0
                page_end = int(page_matches[-1]) if len(page_matches) > 1 else page_start
                meta = {
                    "source": source_name,
                    "ref": ref_id,
                    "chunk_id": i,
                    "total_chunks": total_chunks,
                    "ingestion_type": "text_splitter",
                    "section": self._extract_section(chunk),
                    "heading": self._extract_heading(chunk),
                    "ingestion_timestamp": ts
                }
                if page_start > 0:
                    meta["page_start"] = page_start
                    meta["page_end"] = page_end
                metadatas.append(meta)

            if not documents:
                return False, "Nessun frammento indicizzato."

            # Insert ChromaDB a batch (evita il limite di 5461)
            for start in range(0, len(documents), CHROMA_MAX_BATCH):
                end = start + CHROMA_MAX_BATCH
                _s, _e = start, end
                self._with_collection_retry(lambda s=_s, e=_e: self.collection.add(
                    ids=ids[s:e],
                    documents=documents[s:e],
                    embeddings=embeddings[s:e],
                    metadatas=metadatas[s:e],
                ))

            self.bm25.add_documents(source_name, documents, metadatas)
            return True, f"Indicizzati {len(documents)} frammenti per {source_name}."

        except Exception as e:
            logger.error(f"Errore ingest_text: {e}")
            return False, str(e)
    
    def _extract_section(self, text: str) -> str:
        """Estrae la sezione dal testo (es: 'Articolo 1', 'Sezione 2.1')."""
        match = re.search(r'(?:Articolo|Art\.?|Sezione|Section|Capitolo)\s*(\d+[\.\d]*)', text, re.IGNORECASE)
        if match:
            return match.group(0)
        # Fallback: prima riga che sembra un titolo
        lines = text.strip().split('\n')
        for line in lines[:5]:
            line = line.strip()
            if line and len(line) < 80 and (line.startswith('#') or line.isupper()):
                return line.replace('#', '').strip()
        return "generic"

    def _extract_heading(self, text: str) -> str:
        """Estrae il heading più rilevante dal chunk."""
        # Markdown headings
        match = re.search(r'^#+\s+(.+)$', text, re.MULTILINE)
        if match:
            return match.group(1).strip()
        # Testo in maiuscolo
        match = re.search(r'^([A-Z][A-Z\s\-\.]{3,60})$', text, re.MULTILINE)
        if match:
            return match.group(1).strip()
        return ""

    @staticmethod
    def _positional_prefix(idx: int, total: int) -> str:
        """
        Genera un prefisso posizionale da anteporre al testo del chunk PRIMA
        dell'embedding (ma NON salvato in ChromaDB).
        Permette alla ricerca semantica di trovare chunk per posizione nel documento:
          "dall'inizio" / "beginning" → match con zone "opening"
          "verso la fine" / "ending"  → match con zone "closing"
        """
        ratio = idx / max(total - 1, 1)
        if ratio < 0.25:
            zone = "opening"
        elif ratio < 0.75:
            zone = "middle"
        else:
            zone = "closing"
        return f"[Section: {zone} | chunk {idx + 1}/{total}]\n"

    def _create_chunks(self, text: str, chunk_size: int = 1800, overlap: int = 150) -> List[str]:
        """
        Divide testo in chunk intelligenti per documenti legali/aziendali.
        - chunk_size 1800 chars (~450 token): mantiene articoli/clausole intere
        - overlap 150 chars: preserva il contesto al confine tra chunk
        - Rispetta boundary legali (Articolo, Art., Comma, Sezione, Capitolo)
        - Fallback a sentence boundary per testo generico
        """
        if not text:
            return []

        # --- Boundary detection per struttura legale ---
        legal_boundary = re.compile(
            r'(?=(?:Art(?:icolo|\.)\s*\d+|Comma\s*\d+|Sezione\s*\d+|Capitolo\s*\d+|§\s*\d+))',
            re.IGNORECASE
        )
        legal_parts = legal_boundary.split(text)

        # Se il documento ha struttura legale rilevata, usa quella come guida
        if len(legal_parts) > 2:
            segments = [p.strip() for p in legal_parts if p.strip()]
        else:
            # Fallback: split per paragrafi doppi, poi per frasi
            paragraphs = re.split(r'\n{2,}', text)
            segments = [p.strip() for p in paragraphs if p.strip()]

        chunks = []
        current_chunk = ""

        for segment in segments:
            # Se il segmento entra nel chunk corrente, aggiungilo
            if len(current_chunk) + len(segment) + 1 <= chunk_size:
                current_chunk += (" " if current_chunk else "") + segment
            else:
                # Chunk corrente pieno: salvalo
                if current_chunk.strip():
                    chunks.append(current_chunk.strip())

                # Segmento troppo lungo da solo? Spezzalo per frasi
                if len(segment) > chunk_size:
                    sentences = re.split(r'(?<=[.!?;])\s+', segment)
                    temp = ""
                    for sentence in sentences:
                        if len(temp) + len(sentence) + 1 <= chunk_size:
                            temp += (" " if temp else "") + sentence
                        else:
                            if temp.strip():
                                chunks.append(temp.strip())
                            # Se la singola frase supera chunk_size, spezza per parole
                            if len(sentence) > chunk_size:
                                words = sentence.split()
                                word_buf = ""
                                for word in words:
                                    if len(word_buf) + len(word) + 1 <= chunk_size:
                                        word_buf += (" " if word_buf else "") + word
                                    else:
                                        if word_buf.strip():
                                            chunks.append(word_buf.strip())
                                        word_buf = word
                                if word_buf.strip():
                                    temp = word_buf
                                else:
                                    temp = ""
                            else:
                                temp = sentence
                    if temp.strip():
                        current_chunk = temp
                    else:
                        current_chunk = ""
                else:
                    # Overlap: prendi gli ultimi `overlap` chars dal chunk precedente
                    if overlap > 0 and chunks:
                        overlap_text = chunks[-1][-overlap:]
                        # Tronca all'inizio di una parola per non spezzare mid-word
                        space_idx = overlap_text.find(' ')
                        if space_idx > 0:
                            overlap_text = overlap_text[space_idx + 1:]
                        current_chunk = overlap_text + " " + segment
                    else:
                        current_chunk = segment

        if current_chunk.strip():
            chunks.append(current_chunk.strip())

        return chunks
    
    async def query(self, query_text: str, top_k: int = 12, where_filter: Optional[Dict] = None) -> Dict:
        """
        Query semantica su ChromaDB.
        
        Args:
            query_text: Testo da cercare
            top_k: Numero risultati
            where_filter: Filtro ChromaDB (opzionale)
        
        Returns:
            Dict con documents, metadatas, distances
        """
        try:
            query_emb = await self.chroma.get_embedding(query_text)
            if query_emb is None:
                return {"documents": [], "metadatas": [], "distances": []}
            
            kwargs = {
                "query_embeddings": [query_emb],
                "n_results": top_k
            }
            
            if where_filter:
                kwargs["where"] = where_filter

            results = self._with_collection_retry(lambda: self.collection.query(**kwargs))
            return results
        
        except Exception as e:
            logger.error(f"Errore query: {e}")
            return {"documents": [], "metadatas": [], "distances": []}
    
    async def get_context(self, query: str, limit: int = 5) -> str:
        """
        Recupera contesto formattato per l'IA.
        
        Args:
            query: La query dell'utente
            limit: Numero di frammenti da recuperare
            
        Returns:
            Stringa con il contesto unito
        """
        try:
            results = await self.query(query, top_k=limit)
            
            if not results.get('documents') or not results['documents'][0]:
                return ""
                
            # Unisce i frammenti con un separatore leggibile (Legacy alignment)
            context = "\n\n--- FRAMMENTO ---\n" + "\n\n--- FRAMMENTO ---\n".join(results['documents'][0])
            return context
        except Exception as e:
            logger.error(f"Error in get_context: {e}")
            return ""

    def delete_file_from_db(self, filename: str):
        """Elimina file da ChromaDB."""
        try:
            results = self._with_collection_retry(lambda: self.collection.get(
                where={"source": filename},
                include=['metadatas'],
            ))

            if results and results.get('ids'):
                ids_to_delete = results['ids']
                self._with_collection_retry(lambda: self.collection.delete(ids=ids_to_delete))
                logger.info(f"Eliminati {len(ids_to_delete)} chunk per {filename}")

        except Exception as e:
            logger.error(f"Errore delete file {filename}: {e}")

    # ========================================================================
    # NUOVI PARSER — FASI 1-7 (USA/EU format support)
    # ========================================================================

    # --- FASE 1: HL7 FHIR (JSON + XML) ---
    def _parse_fhir_json(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Parser HL7 FHIR JSON Bundle.
        Estrae risorse per tipo: Patient, Observation, Condition, Medication,
        Encounter, CarePlan, Procedure, DiagnosticReport, AllergyIntolerance.
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                data = json.load(f)

            # Detect FHIR: root ha "resourceType": "Bundle" o "resourceType": "Patient" etc.
            resource_type = data.get('resourceType', '')
            if resource_type not in ('Bundle', 'Patient', 'Observation', 'Condition',
                                      'Medication', 'Encounter', 'Procedure', 'DiagnosticReport',
                                      'AllergyIntolerance', 'CarePlan', 'MedicationRequest',
                                      'MedicationAdministration', 'Immunization', 'Specimen',
                                      'List', 'Composition'):
                return []  # Non è FHIR

            chunks = []

            def extract_resource_text(res: Dict, parent_type: str = "") -> str:
                """Estrae testo leggibile da una risorsa FHIR."""
                parts = []
                rt = res.get('resourceType', 'Unknown')
                parts.append(f"Resource Type: {rt}")

                # ID
                if 'id' in res:
                    parts.append(f"ID: {res['id']}")

                # Patient info
                if rt == 'Patient' and 'name' in res:
                    for name in res['name']:
                        given = ' '.join(name.get('given', []))
                        family = name.get('family', '')
                        if given or family:
                            parts.append(f"Patient Name: {given} {family}")
                if rt == 'Patient' and 'gender' in res:
                    parts.append(f"Gender: {res['gender']}")
                if rt == 'Patient' and 'birthDate' in res:
                    parts.append(f"Birth Date: {res['birthDate']}")

                # Observation
                if rt == 'Observation':
                    code = res.get('code', {})
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Observation: {codings[0].get('display', codings[0].get('code', ''))}")
                    val = res.get('valueQuantity', {})
                    if val:
                        parts.append(f"Value: {val.get('value', '')} {val.get('unit', '')}")
                    elif 'valueString' in res:
                        parts.append(f"Value: {res['valueString']}")
                    if 'effectiveDateTime' in res:
                        parts.append(f"Date: {res['effectiveDateTime']}")

                # Condition
                if rt == 'Condition':
                    code = res.get('code', {})
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Condition: {codings[0].get('display', codings[0].get('code', ''))}")
                    if 'onsetDateTime' in res:
                        parts.append(f"Onset: {res['onsetDateTime']}")
                    if 'clinicalStatus' in res:
                        cs = res['clinicalStatus'].get('coding', [{}])
                        if cs:
                            parts.append(f"Status: {cs[0].get('code', '')}")

                # Medication/MedicationRequest
                if rt in ('Medication', 'MedicationRequest', 'MedicationAdministration'):
                    code = res.get('medicationCodeableConcept', res.get('code', {}))
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Medication: {codings[0].get('display', codings[0].get('code', ''))}")
                    if 'dosageInstruction' in res:
                        for d in res['dosageInstruction'][:2]:
                            if 'text' in d:
                                parts.append(f"Dosage: {d['text']}")

                # Encounter
                if rt == 'Encounter':
                    class_info = res.get('class', {})
                    parts.append(f"Encounter Class: {class_info.get('code', class_info.get('display', ''))}")
                    if 'period' in res:
                        p = res['period']
                        if 'start' in p:
                            parts.append(f"Start: {p['start']}")
                        if 'end' in p:
                            parts.append(f"End: {p['end']}")

                # Procedure
                if rt == 'Procedure':
                    code = res.get('code', {})
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Procedure: {codings[0].get('display', codings[0].get('code', ''))}")
                    if 'performedDateTime' in res:
                        parts.append(f"Date: {res['performedDateTime']}")

                # DiagnosticReport
                if rt == 'DiagnosticReport':
                    code = res.get('code', {})
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Report: {codings[0].get('display', codings[0].get('code', ''))}")
                    if 'conclusion' in res:
                        parts.append(f"Conclusion: {res['conclusion']}")
                    if 'effectiveDateTime' in res:
                        parts.append(f"Date: {res['effectiveDateTime']}")

                # AllergyIntolerance
                if rt == 'AllergyIntolerance':
                    code = res.get('code', {})
                    codings = code.get('coding', [])
                    if codings:
                        parts.append(f"Allergy: {codings[0].get('display', codings[0].get('code', ''))}")
                    if 'criticality' in res:
                        parts.append(f"Criticality: {res['criticality']}")

                # Meta
                if 'meta' in res and 'lastUpdated' in res['meta']:
                    parts.append(f"Last Updated: {res['meta']['lastUpdated']}")

                return '\n'.join(parts)

            if resource_type == 'Bundle':
                entries = data.get('entry', [])
                for i, entry in enumerate(entries):
                    res = entry.get('resource', {})
                    text = extract_resource_text(res, resource_type)
                    res_type = res.get('resourceType', 'Unknown')
                    chunks.append({
                        "content": text,
                        "metadata": {"tipo": "FHIR_Resource", "resource_type": res_type,
                                     "index": i, "domain": "clinical_fhir"}
                    })
            else:
                # Singola risorsa
                text = extract_resource_text(data)
                chunks.append({
                    "content": text,
                    "metadata": {"tipo": "FHIR_Resource", "resource_type": resource_type,
                                 "domain": "clinical_fhir"}
                })

            return chunks

        except Exception as e:
            logger.warning(f"FHIR JSON parser error: {e}")
            return []

    def _parse_fhir_xml(self, file_path: str) -> List[Dict[str, Any]]:
        """Parser HL7 FHIR XML Bundle."""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(500).decode('utf-8', errors='ignore')

            # Detect FHIR XML: namespace fhir="http://hl7.org/fhir"
            if 'hl7.org/fhir' not in header:
                return []

            tree = ET.parse(file_path)
            root = tree.getroot()
            ns = {'f': 'http://hl7.org/fhir'}

            chunks = []

            # Find all resources in Bundle
            entries = root.findall('.//f:entry', ns)
            if not entries:
                entries = [root]  # Single resource

            for i, entry in enumerate(entries):
                parts = []
                # Resource type
                child = list(entry)
                if child:
                    res_elem = child[0]
                    res_tag = res_elem.tag.split('}')[-1] if '}' in res_elem.tag else res_elem.tag
                    parts.append(f"Resource Type: {res_elem.tag}")

                    # Extract common elements
                    for elem_name in ['id', 'gender', 'birthDate', 'effectiveDateTime',
                                       'performedDateTime', 'conclusion', 'criticality']:
                        found = res_elem.find(f'.//f:{elem_name}', ns)
                        if found is not None and found.text:
                            parts.append(f"{elem_name}: {found.text}")

                    # Code elements
                    for code_elem in res_elem.findall('.//f:code', ns):
                        display = code_elem.find('.//f:display', ns)
                        if display is not None and display.text:
                            parts.append(f"Code: {display.text}")

                if parts:
                    chunks.append({
                        "content": '\n'.join(parts),
                        "metadata": {"tipo": "FHIR_XML", "index": i, "domain": "clinical_fhir"}
                    })

            return chunks

        except Exception as e:
            logger.warning(f"FHIR XML parser error: {e}")
            return []

    # --- FASE 2: HL7 v2 (pipe-delimited) ---
    def _parse_hl7_v2(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Parser HL7 v2.x messaggi (pipe-delimited).
        Segmenti: MSH (header), PID (paziente), PV1 (visita), OBX (osservazioni),
        ORC (ordini), RXA (somministrazioni), AL1 (allergie), DG1 (diagnosi).
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Detect HL7 v2: linee iniziano con MSH|, PID|, OBX|, etc.
            lines = content.strip().split('\n')
            if not any(line.startswith(('MSH|', 'MSH^')) for line in lines):
                return []

            chunks = []
            current_segment = ""
            segment_data = []

            # Segment descriptions for context
            segment_names = {
                'MSH': 'Message Header',
                'PID': 'Patient Identification',
                'PV1': 'Patient Visit',
                'PV2': 'Patient Visit Additional',
                'OBX': 'Observation Result',
                'ORC': 'Common Order',
                'OBR': 'Observation Request',
                'RXA': 'Pharmacy/Treatment Administration',
                'RXE': 'Pharmacy/Treatment Encoded Order',
                'AL1': 'Patient Allergy',
                'DG1': 'Diagnosis',
                'NTE': 'Notes and Comments',
                'NK1': 'Next of Kin',
                'IN1': 'Insurance',
                'GT1': 'Guarantor',
                'SAC': 'Specimen Container',
                'SPM': 'Specimen',
            }

            for line in lines:
                line = line.strip()
                if not line:
                    continue

                # Extract segment type (first 3 chars before | or ^)
                seg_type = line[:3] if len(line) >= 3 else ''

                if seg_type in segment_names or (seg_type.isalpha() and len(seg_type) == 3):
                    # New segment — save previous
                    if segment_data:
                        chunks.append({
                            "content": '\n'.join(segment_data),
                            "metadata": {"tipo": "HL7v2_Segment", "segment": segment_data[0][:3],
                                         "domain": "clinical_hl7v2"}
                        })
                    segment_data = [line]
                else:
                    # Continuation or unknown
                    segment_data.append(line)

            # Save last segment
            if segment_data:
                chunks.append({
                    "content": '\n'.join(segment_data),
                    "metadata": {"tipo": "HL7v2_Segment", "segment": segment_data[0][:3],
                                 "domain": "clinical_hl7v2"}
                })

            return chunks

        except Exception as e:
            logger.warning(f"HL7 v2 parser error: {e}")
            return []

    # --- FASE 3: XBRL ---
    def _parse_xbrl(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Parser XBRL (eXtensible Business Reporting Language).
        Usato da SEC (USA) e ESMA/ESEF (EU) per report finanziari.
        """
        try:
            with open(file_path, 'rb') as f:
                header = f.read(500).decode('utf-8', errors='ignore')

            if 'xbrl.org' not in header and '<xbrl' not in header.lower():
                return []

            tree = ET.parse(file_path)
            root = tree.getroot()

            # Build namespace map (stdlib ElementTree compatible)
            ns = {}
            for match in re.finditer(r'xmlns(:([^=]+))?="([^"]+)"', header):
                prefix = match.group(2) or 'xbrli'
                ns[prefix] = match.group(3)
            if not ns:
                ns = {'xbrli': 'http://www.xbrl.org/2003/instance'}

            chunks = []

            # Extract context definitions
            contexts = {}
            for ctx_elem in root.iter():
                tag = ctx_elem.tag.split('}')[-1] if '}' in ctx_elem.tag else ctx_elem.tag
                if tag == 'context':
                    ctx_id = ctx_elem.get('id', '')
                    ctx_parts = []
                    for sub in ctx_elem.iter():
                        st = sub.tag.split('}')[-1] if '}' in sub.tag else sub.tag
                        if st == 'identifier' and sub.text:
                            ctx_parts.append(f"Entity: {sub.text}")
                        if st == 'instant' and sub.text:
                            ctx_parts.append(f"Date: {sub.text}")
                        if st == 'startDate' and sub.text:
                            ctx_parts.append(f"Start: {sub.text}")
                        if st == 'endDate' and sub.text:
                            ctx_parts.append(f"End: {sub.text}")
                    contexts[ctx_id] = ', '.join(ctx_parts)

            # Extract units
            units = {}
            for u_elem in root.iter():
                tag = u_elem.tag.split('}')[-1] if '}' in u_elem.tag else u_elem.tag
                if tag == 'unit':
                    unit_id = u_elem.get('id', '')
                    for m in u_elem.iter():
                        mt = m.tag.split('}')[-1] if '}' in m.tag else m.tag
                        if mt == 'measure' and m.text:
                            units[unit_id] = m.text

            # Extract facts (any element with contextRef attribute)
            for child in root:
                ctx_ref = child.get('contextRef', '')
                if not ctx_ref:
                    continue

                tag = child.tag
                local_name = tag.split('}')[1] if '}' in tag else tag

                if local_name in ('schema', 'schemaRef', 'context', 'unit', 'linkbase',
                                   'roleRef', 'arcroleRef'):
                    continue

                value = (child.text or '').strip()
                if not value:
                    continue

                parts = [f"Fact: {local_name}", f"Value: {value}"]
                if ctx_ref in contexts:
                    parts.append(f"Context: {contexts[ctx_ref]}")
                unit_ref = child.get('unitRef', '')
                if unit_ref in units:
                    parts.append(f"Unit: {units[unit_ref]}")
                decimals = child.get('decimals', '')
                if decimals:
                    parts.append(f"Decimals: {decimals}")

                chunks.append({
                    "content": '\n'.join(parts),
                    "metadata": {"tipo": "XBRL_Fact", "fact_name": local_name,
                                 "context": ctx_ref, "domain": "financial_xbrl"}
                })

            return chunks

        except Exception as e:
            logger.warning(f"XBRL parser error: {e}")
            return []

    # --- FASE 4+5: EDIFACT / X12 EDI ---
    def _parse_edi_file(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Parser universale per EDIFACT e X12 EDI.
        Rileva automaticamente il formato e estrae transazioni/segmenti.
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            chunks = []

            # Detect EDIFACT: starts with UNA or UNB
            if content.startswith('UNA') or content.startswith('UNB'):
                return self._parse_edifact(content)

            # Detect X12: starts with ISA
            if content.startswith('ISA'):
                return self._parse_x12(content)

            return []

        except Exception as e:
            logger.warning(f"EDI parser error: {e}")
            return []

    def _parse_edifact(self, content: str) -> List[Dict[str, Any]]:
        """Parser EDIFACT messages."""
        chunks = []
        segments = content.strip().split("'")

        current_msg = []
        msg_id = 0

        for seg in segments:
            seg = seg.strip()
            if not seg:
                continue

            # New message starts with UNB
            if seg.startswith('UNB'):
                if current_msg:
                    chunks.append({
                        "content": '\n'.join(current_msg),
                        "metadata": {"tipo": "EDIFACT_Message", "msg_id": msg_id,
                                     "domain": "edi_edifact"}
                    })
                    msg_id += 1
                current_msg = [seg]
            elif seg.startswith('UNZ'):
                # End of message
                current_msg.append(seg)
                chunks.append({
                    "content": '\n'.join(current_msg),
                    "metadata": {"tipo": "EDIFACT_Message", "msg_id": msg_id,
                                 "domain": "edi_edifact"}
                })
                msg_id += 1
                current_msg = []
            else:
                current_msg.append(seg)

        # Handle last message
        if current_msg:
            chunks.append({
                "content": '\n'.join(current_msg),
                "metadata": {"tipo": "EDIFACT_Message", "msg_id": msg_id,
                             "domain": "edi_edifact"}
            })

        return chunks

    def _parse_x12(self, content: str) -> List[Dict[str, Any]]:
        """Parser X12 EDI transactions."""
        chunks = []
        segments = content.strip().split('~')

        current_txn = []
        txn_id = 0
        txn_type = ""

        for seg in segments:
            seg = seg.strip()
            if not seg:
                continue

            seg_id = seg.split('*')[0] if '*' in seg else seg[:3]

            if seg_id == 'ISA':
                if current_txn:
                    chunks.append({
                        "content": '\n'.join(current_txn),
                        "metadata": {"tipo": "X12_Transaction", "txn_id": txn_id,
                                     "transaction_type": txn_type, "domain": "edi_x12"}
                    })
                    txn_id += 1
                current_txn = [seg]
                txn_type = ""
            elif seg_id == 'ST':
                # Transaction set header — extract type
                parts = seg.split('*')
                if len(parts) >= 2:
                    txn_type = parts[1]  # e.g., 837, 835, 850
                current_txn.append(seg)
            elif seg_id == 'SE':
                current_txn.append(seg)
            elif seg_id == 'GE' or seg_id == 'IEA':
                current_txn.append(seg)
                chunks.append({
                    "content": '\n'.join(current_txn),
                    "metadata": {"tipo": "X12_Transaction", "txn_id": txn_id,
                                 "transaction_type": txn_type, "domain": "edi_x12"}
                })
                txn_id += 1
                current_txn = []
            else:
                current_txn.append(seg)

        if current_txn:
            chunks.append({
                "content": '\n'.join(current_txn),
                "metadata": {"tipo": "X12_Transaction", "txn_id": txn_id,
                             "transaction_type": txn_type, "domain": "edi_x12"}
            })

        return chunks

    # --- FASE 6: Email (.eml) ---
    def _parse_email_file(self, file_path: str) -> List[Dict[str, Any]]:
        """Parser file email .eml usando stdlib email."""
        try:
            import email
            from email import policy

            with open(file_path, 'rb') as f:
                msg = email.message_from_binary_file(f, policy=policy.default)

            chunks = []
            parts_text = []

            # Headers
            headers = {
                'From': msg.get('From', ''),
                'To': msg.get('To', ''),
                'Cc': msg.get('Cc', ''),
                'Subject': msg.get('Subject', ''),
                'Date': msg.get('Date', ''),
                'Message-ID': msg.get('Message-ID', ''),
            }

            header_text = '\n'.join(f"{k}: {v}" for k, v in headers.items() if v)

            # Body
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    if content_type == 'text/plain':
                        payload = part.get_payload(decode=True)
                        if payload:
                            charset = part.get_content_charset() or 'utf-8'
                            parts_text.append(payload.decode(charset, errors='replace'))
                    elif content_type == 'text/html':
                        payload = part.get_payload(decode=True)
                        if payload:
                            charset = part.get_content_charset() or 'utf-8'
                            text = payload.decode(charset, errors='replace')
                            # Simple HTML strip
                            import re
                            text = re.sub(r'<[^>]+>', '', text)
                            parts_text.append(text)
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    charset = msg.get_content_charset() or 'utf-8'
                    text = payload.decode(charset, errors='replace')
                    import re
                    text = re.sub(r'<[^>]+>', '', text)
                    parts_text.append(text)

            body_text = '\n\n'.join(parts_text)

            # Attachments info
            attachments = []
            for part in msg.walk():
                if part.get_content_maintype() == 'multipart':
                    continue
                filename = part.get_filename()
                if filename:
                    attachments.append(f"Attachment: {filename} ({part.get_content_type()})")

            full_text = header_text + '\n\n' + body_text
            if attachments:
                full_text += '\n\n' + '\n'.join(attachments)

            chunks.append({
                "content": full_text,
                "metadata": {"tipo": "Email", "from": headers['From'],
                             "to": headers['To'], "subject": headers['Subject'],
                             "date": headers['Date'], "domain": "email"}
            })

            return chunks

        except Exception as e:
            logger.warning(f"Email parser error: {e}")
            return []

    # --- FASE 7: ODT ---
    def _extract_odt_text(self, file_path: str) -> str:
        """Estrae testo da ODT (OpenDocument Text)."""
        try:
            if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
                return ""
            if not zipfile.is_zipfile(file_path):
                return ""

            with zipfile.ZipFile(file_path) as z:
                if 'content.xml' not in z.namelist():
                    return ""
                xml_content = z.read('content.xml')
                tree = ET.fromstring(xml_content)
                # Namespace ODF
                ns = {'text': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0',
                      'p': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'}
                paragraphs = []
                for elem in tree.iter():
                    tag = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                    if tag == 'p' and elem.text:
                        paragraphs.append(elem.text)
                    if elem.text and tag not in ('p',):
                        paragraphs.append(elem.text)
                return '\n\n'.join(paragraphs)
        except Exception as e:
            logger.error(f"ODT extraction error: {e}")
            return ""

    # --- FASE 7: RTF ---
    def _extract_rtf_text(self, file_path: str) -> str:
        """Estrae testo da RTF (Rich Text Format)."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            if not content.startswith('{\\rtf'):
                return ""

            # Simple RTF text extraction: remove control words
            import re
            # Remove control words (\word or \word123)
            text = re.sub(r'\\[a-zA-Z]+-?\d*\s?', ' ', content)
            # Remove braces
            text = text.replace('{', '').replace('}', '')
            # Remove special chars
            text = re.sub(r'\\[\'"][0-9a-fA-F]{2}', ' ', text)
            # Collapse whitespace
            text = re.sub(r'\s+', ' ', text).strip()

            return text
        except Exception as e:
            logger.error(f"RTF extraction error: {e}")
            return ""

    def reset_database(self):
        """Reset completo collezione."""
        try:
            self.chroma.client.delete_collection(self.collection_name)
            self.collection = self.chroma.client.get_or_create_collection(name=self.collection_name)
            logger.info("Database reset completo")
        except Exception as e:
            logger.error(f"Errore reset database: {e}")
