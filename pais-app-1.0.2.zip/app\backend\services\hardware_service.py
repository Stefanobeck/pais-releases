"""
Hardware Service - Cross-platform CPU/RAM/GPU/VRAM detection.

Strategy:
- CPU/RAM: psutil (mandatory dep). Model name via platform.processor()
  with platform-specific fallbacks.
- GPU/VRAM: try pynvml first (NVIDIA, most reliable). Fall back to:
    Win    -> wmic path win32_VideoController
    macOS  -> system_profiler SPDisplaysDataType -json
    Linux  -> nvidia-smi --query-gpu / lspci
- Apple Silicon: VRAM = total RAM (unified memory). HIGH threshold = 24GB RAM.

Recommended profile heuristic:
    HIGH if VRAM >= 12GB (or RAM >= 24GB on Apple Silicon)
    LOW  otherwise

Cached per-process for 60 seconds (hardware doesn't change at runtime).
"""
import json
import logging
import platform
import re
import subprocess
import sys
import time
from typing import Any, Dict, Optional

logger = logging.getLogger("PAIS.Hardware")

_CACHE: Dict[str, Any] = {"data": None, "ts": 0.0}
_CACHE_TTL_SECONDS = 60.0

VRAM_HIGH_THRESHOLD_GB = 12.0
APPLE_RAM_HIGH_THRESHOLD_GB = 24.0

# Soglie verdict — i modelli LLM richiedono GPU dedicata su non-Apple per latenza
# accettabile. Sotto VRAM 8 GB o RAM 16 GB → MARGINALE. Apple Silicon usa RAM
# unificata come VRAM, quindi gestito separatamente con soglie più alte.
VERDICT_OTTIMO_VRAM_GB = 16.0
VERDICT_OTTIMO_APPLE_RAM_GB = 32.0
VERDICT_ADEGUATO_VRAM_GB = 8.0
VERDICT_ADEGUATO_APPLE_RAM_GB = 24.0
VERDICT_MIN_RAM_GB = 16.0  # RAM minima per qualunque tier non-MARGINALE su path GPU


def _detect_ollama_version() -> Optional[str]:
    """Versione del bin Ollama BUNDLATO con l'app (non quello di sistema).
    Usa settings.OLLAMA_BIN_PATH. Esegue --version, parse prima riga
    'ollama version is X.Y.Z'. Ritorna None se non disponibile.
    """
    try:
        from backend_config import settings as app_settings
        bin_path = getattr(app_settings, "OLLAMA_BIN_PATH", None)
        if not bin_path:
            return None
        from pathlib import Path
        bin_path = Path(bin_path)
        if not bin_path.exists():
            return None
        out = subprocess.check_output(
            [str(bin_path), "--version"],
            stderr=subprocess.STDOUT, timeout=3.0,
        ).decode("utf-8", errors="ignore")
        # Output varia in base allo stato del server:
        #   - serve attivo:  "ollama version is 0.23.1\nWarning: server version is ..."
        #   - serve down:    "Warning: could not connect ...\nWarning: client version is 0.21.2"
        # Su PC pulito post-install il server PAIS non è ancora partito quando
        # questa funzione viene chiamata → matchiamo anche "client version is".
        m = re.search(r"version is\s+(\d+\.\d+\.\d+(?:[\w.+-]*)?)", out, re.IGNORECASE)
        if m:
            return m.group(1)
        return None
    except Exception as e:
        logger.warning(f"ollama version detection failed: {e}")
        return None


def _round_gb(bytes_value: float) -> float:
    return round(bytes_value / (1024 ** 3), 1)


def _is_branded_cpu_string(s: str) -> bool:
    """True only when the string looks like a marketing brand (Intel Core i7, AMD Ryzen, etc.).
    platform.processor() on Windows often returns 'Intel64 Family 6 Model 167 Stepping 1, GenuineIntel'
    which is technically valid but useless for the user — we want the brand string from wmic instead.
    """
    if not s:
        return False
    sl = s.lower()
    branded_markers = (
        "intel(r)", "core(tm)", "ryzen", "epyc", "xeon", "celeron", "pentium",
        "atom", "i3-", "i5-", "i7-", "i9-", "ultra ", "apple m", "snapdragon",
        "ampere", "graviton", "threadripper",
    )
    return any(m in sl for m in branded_markers)


def _detect_cpu() -> Dict[str, Any]:
    import psutil
    model = platform.processor() or ""
    if not _is_branded_cpu_string(model):
        # platform.processor() returned arch metadata — replace with the marketing brand string.
        if sys.platform == "linux":
            try:
                with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
                    for line in f:
                        if line.startswith("model name"):
                            model = line.split(":", 1)[1].strip()
                            break
            except Exception:
                pass
        elif sys.platform == "darwin":
            try:
                out = subprocess.check_output(
                    ["sysctl", "-n", "machdep.cpu.brand_string"],
                    stderr=subprocess.DEVNULL, timeout=2.0
                ).decode("utf-8", errors="ignore").strip()
                if out:
                    model = out
            except Exception:
                pass
        elif sys.platform == "win32":
            # platform.processor() on Windows usually returns the brand string already,
            # but if empty fall back to wmic.
            try:
                out = subprocess.check_output(
                    ["wmic", "cpu", "get", "Name", "/value"],
                    stderr=subprocess.DEVNULL, timeout=3.0
                ).decode("utf-8", errors="ignore")
                m = re.search(r"Name=(.+)", out)
                if m:
                    model = m.group(1).strip()
            except Exception:
                pass

    return {
        "model": model or "Unknown CPU",
        "cores": psutil.cpu_count(logical=False) or 0,
        "threads": psutil.cpu_count(logical=True) or 0,
        "arch": platform.machine() or "",
    }


def _detect_ram() -> Dict[str, Any]:
    import psutil
    vm = psutil.virtual_memory()
    return {
        "total_gb": _round_gb(vm.total),
        "available_gb": _round_gb(vm.available),
    }


def _gpu_via_pynvml() -> Optional[Dict[str, Any]]:
    try:
        import pynvml  # type: ignore
        pynvml.nvmlInit()
        try:
            count = pynvml.nvmlDeviceGetCount()
            if count <= 0:
                return None
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8", errors="ignore")
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            return {
                "vendor": "NVIDIA",
                "model": name,
                "vram_gb": _round_gb(mem.total),
                "detected_via": "pynvml",
            }
        finally:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass
    except Exception as e:
        logger.debug(f"pynvml unavailable: {e}")
        return None


def _gpu_via_nvidia_smi() -> Optional[Dict[str, Any]]:
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            stderr=subprocess.DEVNULL, timeout=3.0
        ).decode("utf-8", errors="ignore").strip()
        if not out:
            return None
        first = out.splitlines()[0]
        parts = [p.strip() for p in first.split(",")]
        if len(parts) < 2:
            return None
        name = parts[0]
        # memory.total in MiB
        try:
            mib = float(parts[1])
        except ValueError:
            return None
        return {
            "vendor": "NVIDIA",
            "model": name,
            "vram_gb": round(mib / 1024.0, 1),
            "detected_via": "nvidia-smi",
        }
    except Exception:
        return None


def _gpu_via_wmic() -> Optional[Dict[str, Any]]:
    """Windows fallback for non-NVIDIA (AMD, Intel) GPUs."""
    try:
        out = subprocess.check_output(
            ["wmic", "path", "win32_VideoController", "get",
             "Name,AdapterRAM,DriverVersion", "/format:list"],
            stderr=subprocess.DEVNULL, timeout=3.0
        ).decode("utf-8", errors="ignore")
    except Exception:
        return None

    blocks = [b for b in out.split("\r\r\n\r\r\n") if b.strip()]
    # Pick the GPU with the largest AdapterRAM (filter virtual / Microsoft Basic Display).
    best: Optional[Dict[str, Any]] = None
    for block in blocks:
        fields: Dict[str, str] = {}
        for line in block.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                fields[k.strip()] = v.strip()
        name = fields.get("Name", "")
        ram_str = fields.get("AdapterRAM", "")
        if not name or "Microsoft Basic" in name or "Remote" in name:
            continue
        try:
            ram_bytes = int(ram_str) if ram_str else 0
        except ValueError:
            ram_bytes = 0
        # AdapterRAM is uint32: capped at 4GB on cards with more — unreliable for VRAM.
        # We still keep it as a coarse hint.
        vendor = "Unknown"
        nl = name.lower()
        if "nvidia" in nl or "geforce" in nl or "rtx" in nl or "gtx" in nl:
            vendor = "NVIDIA"
        elif "amd" in nl or "radeon" in nl:
            vendor = "AMD"
        elif "intel" in nl:
            vendor = "Intel"
        candidate = {
            "vendor": vendor,
            "model": name,
            "vram_gb": _round_gb(ram_bytes) if ram_bytes else None,
            "detected_via": "wmic",
        }
        if best is None or (candidate.get("vram_gb") or 0) > (best.get("vram_gb") or 0):
            best = candidate
    return best


def _gpu_via_system_profiler() -> Optional[Dict[str, Any]]:
    """macOS GPU detection (Apple Silicon = unified memory)."""
    try:
        out = subprocess.check_output(
            ["system_profiler", "SPDisplaysDataType", "-json"],
            stderr=subprocess.DEVNULL, timeout=5.0
        ).decode("utf-8", errors="ignore")
        data = json.loads(out)
    except Exception:
        return None

    displays = data.get("SPDisplaysDataType") or []
    if not displays:
        return None
    g = displays[0]
    name = g.get("sppci_model") or g.get("_name") or "Apple GPU"
    vendor = "Apple" if "apple" in name.lower() or "m1" in name.lower() or "m2" in name.lower() or "m3" in name.lower() or "m4" in name.lower() else "Unknown"
    # Discrete VRAM (rare on modern Macs): "spdisplays_vram"; e.g. "8 GB"
    vram_gb: Optional[float] = None
    vram_raw = g.get("spdisplays_vram") or g.get("spdisplays_vram_shared")
    if isinstance(vram_raw, str):
        m = re.match(r"\s*([\d.]+)\s*(GB|MB)\s*", vram_raw, re.IGNORECASE)
        if m:
            n = float(m.group(1))
            unit = m.group(2).upper()
            vram_gb = n if unit == "GB" else round(n / 1024.0, 1)
    return {
        "vendor": vendor,
        "model": name,
        "vram_gb": vram_gb,  # may be None on Apple Silicon (unified memory handled below)
        "detected_via": "system_profiler",
    }


def _gpu_via_lspci() -> Optional[Dict[str, Any]]:
    """Linux last-resort: list VGA controllers, no VRAM info."""
    try:
        out = subprocess.check_output(
            ["lspci"], stderr=subprocess.DEVNULL, timeout=2.0
        ).decode("utf-8", errors="ignore")
    except Exception:
        return None
    for line in out.splitlines():
        if "VGA" in line or "3D controller" in line:
            name = line.split(":", 2)[-1].strip()
            nl = name.lower()
            vendor = "NVIDIA" if "nvidia" in nl else "AMD" if "amd" in nl or "radeon" in nl else "Intel" if "intel" in nl else "Unknown"
            return {
                "vendor": vendor,
                "model": name,
                "vram_gb": None,
                "detected_via": "lspci",
            }
    return None


def _detect_gpu(ram_total_gb: float) -> Dict[str, Any]:
    """Return GPU info dict. vram_gb may be None when undetectable."""
    # 1) NVIDIA via pynvml (best signal, exact VRAM)
    g = _gpu_via_pynvml()
    if g:
        return g
    # 2) NVIDIA via nvidia-smi CLI
    g = _gpu_via_nvidia_smi()
    if g:
        return g
    # 3) Platform-specific
    if sys.platform == "win32":
        g = _gpu_via_wmic()
        if g:
            return g
    elif sys.platform == "darwin":
        g = _gpu_via_system_profiler()
        if g:
            # Apple Silicon: unified memory — report RAM as VRAM proxy.
            if (g.get("vram_gb") in (None, 0)) and g.get("vendor") == "Apple":
                g["vram_gb"] = ram_total_gb
                g["detected_via"] = "system_profiler+unified_memory"
            return g
    elif sys.platform == "linux":
        g = _gpu_via_lspci()
        if g:
            return g
    return {
        "vendor": "Unknown",
        "model": "Unknown GPU",
        "vram_gb": None,
        "detected_via": "none",
    }


def _recommend_profile(gpu: Dict[str, Any], ram_total_gb: float) -> str:
    """Mantenuto SOLO per backward compat (vecchi caller). Il sistema profili
    HIGH/LOW è stato rimosso — il nuovo path è `_compute_verdict()`."""
    vendor = (gpu.get("vendor") or "").lower()
    vram = gpu.get("vram_gb")
    if vendor == "apple":
        return "HIGH" if ram_total_gb >= APPLE_RAM_HIGH_THRESHOLD_GB else "LOW"
    if vram is None:
        return "LOW"
    return "HIGH" if vram >= VRAM_HIGH_THRESHOLD_GB else "LOW"


# Testi verdict in IT + EN. Tre tier: OTTIMO / ADEGUATO / MARGINALE.
# Frontend sceglie il testo in base alla lingua attiva.
_VERDICT_TEXTS = {
    "OTTIMO": {
        "it": (
            "Hardware eccellente. PAIS gira al massimo su tutti i moduli, anche con "
            "file grandi e analisi complesse. Nessun compromesso di performance."
        ),
        "en": (
            "Excellent hardware. PAIS runs at full performance across all modules, "
            "even with large files and complex analyses. No performance trade-offs."
        ),
    },
    "ADEGUATO": {
        "it": (
            "Hardware adeguato. PAIS gira bene per uso quotidiano su tutti i moduli. "
            "Su query complesse o file molto grandi alcune risposte potrebbero richiedere "
            "qualche secondo in più."
        ),
        "en": (
            "Adequate hardware. PAIS runs well for everyday use across all modules. "
            "On complex queries or very large files some responses may take a few extra seconds."
        ),
    },
    "MARGINALE": {
        "it": (
            "Hardware sotto i requisiti consigliati. PAIS funzionerà ma l'esperienza "
            "sarà molto lenta: la generazione delle risposte e l'analisi di file grandi "
            "potrebbero richiedere minuti invece di secondi. Lo spazio disco richiesto "
            "(~50 GB) potrebbe inoltre essere problematico. Considera un upgrade di RAM "
            "e/o GPU per un'esperienza fluida."
        ),
        "en": (
            "Hardware below recommended requirements. PAIS will work but the experience "
            "will be very slow: response generation and large-file analysis may take "
            "minutes instead of seconds. The required disk space (~50 GB) may also be "
            "problematic. Consider a RAM and/or GPU upgrade for a smooth experience."
        ),
    },
}


def _compute_verdict(gpu: Dict[str, Any], ram_total_gb: float) -> Dict[str, Any]:
    """Valuta l'hardware su 3 tier basati su VRAM dedicata + RAM totale.

    Tiering:
    - OTTIMO:   (VRAM ≥ 16 GB E RAM ≥ 16 GB) oppure (Apple Silicon + RAM ≥ 32 GB)
    - ADEGUATO: (VRAM ≥ 8 GB E RAM ≥ 16 GB) oppure (Apple Silicon + RAM ≥ 24 GB)
    - MARGINALE: nessuna GPU dedicata su non-Apple, OPPURE VRAM < 8 GB,
                 OPPURE RAM < 16 GB. PAIS funziona ma molto lentamente — i modelli
                 LLM richiedono accelerazione GPU per latenza accettabile.
    """
    vendor = (gpu.get("vendor") or "").lower()
    vram = gpu.get("vram_gb")

    tier: str
    if vendor == "apple":
        # Apple Silicon: la RAM unificata fa da VRAM, quindi una RAM elevata basta.
        if ram_total_gb >= VERDICT_OTTIMO_APPLE_RAM_GB:
            tier = "OTTIMO"
        elif ram_total_gb >= VERDICT_ADEGUATO_APPLE_RAM_GB:
            tier = "ADEGUATO"
        else:
            tier = "MARGINALE"
    elif vram is not None and ram_total_gb >= VERDICT_MIN_RAM_GB:
        # GPU dedicata su non-Apple + RAM sopra la soglia minima.
        if vram >= VERDICT_OTTIMO_VRAM_GB:
            tier = "OTTIMO"
        elif vram >= VERDICT_ADEGUATO_VRAM_GB:
            tier = "ADEGUATO"
        else:
            tier = "MARGINALE"
    else:
        # Nessuna GPU dedicata (su non-Apple) oppure RAM < 16 GB.
        # I modelli LLM richiedono GPU per essere usabili senza latenze enormi.
        tier = "MARGINALE"

    texts = _VERDICT_TEXTS[tier]
    return {
        "tier": tier,
        "text_it": texts["it"],
        "text_en": texts["en"],
    }


def detect_hardware(force_refresh: bool = False) -> Dict[str, Any]:
    """Public entrypoint. Cached for 60s."""
    now = time.monotonic()
    if not force_refresh and _CACHE["data"] is not None and (now - _CACHE["ts"]) < _CACHE_TTL_SECONDS:
        return _CACHE["data"]

    warnings: list = []
    try:
        cpu = _detect_cpu()
    except Exception as e:
        logger.error(f"CPU detection failed: {e}")
        cpu = {"model": "Unknown CPU", "cores": 0, "threads": 0, "arch": ""}
        warnings.append(f"cpu_detection_failed: {e}")
    try:
        ram = _detect_ram()
    except Exception as e:
        logger.error(f"RAM detection failed: {e}")
        ram = {"total_gb": 0.0, "available_gb": 0.0}
        warnings.append(f"ram_detection_failed: {e}")
    try:
        gpu = _detect_gpu(ram.get("total_gb", 0.0))
    except Exception as e:
        logger.error(f"GPU detection failed: {e}")
        gpu = {"vendor": "Unknown", "model": "Unknown GPU", "vram_gb": None, "detected_via": "error"}
        warnings.append(f"gpu_detection_failed: {e}")

    recommended = _recommend_profile(gpu, ram.get("total_gb", 0.0))
    verdict = _compute_verdict(gpu, ram.get("total_gb", 0.0))

    ollama_version = _detect_ollama_version()

    data = {
        "platform": sys.platform,
        "cpu": cpu,
        "ram": ram,
        "gpu": gpu,
        "ollama_version": ollama_version,
        "recommended_profile": recommended,  # deprecato, lasciato per backward compat
        "verdict": verdict,
        "detection_warnings": warnings,
    }
    _CACHE["data"] = data
    _CACHE["ts"] = now
    return data
