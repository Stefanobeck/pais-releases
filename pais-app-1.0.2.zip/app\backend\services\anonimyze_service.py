"""
Anonimyze Service - Robust Port with Batch Processing & Streaming
GDPR-Hardened with full legacy pattern support and surgical tabular protection.
"""
import os
import json
import asyncio
import logging
import time
import re
import sqlite3
import base64
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Callable, AsyncGenerator

import spacy
import pandas as pd
import pypdf
from docx import Document
from langdetect import detect, DetectorFactory
from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern, RecognizerRegistry
from presidio_analyzer.nlp_engine import SpacyNlpEngine
from PIL import Image

from backend_config.settings import BASE_DIR
from backend_config.project_manager import project_manager
from services.i18n_service import i18n
from services.ner import get_ner_engine, PiiNerRecognizer
from services.anonimyze_patterns import (
    JURISDICTION_PATTERNS,
    COUNTRY_TO_LANG,
    LANG_TO_DEFAULT_COUNTRY,
)

DetectorFactory.seed = 0
logger = logging.getLogger(__name__)

# SILENCE NOISY LOGS
logging.getLogger("presidio-analyzer").setLevel(logging.ERROR)
logging.getLogger("spacy").setLevel(logging.ERROR)

ENTITY_PREFIX_MAP = {
    "PERSON":         "PERS",
    "ORGANIZATION":   "ORG",
    "LOCATION":       "LOC",
    "PHONE_NUMBER":   "TEL",
    "PHONE_INTL":     "TEL",
    "EMAIL_ADDRESS":  "EMAIL",
    "IBAN_CODE":      "IBAN",
    "CREDIT_CARD":    "CC",
    "IP_ADDRESS":     "IP",
    "DATE_TIME":      "DATA",
    "DATE_ISO":       "DATA",
    "DATE_EU":        "DATA",
    "DATE_US":        "DATA",
    "NRP":            "NAZ",
    "URL":            "URL",
    "SWIFT_BIC":      "SWIFT",
    "MEDICAL":        "MED",
    "SENSITIVE":      "SENS",
    "ADDRESS_IT":     "ADDR",
    # Italy
    "IT_FISCAL_CODE": "CF",
    "IT_VAT_CODE":    "PIVA",
    "LICENSE_PLATE":  "TARGA",
    "IT_CIE":         "CIE",
    "IT_REA":         "REA",
    "IT_TESSERA_SANITARIA": "TSAN",
    # Italy — categorie aggiunte 2026-05-13 per atti notarili / finanziari.
    # LEGAL_REF: blacklist (riferimenti normativi pubblici — nessun prefix
    # perché non viene mai sostituito; vedi skip nella anonymize loop).
    "LEGAL_REF":      "LEGAL",   # placeholder unused, ma serve nel map per gli stat
    "NOTAIO_REP":     "DOC",     # Rep./Racc. notarili
    "CATASTO":        "CATASTO", # foglio/mappale/subalterno
    "ACCT":           "ACCT",    # numeri conto / libretto (distinto da TEL)
    "CURRENCY":       "EUR",     # importi monetari €/EUR/euro
    # Universale italiano (corpus atti notarili/civili/sanitari/amministrativi)
    "IT_POSTAL_CODE": "CAP",     # 5 cifre + città
    "IT_PROT":        "PROT",    # Prot. n. AAAA/NNNN
    "IT_JUDICIAL_REF":"RG",      # R.G., Sent. n., Proc. pen. n.
    "IT_CARTELLA_AE": "CART",    # Cartella di pagamento AdE
    "IT_INPS":        "INPS",    # matricola INPS
    "IT_INAIL":       "INAIL",   # posizione INAIL
    "IT_INSURANCE_POLICY": "POL",# polizza assicurativa
    "IT_DRIVER_LICENSE":"PAT",   # patente di guida italiana
    "VEHICLE_VIN":    "VIN",     # numero telaio (17 char ISO 3779)
    "MEDICAL_ICD":    "ICD",     # codice diagnosi ICD-10 (dato sanitario)
    # USA
    "US_SSN":         "SSN",
    "US_ITIN":        "ITIN",
    "US_PASSPORT":    "USPS",
    "US_DRIVERS_LICENSE": "DL",
    "US_EIN":         "EIN",
    "US_BANK_ROUTING": "ROUTE",
    "US_BANK_ACCOUNT": "BANK",
    "US_MEDICARE":    "MCARE",
    "US_STATE_ZIP":   "ADDR",
    "US_ADDRESS":     "ADDR",
    # UK
    "UK_NINO":        "NINO",
    "UK_NHS":         "NHS",
    "UK_PASSPORT":    "UKPS",
    # India
    "IN_AADHAAR":     "AADH",
    "IN_PAN":         "PAN",
    "IN_PASSPORT":    "INPS",
    # Singapore
    "SG_NRIC":        "NRIC",
    # Australia
    "AU_TFN":         "TFN",
    "AU_MEDICARE":    "MED",
    "AU_DRIVERS_LICENSE": "AUDL",
    # New Zealand
    "NZ_IRD":         "IRD",
    # China
    "CN_RESIDENT_ID": "RID",
    # Japan
    "JP_MY_NUMBER":   "MYNO",
    "JP_PASSPORT":    "JPPS",
    # Spain
    "ES_DNI":         "DNI",
    "ES_NIE":         "NIE",
    "ES_VAT":         "VATES",
    # Latin America
    "AR_CUIT":        "CUIT",
    "AR_DNI":         "DNIA",
    "CL_RUT":         "RUT",
    "CO_CEDULA":      "CED",
    "MX_CURP":        "CURP",
    "MX_RFC":         "RFC",
    # Brazil
    "BR_CPF":         "CPF",
    "BR_CNPJ":        "CNPJ",
    "BR_RG":          "RG",
    "BR_PIS":         "PIS",
    # Portugal
    "PT_NIF":         "NIF",
    "PT_CC":          "CC",
    # France
    "FR_SIRET":       "SIRET",
    "FR_SIREN":       "SIREN",
    "FR_NIR":         "NIR",
    "FR_VAT":         "TVA",
    "FR_POSTAL":      "CP",
    # Germany
    "DE_STEUER_ID":   "STID",
    "DE_RVNR":        "RVNR",
    "DE_VAT":         "UST",
    "DE_POSTAL":      "PLZ",
}

GLOBAL_PATTERNS = [
    ("IBAN_CODE", r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b", 0.85),
    # CREDIT_CARD: 16 digits (Visa/MC/Discover). Era 5×4=20 digits — bug pre-esistente che
    # non matchava nessun PAN reale; mascherato dalla forced_type per colonne con "card" nel nome.
    # Amex (15 digits) non coperto qui — i template Amex sono rari in HR/Sales test data.
    ("CREDIT_CARD", r"\b(?:4\d{3}|5[1-5]\d{2}|6011|3[47]\d{2})[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b", 0.95),
    # SWIFT/BIC: 4 lettere bank + 2 lettere country (ISO 3166) + 2 alfanum location + opzionale 3 alfanum branch.
    # `(?-i:...)` disabilita IGNORECASE: presidio applica re.IGNORECASE di default e altrimenti il pattern
    # matcherebbe parole inglesi minuscole 8-char come "transfer", "approved", "national".
    # Score 0.45 (sopra threshold 0.3) perché il context enhancer di presidio non boosta in setup
    # multilang `xx_ent_wiki_sm` (no lemmatizer). Senza boost, score basso lascerebbe scoperti BIC
    # in free-text. Ricaduta: parole UPPERCASE 8-char comuni rischiano FP (es. "STANDARD") — raro nei doc reali.
    ("SWIFT_BIC", r"(?-i:\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b)", 0.45),
    ("EMAIL_ADDRESS", r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", 0.95),
    ("IP_ADDRESS", r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", 0.95),
    ("PHONE_INTL", r"(?:\+|00)\d{1,3}[\s.-]?\d{6,14}\b", 0.80),
    ("URL", r'\bhttps?://[^\s<>"{}|\\^`\[\]]+', 0.85),
    ("DATE_ISO", r"\b\d{4}-\d{2}-\d{2}\b", 0.90),
    ("DATE_EU", r"\b\d{1,2}/\d{1,2}/\d{2,4}\b", 0.85),
    ("DATE_US", r"\b\d{1,2}-\d{1,2}-\d{4}\b", 0.85),
]

# Tokenizer multilingua MIT — sostituisce i modelli `*_core_news_lg` (CC BY-NC-SA, non commerciali).
# Il NER vero è delegato a PiiNerRecognizer (modello ONNX MIT).
TOKENIZER_MODEL = "xx_ent_wiki_sm"
SUPPORTED_LANGUAGES = ("it", "en", "fr", "de")

# File estensioni accettate dal modulo Anonimyze. Le altre vengono rigettate
# in upload e in process_file_stream — evita che file binari (audio/video/exe/zip)
# vengano copiati come-se nell'output_dir senza alcuna anonimizzazione.
ANONYMIZE_SUPPORTED_EXT = (
    # Tabular
    ".xlsx", ".xls", ".csv",
    # Documents
    ".pdf", ".docx", ".txt", ".md",
)
# Alias di compatibilità: il router può importare MODEL_MAP per validare locale_hint.
MODEL_MAP = {lang: TOKENIZER_MODEL for lang in SUPPORTED_LANGUAGES}

# Paesi supportati. EN è lo unione UK ∪ US ∪ pattern globali — l'opzione di default
# per documenti in inglese, evita all'utente di scegliere UK vs US.
# UK/US/DE/FR restano selezionabili via API per usi avanzati ma non sono in UI.
SUPPORTED_COUNTRIES = ("IT", "EN", "DE", "FR", "UK", "US", "NEUTRAL")

# NOTE: JURISDICTION_PATTERNS, COUNTRY_TO_LANG, and LANG_TO_DEFAULT_COUNTRY
# now live in `services.anonimyze_patterns` (single source of truth, also
# consumed by AdvancedTextAnonymizer). They are imported at the top of
# this file.
class AnonimyzeService:
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(AnonimyzeService, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized'): return
        self._initialized = True
        self.lang = "it"
        self.country = None  # None = auto-detect; altrimenti uno di IT/DE/FR/UK/US/NEUTRAL
        self._analyzers = {}
        self.sessions: Dict[str, List[Dict]] = {}
        self.uploaded_files: Dict[str, List[Dict]] = {}
        self.staged_files: Dict[str, List[Dict]] = {}
        self.db_path = None
        self.project_id = "DFT"
        self._sync_vault()
        # Non chiamare warmup qui per non bloccare l'importazione, 
        # verrà chiamato al primo utilizzo o esplicitamente.

    def warmup(self):
        """Assicura che il tokenizer spaCy e il NER ONNX siano pronti."""
        try:
            if not spacy.util.is_package(TOKENIZER_MODEL):
                logger.info(f"Pre-downloading SpaCy tokenizer {TOKENIZER_MODEL}...")
                spacy.cli.download(TOKENIZER_MODEL)

            logger.info("Pre-loading ONNX PII NER engine...")
            get_ner_engine().warmup()

            # Pre-build analyzer per i due paesi più comuni del target.
            for country in ("IT", "US"):
                key = f"{country}:{COUNTRY_TO_LANG[country]}"
                if key not in self._analyzers:
                    self._get_analyzer(country=country)
        except Exception as e:
            logger.error(f"Error during Anonimyze warmup: {e}")
        logger.info("✅ Anonimyze Service warmup complete.")

    def _sync_vault(self):
        self.project_id = project_manager.get_short_id()
        db_dir = project_manager.get_path("db")
        self.db_path = db_dir / "privacy_vault.sqlite"
        self._init_db()
        logger.info(f"🔒 Privacy Vault synced for project {self.project_id}")

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pii_mapping (
                original_text TEXT PRIMARY KEY,
                placeholder TEXT UNIQUE,
                entity_type TEXT,
                prefix TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS counters (
                prefix TEXT PRIMARY KEY,
                last_val INTEGER
            )
        ''')
        conn.commit()
        conn.close()

    @property
    def reverse(self) -> Dict[str, str]:
        """Restituisce la mappa inversa placeholder -> original_text dal database."""
        if not self.db_path or not self.db_path.exists():
            return {}
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT placeholder, original_text FROM pii_mapping")
            rows = cursor.fetchall()
            conn.close()
            return {r[0]: r[1] for r in rows}
        except Exception as e:
            logger.error(f"Error fetching reverse mapping: {e}")
            return {}

    def set_language(self, lang: str):
        self.lang = lang
        from services.i18n_service import i18n
        i18n.set_language(lang)

    def set_country(self, country: str):
        """Imposta la jurisdiction (paese di origine documento). Drive i pattern regex.
        Valori validi: IT, DE, FR, UK, US, NEUTRAL, oppure 'auto' (None) per autodetect."""
        if country and country.upper() in JURISDICTION_PATTERNS:
            self.country = country.upper()
        else:
            self.country = None  # auto

    def _detect_document_language(self, input_path: Path) -> str:
        """Detects the language of a document by sampling its content.
        Falls back to self.lang (UI language) if detection fails.
        """
        sample = ""
        ext = input_path.suffix.lower()
        try:
            if ext in ['.xlsx', '.xls']:
                import openpyxl
                wb = openpyxl.load_workbook(input_path, read_only=True, data_only=True)
                texts = []
                for sheet in wb.worksheets:
                    for row in sheet.iter_rows(max_row=5, values_only=True):
                        for cell in row:
                            if isinstance(cell, str) and len(cell.strip()) > 3:
                                texts.append(cell)
                            if len(texts) > 30:
                                break
                    if len(texts) > 30:
                        break
                wb.close()
                sample = " ".join(texts)
            elif ext == '.csv':
                import chardet
                with open(input_path, 'rb') as f:
                    enc = chardet.detect(f.read(10000))['encoding'] or 'utf-8'
                df = pd.read_csv(input_path, encoding=enc, sep=None, engine='python', nrows=5)
                sample = " ".join(df.astype(str).values.flatten())
            elif ext == '.txt' or ext == '.md':
                with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                    sample = f.read(2000)
            elif ext == '.docx':
                doc = Document(input_path)
                sample = "\n".join([p.text for p in doc.paragraphs[:10]])
            elif ext == '.pdf':
                import pypdf
                reader = pypdf.PdfReader(input_path)
                sample = reader.pages[0].extract_text()[:2000] if len(reader.pages) > 0 else ""
        except Exception as e:
            logger.warning(f"Language detection sample extraction failed: {e}")

        if not sample or len(sample.strip()) < 20:
            return self.lang

        try:
            from langdetect import detect, LangDetectException
            detected = detect(sample)
            if detected in SUPPORTED_LANGUAGES:
                logger.info(f"🌐 Document language detected: {detected.upper()}")
                return detected
            else:
                logger.info(f"🌐 Document language '{detected}' not in {SUPPORTED_LANGUAGES}, fallback to UI: {self.lang}")
        except ImportError:
            pass
        except Exception as e:
            logger.warning(f"Language detection failed: {e}")

        return self.lang

    def _extract_text_sample(self, input_path: Path, max_chars: int = 2000) -> str:
        """Estrae un sample testuale dal documento per la disambiguazione country (UK vs US)."""
        ext = input_path.suffix.lower()
        try:
            if ext in ('.txt', '.md'):
                with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read(max_chars)
            if ext == '.docx':
                doc = Document(input_path)
                return "\n".join(p.text for p in doc.paragraphs[:30])[:max_chars]
            if ext == '.pdf':
                import pypdf
                reader = pypdf.PdfReader(input_path)
                if reader.pages:
                    return (reader.pages[0].extract_text() or "")[:max_chars]
            if ext in ('.xlsx', '.xls'):
                import openpyxl
                wb = openpyxl.load_workbook(input_path, read_only=True, data_only=True)
                buf = []
                for sheet in wb.worksheets:
                    for row in sheet.iter_rows(max_row=10, values_only=True):
                        for cell in row:
                            if isinstance(cell, str): buf.append(cell)
                wb.close()
                return " ".join(buf)[:max_chars]
            if ext == '.csv':
                with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read(max_chars)
        except Exception:
            pass
        return ""

    def _classify_column(self, col_name: str, sample_values: List[str], analyzer, lang: str = None) -> str:
        """Classify column as 'pii_structured' or 'free_text' using keywords + Presidio."""
        col_lower = col_name.lower().replace("_", " ").replace("-", " ")
        # La lingua deve corrispondere a quella per cui l'analyzer è stato costruito,
        # altrimenti Presidio non trova recognizer matching.
        if not lang:
            sup = list(getattr(analyzer, "supported_languages", []) or [])
            lang = sup[0] if sup else "it"

        PII_KEYWORDS = [
            "iban", "email", "telefono", "tel ", "phone", "cellulare", "fax",
            "codice fiscale", "cf ", "fiscal code",
            "partita iva", "p.iva", "iva ", "vat code",
            "targa", "plate", "veicolo",
            "ssn", "social security", "security number",
            "itin", "tax id", "taxpayer",
            "ein", "employer id", "federal tax",
            "nhs", "national insurance", "medicare", "passport",
            "routing", "account number", "bank account",
            "swift", "bic",
            "carta ", "card", "credit", "payment", "visa", "mastercard",
            "ip address", "ip ", "indirizzo ip", "host",
            "soggetto", "nome", "cognome", "person", "name",
            "ragione sociale", "denominazione",
            "citta", "città", "city", "indirizzo", "address", "location",
            "luogo", "residenza", "comune", "provincia", "stato", "cap",
            "nazione", "paese", "localita", "località",
            "utente", "dipendente", "lavoratore", "cliente", "paziente",
            "fornitore", "contraente", "intestatario",
        ]
        if any(k in col_lower for k in PII_KEYWORDS):
            return "pii_structured"

        if not sample_values:
            return "free_text"

        pii_count = 0
        sample = sample_values[:min(30, len(sample_values))]
        for val in sample:
            if self.is_pure_data(val):
                continue
            try:
                results = analyzer.analyze(text=val, language=lang, score_threshold=0.3)
            except ValueError:
                results = []
            if results:
                pii_count += 1

        ratio = pii_count / len(sample) if sample else 0
        if ratio > 0.5:
            return "pii_structured"

        return "free_text"

    def _generate_username_variants(self, name: str) -> List[str]:
        """Generate username-style variants from a full name.
        'Anna Bianchi' → ['anna_bianchi', 'anna.bianchi', 'annabianchi', 'a_bianchi', 'anna_b']
        """
        parts = name.strip().split()
        if len(parts) < 2:
            return []
        first = parts[0].lower()
        last = parts[-1].lower()
        variants = [
            f"{first}_{last}",
            f"{first}.{last}",
            f"{first}{last}",
            f"{first[0]}_{last}",
            f"{first}_{last[0]}",
        ]
        return list(set(variants))

    def _generate_username_regex(self, name: str) -> List[str]:
        r"""Generate regex patterns for username-style variants with optional trailing digits.
        'Anna Bianchi' → [r'anna_bianchi\d*', r'anna\.bianchi\d*', ...]
        """
        parts = name.strip().split()
        if len(parts) < 2:
            return []
        first = parts[0].lower()
        last = parts[-1].lower()
        patterns = [
            re.escape(f"{first}_{last}") + r'\d*',
            re.escape(f"{first}.{last}") + r'\d*',
            re.escape(f"{first}{last}") + r'\d*',
            re.escape(f"{first[0]}_{last}") + r'\d*',
            re.escape(f"{first}_{last[0]}") + r'\d*',
        ]
        return list(set(patterns))

    def _detect_country(self, text_sample: str, lang: str) -> str:
        """Mappa lingua → paese di default."""
        return LANG_TO_DEFAULT_COUNTRY.get(lang, "NEUTRAL")

    def _get_analyzer(self, country: str = "IT", lang: str = None) -> AnalyzerEngine:
        """Costruisci/cache l'analyzer per la coppia (country, lang).
        - `country` determina quali pattern recognizer (regex giurisdizionali) caricare.
        - `lang` determina il routing del NLP engine Presidio (tokenizer + lingua dei recognizer).
        Se `lang` è None, deriva da COUNTRY_TO_LANG.
        """
        if country not in JURISDICTION_PATTERNS:
            country = "NEUTRAL"
        if not lang:
            lang = COUNTRY_TO_LANG.get(country, "en")

        cache_key = f"{country}:{lang}"
        if cache_key in self._analyzers: return self._analyzers[cache_key]

        if not spacy.util.is_package(TOKENIZER_MODEL):
            spacy.cli.download(TOKENIZER_MODEL)

        # xx_ent_wiki_sm fa solo da tokenizer/sentencizer per Presidio. Il suo NER nativo
        # è disabilitato — il NER reale è delegato a PiiNerRecognizer (modello ONNX MIT).
        nlp_engine = SpacyNlpEngine(models=[{
            "lang_code": lang,
            "model_name": TOKENIZER_MODEL,
            "ner_model_configuration": {
                "labels_to_ignore": ["PER", "LOC", "ORG", "MISC", "CARDINAL", "ORDINAL", "QUANTITY", "PERCENT"]
            }
        }])

        registry = RecognizerRegistry(supported_languages=[lang])

        GLOBAL_CONTEXT = {
            "IBAN_CODE": ["iban", "bank", "account"],
            "PHONE_INTL": ["phone", "tel", "mobile", "cell"],
            "EMAIL_ADDRESS": ["email", "e-mail", "mail"],
            # SWIFT_BIC ha score 0.25 (sotto threshold 0.3): solo con context boost passa.
            # Necessario per evitare FP su county UK (STRATHCLYDE) e altri toponimi maiuscoli.
            "SWIFT_BIC": ["bic", "swift", "wire", "transfer", "iban", "bank"],
            # Boost su nomi UPPERCASE italiani quando appaiono vicino a keyword di ruolo/identità.
            "PERSON": [
                "codice fiscale", "cf", "p.iva", "erede", "defunto", "deceduta", "deceduto",
                "soggetto", "oggetto", "dichiarante", "intestatario", "beneficiario",
                "coniuge", "fratello", "sorella", "genitore", "figlio", "figlia",
                "relativa a", "in qualita", "in qualità",
            ],
        }

        # Pattern globali (sempre attivi, indipendenti da country).
        for entity_type, regex, score in GLOBAL_PATTERNS:
            registry.add_recognizer(PatternRecognizer(
                supported_entity=entity_type,
                supported_language=lang,
                context=GLOBAL_CONTEXT.get(entity_type, []),
                patterns=[Pattern(f"{entity_type.lower()}_global", regex, score)]
            ))

        # Pattern jurisdiction-specifici: SOLO quelli del country selezionato.
        # Questo evita il falso positivo storico (es. US_DRIVERS_LICENSE su CF italiano).
        patterns = JURISDICTION_PATTERNS.get(country, [])
        for entity_type, regex, score in patterns:
            registry.add_recognizer(PatternRecognizer(
                supported_entity=entity_type,
                supported_language=lang,
                patterns=[Pattern(f"{entity_type.lower()}_{country.lower()}", regex, score)]
            ))

        registry.add_recognizer(PiiNerRecognizer(get_ner_engine(), supported_language=lang))

        analyzer = AnalyzerEngine(registry=registry, nlp_engine=nlp_engine, supported_languages=[lang])
        self._analyzers[cache_key] = analyzer
        return analyzer

    def get_or_create_placeholder(self, original_text: str, entity_type: str) -> str:
        key = str(original_text).strip()
        if not key: return original_text

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT placeholder FROM pii_mapping WHERE original_text = ?", (key,))
        row = cursor.fetchone()
        if row:
            conn.close()
            return row[0]

        prefix = ENTITY_PREFIX_MAP.get(entity_type, "UNKN")
        cursor.execute("SELECT last_val FROM counters WHERE prefix = ?", (prefix,))
        crow = cursor.fetchone()
        count = (crow[0] + 1) if crow else 1
        
        placeholder = f"[{self.project_id}-{prefix}-{count}]"
        
        try:
            cursor.execute("INSERT INTO pii_mapping VALUES (?, ?, ?, ?)", (key, placeholder, entity_type, prefix))
            cursor.execute("INSERT OR REPLACE INTO counters VALUES (?, ?)", (prefix, count))
            conn.commit()
        except sqlite3.IntegrityError:
            cursor.execute("SELECT placeholder FROM pii_mapping WHERE original_text = ?", (key,))
            placeholder = cursor.fetchone()[0]
        
        conn.close()
        return placeholder

    def is_pure_data(self, text: str) -> bool:
        """Determines if a string is a pure number or simple date that should NOT be anonymized.

        EXCEPTION: SSN, ITIN, CPF, CC, IP, EIN, etc. should ALWAYS be anonymized
        even if they look like pure numbers.
        """
        t = str(text).strip()
        if not t or len(t) < 2: return True

        # EXCEPTION: CPF format (XXX.XXX.XXX-XX) → NOT pure data
        if re.match(r"^\d{3}\.\d{3}\.\d{3}-\d{2}$", t): return False
        # EXCEPTION: SSN format (XXX-XX-XXXX) → NOT pure data
        if re.match(r"^\d{3}-\d{2}-\d{4}$", t): return False
        # EXCEPTION: ITIN format (9XX-XX-XXXX) → NOT pure data
        if re.match(r"^9\d{2}[-\s]\d{2}[-\s]\d{4}$", t): return False
        # EXCEPTION: US EIN format (XX-XXXXXXX) → NOT pure data
        if re.match(r"^\d{2}-\d{7}$", t): return False
        # EXCEPTION: Credit Card format → NOT pure data
        if re.match(r"^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$", t): return False
        # EXCEPTION: IP Address format → NOT pure data
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", t): return False
        # EXCEPTION: US Bank Routing (9 digits standalone with context) → check length
        # EXCEPTION: CN Resident ID (18 chars with X) → NOT pure data
        if re.match(r"^\d{17}[Xx]$", t): return False
        # EXCEPTION: JP My Number (12 digits) → NOT pure data
        if re.match(r"^\d{12}$", t): return False
        # EXCEPTION: IN Aadhaar (12 digits with spaces) → NOT pure data
        if re.match(r"^\d{4}\s?\d{4}\s?\d{4}$", t): return False

        # 1. Check for numeric (removes common separators)
        num_check = t.replace(".", "").replace(",", "").replace("-", "").replace(" ", "")
        if num_check.isdigit():
            return True

        # 2. Check for simple dates
        date_patterns = [
            r"^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}$",
            r"^\d{4}[/-]\d{1,2}[/-]\d{1,2}$"
        ]
        for p in date_patterns:
            if re.match(p, t): return True

        return False

    async def anonymize_batch(self, texts: List[str], force_lang: str = None, column_hint: str = None, force_country: str = None) -> List[str]:
        if not texts: return []

        lang = force_lang or self.lang
        if lang not in SUPPORTED_LANGUAGES: lang = "it"

        country = force_country or getattr(self, "country", None) or LANG_TO_DEFAULT_COUNTRY.get(lang, "NEUTRAL")
        if country not in JURISDICTION_PATTERNS: country = "NEUTRAL"

        analyzer = self._get_analyzer(country=country, lang=lang)
        results = []
        
        # SURGICAL COLUMN PROTECTION — Expanded for all PII types
        is_sensitive_col = False
        forced_type = None
        if column_hint:
            ch = column_hint.lower().replace("_", " ").replace("-", " ")
            # Names / Persons
            if any(k in ch for k in ["soggetto", "nome", "cognome", "person", "name", "ragione sociale", "denominazione", "cliente", "paziente", "utente", "dipendente", "lavoratore", "fornitore", "contraente", "intestatario"]):
                is_sensitive_col = True
                forced_type = "PERSON"
            # Locations
            elif any(k in ch for k in ["citta", "città", "city", "indirizzo", "address", "location", "luogo", "residenza", "comune", "provincia", "stato", "cap", "nazione", "paese", "localita", "località"]):
                is_sensitive_col = True
                forced_type = "LOCATION"
            # Phones
            elif any(k in ch for k in ["telefono", "tel", "phone", "cellulare", "mobile", "fax"]):
                is_sensitive_col = True
                forced_type = "PHONE_NUMBER"
            # Italian Fiscal Code
            elif any(k in ch for k in ["codice fiscale", "cf ", "fiscal code"]):
                is_sensitive_col = True
                forced_type = "IT_FISCAL_CODE"
            # Email
            elif any(k in ch for k in ["email", "e-mail", "mail", "posta elettronica", "pec"]):
                is_sensitive_col = True
                forced_type = "EMAIL_ADDRESS"
            # IBAN / Bank
            elif any(k in ch for k in ["iban", "bank", "conto", "abi", "cab", "routing", "bancario", "coordinate bancarie"]):
                is_sensitive_col = True
                forced_type = "IBAN_CODE"
            # Credit Card
            elif any(k in ch for k in ["carta", "card", "credit", "payment", "visa", "mastercard", "amex", "pan"]):
                is_sensitive_col = True
                forced_type = "CREDIT_CARD"
            # IP Address
            elif any(k in ch for k in ["ip address", "ip ", "indirizzo ip", "host"]):
                is_sensitive_col = True
                forced_type = "IP_ADDRESS"
            # US SSN
            elif any(k in ch for k in ["ssn", "social security", "security number"]):
                is_sensitive_col = True
                forced_type = "US_SSN"
            # US ITIN
            elif any(k in ch for k in ["itin", "tax id", "taxpayer"]):
                is_sensitive_col = True
                forced_type = "US_ITIN"
            # US EIN
            elif any(k in ch for k in ["ein", "employer id", "federal tax"]):
                is_sensitive_col = True
                forced_type = "US_EIN"
            # Italian VAT
            elif any(k in ch for k in ["partita iva", "p.iva", "iva", "vat code"]):
                is_sensitive_col = True
                forced_type = "IT_VAT_CODE"
            # License Plate
            elif any(k in ch for k in ["targa", "plate", "veicolo", "license plate"]):
                is_sensitive_col = True
                forced_type = "LICENSE_PLATE"
            # Dates
            elif any(k in ch for k in ["data ", "date ", "nascita", "birth", "scadenza", "expiration"]):
                is_sensitive_col = True
                forced_type = "DATE_TIME"
            # URL
            elif any(k in ch for k in ["url", "website", "sito web", "link", "http"]):
                is_sensitive_col = True
                forced_type = "URL"
            # SSN / UK NINO / Foreign IDs
            elif any(k in ch for k in ["nino", "national insurance", "aadhaar", "pan card", "my number", "pesel", "bsn"]):
                is_sensitive_col = True
                forced_type = "US_SSN"
            # UK NHS Number
            elif "nhs" in ch:
                is_sensitive_col = True
                forced_type = "UK_NHS"
            # US Medicare ID
            elif "medicare" in ch:
                is_sensitive_col = True
                forced_type = "US_MEDICARE"
            # Passport (UK / US generic 9-digit)
            elif "passport" in ch:
                is_sensitive_col = True
                forced_type = "US_PASSPORT"
            # SWIFT / BIC
            elif any(k in ch for k in ["swift", "bic"]):
                is_sensitive_col = True
                forced_type = "SWIFT_BIC"

        for text in texts:
            if not isinstance(text, str):
                results.append(text)
                continue

            # SENSITIVE COLUMN: bypass is_pure_data filter — for known-PII columns
            # (NHS, Medicare, routing, passport, etc.) we must anonymize even pure-digit values.
            # This must run BEFORE is_pure_data, otherwise e.g. NHS "171 346 2486" → strip spaces
            # → 10 digits → is_pure_data returns True → value passes through unchanged.
            if is_sensitive_col and forced_type and len(text.strip()) > 2:
                results.append(self.get_or_create_placeholder(text, forced_type))
                continue

            if self.is_pure_data(text):
                results.append(text)
                continue
            try:
                # Eseguiamo l'analisi SpaCy in un thread separato per evitare di bloccare l'event loop async
                pii_results = await asyncio.to_thread(
                    analyzer.analyze,
                    text=text,
                    language=lang,
                    score_threshold=0.3
                )

                sorted_pii = sorted(pii_results, key=lambda r: r.start, reverse=True)
                anon_text = text

                # CRITICAL FIX: If ANY detected entity covers the ENTIRE input text,
                # just replace the whole thing directly. This avoids ALL corruption
                # from overlapping matches within a single cell value.
                full_match = None
                for r in pii_results:
                    if r.start == 0 and r.end >= len(text):
                        if full_match is None or r.score > full_match.score:
                            full_match = r

                if full_match:
                    # LEGAL_REF (blacklist): riferimenti normativi pubblici —
                    # consumiamo lo span (così altri engine non lo tagghino) ma
                    # NON sostituiamo nulla. Lasciamo il testo originale.
                    if full_match.entity_type == "LEGAL_REF":
                        results.append(text)
                        continue
                    if full_match.entity_type not in ["PHONE_NUMBER", "IT_FISCAL_CODE"] and self.is_pure_data(text):
                        results.append(text)  # Skip pure data
                    else:
                        placeholder = self.get_or_create_placeholder(text, full_match.entity_type)
                        results.append(placeholder)
                    continue

                # Deduplicate overlapping entities, accept all non-overlapping spans.
                # Bug fix: il vecchio algoritmo confrontava solo con last_start (estremo sinistro)
                # → rigettava entità a destra non sovrapposte. Es.: DATE [23:27] accettato →
                # last_start=23 → SWIFT_BIC [40:51] rigettato pur senza overlap. Ora il check è
                # contro tutti gli elementi accettati.
                non_overlapping = []
                # Sort by LARGER COVERAGE first, score as tiebreak.
                # Quando due entità si sovrappongono (es. DATE_TIME "2026" 4-char dentro DATE_ISO
                # "2026-04-02" 10-char), la più estesa è di solito la più semantica e va privilegiata.
                # `start-end` è negativo: più ampia = più negativa = sortita prima ascendente.
                for r in sorted(pii_results, key=lambda x: (x.start - x.end, -x.score)):
                    overlaps = any(
                        r.end > acc.start and r.start < acc.end
                        for acc in non_overlapping
                    )
                    if not overlaps:
                        non_overlapping.append(r)

                # Re-sort in reverse order (end to start) for safe replacement
                non_overlapping = sorted(non_overlapping, key=lambda r: r.start, reverse=True)

                for r in non_overlapping:
                    original = text[r.start:r.end]
                    # LEGAL_REF (blacklist): vedi commento sopra — span consumato,
                    # nessuna sostituzione effettuata.
                    if r.entity_type == "LEGAL_REF":
                        continue
                    if r.entity_type not in ["PHONE_NUMBER", "IT_FISCAL_CODE", "DATE_ISO", "DATE_EU", "DATE_US", "UK_NHS", "US_MEDICARE", "US_PASSPORT", "UK_PASSPORT", "US_BANK_ROUTING", "ACCT", "NOTAIO_REP"] and self.is_pure_data(original):
                        continue
                    placeholder = self.get_or_create_placeholder(original, r.entity_type)
                    anon_text = anon_text[:r.start] + placeholder + anon_text[r.end:]
                results.append(anon_text)
            except Exception as e:
                logger.error(f"❌ Error anonymizing individual text '{text[:20]}...': {e}")
                results.append(text)
        return results

    async def deanonymize_batch(self, texts: List[str]) -> List[str]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT placeholder, original_text FROM pii_mapping ORDER BY length(placeholder) DESC")
        mappings = cursor.fetchall()
        conn.close()
        results = []
        for text in texts:
            if not text or not isinstance(text, str):
                results.append(text)
                continue
            res = text
            for placeholder, original in mappings:
                res = res.replace(placeholder, original)
            results.append(res)
        return results

    def get_columns(self, filename: str) -> List[str]:
        input_dir = project_manager.get_path("uploads") / "anonimyze"
        file_path = input_dir / filename
        if not file_path.exists(): return []
        try:
            if file_path.suffix.lower() in ['.xlsx', '.xls']:
                xl = pd.ExcelFile(file_path)
                cols = []
                for sheet in xl.sheet_names:
                    df = xl.parse(sheet, nrows=0)
                    cols.extend([f"{sheet}!!{c}" for c in df.columns])
                return cols
            elif file_path.suffix.lower() == '.csv':
                df = pd.read_csv(file_path, sep=None, engine='python', nrows=0)
                return list(df.columns)
        except: pass
        return []

    async def process_file_stream(self, session_id: str, filename: str, mode: str = "anonymize", cloud_ready: bool = True, selected_columns: List[str] = None) -> AsyncGenerator[str, None]:
        """Robust execution with progress streaming."""
        try:
            yield f"⚙️ Starting: {filename}\n"
            self._sync_vault()
            
            input_dir = project_manager.get_path("uploads") / "anonimyze"

            # Separate folders for cleanup (GDPR Standard)
            if mode == "anonymize":
                output_dir = project_manager.get_path("output") / "Anonymized"
            else:
                output_dir = project_manager.get_path("output") / "Deanonimyzed"

            output_dir.mkdir(parents=True, exist_ok=True)

            input_path = input_dir / filename
            if not input_path.exists():
                yield f"❌ File not found: {filename}\n"
                return

            ext = input_path.suffix.lower()

            # Fail-safe: rifiuta qualsiasi estensione fuori dalla whitelist anche se è
            # arrivata fin qui (il router /upload già blocca, ma se qualcuno chiama
            # /process direttamente o c'è un upload pre-fix sul disco, rifiuta esplicitamente
            # invece di copiare il file as-is in output/ — vecchio comportamento bug-prone).
            if ext not in ANONYMIZE_SUPPORTED_EXT:
                allowed = ", ".join(s.lstrip(".") for s in ANONYMIZE_SUPPORTED_EXT)
                yield f"❌ Unsupported file type '{ext or '(no extension)'}'. Anonimyze accepts only: {allowed}.\n"
                return

            ts = int(time.time())

            # Simple and direct naming convention
            if mode == "anonymize":
                out_name = f"{input_path.stem}_ANON_{ts}{ext}"
                if ext == '.pdf': out_name = f"{input_path.stem}_ANON_{ts}.docx"
            else:
                out_name = f"{input_path.stem}_DEANON_{ts}{ext}"

            out_path = output_dir / out_name

            # LANGUAGE DETECTION: Auto-detect document language for optimal PII detection
            detected_lang = self._detect_document_language(input_path)
            if detected_lang != self.lang:
                yield f"🌐 Language detected: {detected_lang.upper()} (UI: {self.lang.upper()})\n"
            else:
                yield f"🌐 Language: {detected_lang.upper()}\n"

            # COUNTRY DETECTION: usa override manuale se presente, altrimenti
            # deriva da lingua + marker testuali (per disambiguare en→UK/US).
            if self.country:
                detected_country = self.country
                yield f"🏳️  Country (manual): {detected_country}\n"
            else:
                sample_for_marker = self._extract_text_sample(input_path, max_chars=2000)
                detected_country = self._detect_country(sample_for_marker, detected_lang)
                yield f"🏳️  Country detected: {detected_country}\n"

            if ext in ['.xlsx', '.xls']:
                # === EXCEL: openpyxl column-aware (Type-Preserving + Column-Hint) ===
                import openpyxl
                yield "📊 Loading workbook...\n"
                wb = openpyxl.load_workbook(input_path)
                analyzer = self._get_analyzer(country=detected_country, lang=detected_lang)

                # ... (selection_map logic unchanged) ...
                selection_map = {}
                if selected_columns:
                    for item in selected_columns:
                        if "!!" in item:
                            s, c = item.split("!!", 1)
                            selection_map.setdefault(s, []).append(c)

                val_map = {}

                if mode == 'anonymize':
                    # Phase 1: Classify columns and collect values
                    all_columns = {}

                    for sheet in wb.worksheets:
                        target_cols = selection_map.get(sheet.title) if selected_columns else None
                        if selected_columns and target_cols is None:
                            continue

                        header_cells = next(sheet.iter_rows(min_row=1, max_row=1, values_only=False))
                        header = [cell.value for cell in header_cells]
                        all_columns[sheet.title] = []

                        for col_idx, col_name in enumerate(header):
                            if target_cols and col_name not in target_cols:
                                continue
                            if col_name is None:
                                continue

                            col_vals = []
                            seen = set()
                            for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=col_idx+1, max_col=col_idx+1, values_only=False):
                                cell = row[0]
                                v = cell.value
                                if isinstance(v, str) and v.strip() and v not in seen:
                                    col_vals.append(v)
                                    seen.add(v)

                            if not col_vals:
                                continue

                            col_type = self._classify_column(col_name, col_vals, analyzer, detected_lang)
                            all_columns[sheet.title].append({
                                'col_idx': col_idx,
                                'col_name': col_name,
                                'col_vals': col_vals,
                                'col_type': col_type,
                            })

                            yield f"   ➜ Column '{col_name}': {len(col_vals)} values [{col_type}]...\n"

                    # ... (rest of logic) ...
                    for sheet_title, cols in all_columns.items():
                        for col_info in cols:
                            if col_info['col_type'] != 'pii_structured':
                                continue
                            chunk_size = 50
                            for i in range(0, len(col_info['col_vals']), chunk_size):
                                chunk = col_info['col_vals'][i:i + chunk_size]
                                processed = await self.anonymize_batch(chunk, force_lang=detected_lang, column_hint=col_info['col_name'], force_country=detected_country)
                                for orig, proc in zip(chunk, processed):
                                    if orig != proc:
                                        val_map[orig] = proc

                    username_variants = {}
                    for orig, placeholder in val_map.items():
                        if '[PERS' in placeholder or '[ORG' in placeholder or '[LOC' in placeholder:
                            variants = self._generate_username_variants(orig)
                            for variant in variants:
                                if variant not in username_variants:
                                    username_variants[variant] = placeholder

                    for variant, placeholder in username_variants.items():
                        if variant not in val_map:
                            val_map[variant] = placeholder

                    if username_variants:
                        yield f"   🔗 Generated {len(username_variants)} username variants for cross-matching\n"

                    free_text_values = set()
                    free_text_col_indices = set()
                    for sheet in wb.worksheets:
                        sheet_cols = all_columns.get(sheet.title, [])
                        for c in sheet_cols:
                            if c['col_type'] == 'free_text':
                                free_text_col_indices.add((sheet.title, c['col_idx']))
                                for v in c['col_vals']:
                                    if len(v) > 10:
                                        free_text_values.add(v)

                    if free_text_values:
                        yield f"   🔍 Scanning {len(free_text_values)} free text values for embedded PII...\n"
                        ft_list = list(free_text_values)
                        for i in range(0, len(ft_list), 50):
                            chunk = ft_list[i:i+50]
                            processed = await self.anonymize_batch(chunk, force_lang=detected_lang, force_country=detected_country)
                            for orig, proc in zip(chunk, processed):
                                if orig != proc:
                                    val_map[orig] = proc

                    cross_match_keys = sorted(val_map.keys(), key=len, reverse=True)
                    username_regexes = []
                    for orig, placeholder in val_map.items():
                        if '[PERS' in placeholder or '[ORG' in placeholder or '[LOC' in placeholder:
                            patterns = self._generate_username_regex(orig)
                            for pat in patterns:
                                username_regexes.append((pat, placeholder))

                    for sheet in wb.worksheets:
                        sheet_cols = all_columns.get(sheet.title, [])
                        col_type_map = {c['col_idx']: c['col_type'] for c in sheet_cols}

                        target_cols = selection_map.get(sheet.title) if selected_columns else None
                        if selected_columns and target_cols is None:
                            continue

                        header_row = next(sheet.iter_rows(min_row=1, max_row=1, values_only=False))
                        col_indices = []
                        for i, cell in enumerate(header_row):
                            if not target_cols or cell.value in target_cols:
                                col_indices.append(i)

                        for row in sheet.iter_rows(min_row=2, values_only=False):
                            for idx in col_indices:
                                cell = row[idx]
                                if not isinstance(cell.value, str):
                                    continue

                                col_type = col_type_map.get(idx, 'free_text')
                                if col_type == 'pii_structured':
                                    if cell.value in val_map:
                                        cell.value = val_map[cell.value]
                                else:
                                    text = cell.value
                                    if text in val_map:
                                        text = val_map[text]
                                    else:
                                        for key in cross_match_keys:
                                            if key in text:
                                                text = text.replace(key, val_map[key])
                                        for pattern, placeholder in username_regexes:
                                            text = re.sub(pattern, placeholder, text)
                                    cell.value = text

                else:
                    # === DIRECT DE-ANONYMIZE PHASE ===
                    current_project_id = project_manager.get_short_id()
                    reverse_map = self.reverse
                    yield f"🛠️ Vault Sync: Loaded {len(reverse_map)} mappings for Project {current_project_id}\n"
                    
                    if not reverse_map:
                        yield "❌ ERROR: Vault is empty. Cannot restore data.\n"
                    else:
                        stats = {'cells': 0, 'tags': 0}
                        for sheet in wb.worksheets:
                            target_cols_raw = selection_map.get(sheet.title) or selection_map.get("Default") if selected_columns else None
                            target_cols = [str(c).strip().upper() for c in target_cols_raw] if target_cols_raw else None

                            header_row = next(sheet.iter_rows(min_row=1, max_row=1))
                            col_indices = []
                            for i, cell in enumerate(header_row):
                                val_str = str(cell.value).strip().upper() if cell.value else ""
                                if not target_cols or val_str in target_cols: 
                                    col_indices.append(i)

                            if selected_columns and not col_indices:
                                yield f"⚠️ No matching columns in sheet {sheet.title}. Global scan active.\n"
                                col_indices = list(range(len(header_row)))

                            yield f"🔍 Scanning {sheet.title} ({len(col_indices)} columns)...\n"
                            
                            for row in sheet.iter_rows(min_row=2):
                                for idx in col_indices:
                                    if idx >= len(row): continue
                                    cell = row[idx]
                                    stats['cells'] += 1
                                    
                                    val_as_str = str(cell.value) if cell.value is not None else ""
                                    if "[" in val_as_str and "]" in val_as_str:
                                        full_tags = re.findall(r'\[\s*[A-Za-z0-9]{2,10}\s*\-\s*[A-Za-z_]{2,20}\s*\-\s*\d+\s*\]', val_as_str)
                                        if full_tags:
                                            original_text = val_as_str
                                            for raw_tag in sorted(list(set(full_tags)), key=len, reverse=True):
                                                clean_tag = re.sub(r'\s+', '', raw_tag).upper()
                                                if clean_tag in reverse_map:
                                                    val_as_str = val_as_str.replace(raw_tag, str(reverse_map[clean_tag]))
                                            if val_as_str != original_text:
                                                cell.value = val_as_str
                                                stats['tags'] += 1
                        
                        yield f"✅ SUCCESS: Restored {stats['tags']} tags in {stats['cells']} cells.\n"
                        val_map = {"dummy": stats['tags']}

                # Filtro output: rimuovi colonne/fogli non selezionati dall'utente in Manual mode.
                # Solo in fase di anonymize: per la deanonimizzazione l'utente vuole il file completo.
                if mode == 'anonymize' and selected_columns:
                    sheets_to_drop = [s.title for s in list(wb.worksheets) if selection_map.get(s.title) is None]
                    for sheet in list(wb.worksheets):
                        target_cols = selection_map.get(sheet.title)
                        if target_cols is None:
                            continue
                        header_row = next(sheet.iter_rows(min_row=1, max_row=1, values_only=False))
                        cols_to_delete = []
                        for i, cell in enumerate(header_row):
                            if cell.value not in target_cols:
                                cols_to_delete.append(i + 1)  # openpyxl: 1-based
                        for col_idx in sorted(cols_to_delete, reverse=True):
                            sheet.delete_cols(col_idx)
                    for title in sheets_to_drop:
                        del wb[title]
                    if not wb.sheetnames:
                        wb.create_sheet("Empty")
                    yield f"   ✂️  Output filtered to user selection ({len(wb.worksheets)} sheet(s) kept)\n"

                wb.save(out_path)
                yield f"💾 Workbook saved ({len(wb.worksheets)} sheets, {len(val_map)} replacements)\n"

            elif ext == '.csv':
                # === CSV ===
                import chardet
                with open(input_path, 'rb') as f:
                    enc = chardet.detect(f.read(10000))['encoding'] or 'utf-8'

                df = pd.read_csv(input_path, encoding=enc, sep=None, engine='python')
                yield f"📊 Loading CSV ({len(df)} rows, {len(df.columns)} columns)...\n"

                target_cols = [c for c in (selected_columns or []) if c in df.columns]
                if not target_cols:
                    target_cols = list(df.columns)

                string_cols = []
                numeric_cols = []
                for col in target_cols:
                    if df[col].dtype == 'object':
                        string_cols.append(col)
                    else:
                        numeric_cols.append(col)

                if numeric_cols:
                    yield f"   ⏭️ Numeric columns preserved: {numeric_cols}\n"

                if string_cols:
                    yield f"   🔍 Text columns to analyze: {string_cols}\n"

                    sensitive_keywords = ["soggetto", "nome", "cognome", "person", "name", "città", "city", "indirizzo", "address", "location", "telefono", "tel", "phone", "codice fiscale", "cf", "fiscal code", "iban", "email", "mail", "cliente", "paziente", "utente", "dipendente", "lavoratore"]
                    sensitive_cols = [col for col in string_cols if any(k in col.lower() for k in sensitive_keywords)]
                    free_text_cols = [col for col in string_cols if col not in sensitive_cols]

                    orig_df = df.copy()

                    for col in sensitive_cols:
                        unique_vals = [v for v in df[col].dropna().unique() if isinstance(v, str) and v.strip()]
                        if not unique_vals:
                            continue

                        yield f"   ➜ Protecting Structured Data: '{col}' ({len(unique_vals)} values)...\n"
                        val_map = {}
                        for i in range(0, len(unique_vals), 50):
                            chunk = unique_vals[i:i+50]
                            processed = await self.anonymize_batch(chunk, force_lang=detected_lang, column_hint=col, force_country=detected_country) if mode == 'anonymize' else await self.deanonymize_batch(chunk)
                            for orig, proc in zip(chunk, processed):
                                val_map[orig] = proc

                        df[col] = df[col].replace(val_map)

                    if sensitive_cols and free_text_cols and mode == 'anonymize':
                        yield f"   ➜ Entity Matching Synchronization...\n"
                        for idx in df.index:
                            row_map = {}
                            for s_col in sensitive_cols:
                                orig_val = str(orig_df.at[idx, s_col]).strip()
                                new_val = str(df.at[idx, s_col]).strip()
                                if orig_val and orig_val != "nan" and len(orig_val) > 2 and orig_val != new_val:
                                    row_map[orig_val] = new_val

                            if not row_map:
                                continue

                            for f_col in free_text_cols:
                                text = str(df.at[idx, f_col])
                                if not text or text == "nan":
                                    continue
                                modified = False
                                for orig_val, new_val in row_map.items():
                                    if orig_val in text:
                                        try:
                                            pattern = re.compile(r'\b' + re.escape(orig_val) + r'\b', re.IGNORECASE)
                                            new_text = pattern.sub(new_val, text)
                                            if new_text != text:
                                                text = new_text
                                                modified = True
                                        except:
                                            pass
                                if modified:
                                    df.at[idx, f_col] = text

                    for col in free_text_cols:
                        unique_vals = [v for v in df[col].dropna().unique() if isinstance(v, str) and v.strip()]
                        if not unique_vals:
                            continue

                        yield f"   ➜ Free Text Scanning: '{col}' ({len(unique_vals)} phrases)...\n"
                        val_map = {}
                        for i in range(0, len(unique_vals), 50):
                            chunk = unique_vals[i:i+50]
                            processed = await self.anonymize_batch(chunk, force_lang=detected_lang, column_hint=col, force_country=detected_country) if mode == 'anonymize' else await self.deanonymize_batch(chunk)
                            for orig, proc in zip(chunk, processed):
                                val_map[orig] = proc
                        df[col] = df[col].replace(val_map)

                if mode == 'anonymize' and free_text_cols and val_map:
                    pii_values = {orig for orig in val_map if len(orig) > 2 and not self.is_pure_data(orig)}
                    if pii_values:
                        yield f"   🔗 Cross-matching {len(pii_values)} PII values in free text...\n"
                        for f_col in free_text_cols:
                            for idx in df.index:
                                text = str(df.at[idx, f_col])
                                if not text or text == "nan" or len(text) <= 10:
                                    continue
                                modified = False
                                for orig in sorted(pii_values, key=len, reverse=True):
                                    if orig in text:
                                        text = text.replace(orig, val_map[orig])
                                        modified = True
                                if modified:
                                    df.at[idx, f_col] = text

                # Filtro output: solo colonne selezionate (Manual mode in anonymize).
                if mode == 'anonymize' and selected_columns:
                    keep = [c for c in df.columns if c in target_cols]
                    if keep:
                        df = df[keep]
                        yield f"   ✂️  Output filtered to {len(keep)} selected column(s)\n"

                yield "💾 Saving CSV...\n"
                df.to_csv(out_path, index=False, encoding='utf-8-sig', sep=';')

            elif ext == '.docx':
                yield "📝 Advanced Word Processing (Layout-Preserving)...\n"
                if mode == 'anonymize':
                    from services.word_anonymizer import WordAnonymizer
                    class VaultProxy:
                        def __init__(self, service): self.service = service
                        def get_or_create(self, text, etype): return self.service.get_or_create_placeholder(text, etype)
                    
                    word_anonymizer = WordAnonymizer(VaultProxy(self), language=detected_lang)
                    await word_anonymizer.process(str(input_path), str(out_path))
                else:
                    # DE-ANONYMIZE DOCX (Granular in-place replacement to preserve styles)
                    doc = Document(input_path)
                    reverse_map = self.reverse
                    
                    def process_element(element):
                        """Itera sui runs di un elemento per preservare gli stili."""
                        # Se l'elemento ha 'paragraphs', è una cella o una sezione
                        paragraphs = element.paragraphs if hasattr(element, 'paragraphs') else [element]
                            
                        for para in paragraphs:
                            for run in para.runs:
                                if "[" in run.text and "]" in run.text:
                                    original_run_text = run.text
                                    new_run_text = original_run_text
                                    for placeholder, original in reverse_map.items():
                                        new_run_text = new_run_text.replace(placeholder, original)
                                    if new_run_text != original_run_text:
                                        run.text = new_run_text

                    # 1. Paragrafi principali
                    for para in doc.paragraphs:
                        process_element(para)

                    # 2. Tabelle
                    for table in doc.tables:
                        for row in table.rows:
                            for cell in row.cells:
                                process_element(cell)
                    
                    # 3. Header/Footer
                    for section in doc.sections:
                        if section.header:
                            for para in section.header.paragraphs:
                                process_element(para)
                        if section.footer:
                            for para in section.footer.paragraphs:
                                process_element(para)

                    doc.save(out_path)

            elif ext in ['.txt', '.md']:
                yield "📄 Advanced Text Processing (Hybrid LLM)...\n"
                with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                if mode == 'anonymize':
                    from services.text_advanced_anonymizer import AdvancedTextAnonymizer
                    class VaultProxy:
                        def __init__(self, service): self.service = service
                        def get_or_create(self, text, etype): return self.service.get_or_create_placeholder(text, etype)
                    
                    text_anonymizer = AdvancedTextAnonymizer(VaultProxy(self), language=detected_lang)
                    processed = await text_anonymizer.process(content)
                else:
                    processed = await self.deanonymize_text(content)
                
                with open(out_path, 'w', encoding='utf-8') as f:
                    f.write(processed)

            elif ext == '.pdf' and mode == 'anonymize':
                yield "📑 Advanced PDF Processing (OCR + Hybrid LLM)...\n"
                from services.pdf_anonymizer import PDFAnonymizer
                
                class VaultProxy:
                    def __init__(self, service): self.service = service
                    def get_or_create(self, text, etype): return self.service.get_or_create_placeholder(text, etype)
                
                pdf_anonymizer = PDFAnonymizer(VaultProxy(self), language=detected_lang)
                
                try:
                    yield "📑 Analyzing PDF structure (Checking for images/scans)...\n"
                    
                    # Detect images before processing
                    import pypdf
                    reader = pypdf.PdfReader(input_path)
                    has_images = False
                    for page in reader.pages:
                        if page.images:
                            has_images = True
                            break
                    
                    if has_images:
                        yield "📸 PDF with images detected. Initializing OCR engine (glm-ocr)...\n"
                    
                    # Intercept the OCRImgPDFProcessor
                    from processors.ocr_processor import OCRImgPDFProcessor
                    proc = OCRImgPDFProcessor()
                    success, raw_text = await proc.process_pdf(str(input_path))
                    
                    if not success:
                        raise Exception(f"Failed to extract text from PDF: {raw_text}")
                    
                    yield "🛡️ Anonymizing extracted text using hybrid engine...\n"

                    # Salva raw OCR per ispezione (debug helper, separato dall'output finale)
                    debug_raw = out_path.with_name(f"_DEBUG_{out_path.stem}_OCR_RAW.txt")
                    try:
                        with open(debug_raw, 'w', encoding='utf-8') as f:
                            f.write(raw_text)
                        yield f"   📝 Raw OCR saved for inspection: {debug_raw.name}\n"
                    except Exception:
                        pass

                    # Splitter: pagine → chunk piccoli (paragrafi / tabelle / liste).
                    # Soglia 400 char: blocchi più grandi fanno perdere recall a gemma4:e4b
                    # (testato su atti AdE — con 800 char perde nomi UPPERCASE in tabelle).
                    def split_into_chunks(text_block: str, max_chars: int = 400) -> List[str]:
                        if len(text_block) <= max_chars:
                            return [text_block]
                        # Split per doppia newline (paragrafi). Mantieni tabelle HTML/MD intere se stanno sotto soglia.
                        raw_paragraphs = text_block.split("\n\n")
                        chunks: List[str] = []
                        buf = ""
                        for para in raw_paragraphs:
                            if len(para) > max_chars:
                                # Tabella o paragrafo enorme: spezza per singola newline
                                if buf:
                                    chunks.append(buf)
                                    buf = ""
                                lines_para = para.split("\n")
                                line_buf = ""
                                for ln in lines_para:
                                    if len(line_buf) + len(ln) + 1 > max_chars and line_buf:
                                        chunks.append(line_buf)
                                        line_buf = ln
                                    else:
                                        line_buf = (line_buf + "\n" + ln) if line_buf else ln
                                if line_buf:
                                    chunks.append(line_buf)
                            elif len(buf) + len(para) + 2 > max_chars and buf:
                                chunks.append(buf)
                                buf = para
                            else:
                                buf = (buf + "\n\n" + para) if buf else para
                        if buf:
                            chunks.append(buf)
                        return chunks

                    lines = raw_text.split("\n")
                    anonymized_parts = []
                    current_block = []

                    async def process_block(block_text: str):
                        """Anonimizza un blocco-pagina splittandolo in chunk piccoli."""
                        if not block_text.strip(): return
                        chunks = split_into_chunks(block_text, max_chars=400)
                        for chunk in chunks:
                            if chunk.strip():
                                anon = await pdf_anonymizer.text_engine.process(chunk)
                                anonymized_parts.append(anon)

                    for line in lines:
                        if "--- Page" in line and "---" in line:
                            if current_block:
                                await process_block("\n".join(current_block))
                                current_block = []
                            anonymized_parts.append(line)
                        else:
                            current_block.append(line)

                    if current_block:
                        await process_block("\n".join(current_block))

                    # Salva versione anonimizzata raw per ispezione (debug helper)
                    debug_anon = out_path.with_name(f"_DEBUG_{out_path.stem}_ANON_RAW.txt")
                    try:
                        with open(debug_anon, 'w', encoding='utf-8') as f:
                            f.write("\n\n".join(anonymized_parts))
                    except Exception:
                        pass
                    yield "💾 Reconstructing as DOCX with advanced formatting...\n"
                    from docx.shared import Pt, RGBColor
                    from docx.enum.text import WD_ALIGN_PARAGRAPH
                    from bs4 import BeautifulSoup

                    doc = Document()

                    doc.core_properties.title = f"Anonymized_{input_path.stem}"

                    def add_formatted_text(p, text_content):
                        """Aggiunge testo al paragrafo gestendo il grassetto **text**."""
                        import re
                        parts = re.split(r'(\*\*.*?\*\*)', text_content)
                        for part in parts:
                            if part.startswith('**') and part.endswith('**'):
                                run = p.add_run(part[2:-2])
                                run.bold = True
                            else:
                                p.add_run(part)

                    # Parser avanzato per gestire Markdown e HTML Tables
                    for block in anonymized_parts:
                        block_strip = block.strip()
                        if not block_strip: continue

                        # 1. Header di Pagina
                        if "--- Page" in block and "---" in block:
                            p = doc.add_paragraph()
                            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                            run = p.add_run(block.replace("**", "").replace("---", "").strip())
                            run.bold = True
                            run.font.size = Pt(12)
                            run.font.color.rgb = RGBColor(0, 102, 204)
                            continue

                        # 2. Tabelle HTML (GLM-OCR Special)
                        if "<table" in block.lower():
                            try:
                                soup = BeautifulSoup(block, 'html.parser')
                                for table_tag in soup.find_all('table'):
                                    rows = table_tag.find_all('tr')
                                    if not rows: continue
                                    
                                    # Calcolo colonne
                                    max_cols = 0
                                    for row in rows:
                                        cols_in_row = sum(int(cell.get('colspan', 1)) for cell in row.find_all(['td', 'th']))
                                        max_cols = max(max_cols, cols_in_row)
                                    
                                    word_table = doc.add_table(rows=len(rows), cols=max_cols)
                                    word_table.style = 'Table Grid'
                                    
                                    for r_idx, row in enumerate(rows):
                                        word_row = word_table.rows[r_idx]
                                        current_col = 0
                                        for cell in row.find_all(['td', 'th']):
                                            if current_col < max_cols:
                                                w_cell = word_row.cells[current_col]
                                                text_val = cell.get_text().strip()
                                                p = w_cell.paragraphs[0]
                                                add_formatted_text(p, text_val)
                                                if cell.name == 'th' or r_idx == 0:
                                                    for run in p.runs: run.bold = True
                                                current_col += int(cell.get('colspan', 1))
                                continue
                            except Exception as e:
                                logger.error(f"Error parsing HTML table in anonymize: {e}")
                                # Fallback a testo grezzo se BS4 fallisce
                                doc.add_paragraph(block)
                                continue

                        # 3. Tabelle Markdown
                        if block_strip.startswith('|') and '|' in block_strip[1:]:
                            table_lines = [l.strip() for l in block.split('\n') if l.strip().startswith('|')]
                            table_data = []
                            for row_str in table_lines:
                                if re.match(r'^\s*\|?[\s-]*:?-+[:\s-]*\|', row_str): continue
                                cells = [c.strip() for c in row_str.split('|') if c.strip() or row_str.count('|') > 1]
                                if row_str.startswith('|'): cells = cells[1:]
                                if row_str.endswith('|'): cells = cells[:-1]
                                if cells: table_data.append(cells)
                            
                            if table_data:
                                word_table = doc.add_table(rows=len(table_data), cols=max(len(r) for r in table_data))
                                word_table.style = 'Table Grid'
                                for r_idx, row_cells in enumerate(table_data):
                                    for c_idx, cell_text in enumerate(row_cells):
                                        if c_idx < len(word_table.columns):
                                            p = word_table.cell(r_idx, c_idx).paragraphs[0]
                                            add_formatted_text(p, cell_text)
                                            if r_idx == 0:
                                                for run in p.runs: run.bold = True
                            continue

                        # 4. Markdown Headers e Testo
                        if block_strip.startswith('# '):
                            doc.add_heading(block_strip[2:], level=1)
                        elif block_strip.startswith('## '):
                            doc.add_heading(block_strip[3:], level=2)
                        elif block_strip.startswith('- ') or block_strip.startswith('* '):
                            p = doc.add_paragraph(style='List Bullet')
                            add_formatted_text(p, block_strip[2:])
                        else:
                            p = doc.add_paragraph()
                            add_formatted_text(p, block_strip)

                    doc.save(str(out_path))
                except Exception as e:
                    yield f"❌ PDF Processing Error: {str(e)}\n"
                    return

            if mode == 'anonymize' and cloud_ready:
                yield "🛡️ Applying CLOUD READY Deep Sanitization...\n"
                await self._apply_cloud_ready(out_path)

            yield f"✅ Created: {out_name}\n"
            yield f"DONE:{out_name}\n"

        except Exception as e:
            import traceback
            logger.error(f"Fatal error in process_file_stream: {e}\n{traceback.format_exc()}")
            yield f"❌ Fatal Error: {str(e)}\n"

    async def _process_pdf_with_yielding(self, pdf_path: Path, session_id: str) -> Tuple[bool, str]:
        """Custom PDF processor that detects images and yields OCR status."""
        from processors.ocr_processor import OCRImgPDFProcessor
        proc = OCRImgPDFProcessor()
        
        import pypdf
        reader = pypdf.PdfReader(pdf_path)
        has_images = False
        for page in reader.pages:
            if page.images:
                has_images = True
                break
        
        # Note: we still return a tuple, but the calling function (process_file_stream)
        # will have already yielded the OCR message if has_images was true.
        return await proc.process_pdf(str(pdf_path))

    async def _apply_cloud_ready(self, file_path: Path):
        from processors.office_utility_processor import OfficeUtilityProcessor
        temp_out = file_path.with_name(file_path.name + ".tmp")
        processor = OfficeUtilityProcessor()
        try:
            success, removed_meta = await processor.sanitize_file(file_path, temp_out)
            if success and temp_out.exists():
                import shutil
                shutil.move(str(temp_out), str(file_path))
            else:
                self._strip_metadata(file_path)
        except Exception as e:
            logger.warning(f"Cloud Ready sanitization failed: {e}")
            self._strip_metadata(file_path)

    def _strip_metadata(self, path: Path):
        try:
            past_ts = time.mktime((2000, 1, 1, 0, 0, 0, 0, 0, 0))
            os.utime(path, (past_ts, past_ts))
        except: pass

    async def upload_file(self, file_path: str, filename: str, session_id: str, mode: str = "anonymize") -> Dict:
        self.staged_files.setdefault(session_id, []).append({"name": filename, "path": file_path, "mode": mode})
        return {"status": "staged", "message": f"Pronto."}

    def get_files(self, session_id: str) -> Dict:
        return {"staged": self.staged_files.get(session_id, []), "uploaded": self.uploaded_files.get(session_id, [])}

    def clear_session(self, session_id: str):
        self.staged_files[session_id] = []
        self.uploaded_files[session_id] = []

    async def anonymize_text(self, text: str, force_lang: str = None) -> str:
        res = await self.anonymize_batch([text], force_lang)
        return res[0] if res else text

    async def deanonymize_text(self, text: str) -> str:
        res = await self.deanonymize_batch([text])
        return res[0] if res else text

    # ─── Interactive review workflow ────────────────────────────────────────
    # New flow added to support the "Analyze → Review → Apply" UX inspired by
    # the PDF Toolkit "PECETTE" feature. Only for text-bearing files (PDF,
    # DOCX, TXT, MD). XLSX/CSV keep their legacy Manual columns workflow.

    SUPPORTED_TEXT_REVIEW_EXT = {".pdf", ".docx", ".doc", ".txt", ".md"}

    async def _extract_text_for_review(self, input_path: Path) -> Tuple[str, str]:
        """Return (text, file_kind) where file_kind is one of:
            'pdf' (always passed through OCR/text extraction → page markers),
            'docx', 'txt'.
        For PDF, returns text with `--- Page N ---` markers (same format
        produced by OCRImgPDFProcessor) so we can reconstruct paginated DOCX.
        """
        ext = input_path.suffix.lower()
        if ext == ".pdf":
            from processors.ocr_processor import OCRImgPDFProcessor
            proc = OCRImgPDFProcessor()
            success, raw_text = await proc.process_pdf(str(input_path))
            if not success:
                raise RuntimeError(f"PDF text extraction failed: {raw_text}")
            return raw_text, "pdf"
        if ext in (".docx", ".doc"):
            from docx import Document
            doc = Document(input_path)
            parts: List[str] = []
            for para in doc.paragraphs:
                if para.text:
                    parts.append(para.text)
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        if cell.text:
                            parts.append(cell.text)
            return "\n\n".join(parts), "docx"
        if ext in (".txt", ".md"):
            with open(input_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read(), "txt"
        raise ValueError(f"Unsupported extension for review workflow: {ext}")

    async def analyze_text_file(
        self,
        input_path: Path,
        country: Optional[str] = None,
        locale: Optional[str] = None,
    ) -> Dict:
        """Extract text from the file and detect PII entities WITHOUT applying
        substitutions. Returns:

            {
                'text': str,                 # raw extracted text
                'file_kind': str,            # 'pdf' | 'docx' | 'txt'
                'detected_lang': str,        # auto-detected language code
                'detected_country': str,     # auto-detected or forced country
                'entities': [                # detected PII, ready for review
                    {'id', 'type', 'text', 'start', 'end', 'score',
                     'occurrences': N, 'sample_context': '...'},
                    ...
                ],
            }
        """
        text, file_kind = await self._extract_text_for_review(input_path)

        # Resolve language (UI override > document detection > IT fallback).
        if locale and locale.lower() in ("it", "en", "fr", "de"):
            detected_lang = locale.lower()
        else:
            detected_lang = self._detect_document_language(input_path)

        # Resolve country (UI override > sample-based detection).
        if country and country.lower() != "auto":
            detected_country = country.upper()
        else:
            sample = text[:2000]
            detected_country = self._detect_country(sample, detected_lang)

        # Run analyze() on the AdvancedTextAnonymizer. We don't apply yet.
        from services.text_advanced_anonymizer import AdvancedTextAnonymizer

        class _NullVault:
            """No-op vault used during analyze (no placeholders persisted)."""
            def get_or_create(self, text, etype):
                return f"[{etype}]"

        engine = AdvancedTextAnonymizer(_NullVault(), language=detected_lang)
        raw_entities = await engine.analyze(text)

        # Group by (type, normalized_text) so the UI can show one row per
        # logical entity even when it appears multiple times. For each group
        # we build a wider context window (±80 chars) split into pre/match/
        # post pieces so the frontend can highlight the match inline.
        CTX_RADIUS = 80
        grouped: Dict[Tuple[str, str], Dict] = {}
        for e in raw_entities:
            key = (e["type"], e["text"].strip().lower())
            if key not in grouped:
                ctx_start = max(0, e["start"] - CTX_RADIUS)
                ctx_end = min(len(text), e["end"] + CTX_RADIUS)
                pre = text[ctx_start:e["start"]].replace("\n", " ")
                match = text[e["start"]:e["end"]].replace("\n", " ")
                post = text[e["end"]:ctx_end].replace("\n", " ")
                grouped[key] = {
                    "id": f"{e['type']}-{e['text'].strip()[:30]}",
                    "type": e["type"],
                    "text": e["text"].strip(),
                    "occurrences_count": 0,
                    # Legacy field — kept for backward compat with any older
                    # frontend that hasn't been updated to use the split fields.
                    "sample_context": f"{pre}{match}{post}".strip(),
                    "sample_pre": pre,
                    "sample_match": match,
                    "sample_post": post,
                    "max_score": 0.0,
                    "_raw_spans": [],
                }
            grouped[key]["occurrences_count"] += 1
            if float(e["score"]) > grouped[key]["max_score"]:
                grouped[key]["max_score"] = float(e["score"])
            grouped[key]["_raw_spans"].append({
                "start": e["start"],
                "end": e["end"],
                "score": e["score"],
            })

        entities_for_ui = []
        for _, g in grouped.items():
            entities_for_ui.append({
                "id": g["id"],
                "type": g["type"],
                "text": g["text"],
                "occurrences_count": g["occurrences_count"],
                "sample_context": g["sample_context"],
                "sample_pre": g["sample_pre"],
                "sample_match": g["sample_match"],
                "sample_post": g["sample_post"],
                "max_score": g["max_score"],
                # _raw_spans is kept server-side via job cache.
                "_raw_spans": g["_raw_spans"],
            })

        return {
            "text": text,
            "file_kind": file_kind,
            "detected_lang": detected_lang,
            "detected_country": detected_country,
            "entities": entities_for_ui,
        }

    async def apply_text_anonymization_filtered(
        self,
        input_path: Path,
        output_dir: Path,
        original_text: str,
        entities: List[Dict],
        selected_ids: List[str],
        file_kind: str,
        detected_lang: str = "it",
        sanitize: bool = False,
    ) -> Dict:
        """Apply anonymization on `original_text` using only the entities whose
        id is in `selected_ids`, save the output file in `output_dir`, and
        persist the vault mapping (so deanonymization will work later).

        Returns {'filename', 'applied_count'}.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        ts = int(time.time())
        base = input_path.stem

        # Flatten the grouped entities back to span-level entries so
        # AdvancedTextAnonymizer.apply_selected can do offset-based replace.
        # The id we ship to the frontend is grouped; here we expand it.
        selected = set(selected_ids or [])
        flat_entities: List[Dict] = []
        for e in entities:
            if e["id"] not in selected:
                continue
            for span in e.get("_raw_spans", []):
                flat_entities.append({
                    "id": f"{e['type']}-{span['start']}-{span['end']}",
                    "type": e["type"],
                    "text": original_text[span["start"]:span["end"]],
                    "start": span["start"],
                    "end": span["end"],
                    "score": span["score"],
                })

        applied_count = len(flat_entities)

        # Apply substitutions using the real vault (so deanon will work).
        from services.text_advanced_anonymizer import AdvancedTextAnonymizer

        class _ServiceVault:
            def __init__(self, service):
                self.service = service
            def get_or_create(self, text, etype):
                return self.service.get_or_create_placeholder(text, etype)

        engine = AdvancedTextAnonymizer(_ServiceVault(self), language=detected_lang)
        # apply_selected with None on the flat list (all flat entries are
        # already pre-filtered).
        anonymized_text = engine.apply_selected(original_text, flat_entities, selected_ids=None)

        # Reconstruct output file based on the original file kind.
        if file_kind == "txt":
            out_name = f"{base}_ANON_{ts}.txt"
            out_path = output_dir / out_name
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(anonymized_text)
        elif file_kind == "docx":
            out_name = f"{base}_ANON_{ts}.docx"
            out_path = output_dir / out_name
            from docx import Document
            doc = Document()
            for para_text in anonymized_text.split("\n\n"):
                doc.add_paragraph(para_text)
            doc.save(out_path)
        else:  # pdf → output DOCX with simple paragraph layout
            out_name = f"{base}_ANON_{ts}.docx"
            out_path = output_dir / out_name
            from docx import Document
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            doc = Document()
            doc.core_properties.title = f"Anonymized_{base}"
            for line in anonymized_text.split("\n"):
                line_strip = line.strip()
                if "--- Page" in line_strip and "---" in line_strip:
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p.add_run(line_strip.replace("---", "").strip()).bold = True
                elif line_strip:
                    doc.add_paragraph(line_strip)
            doc.save(out_path)

        if sanitize:
            try:
                await self._apply_cloud_ready(out_path)
            except Exception as e:
                logger.warning(f"Sanitize failed for {out_path.name}: {e}")

        return {
            "filename": out_name,
            "applied_count": applied_count,
        }


anonimyze_service = AnonimyzeService()
