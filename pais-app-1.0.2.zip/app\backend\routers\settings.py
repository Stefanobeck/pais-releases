"""
Settings Routes - API per impostazioni e traduzioni
"""
import json
from fastapi import APIRouter, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Dict, List, Any, Optional

from services.i18n_service import i18n
from services.system_service import system_service
from backend_config import settings as app_settings

router = APIRouter()


class LanguageRequest(BaseModel):
    lang: str


class LanguageResponse(BaseModel):
    lang: str
    available: List[str]


class LabelsResponse(BaseModel):
    labels: Dict
    lang: str


@router.get("/settings/language", response_model=LanguageResponse)
async def get_language():
    """Ottieni lingua corrente e lingue disponibili."""
    return LanguageResponse(
        lang=i18n.get_current_lang(),
        available=i18n.get_available_languages()
    )


@router.post("/settings/language", response_model=LanguageResponse)
async def set_language(request: LanguageRequest):
    """Imposta lingua corrente."""
    success = i18n.set_language(request.lang)
    
    if not success:
        raise HTTPException(status_code=400, detail=f"Lingua '{request.lang}' non disponibile")
    
    return LanguageResponse(
        lang=i18n.get_current_lang(),
        available=i18n.get_available_languages()
    )


@router.get("/settings/labels", response_model=LabelsResponse)
async def get_labels():
    """Ottieni tutte le label per la lingua corrente."""
    return LabelsResponse(
        labels=i18n.get_all_labels(),
        lang=i18n.get_current_lang()
    )


@router.get("/settings/label/{key}")
async def get_label(key: str, default: str = None):
    """Ottieni una label specifica per chiave."""
    label = i18n.get(key, default)
    return {"key": key, "value": label, "lang": i18n.get_current_lang()}


@router.get("/system/status")
async def get_system_status():
    """Restituisce lo stato di salute dei modelli e del motore AI."""
    try:
        return await system_service.get_system_status()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/system/hardware")
async def get_system_hardware(refresh: bool = False):
    """CPU/RAM/GPU/VRAM detection + verdict honest assessment.
    Cached 60s. Pass ?refresh=true per forzare la rilevazione.

    Il sistema profili HIGH/LOW è stato rimosso: la response include `verdict`
    {tier: OTTIMO|ADEGUATO|MARGINALE, text_it, text_en} che il frontend
    renderizza al posto del vecchio profile picker.
    """
    try:
        from services.hardware_service import detect_hardware
        return detect_hardware(force_refresh=refresh)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/system/install")
async def install_model(model_type: str, model_id: str):
    """Avvia l'installazione di un modello in streaming."""
    async def stream_progress():
        try:
            async for progress in system_service.install_model(model_id, model_type):
                yield json.dumps(progress) + "\n"
        except Exception as e:
            yield json.dumps({"status": "error", "message": str(e)}) + "\n"

    return StreamingResponse(stream_progress(), media_type="application/x-ndjson")


@router.get("/system/install_preflight")
async def install_preflight_endpoint(required_bytes: int = 0):
    """Controlla lo spazio disco prima di avviare il download batch dei modelli.
    `required_bytes` = somma stimata dei modelli mancanti (passata dal frontend)."""
    try:
        return system_service.install_preflight(required_bytes)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Auto-update (Opzione 1: manifest + download setup.exe + lancio) ──────────
class UpdateLaunchRequest(BaseModel):
    path: str


@router.get("/system/update_check")
async def update_check_endpoint():
    """Controlla se c'è una versione più recente (manifest remoto). Graceful:
    se il manifest è assente/irraggiungibile ritorna update_available=False."""
    from services import update_service
    return update_service.check_for_update()


@router.get("/system/update_download")
async def update_download_endpoint(url: str, sha256: str = ""):
    """Scarica il nuovo setup.exe in streaming (NDJSON) con verifica sha256."""
    from services import update_service

    async def stream_progress():
        try:
            async for progress in update_service.download_update(url, sha256):
                yield json.dumps(progress) + "\n"
        except Exception as e:
            yield json.dumps({"status": "error", "message": str(e)}) + "\n"

    return StreamingResponse(stream_progress(), media_type="application/x-ndjson")


@router.post("/system/update_launch")
async def update_launch_endpoint(req: UpdateLaunchRequest):
    """Lancia l'installer scaricato (upgrade in-place). Il frontend chiude poi l'app."""
    from services import update_service
    try:
        return update_service.launch_installer(req.path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/update_app_apply")
async def update_app_apply_endpoint(req: UpdateLaunchRequest):
    """Applica un update incrementale 'app-only' (zip già scaricato+verificato):
    un helper sovrascrive app\\ a PAIS chiuso e rilancia. Il frontend chiude poi l'app."""
    from services import update_service
    try:
        return update_service.apply_app_update(req.path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/system/model")
async def delete_model(model_type: str, model_id: str):
    """Elimina fisicamente un modello dal sistema."""
    try:
        success = await system_service.delete_model(model_id, model_type)
        if success:
            return {"status": "success", "message": f"Model {model_id} deleted."}
        else:
            raise HTTPException(status_code=400, detail="Failed to delete model")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Enabled modules ────────────────────────────────────────────────────────
# Persistenza dei moduli che l'utente ha esplicitamente attivato dalla pagina
# AI Setup. Source of truth: user_settings.json (vedi user_settings_service).


class _EnabledModulesBody(BaseModel):
    enabled: List[str]


@router.get("/system/enabled_modules")
async def get_enabled_modules_endpoint():
    """Ritorna {"enabled": [...]} con la lista di moduli attivati dall'utente.

    Migrazione lazy: se la lista persistita e' vuota MA l'utente ha gia' modelli
    installati (upgrade da versione precedente), auto-popola la lista con i
    moduli i cui requisiti minimi sono soddisfatti.
    """
    from services import user_settings_service as uss
    current = uss.get_enabled_modules()
    if current:
        return {"enabled": current}
    # Migrazione lazy — recupera installed names da system_service e auto-detect.
    try:
        status = await system_service.get_system_status()
        installed: List[str] = []
        for m in (status.get("models") or {}).get("ollama", []):
            if m.get("installed") and m.get("id"):
                installed.append(m["id"])
        for m in (status.get("models") or {}).get("local", []):
            if m.get("installed") and m.get("id"):
                installed.append(m["id"])
        auto = uss.auto_detect_and_persist_enabled_modules(installed)
        return {"enabled": auto}
    except Exception as e:
        # Migrazione fallita non blocca: ritorna lista vuota, utente sceglie da zero.
        import logging
        logging.getLogger("PAIS").warning(f"enabled_modules migration skipped: {e}")
        return {"enabled": []}


@router.post("/system/enabled_modules")
async def set_enabled_modules_endpoint(body: _EnabledModulesBody):
    """Persiste la nuova lista. Whitelist + dedup applicati lato service.
    Echo back la lista pulita cosi' il frontend si sincronizza con la verita'.
    """
    from services import user_settings_service as uss
    try:
        clean = uss.set_enabled_modules(body.enabled)
        return {"enabled": clean}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/system/tos")
async def get_tos_status():
    """Controlla se i termini di servizio sono stati accettati."""
    return {"accepted": system_service.get_tos_status()}


@router.get("/system/hai-def-terms")
async def get_hai_def_terms_status():
    """Stato accettazione HAI-DEF Terms (richiesti per MedGemma).

    Returns: { accepted: bool, accepted_at: str|null, version: str|null,
               current_version: str (server-side current HAI-DEF version) }
    """
    status = system_service.get_hai_def_status()
    status["current_version"] = system_service.HAI_DEF_CURRENT_VERSION
    return status


class _HaiDefAcceptBody(BaseModel):
    version: Optional[str] = None


@router.post("/system/hai-def-terms")
async def accept_hai_def_terms(body: Optional[_HaiDefAcceptBody] = None):
    """Registra l'accettazione dei HAI-DEF Terms (Section 3.1.4 pass-through)."""
    version = body.version if body and body.version else None
    if system_service.accept_hai_def_terms(version=version):
        return {
            "status": "success",
            "version": version or system_service.HAI_DEF_CURRENT_VERSION,
        }
    raise HTTPException(status_code=500, detail="Failed to save HAI-DEF acceptance")


@router.post("/system/tos")
async def accept_tos():
    """Registra l'accettazione dei termini di servizio."""
    if system_service.accept_tos():
        return {"status": "success"}
    else:
        raise HTTPException(status_code=500, detail="Failed to save ToS acceptance")


# ─── Telegram bot per-channel overrides (model/profile/lang) ────────────────
class BotOverridesRequest(BaseModel):
    model: str | None = None
    profile: str | None = None
    lang: str | None = None


@router.get("/system/bot/overrides")
async def get_bot_overrides():
    """Read current Telegram-bot overrides + the desktop defaults that would apply
    when an override is null. Useful for the Settings UI dropdowns.
    """
    overrides = system_service.get_telegram_overrides()
    return {
        "telegram": overrides,
        "defaults": {
            "model": getattr(app_settings, "CHAT_MODEL", None),
            "profile": getattr(app_settings, "CHAT_PROFILE", None),
            "lang": i18n.get_current_lang(),
        },
    }


@router.post("/system/bot/overrides")
async def set_bot_overrides(req: BotOverridesRequest):
    ok = system_service.set_telegram_overrides(req.model, req.profile, req.lang)
    if not ok:
        raise HTTPException(status_code=500, detail="Failed to save bot overrides")
    return {"status": "success", "telegram": system_service.get_telegram_overrides()}


# ─── Studio Identity (header per export Word/PDF) ──────────────────────────
class StudioIdentityRequest(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    vat: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None


@router.get("/system/studio_identity")
async def get_studio_identity():
    """Read the studio identity (or null if not configured). Logo URL is the
    relative path; frontend serves it from /api/system/studio_identity/logo.
    """
    try:
        from services import user_settings_service as uss
        return {"studio": uss.get_studio_identity()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/studio_identity")
async def update_studio_identity(req: StudioIdentityRequest):
    """Persist studio identity fields. Empty strings clear the field."""
    try:
        from services import user_settings_service as uss
        saved = uss.set_studio_identity(req.model_dump(exclude_none=False))
        return {"status": "success", "studio": uss.get_studio_identity(), "raw": saved}
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/studio_identity/logo")
async def upload_studio_logo(file: UploadFile = File(...)):
    """Upload studio logo (PNG/JPG/SVG, max 2MB). Replaces any existing logo."""
    try:
        from services.studio_identity_service import save_logo
        content = await file.read()
        rel_path = save_logo(content, file.content_type or "", file.filename or "")
        return {"status": "success", "logo_path": rel_path}
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/system/studio_identity/logo")
async def serve_studio_logo():
    """Serve the current logo file (used by frontend to preview)."""
    from fastapi.responses import FileResponse
    try:
        from services.studio_identity_service import get_logo_full_path
        p = get_logo_full_path()
        if not p:
            raise HTTPException(status_code=404, detail="No logo configured")
        # Cache breaker: il path lo sceglie il backend al save (estensione fissa per content-type),
        # quindi possiamo lasciare i default.
        return FileResponse(str(p))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/system/studio_identity/logo")
async def delete_studio_logo():
    try:
        from services.studio_identity_service import delete_logo
        existed = delete_logo()
        return {"status": "success", "deleted": existed}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Studio export options (header only: toggle + template + posizione logo) ──
# NB: il footer studio è stato rimosso dal prodotto. `include_footer` resta
# accettato (ignorato) solo per retro-compatibilità di vecchi client.
class StudioExportOptionsRequest(BaseModel):
    include_header: bool = True
    header_template: str = "blue"
    logo_position: str = "left"
    include_footer: bool | None = None  # deprecato, ignorato


@router.get("/system/studio_export_options")
async def get_studio_export_options_endpoint():
    try:
        from services import user_settings_service as uss
        return uss.get_studio_export_options()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/studio_export_options")
async def set_studio_export_options_endpoint(req: StudioExportOptionsRequest):
    try:
        from services import user_settings_service as uss
        return uss.set_studio_export_options(
            req.include_header, req.header_template, req.logo_position
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Interrogate direct mode (system prompt injection) ────────────────────
class DirectModeRequest(BaseModel):
    enabled: bool


@router.get("/system/interrogate_direct_mode")
async def get_direct_mode_endpoint():
    try:
        from services import user_settings_service as uss
        return {"enabled": uss.get_interrogate_direct_mode()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/interrogate_direct_mode")
async def set_direct_mode_endpoint(req: DirectModeRequest):
    try:
        from services import user_settings_service as uss
        return {"enabled": uss.set_interrogate_direct_mode(req.enabled)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Interrogate Compare Mode (document diff) ──────────────────────────────
class CompareModeRequest(BaseModel):
    enabled: bool


@router.get("/system/interrogate_compare_mode")
async def get_compare_mode_endpoint():
    try:
        from services import user_settings_service as uss
        return {"enabled": uss.get_interrogate_compare_mode()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/system/interrogate_compare_mode")
async def set_compare_mode_endpoint(req: CompareModeRequest):
    try:
        from services import user_settings_service as uss
        # PRO gate — Compare Mode is a PRO feature. Only enabling it requires
        # PRO/trial; disabling is always allowed so a lapsed user can turn it
        # off and keep using plain Interrogate.
        if req.enabled:
            from backend_config.auth_pro import require_pro_or_trial
            require_pro_or_trial()  # raises 402 if not pro/trial
        return {"enabled": uss.set_interrogate_compare_mode(req.enabled)}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
