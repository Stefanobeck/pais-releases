"""ONNX-backed PII NER engine — modello `onnx-community/multilang-pii-ner-ONNX` (MIT).

Usa onnxruntime puro invece di optimum per evitare dipendenze pesanti (e bug noti
con torch>=2.11 che rompono `optimum.exporters.onnx`). Il modello è bundlato nella
source tree dell'app (`pai-premium/backend/models/onnx_pii/`) per essere shippato
direttamente nell'installer commerciale.
"""
import json
import logging
import os
import threading
from pathlib import Path
from typing import Optional

from .base import NerEngine, NerSpan

logger = logging.getLogger(__name__)

MODEL_REPO = "onnx-community/multilang-pii-ner-ONNX"
SUPPORTED_LANGS = {"en", "it", "de", "fr"}
BACKEND_DIR = Path(__file__).resolve().parent.parent.parent
LOCAL_MODEL_DIR = BACKEND_DIR / "models" / "onnx_pii" / MODEL_REPO.split("/")[-1]

# Mapping label nativi del modello → entity type Presidio. GENDER/SEX scartati.
# DRIVERLICENSENUM e PASSPORTNUM esclusi: il NER non sa distinguere il paese e
# tende a falsi positivi (parti di un CF italiano / NIR francese vengono spesso
# classificati come US driver's license). Questi pattern restano alle regex
# jurisdiction-aware in JURISDICTION_PATTERNS, che sono deterministiche e per-paese.
LABEL_MAP = {
    "GIVENNAME": "PERSON",
    "SURNAME": "PERSON",
    "STREET": "LOCATION",
    "BUILDINGNUM": "LOCATION",
    "CITY": "LOCATION",
    "EMAIL": "EMAIL_ADDRESS",
    "TELEPHONENUM": "PHONE_NUMBER",
    "DATE": "DATE_TIME",
    "TIME": "DATE_TIME",
    "AGE": "DATE_TIME",
}

SUPPORTED_ENTITIES = set(LABEL_MAP.values())


class OnnxPiiNerEngine(NerEngine):
    def __init__(self):
        self._model = None
        self._tokenizer = None
        self._id2label = None
        self._lock = threading.Lock()

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        with self._lock:
            if self._model is not None:
                return
            import onnxruntime as ort
            from transformers import AutoTokenizer

            if not (LOCAL_MODEL_DIR / ".install_complete").exists():
                raise RuntimeError(
                    f"PII NER model not found at {LOCAL_MODEL_DIR}. "
                    "Run `python -m scripts.fetch_pii_model` from the backend dir."
                )

            onnx_rel = os.environ.get("PAI_ONNX_MODEL_FILE", "onnx/model.onnx")
            onnx_path = LOCAL_MODEL_DIR / onnx_rel
            config_path = LOCAL_MODEL_DIR / "config.json"

            logger.info(f"Loading ONNX PII NER from {LOCAL_MODEL_DIR} (variant: {onnx_rel})")
            self._model = ort.InferenceSession(
                str(onnx_path),
                providers=["CPUExecutionProvider"],
            )
            # local_files_only=True: il modello è già stato scaricato da
            # scripts/fetch_pii_model.py con commit hash pinato. Vietiamo
            # esplicitamente fallback di rete per evitare scarichi non pinati.
            self._tokenizer = AutoTokenizer.from_pretrained(  # nosec B615 - local_files_only=True forbids network fetch; model already pinned in fetch_pii_model.py
                str(LOCAL_MODEL_DIR),
                local_files_only=True,
            )
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            # id2label arriva come dict[str, str] dal JSON; normalizza a dict[int, str].
            self._id2label = {int(k): v for k, v in config.get("id2label", {}).items()}
            logger.info(
                f"ONNX PII NER ready ({len(self._id2label)} labels, "
                f"{len(SUPPORTED_LANGS)} languages, providers={self._model.get_providers()})"
            )

    def warmup(self) -> None:
        self._ensure_loaded()
        self.analyze("warmup string", "en")

    def analyze(self, text: str, language: str) -> list[NerSpan]:
        if not text or not text.strip():
            return []
        self._ensure_loaded()

        if language not in SUPPORTED_LANGS:
            logger.debug(
                f"Language '{language}' outside {SUPPORTED_LANGS}; "
                "running inference anyway (XLM-R is multilingual at base)."
            )

        import numpy as np

        encoded = self._tokenizer(
            text,
            return_tensors="np",
            return_offsets_mapping=True,
            truncation=True,
            max_length=512,
        )
        offset_mapping = encoded.pop("offset_mapping")[0].tolist()

        ort_inputs = {k: v for k, v in encoded.items() if k in {i.name for i in self._model.get_inputs()}}
        outputs = self._model.run(None, ort_inputs)
        logits = outputs[0][0]

        # Softmax + argmax in numpy (più leggero di torch).
        max_logits = logits.max(axis=-1, keepdims=True)
        exp = np.exp(logits - max_logits)
        probs = exp / exp.sum(axis=-1, keepdims=True)
        pred_ids = logits.argmax(axis=-1).tolist()
        pred_scores = probs.max(axis=-1).tolist()

        return self._decode_spans(text, pred_ids, pred_scores, offset_mapping)

    def _decode_spans(
        self,
        text: str,
        pred_ids: list[int],
        pred_scores: list[float],
        offset_mapping: list[list[int]],
    ) -> list[NerSpan]:
        spans: list[NerSpan] = []
        cur_label: Optional[str] = None
        cur_start: Optional[int] = None
        cur_end: Optional[int] = None
        cur_scores: list[float] = []

        for pred_id, score, offsets in zip(pred_ids, pred_scores, offset_mapping):
            offset_start, offset_end = offsets[0], offsets[1]
            if offset_start == 0 and offset_end == 0:
                if cur_label is not None:
                    self._emit(text, cur_label, cur_start, cur_end, cur_scores, spans)
                    cur_label, cur_start, cur_end, cur_scores = None, None, None, []
                continue

            label = self._id2label.get(pred_id, "O")
            if label == "O":
                if cur_label is not None:
                    self._emit(text, cur_label, cur_start, cur_end, cur_scores, spans)
                    cur_label, cur_start, cur_end, cur_scores = None, None, None, []
                continue

            base = label.split("-", 1)[1] if "-" in label else label

            if cur_label == base:
                cur_end = offset_end
                cur_scores.append(score)
            else:
                if cur_label is not None:
                    self._emit(text, cur_label, cur_start, cur_end, cur_scores, spans)
                cur_label, cur_start, cur_end, cur_scores = base, offset_start, offset_end, [score]

        if cur_label is not None:
            self._emit(text, cur_label, cur_start, cur_end, cur_scores, spans)

        return self._merge_adjacent(spans, text)

    @staticmethod
    def _emit(
        text: str,
        base_label: str,
        start: Optional[int],
        end: Optional[int],
        scores: list[float],
        out: list,
    ) -> None:
        target = LABEL_MAP.get(base_label)
        if not target or start is None or end is None or end <= start:
            return
        avg = sum(scores) / len(scores) if scores else 0.0
        out.append(NerSpan(
            entity_type=target,
            start=start,
            end=end,
            score=float(avg),
            text=text[start:end],
        ))

    @staticmethod
    def _merge_adjacent(spans: list[NerSpan], text: str) -> list[NerSpan]:
        # GIVENNAME + SURNAME (es. "Mario Rossi") emettono due PERSON adiacenti
        # separati da whitespace. Li uniamo in un'unica span PERSON.
        if not spans:
            return spans
        merged: list[NerSpan] = []
        for s in spans:
            if merged and merged[-1].entity_type == s.entity_type:
                gap = text[merged[-1].end:s.start]
                if gap.strip() == "":
                    prev = merged[-1]
                    merged[-1] = NerSpan(
                        entity_type=prev.entity_type,
                        start=prev.start,
                        end=s.end,
                        score=(prev.score + s.score) / 2,
                        text=text[prev.start:s.end],
                    )
                    continue
            merged.append(s)
        return merged

    @property
    def supported_languages(self) -> set[str]:
        return SUPPORTED_LANGS

    @property
    def supported_entities(self) -> set[str]:
        return SUPPORTED_ENTITIES
