"""Spot test of 10 prompts that previously failed on the 4 Tier-1 patterns
(missing aggregation, per-ogni-X→TOP-1, correlation omitted, Pareto inclusion).

Re-runs them against the patched system prompt + correlation intent check
and prints nominal + retry counts. Numerical correctness must be verified
manually after by opening the produced XLSX files (saved under
test_runs/manipulate_20260512_tier1_spot/).
"""
from __future__ import annotations
import asyncio, json, logging, re, shutil, sys, time, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "test_runs" / "manipulate_20260512_full" / "_spot_test_10.json"
INPUTS_DIR = ROOT / "test_runs" / "manipulate_20260512_full" / "inputs"
OUT_DIR = ROOT / "test_runs" / "manipulate_20260513_tier1_spot"
OUT_DIR.mkdir(parents=True, exist_ok=True)

_SQL_FAIL_RX = re.compile(r"^SQL Execution failed \(Attempt (\d+)\):")
_DIALECT_FAIL_RX = re.compile(r"^Dialect Check failed \(Attempt (\d+)\):")
_CORR_FAIL_RX = re.compile(r"^Correlation intent missing \(Attempt (\d+)\):")
_SOFT_FAIL_RX = re.compile(r"^Soft Validation failed \(Attempt (\d+)\):")


class CaptureHandler(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.INFO)
        self.entries = []
    def emit(self, record):
        try:
            m = record.getMessage()
        except Exception:
            return
        for rx, kind in [(_SQL_FAIL_RX, "sql"), (_DIALECT_FAIL_RX, "dialect"),
                         (_CORR_FAIL_RX, "corr"), (_SOFT_FAIL_RX, "soft")]:
            if rx.match(m):
                self.entries.append({"kind": kind, "msg": m[:300]})
                return


async def main():
    prompts = json.load(SOURCE.open(encoding="utf-8"))
    print(f"Loaded {len(prompts)} spot-test prompts")

    from services.manipulate_service import ManipulateService
    svc = ManipulateService()
    print(f"model: {svc.models.get('manipulate_model', 'unknown')}")

    # Group prompts by file so we can use one session per file
    by_file = {}
    for p in prompts:
        by_file.setdefault(p["file"], []).append(p)

    results = []
    for file_name, entries in by_file.items():
        input_path = INPUTS_DIR / file_name
        if not input_path.exists():
            print(f"INPUT MISSING: {input_path}")
            continue
        session_id = f"spot-tier1-{uuid.uuid4().hex[:6]}"
        print(f"\n=== {file_name} (session {session_id}) ===")
        up = await svc.upload_file(str(input_path), file_name, session_id, mode="Export to Sheet")
        if up.get("status") not in ("staged", "success"):
            print(f"upload failed: {up}")
            continue
        mem = await svc.memorize_files(session_id, mode="Export to Sheet")
        if mem.get("status") != "success":
            print(f"memorize failed: {mem}")
            continue

        for p in entries:
            print(f"\n[{p['area']} / {p['level']}] src={p['source']}#{p['src_idx']}")
            print(f"  prompt: {p['prompt'][:110]!r}")
            cap = CaptureHandler()
            svc_logger = logging.getLogger("services.manipulate_service")
            svc_logger.addHandler(cap)
            t0 = time.time()
            produced = None
            try:
                async for ok, msg, files in svc.analyze(query=p['prompt'], session_id=session_id, mode="Export to Sheet"):
                    if files:
                        produced = files[0]
            except Exception as e:
                print(f"  EXC: {e}")
            finally:
                svc_logger.removeHandler(cap)
            dt = time.time() - t0
            ok = produced is not None
            print(f"  → {'OK ' if ok else 'FAIL'} ({dt:.1f}s, retries={len(cap.entries)})")
            for entry in cap.entries:
                print(f"     [{entry['kind']:7}] {entry['msg']}")
            if ok and produced:
                safe = re.sub(r"[^\w\-]+", "_", f"{p['source']}_{p['src_idx']}").strip("_")
                target = OUT_DIR / f"{safe}.xlsx"
                for src in [Path(produced), *(Path.home() / "Documents" / "PAI_Files").rglob(Path(produced).name)]:
                    if src.exists():
                        try:
                            shutil.copy2(src, target)
                            print(f"     saved: {target.relative_to(ROOT)}")
                            break
                        except Exception:
                            pass
            results.append({
                "source": p["source"], "src_idx": p["src_idx"],
                "file": p["file"], "area": p["area"], "level": p["level"],
                "prompt": p["prompt"], "ok": ok, "duration_s": round(dt, 2),
                "retries": len(cap.entries),
                "retry_kinds": [e["kind"] for e in cap.entries],
            })

        try:
            svc.clear_session(session_id)
        except Exception:
            pass

    (OUT_DIR / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    n_ok = sum(1 for r in results if r["ok"])
    print(f"\n{'='*80}\nSUMMARY: {n_ok}/{len(results)} OK\n{'='*80}")
    # Retry kind breakdown
    kind_count = {}
    for r in results:
        for k in r["retry_kinds"]:
            kind_count[k] = kind_count.get(k, 0) + 1
    print(f"Retry breakdown: {kind_count}")


if __name__ == "__main__":
    asyncio.run(main())
