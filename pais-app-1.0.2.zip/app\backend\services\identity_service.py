"""
Identity Service — hardware fingerprint + first_install_at persistente.

DOPPIO STORAGE (anti-tamper). Su Windows:
- File:     %APPDATA%\\PAIS\\.identity
- Registro: HKCU\\Software\\PAIS\\Identity (REG_SZ con JSON)

Su POSIX solo file in ~/.config/PAIS/.identity (registro non esiste).

Entrambe le locazioni stanno FUORI dalla install dir di PAIS → sopravvivono
a uninstall. Cancellare una sola delle due NON resetta il trial: leggiamo
entrambe e usiamo il `first_install_at` piu' vecchio (anti-tamper). Se una
delle due manca, l'altra viene ri-sincronizzata al boot successivo.

Vedi `PRICING_PLAN.md` §6 — anti-abuso trial. Bypass possibili noti:
- Cambio hardware fisico → nuovo trial (raro per utente medio)
- VM con MAC/CPU diversi → accettato
- Format completo del PC → raro
- Cancellare ENTRAMBI file + chiave registro (utente smaliziato)

Trial duration configurabile via env var `PAIS_TRIAL_SECONDS` (default
30 giorni = 2_592_000). Per test locali settare es. `PAIS_TRIAL_SECONDS=120`
per simulare scadenza in 2 minuti.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("PAIS.Identity")

# Trial duration in secondi. 30 giorni di default; override via env var
# per testing (es. PAIS_TRIAL_SECONDS=120 = 2 minuti).
_DEFAULT_TRIAL_SECONDS = 30 * 24 * 60 * 60  # 30 giorni

# Locazione registro Windows per il secondo storage (anti-tamper).
_REG_SUBKEY = r"Software\PAIS"
_REG_VALUE_NAME = "Identity"

# In-memory cache: leggere il file .identity ad ogni get_account() sarebbe
# wasteful. Cache invalidata solo a process restart (l'identity non cambia).
_CACHED_IDENTITY: Optional[dict] = None


def get_trial_seconds() -> int:
    """Durata trial in secondi. Default 30gg, override via env var."""
    raw = os.environ.get("PAIS_TRIAL_SECONDS")
    if raw:
        try:
            val = int(raw)
            if val > 0:
                return val
        except ValueError:
            logger.warning(f"PAIS_TRIAL_SECONDS invalido: {raw!r}, uso default")
    return _DEFAULT_TRIAL_SECONDS


def _identity_dir() -> Path:
    """Cartella .pais OUT-OF-BAND rispetto all'install dir. Sopravvive a uninstall.

    - Windows: %APPDATA%\\PAIS\\
    - POSIX:   ~/.config/PAIS/
    """
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.expanduser("~\\AppData\\Roaming")
        return Path(base) / "PAIS"
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
        return Path(base) / "PAIS"


def _identity_file() -> Path:
    return _identity_dir() / ".identity"


def _compute_hardware_fingerprint() -> str:
    """Hash SHA256 di MAC address + CPU brand + machine arch. Deterministico
    per device, opaco (niente reverse engineering banale dei componenti)."""
    components = []
    # MAC address — uuid.getnode() ritorna int del MAC primario; se random
    # (no NIC reale) il bit 41 del primo ottetto è 1 → ignoriamo.
    try:
        mac = uuid.getnode()
        if not (mac >> 40) & 0x01:  # non-random
            components.append(f"mac:{mac:012x}")
    except Exception:
        pass
    # CPU brand string (es. "Intel64 Family 6 Model 167" su Windows)
    try:
        cpu = platform.processor() or platform.machine()
        if cpu:
            components.append(f"cpu:{cpu}")
    except Exception:
        pass
    # OS + arch (stabile per device)
    try:
        components.append(f"sys:{platform.system()}-{platform.machine()}")
    except Exception:
        pass
    # Username (per multi-user su stesso PC, ognuno ha il suo trial)
    try:
        user = os.environ.get("USERNAME") or os.environ.get("USER") or ""
        if user:
            components.append(f"user:{user}")
    except Exception:
        pass

    if not components:
        # Fallback degradato: nuovo UUID4 = trial nuovo ad ogni install
        # (peggio del previsto ma non rompe l'app)
        logger.warning("Impossibile calcolare HW fingerprint, uso UUID random")
        return uuid.uuid4().hex

    fp_input = "|".join(components)
    return hashlib.sha256(fp_input.encode("utf-8")).hexdigest()


def _read_identity_file() -> Optional[dict]:
    """Legge .identity file. Ritorna None se mancante o corrotto."""
    path = _identity_file()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        if not data.get("device_id") or not data.get("first_install_at"):
            return None
        return data
    except Exception as e:
        logger.warning(f"Failed to read .identity: {e}")
        return None


def _write_identity_file(payload: dict) -> bool:
    """Scrive .identity. Crea cartella se manca."""
    path = _identity_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return True
    except Exception as e:
        logger.error(f"Failed to write .identity at {path}: {e}")
        return False


def _read_identity_registry() -> Optional[dict]:
    """Lettura HKCU\\Software\\PAIS\\Identity. Ritorna None se chiave assente,
    valore corrotto, o non-Windows."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
    except ImportError:
        return None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_SUBKEY) as key:
            raw, _vtype = winreg.QueryValueEx(key, _REG_VALUE_NAME)
        data = json.loads(raw)
        if not isinstance(data, dict):
            return None
        if not data.get("device_id") or not data.get("first_install_at"):
            return None
        return data
    except FileNotFoundError:
        # Chiave o valore inesistente — caso normale al primo run
        return None
    except OSError:
        # Permessi negati o altro errore registro — comportati come "manca"
        return None
    except Exception as e:
        logger.warning(f"Failed to read identity from registry: {e}")
        return None


def _write_identity_registry(payload: dict) -> bool:
    """Scrive payload (JSON serialized) in HKCU\\Software\\PAIS\\Identity.
    No-op su POSIX."""
    if sys.platform != "win32":
        return False
    try:
        import winreg
    except ImportError:
        return False
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _REG_SUBKEY) as key:
            winreg.SetValueEx(key, _REG_VALUE_NAME, 0, winreg.REG_SZ, json.dumps(payload))
        return True
    except Exception as e:
        logger.error(f"Failed to write identity to registry: {e}")
        return False


def _delete_identity_registry() -> bool:
    """Cancella il valore registry. Usata da reset_identity_for_testing."""
    if sys.platform != "win32":
        return False
    try:
        import winreg
    except ImportError:
        return False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_SUBKEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, _REG_VALUE_NAME)
        return True
    except FileNotFoundError:
        return True  # gia' assente = OK
    except Exception as e:
        logger.error(f"Failed to delete identity from registry: {e}")
        return False


def get_identity() -> dict:
    """Ritorna {device_id, first_install_at} per QUESTO device.

    DOPPIO STORAGE — leggiamo file e registro, e:
    - Se entrambi presenti con device_id matchante → uso first_install_at
      PIU' VECCHIO (anti-tamper: se l'utente cancella uno dei due in fretta,
      l'altro conserva la data originale).
    - Se solo uno presente con device_id matchante → uso quello E ri-scrivo
      l'altro (resync automatico).
    - Se nessuno presente o tutti con device_id mismatch (HW cambiato / backup
      importato da altra macchina) → primo install, first_install_at=now.
    """
    global _CACHED_IDENTITY
    if _CACHED_IDENTITY is not None:
        return _CACHED_IDENTITY

    current_fp = _compute_hardware_fingerprint()
    file_data = _read_identity_file()
    reg_data = _read_identity_registry()

    # Tieni solo i record di QUESTO device.
    candidates = []
    if file_data and file_data.get("device_id") == current_fp:
        candidates.append(("file", file_data))
    if reg_data and reg_data.get("device_id") == current_fp:
        candidates.append(("registry", reg_data))

    if candidates:
        # Anti-tamper: vince il first_install_at piu' vecchio.
        candidates.sort(key=lambda x: x[1]["first_install_at"])
        chosen_src, chosen = candidates[0]

        # Resync della locazione opposta se mancante o disallineata.
        need_file_resync = (
            not file_data
            or file_data.get("device_id") != current_fp
            or file_data.get("first_install_at") != chosen["first_install_at"]
        )
        need_reg_resync = sys.platform == "win32" and (
            not reg_data
            or reg_data.get("device_id") != current_fp
            or reg_data.get("first_install_at") != chosen["first_install_at"]
        )
        if need_file_resync:
            _write_identity_file(chosen)
            logger.info(f"Identity file resynced from {chosen_src} (anti-tamper)")
        if need_reg_resync:
            _write_identity_registry(chosen)
            logger.info(f"Identity registry resynced from {chosen_src} (anti-tamper)")

        _CACHED_IDENTITY = chosen
        return chosen

    # Davvero primo install (o HW cambiato): crea identity nuova in entrambi.
    now_iso = datetime.now(timezone.utc).isoformat()
    payload = {
        "device_id": current_fp,
        "first_install_at": now_iso,
        # Schema_version: per future migrazioni
        "schema": 1,
    }
    _write_identity_file(payload)
    _write_identity_registry(payload)
    _CACHED_IDENTITY = payload
    logger.info(
        f"Identity created (device_id={current_fp[:12]}..., "
        f"stored in file{'+ registry' if sys.platform == 'win32' else ''})"
    )
    return payload


def get_first_install_at() -> str:
    """ISO timestamp del primo install (UTC). Setta a now se non esiste."""
    return get_identity()["first_install_at"]


def reset_identity_for_testing() -> None:
    """SOLO TEST: cancella .identity (file + registro) per simulare un install
    nuovo. Non chiamare in produzione."""
    global _CACHED_IDENTITY
    _CACHED_IDENTITY = None
    path = _identity_file()
    try:
        if path.exists():
            path.unlink()
            logger.warning(f"⚠️ Identity file RESET: {path}")
    except Exception as e:
        logger.error(f"reset_identity_for_testing (file) failed: {e}")
    if _delete_identity_registry():
        logger.warning(f"⚠️ Identity registry value RESET: HKCU\\{_REG_SUBKEY}\\{_REG_VALUE_NAME}")
