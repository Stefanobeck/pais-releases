"""
Export Manager - Gestisce esportazione chat in multipli formati.
Supporta: TXT, MD, HTML, PDF, DOCX
Utilizza Playwright per il rendering PDF fedele (LaTeX/Tabelle).

Studio mode (opzionale): se viene passato un dict `studio` con i dati dello
Studio Identity (ragione sociale, indirizzo, P.IVA, contatti, logo_path), gli
exporter Word/PDF aggiungono un header brandizzato e un footer con disclaimer
+ hash del contenuto. TXT/MD restano plain.
"""
import hashlib
import os
import re
import time
from datetime import datetime
from html import escape as _html_escape
from pathlib import Path
from typing import Tuple, Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)

# --- Asset di terze parti bundlati LOCALMENTE (niente CDN → render OFFLINE) ---
# MathJax (Apache-2.0) e mermaid (MIT) vivono in backend/static/vendor/. Le loro
# licenze sono incluse accanto ai file. Usati per: render LaTeX (HTML/PDF/PNG) e
# diagrammi Mermaid (SVG) senza dipendere dalla connessione internet.
_VENDOR_DIR = Path(__file__).resolve().parent.parent / "static" / "vendor"
_MATHJAX_JS = _VENDOR_DIR / "mathjax" / "tex-svg-full.js"
_MERMAID_JS = _VENDOR_DIR / "mermaid" / "mermaid.min.js"


def _vendor_uri(path: Path) -> str:
    """file:// URI di un asset vendor (per <script src> caricato da Playwright)."""
    return path.as_uri()


def _read_vendor(path: Path) -> str:
    """Contenuto JS di un asset vendor, per l'inline in un documento autoportante.
    Nessuno dei due bundle contiene la stringa '</script>', quindi l'inline è sicuro."""
    return path.read_text(encoding="utf-8")

# Mappa linguaggio (info-string del fence ```lang) → estensione file.
# Default 'txt' per linguaggi non in lista o blocchi senza linguaggio.
_CODE_EXT = {
    'python': 'py', 'py': 'py', 'javascript': 'js', 'js': 'js', 'node': 'js',
    'typescript': 'ts', 'ts': 'ts', 'tsx': 'tsx', 'jsx': 'jsx',
    'json': 'json', 'sql': 'sql', 'bash': 'sh', 'sh': 'sh', 'shell': 'sh', 'zsh': 'sh',
    'html': 'html', 'xml': 'xml', 'css': 'css', 'scss': 'scss', 'less': 'less',
    'java': 'java', 'c': 'c', 'cpp': 'cpp', 'c++': 'cpp', 'csharp': 'cs', 'cs': 'cs',
    'go': 'go', 'golang': 'go', 'rust': 'rs', 'rs': 'rs', 'php': 'php',
    'ruby': 'rb', 'rb': 'rb', 'yaml': 'yaml', 'yml': 'yml', 'toml': 'toml', 'ini': 'ini',
    'markdown': 'md', 'md': 'md', 'r': 'r', 'kotlin': 'kt', 'kt': 'kt', 'swift': 'swift',
    'powershell': 'ps1', 'ps1': 'ps1', 'dockerfile': 'dockerfile', 'makefile': 'mk',
    'perl': 'pl', 'lua': 'lua', 'dart': 'dart', 'scala': 'scala', 'text': 'txt', '': 'txt',
}


def _compute_content_hash(content: str) -> str:
    """SHA256 hex del contenuto chat — usato come 'document hash' nel footer.
    Tracciabile via audit log (che registra anche il file SHA del PDF/DOCX).
    """
    return hashlib.sha256((content or "").encode("utf-8", errors="ignore")).hexdigest()


def _studio_lines(studio: Dict[str, Any]) -> Dict[str, str]:
    """Normalizza il payload studio in stringhe pronte per il template."""
    s = studio or {}
    return {
        "name": (s.get("name") or "").strip(),
        "address": (s.get("address") or "").strip(),
        "vat": (s.get("vat") or "").strip(),
        "phone": (s.get("phone") or "").strip(),
        "email": (s.get("email") or "").strip(),
        "website": (s.get("website") or "").strip(),
        "logo_path": (s.get("logo_path") or "").strip(),
    }


def _resolve_logo_abs_path(studio: Optional[Dict[str, Any]]) -> Optional[Path]:
    """Restituisce il path assoluto del logo se esiste, altrimenti None."""
    if not studio:
        return None
    rel = (studio.get("logo_path") or "").strip()
    if not rel:
        return None
    try:
        from backend_config import settings as app_settings
        p = app_settings.BASE_DIR / rel
        return p if p.exists() else None
    except Exception:
        return None


# Schemi colore header studio: id → (accent principale, accent tenue per testi
# secondari). Tenuti in sync con user_settings_service.STUDIO_HEADER_TEMPLATES
# e col frontend. 'blue' = look storico.
_HEADER_TEMPLATES = {
    "blue":       {"accent": "#1e3a8a", "muted": "#4a5568"},
    "anthracite": {"accent": "#1f2937", "muted": "#4b5563"},
    "green":      {"accent": "#065f46", "muted": "#4b5563"},
    "bordeaux":   {"accent": "#7f1d1d", "muted": "#4b5563"},
}


def _header_palette(studio: Optional[Dict[str, Any]]) -> Dict[str, str]:
    """Palette colori dell'header in base al template scelto (fallback 'blue')."""
    tmpl = (studio or {}).get("_template", "blue")
    return _HEADER_TEMPLATES.get(tmpl, _HEADER_TEMPLATES["blue"])


def _logo_position(studio: Optional[Dict[str, Any]]) -> str:
    """Posizione del logo nell'header: left | center | right (fallback left)."""
    pos = (studio or {}).get("_logo_position", "left")
    return pos if pos in ("left", "center", "right") else "left"


def _hex_to_rgb(hexstr: str):
    """'#1e3a8a' → (0x1e, 0x3a, 0x8a). Per python-docx RGBColor."""
    h = (hexstr or "").lstrip("#")
    if len(h) != 6:
        h = "1e3a8a"
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def strip_thinking_tags(content: str) -> str:
    """
    Rimuove i blocchi di thinking <think></think> dal contenuto.
    """
    if not content:
        return content
    
    # Pattern per rimuovere <think></think> (anche multilinea)
    cleaned = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL)
    
    # Pulizia spazi extra
    cleaned = re.sub(r'\n\s*\n\s*\n', '\n\n', cleaned)
    
    return cleaned.strip()


def _markdown_to_plain(text: str) -> str:
    """Converte il markdown in testo semplice leggibile per l'export TXT.
    Best-effort, basato su regex, PRESERVA i ritorni a capo (niente giro
    HTML che li collasserebbe). Nessuna libreria esterna."""
    if not text:
        return text
    out_lines = []
    in_code = False
    for line in text.split('\n'):
        # Code fence ``` → togli la riga di fence, mantieni il codice dentro.
        if re.match(r'^\s*```', line):
            in_code = not in_code
            continue
        if in_code:
            out_lines.append(line)
            continue
        # Riga separatrice di tabella (|---|:--:|) → scarta.
        if '|' in line and '-' in line and re.fullmatch(r'[\s|:\-]+', line.strip() or ' '):
            continue
        # Riga dati di tabella → togli i pipe esterni, unisci le celle con ' | '.
        if line.strip().startswith('|'):
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            line = ' | '.join(cells)
        # Heading → via i '#'.
        line = re.sub(r'^\s*#{1,6}\s*', '', line)
        # Blockquote → via il '>'.
        line = re.sub(r'^(\s*)>\s?', r'\1', line)
        # HR (---, ***, ___) → riga vuota.
        if re.fullmatch(r'\s*([-*_])(\s*\1){2,}\s*', line):
            out_lines.append('')
            continue
        # Bullet *,+ → '-' (preserva l'indentazione).
        line = re.sub(r'^(\s*)[*+](\s+)', r'\1-\2', line)
        # Immagini ![alt](url) → alt ; link [t](u) → t (u).
        line = re.sub(r'!\[([^\]]*)\]\([^)]*\)', r'\1', line)
        line = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'\1 (\2)', line)
        # Grassetto (prima del corsivo) → x.
        line = re.sub(r'\*\*(.+?)\*\*', r'\1', line)
        line = re.sub(r'__(.+?)__', r'\1', line)
        # Barrato ~~x~~ → x ; code inline `x` → x.
        line = re.sub(r'~~(.+?)~~', r'\1', line)
        line = re.sub(r'`([^`]+)`', r'\1', line)
        # Corsivo *x* → x ; _x_ → x (solo con confini di parola: salva snake_case).
        line = re.sub(r'\*(.+?)\*', r'\1', line)
        line = re.sub(r'(?<!\w)_(.+?)_(?!\w)', r'\1', line)
        out_lines.append(line)
    result = '\n'.join(out_lines)
    result = re.sub(r'\n{3,}', '\n\n', result)
    return result.strip()


# Watermark leggero per gli export della versione FREE (rimosso in PRO).
# Footer discreto sui documenti (HTML/PDF/DOCX), non uno stamp invasivo.
# TODO: confermare il wording/URL ufficiale con il prodotto (basta cambiare qui).
_WATERMARK_TEXT = "Creato con PAIS · Private Intelligence Suite"


def _free_watermark_active() -> bool:
    """True se l'utente NON è PRO (free_trial o free_residual) → si applica il
    watermark leggero agli export documentali; PRO → export puliti.
    Per lasciare pulito anche il trial, cambiare in `== 'free_residual'`.
    Fail-open verso l'utente: in caso di dubbio NON marchia (return False)."""
    try:
        from services import user_settings_service as uss
        return uss.compute_effective_tier().get("effective_tier") != "pro"
    except Exception as e:
        logger.warning(f"watermark tier check failed, exporting clean: {e}")
        return False


class BaseExporter:
    """Classe base per exporter."""

    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        """Da implementare nelle sottoclassi.
        `studio` è opzionale: TXT/MD lo ignorano, HTML/PDF/DOCX lo usano per il
        branding header+footer. `watermark`: footer leggero "versione free"
        (applicato solo da HTML/PDF/DOCX; TXT/MD/PPTX lo ignorano).
        """
        raise NotImplementedError


class TxtExporter(BaseExporter):
    """Export in formato TXT (plain, ignora studio)."""

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.txt"
        filepath = self.output_dir / fname

        # TXT = testo semplice: rimuove la sintassi markdown (l'export MD la tiene).
        clean_content = _markdown_to_plain(strip_thinking_tags(content))

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(clean_content)

        logger.info(f"TXT export: {filepath}")
        return str(filepath)


class MdExporter(BaseExporter):
    """Export in formato Markdown (plain, ignora studio)."""

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.md"
        filepath = self.output_dir / fname

        clean_content = strip_thinking_tags(content)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(clean_content)

        logger.info(f"MD export: {filepath}")
        return str(filepath)


class HtmlExporter(BaseExporter):
    """Export in formato HTML con supporto LaTeX/MathJax (allineato a NiceGUI)."""

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.html"
        filepath = self.output_dir / fname

        clean_content = strip_thinking_tags(content)
        content_hash = _compute_content_hash(clean_content)

        # PRESERVA blocchi LaTeX prima del markdown processing
        # Usa commenti HTML come placeholder (markdown2 li lascia intatti)
        import re
        latex_blocks = []
        
        def preserve_display_latex(match):
            latex_blocks.append(('display', match.group(1)))
            return f'<!--LTXD{len(latex_blocks)-1}-->'
        
        def preserve_inline_latex(match):
            latex_blocks.append(('inline', match.group(1)))
            return f'<!--LTXI{len(latex_blocks)-1}-->'

        # Preserva $$...$$ (display math)
        clean_content = re.sub(r'\$\$(.+?)\$\$', preserve_display_latex, clean_content, flags=re.DOTALL)
        # Preserva \(...\) e \[...\]
        clean_content = re.sub(r'\\\((.+?)\\\)', preserve_inline_latex, clean_content, flags=re.DOTALL)
        clean_content = re.sub(r'\\\[(.+?)\\\]', preserve_display_latex, clean_content, flags=re.DOTALL)
        # Preserva $...$ (inline math) - ma solo se non dentro backticks
        clean_content = re.sub(r'(?<![\\`])\$([^$\n]+?)\$', preserve_inline_latex, clean_content)

        # Style e Script come nella versione originale NiceGUI
        css_style = """
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                line-height: 1.6;
                padding: 40px;
                max-width: 850px;
                margin: 0 auto;
                color: #333;
                background-color: #fff;
            }
            h1, h2, h3 { color: #1a202c; border-bottom: 1px solid #edf2f7; padding-bottom: 0.5rem; margin-top: 1.5rem; }
            code { background-color: #f7fafc; padding: 0.2rem 0.4rem; border-radius: 4px; font-family: 'Cascadia Code', 'Fira Code', monospace; font-size: 0.9em; }
            pre { background-color: #f7fafc; padding: 1rem; border-radius: 8px; overflow-x: auto; border: 1px solid #e2e8f0; }
            pre code { background-color: transparent; padding: 0; }
            blockquote { border-left: 4px solid #cbd5e0; padding-left: 1rem; color: #4a5568; font-style: italic; margin: 1.5rem 0; }
            table { border-collapse: collapse; width: 100%; margin: 1.5rem 0; border: 1px solid #e2e8f0; }
            th, td { border: 1px solid #e2e8f0; padding: 0.75rem; text-align: left; }
            th { background-color: #f8fafc; font-weight: 700; color: #2d3748; }
            img { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
            hr { border: 0; border-top: 1px solid #e2e8f0; margin: 2rem 0; }
            /* LaTeX rendering */
            .latex-display { text-align: center; margin: 1.5rem 0; font-size: 1.1em; }
            .mjx-container { overflow-x: auto; overflow-y: hidden; }
        </style>
        """

        # MathJax bundlato LOCALMENTE e inlinato nel documento: l'HTML/PDF
        # esportato renderizza le formule anche OFFLINE e resta AUTOPORTANTE se
        # condiviso (niente riferimenti a CDN né a path locali dell'app).
        # Inlinato solo quando ci sono formule, per non appesantire gli altri export.
        if latex_blocks:
            _mjx_template = """
        <script>
        MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
            displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']],
            processEscapes: true,
            processEnvironments: true
          },
          options: {
            enableMenu: false
          },
          startup: {
            typeset: true
          }
        };
        </script>
        <script id="MathJax-script">__MATHJAX_LIB__</script>
        """
            try:
                mathjax_script = _mjx_template.replace("__MATHJAX_LIB__", _read_vendor(_MATHJAX_JS))
            except OSError as e:
                logger.warning(f"MathJax bundle non leggibile ({e}); HTML senza render LaTeX")
                mathjax_script = ""
        else:
            mathjax_script = ""

        # Converti markdown in HTML
        try:
            import markdown2
            html_body = markdown2.markdown(
                clean_content,
                extras=['fenced-code-blocks', 'tables', 'strike', 'task_list', 'break-on-newline']
            )
        except:
            html_body = clean_content.replace('\n', '<br>\n')

        # Ripristina blocchi LaTeX come MathJax-compatibili
        for i, (mode, latex) in enumerate(latex_blocks):
            placeholder = f'<!--LTXD{i}-->' if mode == 'display' else f'<!--LTXI{i}-->'
            # Escape HTML characters inside LaTeX
            safe_latex = latex.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            if mode == 'display':
                html_body = html_body.replace(placeholder, f'<div class="latex-display">$${safe_latex}$$</div>')
            else:
                html_body = html_body.replace(placeholder, f'${safe_latex}$')
        
        # Studio header (SOLO header: il footer disclaimer+hash è stato rimosso
        # dal prodotto). Accent colore dal template scelto + posizione logo.
        studio_header_html = ""
        studio_css = ""
        if studio and studio.get('_show_header', True):
            sl = _studio_lines(studio)
            palette = _header_palette(studio)
            accent = palette["accent"]
            muted = palette["muted"]
            position = _logo_position(studio)
            logo_path = _resolve_logo_abs_path(studio)
            logo_html = ""
            if logo_path:
                logo_url = f"file:///{logo_path.absolute().as_posix()}"
                logo_html = f'<img src="{logo_url}" class="studio-logo" alt="logo" />'
            contact_bits = []
            if sl["phone"]:
                contact_bits.append(f"Tel {_html_escape(sl['phone'])}")
            if sl["email"]:
                contact_bits.append(_html_escape(sl["email"]))
            if sl["website"]:
                contact_bits.append(_html_escape(sl["website"]))
            contact_line = " · ".join(contact_bits)
            vat_line = f"P.IVA {_html_escape(sl['vat'])}" if sl["vat"] else ""
            name_html = _html_escape(sl["name"]) if sl["name"] else "PAI Premium"
            address_html = _html_escape(sl["address"]) if sl["address"] else ""
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

            info_html = f"""<div class="studio-info">
                    <h1 class="studio-name">{name_html}</h1>
                    {f'<p class="studio-line">{address_html}</p>' if address_html else ''}
                    {f'<p class="studio-line">{vat_line}</p>' if vat_line else ''}
                    {f'<p class="studio-line">{contact_line}</p>' if contact_line else ''}
                  </div>"""
            meta_html = f'<div class="studio-meta"><p class="studio-date">{now_str}</p></div>'

            if position == "center":
                # Logo centrato in alto, testi e data centrati sotto.
                inner = f"{logo_html}\n                  {info_html}\n                  {meta_html}"
                header_class = "studio-header studio-header--center"
            elif position == "right":
                # Testi a sinistra, data e logo spinti a destra.
                inner = f"{info_html}\n                  {meta_html}\n                  {logo_html}"
                header_class = "studio-header"
            else:  # left (default)
                inner = f"{logo_html}\n                  {info_html}\n                  {meta_html}"
                header_class = "studio-header"

            studio_header_html = f"""
                <div class="{header_class}">
                  {inner}
                </div>
                """

            studio_css = f"""
            <style>
              .studio-header {{ display: flex; align-items: center; gap: 20px; border-bottom: 2px solid {accent}; padding-bottom: 14px; margin-bottom: 24px; }}
              .studio-header.studio-header--center {{ flex-direction: column; text-align: center; gap: 8px; }}
              .studio-header .studio-logo {{ max-width: 100px; max-height: 80px; object-fit: contain; }}
              .studio-header .studio-info {{ flex: 1; min-width: 0; }}
              .studio-header.studio-header--center .studio-info {{ flex: none; }}
              .studio-header .studio-name {{ margin: 0; font-size: 18px; color: {accent}; line-height: 1.2; }}
              .studio-header .studio-line {{ margin: 2px 0; font-size: 11px; color: {muted}; line-height: 1.3; }}
              .studio-header .studio-meta {{ font-size: 10px; color: #718096; white-space: nowrap; }}
              .studio-header.studio-header--center .studio-meta {{ text-align: center; }}
              @media print {{
                .studio-header {{ page-break-after: avoid; }}
              }}
            </style>
            """

        # Watermark leggero versione FREE (footer discreto, indipendente dallo Studio).
        watermark_html = ""
        if watermark:
            watermark_html = (
                '<div style="margin-top:32px;padding-top:10px;border-top:1px solid #edf2f7;'
                'font-size:9px;color:#9aa3af;text-align:center;">'
                f'{_html_escape(_WATERMARK_TEXT)}</div>'
            )

        full_html = f"""<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export</title>
    {css_style}
    {studio_css}
    {mathjax_script}
</head>
<body>
    {studio_header_html}
    <div class="content">
        {html_body}
    </div>
    {watermark_html}
</body>
</html>"""
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(full_html)
        
        logger.info(f"HTML export: {filepath}")
        return str(filepath)


class PdfEngineUnavailable(Exception):
    """Sollevata quando il rendering PDF via Playwright/Chromium non è possibile.

    Porta con sé il file di fallback EFFETTIVAMENTE prodotto (DOCX o TXT) e il
    motivo, così il chiamante può comunque consegnare un file all'utente E
    avvisarlo che non è il PDF richiesto. Sostituisce il vecchio fallback
    silenzioso che spacciava il .docx per PDF riuscito (bug v1.0.1)."""

    def __init__(self, reason: str, detail: str, fallback_path: str, fallback_format: str):
        self.reason = reason                  # pdf_engine_missing | pdf_render_failed
        self.detail = detail
        self.fallback_path = fallback_path
        self.fallback_format = fallback_format
        super().__init__(f"PDF engine unavailable ({reason}): {detail}")


def _classify_pdf_failure(exc: Exception) -> str:
    """Distingue 'motore PDF non installato' (Chromium assente, tipico su PC
    ex-novo senza bundle) dagli altri errori di rendering, così la UI può dare
    un messaggio mirato."""
    msg = str(exc).lower()
    missing_markers = (
        "executable doesn't exist",
        "playwright install",
        "looks like playwright was just installed",
        "please run the following command to download new browsers",
    )
    if any(m in msg for m in missing_markers):
        return "pdf_engine_missing"
    return "pdf_render_failed"


class PdfExporter(BaseExporter):
    """Export in formato PDF utilizzando Playwright (Rendering originale main.py)."""

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.pdf"
        filepath = self.output_dir / fname

        # 1. Genera HTML temporaneo (con header/footer studio se richiesto)
        html_exporter = HtmlExporter(str(self.output_dir))
        temp_html_name = f"temp_rendering_{timestamp}.html"
        html_path_str = await html_exporter.export(content, filename=temp_html_name, studio=studio, watermark=watermark)
        
        # 2. Rendering PDF tramite Playwright
        try:
            from playwright.async_api import async_playwright
            
            async with async_playwright() as p:
                # Lancio browser headless
                browser = await p.chromium.launch()
                page = await browser.new_page()

                # Carica l'HTML locale
                file_url = f"file:///{Path(html_path_str).absolute().as_posix()}"
                await page.goto(file_url, wait_until="networkidle")

                # Attesa attiva per il rendering MathJax (LaTeX)
                await page.evaluate("""
                    async () => {
                        const timeout = 10000;
                        const start = Date.now();
                        while (Date.now() - start < timeout) {
                            if (window.MathJax && window.MathJax.typesetPromise) {
                                await window.MathJax.typesetPromise();
                                return;
                            }
                            await new Promise(r => setTimeout(r, 100));
                        }
                    }
                """)

                # Generazione PDF
                await page.pdf(
                    path=str(filepath),
                    format="A4",
                    margin={"top": "2cm", "bottom": "2cm", "left": "2cm", "right": "2cm"},
                    print_background=True
                )

                await browser.close()
            
            logger.info(f"PDF export (Playwright) SUCCESS: {filepath}")
            
        except Exception as e:
            logger.error(f"Playwright PDF export failed: {e}")
            # Non falliamo in silenzio: produciamo comunque un file (DOCX, o TXT
            # se anche il DOCX fallisce) MA segnaliamo l'accaduto al chiamante via
            # PdfEngineUnavailable. Così la UI avvisa l'utente invece di spacciare
            # il .docx per il PDF richiesto (bug v1.0.1).
            reason = _classify_pdf_failure(e)
            try:
                docx_exp = DocxExporter(str(self.output_dir))
                fallback_path = await docx_exp.export(
                    content, filename=fname.replace('.pdf', '.docx'),
                    studio=studio, watermark=watermark,
                )
                fallback_format = "docx"
            except Exception:
                fallback_path = str(self.output_dir / fname.replace('.pdf', '.txt'))
                with open(fallback_path, 'w', encoding='utf-8') as f:
                    f.write(strip_thinking_tags(content))
                fallback_format = "txt"
            raise PdfEngineUnavailable(
                reason=reason,
                detail=str(e),
                fallback_path=fallback_path,
                fallback_format=fallback_format,
            )

        finally:
            # Pulizia file HTML temporaneo
            try:
                if os.path.exists(html_path_str):
                    os.remove(html_path_str)
            except:
                pass
                
        return str(filepath)


class DocxExporter(BaseExporter):
    """
    Export in formato DOCX utilizzando python-docx (MIT).
    Legalità Commerciale: Sostituisce Pandoc (GPL).
    """

    def _apply_studio_branding(self, doc, studio: Dict[str, Any], content_hash: str) -> None:
        """Aggiunge l'header brandizzato (logo + ragione sociale + contatti) al
        documento. Rispetta il toggle `studio['_show_header']`, il template
        colore `studio['_template']` (accent su nome + bordo) e la posizione
        logo `studio['_logo_position']` (left | center | right).

        NB: il footer studio (disclaimer + hash) è stato RIMOSSO dal prodotto.
        `content_hash` resta nella firma solo per retro-compatibilità del caller.
        """
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.table import WD_ALIGN_VERTICAL
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        if not bool(studio.get('_show_header', True)):
            return

        sl = _studio_lines(studio)
        palette = _header_palette(studio)
        accent_rgb = RGBColor(*_hex_to_rgb(palette["accent"]))
        muted_rgb = RGBColor(*_hex_to_rgb(palette["muted"]))
        position = _logo_position(studio)
        logo_path = _resolve_logo_abs_path(studio)

        section = doc.sections[0]
        header = section.header
        # python-docx crea un paragrafo vuoto di default — lo svuotiamo per riusarlo.
        for p in list(header.paragraphs):
            p.text = ""

        text_lines = [l for l in (
            sl["address"],
            (f"P.IVA {sl['vat']}" if sl["vat"] else ""),
            " · ".join(b for b in [
                (f"Tel {sl['phone']}" if sl["phone"] else ""),
                sl["email"], sl["website"],
            ] if b),
        ) if l]

        def _emit_name(para):
            para.alignment = (WD_ALIGN_PARAGRAPH.CENTER if position == "center"
                              else WD_ALIGN_PARAGRAPH.LEFT)
            r = para.add_run(sl["name"] or "PAI Premium")
            r.bold = True
            r.font.size = Pt(13)
            r.font.color.rgb = accent_rgb

        def _emit_lines(add_para):
            for line in text_lines:
                p = add_para()
                p.alignment = (WD_ALIGN_PARAGRAPH.CENTER if position == "center"
                               else WD_ALIGN_PARAGRAPH.LEFT)
                r = p.add_run(line)
                r.font.size = Pt(9)
                r.font.color.rgb = muted_rgb

        if position == "center":
            # Logo centrato in alto (se presente), poi nome + righe centrati.
            name_para = header.paragraphs[0]
            if logo_path:
                try:
                    p_logo = header.paragraphs[0]
                    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p_logo.add_run().add_picture(str(logo_path), width=Inches(1.0))
                    name_para = header.add_paragraph()
                except Exception as e:
                    logger.warning(f"DOCX logo embed failed: {e}")
            _emit_name(name_para)
            _emit_lines(header.add_paragraph)
        else:
            # left / right: tabella 1×2 (logo e testi affiancati). In 'right' le
            # colonne sono invertite (testi a sinistra, logo a destra).
            htable = header.add_table(rows=1, cols=2, width=Inches(6.5))
            htable.autofit = False
            if position == "left":
                cell_logo, cell_text = htable.cell(0, 0), htable.cell(0, 1)
                htable.columns[0].width = Inches(1.4)
                htable.columns[1].width = Inches(5.1)
                logo_align = WD_ALIGN_PARAGRAPH.LEFT
            else:  # right
                cell_text, cell_logo = htable.cell(0, 0), htable.cell(0, 1)
                htable.columns[0].width = Inches(5.1)
                htable.columns[1].width = Inches(1.4)
                logo_align = WD_ALIGN_PARAGRAPH.RIGHT
            cell_logo.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            cell_text.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

            if logo_path:
                try:
                    p_logo = cell_logo.paragraphs[0]
                    p_logo.alignment = logo_align
                    p_logo.add_run().add_picture(str(logo_path), width=Inches(1.0))
                except Exception as e:
                    logger.warning(f"DOCX logo embed failed: {e}")

            _emit_name(cell_text.paragraphs[0])
            _emit_lines(cell_text.add_paragraph)

    def _apply_watermark_footer(self, doc) -> None:
        """Riga footer leggera 'versione free' (rimossa in PRO). Coesiste col
        footer Studio: riusa il primo paragrafo del footer se vuoto, altrimenti
        ne aggiunge uno."""
        from docx.shared import Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        footer = doc.sections[0].footer
        if footer.paragraphs and not footer.paragraphs[0].text.strip():
            para = footer.paragraphs[0]
        else:
            para = footer.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = para.add_run(_WATERMARK_TEXT)
        r.font.size = Pt(8)
        r.font.color.rgb = RGBColor(0x9C, 0xA3, 0xAF)

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        import time
        from docx import Document
        from docx.shared import Pt, RGBColor, Inches, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.docx"
        filepath = self.output_dir / fname

        clean_content = strip_thinking_tags(content)
        content_hash = _compute_content_hash(clean_content)

        def add_formatted_text(p, text):
            """Aggiunge testo al paragrafo gestendo il grassetto **text**."""
            parts = re.split(r'(\*\*.*?\*\*)', text)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    p.add_run(part)

        try:
            doc = Document()
            doc.core_properties.title = "PAI Premium Export"

            # Studio branding (header + body separator + footer)
            if studio:
                self._apply_studio_branding(doc, studio, content_hash)

            # Watermark leggero versione FREE (footer; coesiste con lo Studio).
            if watermark:
                self._apply_watermark_footer(doc)

            lines = clean_content.split('\n')
            table_buffer = []
            
            i = 0
            while i < len(lines):
                line = lines[i]
                stripped = line.strip()
                
                # --- Gestione TABELLE ---
                if stripped.startswith('|') and '|' in stripped[1:]:
                    table_buffer = []
                    # Accumula tutte le righe della tabella
                    while i < len(lines) and lines[i].strip().startswith('|'):
                        table_buffer.append(lines[i].strip())
                        i += 1
                    
                    if table_buffer:
                        # Filtra la riga di separazione |---|---|
                        table_data = []
                        for row_str in table_buffer:
                            if re.match(r'^\s*\|?[\s-]*:?-+[:\s-]*\|', row_str):
                                continue
                            # Estrai celle
                            cells = [c.strip() for c in row_str.split('|') if c.strip() or row_str.count('|') > 1]
                            # Se la riga inizia e finisce con |, split crea celle vuote all'inizio e fine
                            if row_str.startswith('|'): cells = cells[1:]
                            if row_str.endswith('|'): cells = cells[:-1]
                            if cells: table_data.append(cells)
                        
                        if table_data:
                            num_rows = len(table_data)
                            num_cols = max(len(row) for row in table_data)
                            table = doc.add_table(rows=num_rows, cols=num_cols)
                            table.style = 'Table Grid'
                            
                            for r_idx, row_cells in enumerate(table_data):
                                for c_idx, cell_text in enumerate(row_cells):
                                    if c_idx < num_cols:
                                        cell = table.cell(r_idx, c_idx)
                                        # Pulisce celle se Word crea paragrafi di default
                                        p = cell.paragraphs[0]
                                        add_formatted_text(p, cell_text)
                                        if r_idx == 0: # Header
                                            for run in p.runs: run.bold = True
                        continue
                
                # --- Gestione ALTRO ---
                if not stripped:
                    doc.add_paragraph("")
                elif stripped.startswith('# '):
                    doc.add_heading(stripped[2:], level=1)
                elif stripped.startswith('## '):
                    doc.add_heading(stripped[3:], level=2)
                elif stripped.startswith('### '):
                    doc.add_heading(stripped[4:], level=3)
                elif stripped.startswith('- ') or stripped.startswith('* '):
                    p = doc.add_paragraph(style='List Bullet')
                    add_formatted_text(p, stripped[2:])
                else:
                    p = doc.add_paragraph()
                    add_formatted_text(p, stripped)
                
                i += 1
            
            doc.save(str(filepath))
            logger.info(f"DOCX export (Native MIT) SUCCESS: {filepath}")
            return str(filepath)

        except Exception as e:
            logger.error(f"Native DOCX export failed: {e}. Fallback to TXT.")
            txt_filepath = self.output_dir / f"export_{timestamp}.txt"
            with open(txt_filepath, 'w', encoding='utf-8') as f:
                f.write(clean_content)
            return str(txt_filepath)


class PptxExporter(BaseExporter):
    """Export in PowerPoint: trasforma una risposta in slide. Ogni heading
    markdown (#/##/###) apre una nuova slide (titolo = heading); le righe
    seguenti diventano bullet. Ignora `studio` (no branding)."""

    async def export(self, content: str, filename: Optional[str] = None,
                     studio: Optional[Dict[str, Any]] = None,
                     watermark: bool = False) -> str:
        from pptx import Presentation
        from pptx.util import Pt

        clean = strip_thinking_tags(content)
        timestamp = int(time.time())
        fname = filename or f"export_{timestamp}.pptx"
        filepath = self.output_dir / fname

        # Suddividi in sezioni per heading markdown (fuori dai blocchi di codice).
        sections = []  # (title|None, [righe])
        cur_title, cur_body = None, []
        in_code = False
        for raw in clean.split('\n'):
            line = raw.rstrip()
            if line.strip().startswith('```'):
                in_code = not in_code
                continue  # le fence non finiscono nelle slide
            if not in_code:
                hm = re.match(r'^(#{1,3})\s+(.*)$', line)
                if hm:
                    if cur_title is not None or cur_body:
                        sections.append((cur_title, cur_body))
                    cur_title, cur_body = hm.group(2).strip(), []
                    continue
            cur_body.append(line)
        if cur_title is not None or cur_body:
            sections.append((cur_title, cur_body))

        # Nessun heading → una sola slide con titolo generico.
        if not any(t for t, _ in sections):
            all_lines = [l for _, b in sections for l in b]
            sections = [("PAIS", all_lines)]

        prs = Presentation()
        layout = prs.slide_layouts[1]  # Title and Content
        for title, body in sections:
            slide = prs.slides.add_slide(layout)
            slide.shapes.title.text = (title or "PAIS")[:120]
            tf = slide.placeholders[1].text_frame
            tf.clear()
            first = True
            for raw in body:
                s = raw.strip()
                if not s:
                    continue
                # salta righe separatrici di tabella (|---|---|)
                if re.match(r'^\|[\s:|-]+\|?$', s):
                    continue
                indent = len(raw) - len(raw.lstrip(' '))
                level = min(1 if indent >= 2 else 0, 4)
                text = re.sub(r'^[-*]\s+', '', s)
                text = text.replace('**', '').replace('__', '').replace('`', '').replace('#', '').strip()
                if not text:
                    continue
                p = tf.paragraphs[0] if first else tf.add_paragraph()
                first = False
                p.text = text[:400]
                p.level = level
                for run in p.runs:
                    run.font.size = Pt(16)

        prs.save(str(filepath))
        logger.info(f"PPTX export: {filepath}")
        return str(filepath)


class ExportManager:
    """
    Manager per esportazione in multipli formati.
    Allineato alle funzionalità della versione originale.
    """

    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self.exporters = {
            'txt': TxtExporter(output_dir),
            'md': MdExporter(output_dir),
            'html': HtmlExporter(output_dir),
            'pdf': PdfExporter(output_dir),
            'docx': DocxExporter(output_dir),
            'pptx': PptxExporter(output_dir)
        }
    
    async def export_content(self, content: str, format_type: str,
                             filename: Optional[str] = None,
                             studio: Optional[Dict[str, Any]] = None,
                             watermark: Optional[bool] = None) -> Tuple[bool, str]:
        """Esporta `content` nel formato richiesto.
        Se `studio` è valorizzato (e formato è html/pdf/docx), aggiunge header
        brandizzato + footer con content hash. TXT/MD ignorano `studio`.
        `watermark`: None = decide dalla licenza (free → footer "versione free",
        PRO → pulito); True/False per forzare. Applicato solo da HTML/PDF/DOCX.

        Ritorna `(success, result, warning)`:
          - success=True, result=path, warning=None → export riuscito come richiesto.
          - success=True, result=path, warning={...} → fallback ONESTO: un file è
            stato prodotto ma NON nel formato richiesto (es. PDF→DOCX perché
            Chromium manca). La UI deve avvisare l'utente.
          - success=False, result=msg, warning=None → errore, nessun file.
        """
        exporter = self.exporters.get(format_type.lower())
        if not exporter:
            return False, f"Format '{format_type}' not supported", None

        wm = _free_watermark_active() if watermark is None else watermark

        try:
            filepath = await exporter.export(content, filename, studio=studio, watermark=wm)
            return True, filepath, None
        except PdfEngineUnavailable as e:
            # Fallback onesto: il file e.fallback_path esiste ma non è il PDF
            # richiesto. success=True (un file c'è) + warning strutturato che la
            # UI traduce e mostra.
            logger.warning(
                f"PDF export fell back to {e.fallback_format} ({e.reason}): {e.detail}"
            )
            warning = {
                "code": e.reason,                      # pdf_engine_missing | pdf_render_failed
                "fallback_format": e.fallback_format,  # docx | txt
                "requested_format": format_type.lower(),
            }
            return True, e.fallback_path, warning
        except Exception as e:
            logger.error(f"Export error ({format_type}): {e}")
            return False, str(e), None
    
    async def export_tables_to_excel(self, markdown_text: str) -> Tuple[bool, str]:
        import pandas as pd
        clean_text = strip_thinking_tags(markdown_text)
        table_pattern = r'((?:\|.*\|(?:\n|\r\n?)){2,})'
        matches = re.findall(table_pattern, clean_text)
        
        tables = []
        for m in matches:
            if re.search(r'^\s*\|(?:\s*:?-+[:\s]*\|)+\s*$', m, re.MULTILINE):
                tables.append(m.strip())
        
        if not tables:
            return False, "No tables found"
        
        try:
            timestamp = int(time.strftime("%Y%m%d_%H%M%S"))
            filename = f"extracted_tables_{timestamp}.xlsx"
            filepath = Path(self.output_dir) / filename
            
            with pd.ExcelWriter(filepath, engine='xlsxwriter') as writer:
                for i, table_str in enumerate(tables):
                    lines = table_str.split('\n')
                    clean_lines = [l for l in lines if not re.match(r'^\s*\|[\s-]*:?-+[:\s-]*\|', l)]
                    data = []
                    for line in clean_lines:
                        row = []
                        for cell in line.split('|'):
                            if cell.strip():
                                # Pulizia aggressiva markdown per dati Excel puri
                                c = cell.strip()
                                c = c.replace('**', '') # Grassetto
                                c = c.replace('__', '') # Grassetto alt
                                c = c.replace('*', '')  # Corsivo
                                c = c.replace('`', '')  # Codice
                                row.append(c)
                        
                        if row: data.append(row)
                    
                    if data:
                        df = pd.DataFrame(data[1:], columns=data[0])
                        df.to_excel(writer, sheet_name=f"Table {i+1}", index=False)

            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_code_blocks(self, markdown_text: str) -> Tuple[bool, str]:
        """Estrae i blocchi di codice fenced (```lang ... ```) dal testo e li
        salva su file. Un solo blocco → file singolo con l'estensione del
        linguaggio; due o più → archivio .zip con un file per blocco.
        Ritorna (success, filepath)."""
        clean_text = strip_thinking_tags(markdown_text)
        # Cattura info-string (linguaggio) + corpo del blocco.
        pattern = r'```([^\n`]*)\n(.*?)```'
        blocks = []
        for m in re.finditer(pattern, clean_text, re.DOTALL):
            info = (m.group(1) or '').strip().lower()
            lang = info.split()[0] if info else ''
            code = m.group(2).rstrip('\n')
            if code.strip():
                blocks.append((lang, code))

        if not blocks:
            return False, "No code blocks found"

        try:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            if len(blocks) == 1:
                lang, code = blocks[0]
                ext = _CODE_EXT.get(lang, 'txt')
                filepath = Path(self.output_dir) / f"code_{timestamp}.{ext}"
                filepath.write_text(code + "\n", encoding='utf-8')
                return True, str(filepath)

            # Più blocchi → un singolo archivio .zip.
            import zipfile
            filepath = Path(self.output_dir) / f"code_snippets_{timestamp}.zip"
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
                for i, (lang, code) in enumerate(blocks, 1):
                    ext = _CODE_EXT.get(lang, 'txt')
                    zf.writestr(f"snippet_{i}.{ext}", code + "\n")
            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_json_blocks(self, markdown_text: str) -> Tuple[bool, str]:
        """Estrae i blocchi JSON (fence ```json o blocchi che parsano come JSON),
        li valida e li salva indentati. 1 blocco → .json, ≥2 → .zip."""
        import json as _json
        clean_text = strip_thinking_tags(markdown_text)
        jsons = []
        for m in re.finditer(r'```([^\n`]*)\n(.*?)```', clean_text, re.DOTALL):
            lang = (m.group(1) or '').strip().lower()
            body = m.group(2).strip()
            if not body:
                continue
            is_json_lang = lang in ('json', 'json5', 'jsonc')
            looks_json = body[:1] in ('{', '[')
            if not (is_json_lang or looks_json):
                continue
            try:
                pretty = _json.dumps(_json.loads(body), indent=2, ensure_ascii=False)
            except Exception:
                if not is_json_lang:
                    continue  # blocco senza tag che non parsa: non è JSON
                pretty = body  # taggato json ma non valido: salva il grezzo
            jsons.append(pretty)

        if not jsons:
            return False, "No JSON blocks found"
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        try:
            if len(jsons) == 1:
                filepath = Path(self.output_dir) / f"data_{timestamp}.json"
                filepath.write_text(jsons[0] + "\n", encoding='utf-8')
                return True, str(filepath)
            import zipfile
            filepath = Path(self.output_dir) / f"json_data_{timestamp}.zip"
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
                for i, j in enumerate(jsons, 1):
                    zf.writestr(f"data_{i}.json", j + "\n")
            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_tables_to_csv(self, markdown_text: str) -> Tuple[bool, str]:
        """Come export_tables_to_excel ma in CSV. 1 tabella → .csv (BOM UTF-8
        per apertura corretta in Excel), ≥2 → .zip di .csv."""
        import pandas as pd
        clean_text = strip_thinking_tags(markdown_text)
        matches = re.findall(r'((?:\|.*\|(?:\n|\r\n?)){2,})', clean_text)
        tables = [m.strip() for m in matches
                  if re.search(r'^\s*\|(?:\s*:?-+[:\s]*\|)+\s*$', m, re.MULTILINE)]
        if not tables:
            return False, "No tables found"
        try:
            dfs = []
            for table_str in tables:
                clean_lines = [l for l in table_str.split('\n')
                               if not re.match(r'^\s*\|[\s-]*:?-+[:\s-]*\|', l)]
                data = []
                for line in clean_lines:
                    row = []
                    for cell in line.split('|'):
                        if cell.strip():
                            c = cell.strip().replace('**', '').replace('__', '').replace('*', '').replace('`', '')
                            row.append(c)
                    if row:
                        data.append(row)
                if data:
                    dfs.append(pd.DataFrame(data[1:], columns=data[0]))
            if not dfs:
                return False, "No tables found"

            timestamp = time.strftime("%Y%m%d_%H%M%S")
            if len(dfs) == 1:
                filepath = Path(self.output_dir) / f"table_{timestamp}.csv"
                dfs[0].to_csv(filepath, index=False, encoding='utf-8-sig')
                return True, str(filepath)
            import zipfile
            filepath = Path(self.output_dir) / f"tables_csv_{timestamp}.zip"
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
                for i, df in enumerate(dfs, 1):
                    zf.writestr(f"table_{i}.csv", df.to_csv(index=False))
            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_latex(self, markdown_text: str) -> Tuple[bool, str]:
        """Estrae le formule LaTeX ($$...$$, \\[...\\], \\(...\\)) preservando
        l'ordine e le impacchetta in un singolo .tex compilabile."""
        clean_text = strip_thinking_tags(markdown_text)
        no_code = re.sub(r'```.*?```', '', clean_text, flags=re.DOTALL)
        formulas = []
        for m in re.finditer(r'\$\$(.+?)\$\$|\\\[(.+?)\\\]|\\\((.+?)\\\)', no_code, re.DOTALL):
            f = next((g for g in m.groups() if g is not None), '').strip()
            if f:
                formulas.append(f)
        if not formulas:
            return False, "No LaTeX formulas found"
        body = "".join(f"\\[\n{f}\n\\]\n\n" for f in formulas)
        doc = (
            "\\documentclass{article}\n"
            "\\usepackage{amsmath,amssymb}\n"
            "\\begin{document}\n\n"
            f"{body}"
            "\\end{document}\n"
        )
        try:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filepath = Path(self.output_dir) / f"formule_{timestamp}.tex"
            filepath.write_text(doc, encoding='utf-8')
            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_code_highlight(self, markdown_text: str) -> Tuple[bool, str]:
        """Esporta i blocchi di codice come documento HTML con syntax highlighting
        (pygments) — colorato, stampabile, condivisibile. Tutti i blocchi in un
        unico file, ciascuno col proprio lexer."""
        from pygments import highlight
        from pygments.lexers import get_lexer_by_name, guess_lexer, TextLexer
        from pygments.formatters import HtmlFormatter

        clean_text = strip_thinking_tags(markdown_text)
        blocks = []
        for m in re.finditer(r'```([^\n`]*)\n(.*?)```', clean_text, re.DOTALL):
            info = (m.group(1) or '').strip().lower()
            lang = info.split()[0] if info else ''
            code = m.group(2).rstrip('\n')
            if code.strip():
                blocks.append((lang, code))
        if not blocks:
            return False, "No code blocks found"

        formatter = HtmlFormatter(style='friendly', cssclass='hl')
        parts = []
        for i, (lang, code) in enumerate(blocks, 1):
            try:
                lexer = get_lexer_by_name(lang) if lang else guess_lexer(code)
            except Exception:
                try:
                    lexer = guess_lexer(code)
                except Exception:
                    lexer = TextLexer()
            title = f"Snippet {i}" + (f" · {lang}" if lang else "")
            parts.append(f"<h2>{_html_escape(title)}</h2>" + highlight(code, lexer, formatter))

        style_defs = formatter.get_style_defs('.hl')
        doc = (
            "<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<title>Code snippets</title><style>"
            "body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:900px;"
            "margin:2rem auto;padding:0 1rem;background:#fff;color:#1e293b}"
            "h2{font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#64748b;margin:1.5rem 0 .4rem}"
            ".hl{padding:1rem;border-radius:8px;border:1px solid #e2e8f0;overflow:auto;"
            "font-size:13px;line-height:1.5}"
            f"{style_defs}"
            "</style></head><body>"
            + "".join(parts) +
            "</body></html>"
        )
        try:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filepath = Path(self.output_dir) / f"code_highlight_{timestamp}.html"
            filepath.write_text(doc, encoding='utf-8')
            return True, str(filepath)
        except Exception as e:
            return False, str(e)

    async def export_latex_png(self, markdown_text: str) -> Tuple[bool, str]:
        """Rende le formule LaTeX in una singola immagine PNG (Playwright +
        MathJax), comoda da incollare in Word/email senza LaTeX.
        MathJax è bundlato in locale → funziona anche OFFLINE."""
        if not _MATHJAX_JS.exists():
            return False, "MathJax bundle mancante (static/vendor/mathjax)"
        clean_text = strip_thinking_tags(markdown_text)
        no_code = re.sub(r'```.*?```', '', clean_text, flags=re.DOTALL)
        formulas = []
        for m in re.finditer(r'\$\$(.+?)\$\$|\\\[(.+?)\\\]|\\\((.+?)\\\)', no_code, re.DOTALL):
            f = next((g for g in m.groups() if g is not None), '').strip()
            if f:
                formulas.append(f)
        if not formulas:
            return False, "No LaTeX formulas found"

        body = "".join('<div class="f">$$\n' + f + '\n$$</div>' for f in formulas)
        html = """<!DOCTYPE html><html><head><meta charset="utf-8">
<script>
MathJax = { tex: { inlineMath: [['$','$'],['\\\\(','\\\\)']], displayMath: [['$$','$$'],['\\\\[','\\\\]']] }, options:{enableMenu:false} };
</script>
<script id="MathJax-script" src="__MATHJAX_SRC__"></script>
<style>body{margin:0;background:#fff} #wrap{display:inline-block;padding:24px} .f{font-size:26px;margin:14px 22px}</style>
</head><body><div id="wrap">__BODY__</div></body></html>""".replace("__BODY__", body).replace("__MATHJAX_SRC__", _vendor_uri(_MATHJAX_JS))

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        html_path = Path(self.output_dir) / f"_tmp_latex_{timestamp}.html"
        png_path = Path(self.output_dir) / f"formule_{timestamp}.png"
        try:
            html_path.write_text(html, encoding='utf-8')
            from playwright.async_api import async_playwright
            async with async_playwright() as p:
                browser = await p.chromium.launch()
                page = await browser.new_page(device_scale_factor=2)  # 2x = immagine nitida
                await page.goto(f"file:///{html_path.absolute().as_posix()}", wait_until="networkidle")
                await page.evaluate("""
                    async () => {
                        const start = Date.now();
                        while (Date.now() - start < 10000) {
                            if (window.MathJax && window.MathJax.typesetPromise) { await window.MathJax.typesetPromise(); return; }
                            await new Promise(r => setTimeout(r, 100));
                        }
                    }
                """)
                el = await page.query_selector('#wrap')
                if el:
                    await el.screenshot(path=str(png_path))
                else:
                    await page.screenshot(path=str(png_path))
                await browser.close()
            return True, str(png_path)
        except Exception as e:
            logger.error(f"LaTeX PNG export failed: {e}")
            return False, str(e)
        finally:
            try:
                if html_path.exists():
                    html_path.unlink()
            except Exception:
                pass

    async def export_mermaid(self, markdown_text: str) -> Tuple[bool, str]:
        """Estrae i blocchi ```mermaid e li rende in SVG (Playwright + mermaid.js).
        1 diagramma → .svg, ≥2 → .zip. mermaid è bundlato in locale → OFFLINE ok."""
        if not _MERMAID_JS.exists():
            return False, "Mermaid bundle mancante (static/vendor/mermaid)"
        clean_text = strip_thinking_tags(markdown_text)
        diagrams = []
        for m in re.finditer(r'```mermaid\s*\n(.*?)```', clean_text, re.DOTALL):
            code = m.group(1).strip()
            if code:
                diagrams.append(code)
        if not diagrams:
            return False, "No mermaid diagrams found"

        pres = "".join(f'<pre class="mermaid">{_html_escape(d)}</pre>' for d in diagrams)
        html = """<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="__MERMAID_SRC__"></script>
<style>body{background:#fff;margin:0;padding:16px}</style>
</head><body>__PRES__
<script>mermaid.initialize({ startOnLoad: true });</script>
</body></html>""".replace("__PRES__", pres).replace("__MERMAID_SRC__", _vendor_uri(_MERMAID_JS))

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        html_path = Path(self.output_dir) / f"_tmp_mermaid_{timestamp}.html"
        try:
            html_path.write_text(html, encoding='utf-8')
            from playwright.async_api import async_playwright
            svgs = []
            async with async_playwright() as p:
                browser = await p.chromium.launch()
                page = await browser.new_page(device_scale_factor=2)
                await page.goto(f"file:///{html_path.absolute().as_posix()}", wait_until="networkidle")
                try:
                    await page.wait_for_selector('pre.mermaid svg', timeout=15000)
                except Exception:
                    await browser.close()
                    return False, "Mermaid rendering failed (sintassi del diagramma non valida)"
                for el in await page.query_selector_all('pre.mermaid svg'):
                    svg = await el.evaluate('e => e.outerHTML')
                    # Mermaid su sintassi invalida NON lancia: inietta un SVG-errore
                    # ("Syntax error in text" / aria-roledescription="error"). Senza
                    # questo filtro salvavamo quell'SVG-errore spacciandolo per
                    # diagramma riuscito (stesso vizio del PDF→DOCX silenzioso, fix #2).
                    if 'aria-roledescription="error"' in svg or 'Syntax error' in svg:
                        continue
                    svgs.append(svg)
                await browser.close()

            if not svgs:
                # Tipico con diagrammi generati dall'AI: etichette con ( ) : / non
                # quotate. Messaggio azionabile invece di un file rotto.
                return False, ("Sintassi del diagramma Mermaid non valida: nessun diagramma "
                               "renderizzato. Suggerimento: racchiudi tra virgolette le etichette "
                               'dei nodi che contengono parentesi, due punti o slash — es. A["Testo (1815)"].')
            if len(svgs) == 1:
                filepath = Path(self.output_dir) / f"diagram_{timestamp}.svg"
                filepath.write_text(svgs[0], encoding='utf-8')
                return True, str(filepath)
            import zipfile
            filepath = Path(self.output_dir) / f"diagrams_{timestamp}.zip"
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
                for i, svg in enumerate(svgs, 1):
                    zf.writestr(f"diagram_{i}.svg", svg)
            return True, str(filepath)
        except Exception as e:
            logger.error(f"Mermaid export failed: {e}")
            return False, str(e)
        finally:
            try:
                if html_path.exists():
                    html_path.unlink()
            except Exception:
                pass
