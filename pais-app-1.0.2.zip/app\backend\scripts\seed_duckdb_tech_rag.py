"""
Seed the DuckDB technical knowledge base into the active project's tech_rag
ChromaDB collection.

The ManipulateService also auto-seeds on its first SQL call per project, but
this script lets you reseed on demand (e.g. after bumping KB_VERSION inside
services/duckdb_tech_kb.py) without touching the UI.

Usage:
    ../venv/Scripts/python.exe scripts/seed_duckdb_tech_rag.py [--force]

By default the script targets the project ProjectManager considers active
(same one MANIPULATE SHEET uses). Pass --chroma-path to seed a specific dir.
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass


async def _run(force: bool, chroma_path: str | None) -> int:
    from processors.document_processor import DocumentProcessor
    from services import duckdb_tech_kb

    if chroma_path is None:
        from backend_config.project_manager import project_manager
        from backend_config.settings import BASE_DIR
        if project_manager.active_project_path:
            chroma_path = str(project_manager.get_path("db"))
        else:
            chroma_path = str(BASE_DIR / "chroma_db")

    print(f"target ChromaDB: {chroma_path}")
    tech_rag = DocumentProcessor(
        collection_name="technical_sql",
        persist_directory=chroma_path,
        lang="it",
    )
    res = await duckdb_tech_kb.seed(tech_rag, force=force)
    print(f"result: {res}")
    return 0


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--force", action="store_true",
                   help="Reseed even if the current KB version is already present.")
    p.add_argument("--chroma-path", default=None,
                   help="ChromaDB persist directory (defaults to the active project's).")
    args = p.parse_args()
    return asyncio.run(_run(args.force, args.chroma_path))


if __name__ == "__main__":
    sys.exit(main())
