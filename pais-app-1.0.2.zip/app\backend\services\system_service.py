"""
System Service - Gestione stato hardware, modelli e installazioni.
"""
import os
import sys
import asyncio
import logging
import subprocess
import shutil
import socket
import json
import importlib
import importlib.util
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import ollama
from backend_config import settings

logger = logging.getLogger("PAIS.System")

class SystemService:
    # Modello obbligatorio non cancellabile dall'utente — è il chat default di INTERROGATE
    # e fa anche da fallback per Anonimyze LLM cleanup, catalog/split. Eliminandolo
    # romperebbe più feature contemporaneamente.
    MANDATORY_CHAT_MODEL = "gemma4:e4b"

    # Modelli NON cancellabili (delete_model rifiuta) e core dell'app.
    # Solo gemma4:e4b è davvero indispensabile: regge CHAT + VISION + fa da
    # fallback per Anonimyze/catalog. I due coder di MANIPULATE NON sono qui:
    # sono ALTERNATIVE (ne basta una) e l'utente può cancellarle/scegliere in
    # base all'hardware (qwen3-coder:30b = HIGH RAM, qwen2.5-coder:7b = LOW RAM).
    MANDATORY_MODELS = (
        "gemma4:e4b",
    )

    # Mapping modello → (modulo, ruolo, può-essere-sostituito-dall-utente).
    # Solo INTERROGATE permette swap del chat model. Gli altri ruoli sono fissi
    # perché tarati su modelli specifici (es. OCR → glm-ocr, embeddings →
    # qwen3-embedding). Aggiungere un alternativa qui significa che diventa
    # selezionabile in UI.
    MODEL_ROLES = {
        "gemma4:e4b":                     ("interrogate", "chat",       True),
        "gemma4:26b":                     ("interrogate", "chat_alt",   True),  # heavier alternative
        "gemma4:e2b":                     ("interrogate", "chat_alt",   True),  # lighter alternative
        "qwen3-embedding:0.6b":           ("interrogate", "embeddings", False),
        "bbjson/bge-reranker-base:latest":("interrogate", "reranker",   False),
        "qwen3-vl:4b":                    ("vision",      "image",      False),
        "qwen3-coder:30b":                ("manipulate",  "sql_engine", False),
        "translategemma:4b":              ("utility",     "translate",  False),
        "glm-ocr:latest":                 ("utility",     "ocr",        False),
        "faster-whisper-medium":          ("interrogate", "dictation",  False),
        "xx_ent_wiki_sm":                 ("anonimyze",   "tokenizer",  False),
        "onnx-community/multilang-pii-ner-ONNX": ("anonimyze", "pii_ner", False),
        "pp-doc-layout-v3":               ("interrogate", "layout",     False),
    }

    def __init__(self):
        # Fallback hardcoded — usato solo se profiles.json non si carica.
        # In produzione la lista REALE viene da profiles.json["HIGH"]["models"]["ollama"].
        # Il bot Telegram condivide il CHAT_MODEL di Interrogate (gemma4:e4b) di default;
        # nessun modello dedicato per il bot.
        self.required_ollama_models = [
            "gemma4:e4b", "qwen3-embedding:0.6b", "bbjson/bge-reranker-base:latest",
            "qwen3-coder:30b",
            "translategemma:4b", "glm-ocr:latest",
        ]
        # Modelli "alternativi" installabili a richiesta (chat heavier/lighter switch).
        # Non scaricati di default; appaiono in UI con badge "Optional" e bottone install.
        self.optional_ollama_models = ["gemma4:26b", "gemma4:e2b", "qwen2.5-coder:7b"]
        self.required_spacy_models = ["xx_ent_wiki_sm"]
        self.required_onnx_pii_models = ["onnx-community/multilang-pii-ner-ONNX"]
        self.required_libraries = ["faster-whisper-medium"]
        self.model_sizes = {}
        self._load_profiles()

    def get_ollama_client(self):
        """Restituisce un client aggiornato con la porta dinamica corrente."""
        return ollama.AsyncClient(host=settings.OLLAMA_HOST_URL)

    def _load_profiles(self):
        """Carica la lista unificata dei modelli obbligatori da profiles.json.

        Niente più profili HIGH/LOW: c'è una sola sezione `required` valida
        per qualunque hardware. Il giudizio sul matching hardware è esposto
        via /system/hardware (campo `verdict`) ma non altera i required.
        """
        try:
            base_dir = Path(__file__).parent.parent.resolve()
            profile_path = base_dir / "backend_config" / "profiles.json"

            if profile_path.exists():
                with open(profile_path, 'r', encoding='utf-8') as f:
                    self.profiles = json.load(f)

                self.model_sizes = self.profiles.get("model_sizes_gb", {})
                req = self.profiles.get("required") or {}
                self.required_ollama_models = req.get("ollama", self.required_ollama_models)
                self.required_spacy_models = req.get("spacy", self.required_spacy_models)
                self.required_onnx_pii_models = req.get("onnx_pii", self.required_onnx_pii_models)
                self.required_libraries = req.get("library", self.required_libraries)
                # Optional Ollama: ogni modello del catalog con recommended:true
                # che non sia gia' nei required (alternative non bloccanti).
                catalog = self.profiles.get("catalog") or {}
                req_set = set(self.required_ollama_models)
                opt: List[str] = []
                for module_entries in catalog.values():
                    for e in module_entries:
                        if isinstance(e, dict) and e.get("recommended") and e.get("id") and e["id"] not in req_set:
                            opt.append(e["id"])
                self.optional_ollama_models = opt
                logger.info(f"✅ Required models loaded ({len(self.required_ollama_models)} ollama + {len(opt)} recommended optional)")
            self.mandatory_models = self.MANDATORY_MODELS
        except Exception as e:
            logger.error(f"❌ Error loading profiles.json: {e}")
            self.mandatory_models = self.MANDATORY_MODELS

    def reload_profile(self) -> None:
        """Backward-compat shim. Profili rimossi: ricarica solo la lista required."""
        self._load_profiles()

    async def get_system_status(self) -> Dict[str, Any]:
        """Verifica lo stato di salute di tutti i componenti core."""
        try:
            # IMPORTANTE: Invalida la cache degli import per vedere i nuovi pacchetti installati via subprocess
            importlib.invalidate_caches()
            
            status = {
                "ollama_online": False,
                "models": {
                    "ollama": [],
                    "local": []
                }
            }

            # 1. Check Ollama reachability
            try:
                from urllib.parse import urlparse
                parsed = urlparse(settings.OLLAMA_HOST_URL)
                hostname = parsed.hostname or '127.0.0.1'
                # Fallback hardcoded rimosso: il vecchio `or 11434` era un'arma carica
                # (avrebbe puntato all'Ollama di sistema se OLLAMA_HOST_URL fosse
                # malformato). Se la porta manca trattiamo come "URL invalido" e
                # marchiamo Ollama come offline, così l'errore emerge subito.
                port = parsed.port
                if not port:
                    logger.warning(
                        f"OLLAMA_HOST_URL '{settings.OLLAMA_HOST_URL}' non ha porta — Ollama considerato offline."
                    )
                else:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.settimeout(0.5)
                        if s.connect_ex((hostname, port)) == 0:
                            status["ollama_online"] = True
            except: pass

            # 2. Get Ollama models status
            installed_names = []
            if status["ollama_online"]:
                try:
                    installed_models_info = await self.get_ollama_client().list()
                    if hasattr(installed_models_info, 'models'):
                        for m in installed_models_info.models:
                            installed_names.append(getattr(m, 'model', getattr(m, 'name', '')))
                    elif isinstance(installed_models_info, dict) and 'models' in installed_models_info:
                        for m in installed_models_info['models']:
                            if isinstance(m, dict):
                                installed_names.append(m.get('name') or m.get('model', ''))
                            else:
                                installed_names.append(getattr(m, 'model', getattr(m, 'name', '')))
                except Exception as e:
                    logger.error(f"Error listing ollama models: {e}")

            # Ollama models logic — distingue mandatory (required) vs optional alternatives.
            # Output: ogni voce ha is_optional + is_mandatory_locked (gemma4:e4b non cancellabile).
            def _check_installed(req: str) -> bool:
                if not status["ollama_online"]:
                    return False
                for installed in installed_names:
                    if not installed: continue
                    if req == installed or installed.startswith(req + ":") or (":" not in req and installed.startswith(req)):
                        return True
                return False

            unique_reqs = sorted(list(set(self.required_ollama_models)))
            for req in unique_reqs:
                status["models"]["ollama"].append({
                    "id": req,
                    "name": req,
                    "installed": _check_installed(req),
                    "type": "ollama",
                    "size_gb": self.model_sizes.get(req, 0.0),
                    "is_optional": False,
                    "is_mandatory_locked": (req in self.mandatory_models),
                })

            # Optional alternatives (chat switcher heavy/light). Mostrati in UI
            # ma non inclusi nel "Install All Missing" obbligatorio.
            for opt in sorted(list(set(self.optional_ollama_models))):
                status["models"]["ollama"].append({
                    "id": opt,
                    "name": opt,
                    "installed": _check_installed(opt),
                    "type": "ollama",
                    "size_gb": self.model_sizes.get(opt, 0.0),
                    "is_optional": True,
                    "is_mandatory_locked": False,
                })

            # 3. Check SpaCy models (Robust Check)
            import spacy
            for req in self.required_spacy_models:
                is_pkg = False
                try:
                    if spacy.util.is_package(req):
                        is_pkg = True
                    else:
                        if importlib.util.find_spec(req) is not None:
                            is_pkg = True
                except: pass

                status["models"]["local"].append({
                    "id": req,
                    "name": f"SpaCy {req}",
                    "installed": is_pkg,
                    "type": "spacy",
                    "size_gb": self.model_sizes.get(req, 0.0),
                    "is_optional": False,
                    "is_mandatory_locked": False,
                })

            # 3b. Check ONNX PII models (source tree dell'app, bundlati nell'installer).
            backend_dir = Path(__file__).resolve().parent.parent
            for req in self.required_onnx_pii_models:
                repo_short = req.split("/")[-1]
                local_dir = backend_dir / "models" / "onnx_pii" / repo_short
                marker = local_dir / ".install_complete"
                is_installed = marker.exists()

                status["models"]["local"].append({
                    "id": req,
                    "name": f"PII NER {repo_short.lower()}",
                    "installed": is_installed,
                    "type": "onnx_pii",
                    "size_gb": self.model_sizes.get(repo_short.lower(), self.model_sizes.get(req, 0.0)),
                    "is_optional": False,
                    "is_mandatory_locked": False,
                })

            # 4. Check Faster-Whisper Medium (motore dedicato per la dettatura
            # push-to-talk in Interrogate). Cache su HuggingFace, non OpenAI CDN.
            fw_installed = False
            try:
                from processors.faster_whisper_processor import is_model_installed as _fw_check
                fw_installed = _fw_check()
            except Exception as e:
                logger.warning(f"faster-whisper status check failed: {e}")

            status["models"]["local"].append({
                "id": "faster-whisper-medium",
                "name": "Dictation Engine",
                "installed": fw_installed,
                "type": "library",
                "size_gb": self.model_sizes.get("faster-whisper-medium", 0.0),
                "is_optional": False,
                "is_mandatory_locked": False,
            })

            # 5. Check PP-DocLayoutV3 model
            layout_path = Path(settings.BASE_DIR) / "models" / "layout" / "pp_doc_layout_v3.onnx"
            status["models"]["local"].append({
                "id": "pp-doc-layout-v3",
                "name": "Layout Analysis (ONNX)",
                "installed": layout_path.exists(),
                "type": "onnx",
                "size_gb": 0.05,
                "is_optional": False,
                "is_mandatory_locked": False,
            })

            return status
        except Exception as e:
            logger.error(f"💥 Critical error in get_system_status: {e}")
            # Ritorna uno stato vuoto ma valido per non far crashare il frontend
            return {"ollama_online": False, "models": {"ollama": [], "local": []}}

    async def _ollama_model_present(self, client, model_id: str) -> bool:
        """True se Ollama ha il modello registrato. Usato come verifica post-pull
        per intercettare i 'download corrotti' (pull chiuso senza errori ma blob
        incompleto). Match esatto su model_id (i nostri id hanno tag espliciti,
        es. 'gemma4:e4b'); se l'id è senza tag accetta anche ':latest'.

        Fail-open: se la verifica STESSA fallisce (Ollama momentaneamente muto)
        ritorna True — meglio un falso positivo che un loop di re-download. Il
        runtime rileverà comunque un modello realmente assente."""
        try:
            r = await client.get(f"{settings.OLLAMA_HOST_URL}/api/tags", timeout=15.0)
            r.raise_for_status()
            names = [m.get("name", "") for m in (r.json() or {}).get("models", [])]
            wanted = {model_id}
            if ":" not in model_id:
                wanted.add(f"{model_id}:latest")
            return any(n in wanted for n in names)
        except Exception as e:
            logger.warning(f"Ollama model verification failed for {model_id}: {e}")
            return True

    def install_preflight(self, required_bytes: int) -> dict:
        """Preflight prima del download batch: c'è abbastanza spazio sul volume
        dei modelli per i ~required_bytes mancanti (+ margine)? Evita di morire a
        metà di decine di GB su disco pieno. Il volume di OLLAMA_MODELS_DIR è
        rappresentativo (i modelli Ollama sono la parte dominante, 28-48GB).

        Fail-open: se il check stesso fallisce ritorna ok=True per non bloccare
        l'install per un errore del preflight."""
        import shutil
        try:
            models_dir = Path(settings.OLLAMA_MODELS_DIR)
            models_dir.mkdir(parents=True, exist_ok=True)
            usage = shutil.disk_usage(str(models_dir))
            margin = 2 * 1024 ** 3  # 2 GB di margine operativo
            needed = max(0, int(required_bytes)) + margin
            return {
                "ok": usage.free >= needed,
                "free_bytes": usage.free,
                "required_bytes": int(required_bytes),
                "needed_bytes": needed,
                "drive": models_dir.anchor or str(models_dir),
            }
        except Exception as e:
            logger.warning(f"install preflight failed: {e}")
            return {"ok": True, "free_bytes": 0, "required_bytes": int(required_bytes),
                    "needed_bytes": 0, "drive": "", "error": str(e)}

    async def install_model(self, model_id: str, model_type: str):
        """Gestisce l'installazione di un modello con streaming di progresso."""
        if model_type == "ollama":
            try:
                import httpx
                import json
                # Pull modello: connect rapido, read lunghissimo (download GB).
                pull_timeout = httpx.Timeout(connect=10.0, read=3600.0, write=30.0, pool=10.0)
                async with httpx.AsyncClient(timeout=pull_timeout) as client:
                    url = f"{settings.OLLAMA_HOST_URL}/api/pull"
                    async with client.stream("POST", url, json={"name": model_id, "stream": True}) as response:
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            if line:
                                try:
                                    data = json.loads(line)
                                    yield data
                                except json.JSONDecodeError:
                                    pass
                    # Verifica post-pull: il pull può chiudersi senza eccezioni ma
                    # lasciare il modello NON registrato (rete interrotta, blob
                    # parziale) — la classica "download corrotto". Confermiamo che
                    # Ollama veda davvero il modello prima di dichiarare successo,
                    # così il retry del frontend (Round-2) lo ri-scarica.
                    if not await self._ollama_model_present(client, model_id):
                        raise RuntimeError(
                            f"Pull completato ma il modello '{model_id}' non risulta "
                            f"registrato in Ollama (download incompleto/corrotto)."
                        )
                    yield {"status": "success", "message": f"{model_id} verified", "verified": True}
            except Exception as e:
                logger.error(f"Error during Ollama pull for {model_id}: {e}")
                yield {"status": "error", "message": str(e)}
        elif model_type == "spacy":
            yield {"status": "starting", "message": f"Downloading {model_id}..."}
            # Hardening: pip può fallire (rete, 404, build) ma prima il codice
            # dava SEMPRE "success". Ora verifichiamo: exit 0 + pacchetto
            # importabile; retry 1 volta su fallimento.
            from importlib.util import find_spec
            url = (f"https://github.com/explosion/spacy-models/releases/download/"
                   f"{model_id}-3.8.0/{model_id}-3.8.0.tar.gz")
            MAX_ATTEMPTS = 2
            last_err = ""
            installed_ok = False
            for attempt in range(1, MAX_ATTEMPTS + 1):
                process = await asyncio.create_subprocess_exec(
                    sys.executable, "-m", "pip", "install", url,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                )
                _, stderr = await process.communicate()  # drena le pipe (no deadlock)
                importlib.invalidate_caches()
                if process.returncode == 0 and find_spec(model_id) is not None:
                    installed_ok = True
                    yield {"status": "success", "message": f"Model {model_id} installed.", "verified": True}
                    break
                last_err = (stderr.decode("utf-8", errors="ignore")[-300:]
                            if stderr else f"pip exit {process.returncode}")
                logger.warning(f"spaCy install attempt {attempt}/{MAX_ATTEMPTS} failed for {model_id}: {last_err}")
                if attempt < MAX_ATTEMPTS:
                    await asyncio.sleep(3)
            if not installed_ok:
                yield {"status": "error", "message": f"spaCy {model_id} install failed: {last_err}"}
        elif model_type == "onnx" and model_id == "pp-doc-layout-v3":
            yield {"status": "starting", "message": "Downloading Layout Model..."}
            try:
                from processors.layout_processor import LayoutProcessor
                # Forza il download se manca, o riprova
                proc = LayoutProcessor()
                # Verifica effettiva
                layout_path = Path(settings.BASE_DIR) / "models" / "layout" / "pp_doc_layout_v3.onnx"
                if layout_path.exists() and layout_path.stat().st_size > 0:
                    yield {"status": "success", "message": "Layout Model installed."}
                else:
                    raise Exception("Layout file verification failed after download.")
            except Exception as e:
                logger.error(f"Layout installation failed: {str(e)}")
                yield {"status": "error", "message": str(e)}

        elif model_type == "onnx_pii":
            yield {"status": "starting", "message": f"Downloading {model_id}..."}
            try:
                from huggingface_hub import hf_hub_download
                loop = asyncio.get_event_loop()

                # Pinning revisione: evita supply-chain attack se il repo HF cambia.
                # Pin di default solo per il modello PII conosciuto; altri repo
                # accettano override via env var o restano su HEAD del default branch
                # (in quel caso loggiamo un warning).
                KNOWN_PINS = {
                    "onnx-community/multilang-pii-ner-ONNX":
                        "730c579658f8258600cc8a069b2fad1615289201",
                }
                model_revision = (
                    os.environ.get("PAI_PII_MODEL_REVISION")
                    or KNOWN_PINS.get(model_id)
                )
                if not model_revision:
                    logger.warning(
                        f"No pinned revision for {model_id}; using HEAD of default branch. "
                        f"Set PAI_PII_MODEL_REVISION env var or add to KNOWN_PINS for production."
                    )

                repo_short = model_id.split("/")[-1]
                backend_dir = Path(__file__).resolve().parent.parent
                local_dir = backend_dir / "models" / "onnx_pii" / repo_short
                local_dir.mkdir(parents=True, exist_ok=True)
                marker = local_dir / ".install_complete"
                # Reset marker fino a fine download (evita race condition col polling status).
                if marker.exists():
                    marker.unlink()

                # Una sola variante ONNX (FP32 default, ~1.1GB). Cambiabile via env var.
                onnx_file = os.environ.get("PAI_ONNX_MODEL_FILE", "onnx/model.onnx")
                # File essenziali per ORTModelForTokenClassification + tokenizer.
                # Alcuni potrebbero non esistere su ogni repo: gli errori 404 sono ignorati.
                files_required = ["config.json", onnx_file]
                files_optional = [
                    "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
                    "sentencepiece.bpe.model", "spiece.model", "vocab.txt",
                ]
                files_to_download = files_required + files_optional

                size_gb = self.model_sizes.get(repo_short.lower(), self.model_sizes.get(model_id, 1.15))
                total_bytes = int(size_gb * 1024 * 1024 * 1024) or 1
                total_files = len(files_to_download)

                for idx, fname in enumerate(files_to_download):
                    yield {
                        "status": "downloading",
                        "message": f"Downloading {fname}",
                        "completed": int(idx / total_files * total_bytes),
                        "total": total_bytes,
                    }
                    try:
                        await loop.run_in_executor(
                            None,
                            lambda f=fname: hf_hub_download(
                                repo_id=model_id,
                                filename=f,
                                revision=model_revision,
                                local_dir=str(local_dir),
                            )
                        )
                    except Exception as file_err:
                        if fname in files_required:
                            raise
                        # I file tokenizer LEGACY (sentencepiece.bpe.model, spiece.model,
                        # vocab.txt) NON esistono nei repo onnx-community moderni che usano
                        # solo tokenizer.json (FAST). I 404 sono attesi e gestiti dal
                        # fallback "best effort" — non vogliamo spaventare l'utente con
                        # warning visibili. Resta DEBUG per ispezione manuale se serve.
                        logger.debug(f"Optional file {fname} skipped: {file_err}")

                # Marker = fonte di verità "installazione completa". Scritto SOLO a fine download.
                marker.write_text(f"{model_id}\n{onnx_file}\n", encoding="utf-8")

                yield {
                    "status": "downloading",
                    "message": "Finalizing",
                    "completed": total_bytes,
                    "total": total_bytes,
                }
                yield {"status": "success", "message": f"PII NER {model_id} installed."}
            except Exception as e:
                logger.error(f"ONNX PII installation failed: {str(e)}")
                yield {"status": "error", "message": str(e)}

        elif model_type == "library" and model_id == "faster-whisper-medium":
            yield {"status": "starting", "message": "Downloading Dictation Engine (faster-whisper medium, ~1.5GB)..."}
            # Retry loop: 3 tentativi totali, ogni try fa cleanup pre + download + mark.
            # HF cache puo' avere file parziali da run precedenti -> pulizia idempotente
            # rimuove la cartella prima di ogni tentativo. Pausa 5s tra tentativi per
            # dare tempo alla rete di stabilizzarsi.
            #
            # IMPORTANTE: scarichiamo con snapshot_download(local_dir=...) invece di
            # WhisperModel("medium") perche' il sistema blob+snapshot di HF su Windows
            # embedded Python fallisce silenziosamente: file in blobs/ OK ma symlink
            # in snapshots/<sha>/ non viene creata -> CTranslate2 "Unable to open file
            # 'model.bin' in model '.../snapshots/...'". Con local_dir, i file sono
            # scaricati come file regolari nella flat dir e CTranslate2 li trova.
            from huggingface_hub import snapshot_download
            from faster_whisper import WhisperModel
            from processors.faster_whisper_processor import (
                is_model_installed as _fw_check,
                mark_model_installed as _fw_mark,
                cleanup_corrupted_install as _fw_cleanup,
                get_install_state as _fw_state,
                fw_model_dir as _fw_dir,
            )
            loop = asyncio.get_event_loop()
            MAX_ATTEMPTS = 3
            last_err = None
            for attempt in range(1, MAX_ATTEMPTS + 1):
                try:
                    # Pre-cleanup: rimuove ogni file parziale prima di ritentare
                    state_before = _fw_state()
                    if state_before != "complete":
                        _fw_cleanup()
                        if attempt > 1:
                            yield {
                                "status": "progress",
                                "message": f"Retry {attempt}/{MAX_ATTEMPTS}: cleaning cache, restarting download...",
                            }
                    local_dir = _fw_dir()
                    local_dir.mkdir(parents=True, exist_ok=True)
                    # Step 1: download (regular files, no blob/symlink indirection)
                    await loop.run_in_executor(
                        None,
                        lambda: snapshot_download(
                            repo_id="Systran/faster-whisper-medium",
                            local_dir=str(local_dir),
                        ),
                    )
                    # Step 2: verifica integrita' caricando il modello da local_dir
                    await loop.run_in_executor(
                        None,
                        lambda: WhisperModel(str(local_dir), device="cpu", compute_type="int8"),
                    )
                    _fw_mark()
                    if _fw_check():
                        yield {"status": "success", "message": "Dictation Engine installed."}
                        break
                    else:
                        raise Exception(
                            f"faster-whisper post-load verification failed (state={_fw_state()})"
                        )
                except Exception as e:
                    last_err = e
                    logger.warning(
                        f"faster-whisper attempt {attempt}/{MAX_ATTEMPTS} failed: {e}"
                    )
                    if attempt < MAX_ATTEMPTS:
                        await asyncio.sleep(5)
                    continue
            else:
                # Loop concluso senza break -> tutti i tentativi falliti
                logger.error(
                    f"faster-whisper installation failed after {MAX_ATTEMPTS} attempts: {last_err}"
                )
                try:
                    _fw_cleanup()
                except Exception:
                    pass
                yield {
                    "status": "error",
                    "message": (
                        f"Download Dictation Engine interrotto dopo {MAX_ATTEMPTS} tentativi. "
                        f"Verifica connessione internet e riprova. Ultimo errore: {last_err}"
                    ),
                }

    async def delete_model(self, model_id: str, model_type: str) -> bool:
        """Elimina fisicamente un modello dal disco.

        Lancia ValueError se l'utente prova a cancellare il MANDATORY_CHAT_MODEL —
        è il default di INTERROGATE e fallback di Anonimyze/catalog/split. Senza
        questo modello varie feature smetterebbero di funzionare.

        Per i modelli Ollama: la chiamata pulisce SEMPRE prima i registri custom
        (interrogate / vision / manipulate) in user_settings.json, anche se il
        modello non risulta installato in Ollama. Questo gestisce il caso di
        riferimenti orfani — es. tag `:cloud` registrati come custom ma mai
        scaricati realmente, o entry rimaste dopo un'uninstall manuale.
        Ollama 404 ("model not found") è trattato come successo idempotente:
        il modello "non c'è" è esattamente lo stato target del delete.
        """
        try:
            if model_type == "ollama":
                if model_id in self.mandatory_models:
                    raise ValueError(
                        f"'{model_id}' is a MANDATORY model and cannot be deleted. "
                        "PAIS requires it to function across Interrogate / Manipulate / Vision."
                    )

                # Step 1: pulisci sempre i registri custom — best-effort, ignora errori.
                # Senza questo, un riferimento orfano (es. cloud tag rifiutato da Ollama)
                # resta intrappolato nel JSON e ricompare in UI dopo un refresh.
                try:
                    from services import user_settings_service as uss
                    for module in ("interrogate", "vision", "manipulate"):
                        try:
                            uss.remove_custom_model(module, model_id)
                        except Exception as e:
                            logger.debug(f"remove_custom_model({module}, {model_id}) skipped: {e}")
                except Exception as e:
                    logger.warning(f"Custom model registry cleanup failed: {e}")

                # Step 2: tenta il delete su Ollama.
                import httpx
                async with httpx.AsyncClient(timeout=10.0) as client:
                    url = f"{settings.OLLAMA_HOST_URL}/api/delete"
                    response = await client.request("DELETE", url, json={"name": model_id})
                    if response.status_code == 200:
                        return True
                    if response.status_code == 404:
                        # Modello non presente in Ollama → idempotente: lo stato è già quello desiderato.
                        # Il caso classico: riferimento orfano nel registro custom rimosso allo Step 1.
                        logger.info(f"Ollama delete: {model_id} not present (404), treating as success after registry cleanup")
                        return True
                    logger.error(f"Ollama delete failed for {model_id}: {response.status_code} {response.text[:200]}")
                    return False
            
            elif model_type == "spacy":
                logger.info(f"🗑️ Uninstalling SpaCy model via pip: {model_id}")
                process = await asyncio.create_subprocess_exec(
                    sys.executable, "-m", "pip", "uninstall", "-y", model_id,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                await process.wait()
                importlib.invalidate_caches()
                return True

            elif model_type == "onnx_pii":
                try:
                    repo_short = model_id.split("/")[-1]
                    backend_dir = Path(__file__).resolve().parent.parent
                    local_dir = backend_dir / "models" / "onnx_pii" / repo_short
                    if local_dir.exists():
                        shutil.rmtree(local_dir)
                        logger.info(f"🗑️ Deleted ONNX PII model: {local_dir}")
                        return True
                    return False
                except Exception as e:
                    logger.error(f"ONNX PII delete failed: {e}")
                    return False

            elif model_type == "library" and model_id == "faster-whisper-medium":
                # Cancella entrambe le posizioni: la nuova flat local_dir
                # (pais-models/faster-whisper-medium) E la vecchia HF cache
                # blob/snapshot, per ripulire eventuali orfani da install
                # precedenti col vecchio layout.
                hf_home = os.environ.get("HF_HOME")
                hf_cache_root = Path(hf_home) if hf_home else (
                    Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".cache" / "huggingface"
                )
                candidates = [
                    hf_cache_root / "pais-models" / "faster-whisper-medium",
                    hf_cache_root / "hub" / "models--Systran--faster-whisper-medium",
                ]
                deleted_any = False
                for fw_dir in candidates:
                    if fw_dir.exists():
                        shutil.rmtree(fw_dir, ignore_errors=True)
                        logger.info(f"🗑️ Deleted Dictation Engine weights: {fw_dir}")
                        deleted_any = True
                if deleted_any:
                    return True

            return False
        except Exception as e:
            logger.error(f"Error deleting model {model_id}: {e}")
            return False

    def get_tos_status(self) -> bool:
        config_file = settings.BASE_DIR / "user_settings.json"
        if not config_file.exists():
            return False
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("tos_accepted", False)
        except:
            return False

    # ─── HAI-DEF Terms (Health AI Developer Foundations) ────────────────────────
    # Required for MedGemma. Pass-through obligation to end users (HAI-DEF 3.1.4):
    # the user must accept these terms BEFORE installing or using any HAI-DEF model.
    # Persisted in user_settings.json under `hai_def_terms` so the prompt fires
    # only once per machine, with version tracking for future term updates.

    HAI_DEF_CURRENT_VERSION = "2024-11-15"

    def get_hai_def_status(self) -> dict:
        """Return {accepted, accepted_at, version}. Default: not accepted."""
        config_file = settings.BASE_DIR / "user_settings.json"
        default = {"accepted": False, "accepted_at": None, "version": None}
        if not config_file.exists():
            return default
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            block = data.get("hai_def_terms")
            if not isinstance(block, dict):
                return default
            return {
                "accepted": bool(block.get("accepted", False)),
                "accepted_at": block.get("accepted_at"),
                "version": block.get("version"),
            }
        except Exception as e:
            logger.warning(f"hai_def_terms read failed: {e}")
            return default

    def accept_hai_def_terms(self, version: Optional[str] = None) -> bool:
        """Persist HAI-DEF terms acceptance. version defaults to HAI_DEF_CURRENT_VERSION."""
        config_file = settings.BASE_DIR / "user_settings.json"
        v = version or self.HAI_DEF_CURRENT_VERSION
        try:
            import datetime
            data = {}
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            data["hai_def_terms"] = {
                "accepted": True,
                "accepted_at": datetime.datetime.now().isoformat(),
                "version": v,
            }
            config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving HAI-DEF acceptance: {e}")
            return False

    def model_requires_hai_def(self, model_id: str) -> bool:
        """Return True if the model is subject to HAI-DEF Terms (currently MedGemma family)."""
        if not model_id:
            return False
        return model_id.startswith("medgemma")

    def accept_tos(self) -> bool:
        """Salva l'accettazione dei termini di servizio su disco con versione e timestamp."""
        config_file = settings.BASE_DIR / "user_settings.json"
        try:
            import datetime
            data = {}
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

            data["tos_accepted"] = True
            data["tos_version"] = "1.0"
            data["tos_accepted_at"] = datetime.datetime.now().isoformat()

            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving ToS acceptance: {e}")
            return False

    # ─── Telegram bot per-channel overrides ─────────────────────────────────
    # Permettono al bot di usare modello/profilo/lingua DIVERSI dal desktop UI.
    # Storage: blocco "telegram" in user_settings.json. None/missing = "use desktop default".
    def get_telegram_overrides(self) -> dict:
        """Return {model, profile, lang} overrides for the Telegram bot.
        Each value is a string (override) or None (= use desktop default).
        """
        config_file = settings.BASE_DIR / "user_settings.json"
        if not config_file.exists():
            return {"model": None, "profile": None, "lang": None}
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            tg = data.get("telegram") or {}
            def _norm(v):
                if isinstance(v, str) and v.strip():
                    return v.strip()
                return None
            return {
                "model": _norm(tg.get("model")),
                "profile": _norm(tg.get("profile")),
                "lang": _norm(tg.get("lang")),
            }
        except Exception:
            return {"model": None, "profile": None, "lang": None}

    def set_telegram_overrides(self, model: str | None, profile: str | None, lang: str | None) -> bool:
        """Persist Telegram bot overrides. Pass None or '' for any field to clear it."""
        config_file = settings.BASE_DIR / "user_settings.json"
        try:
            data = {}
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            tg = {}
            if model and model.strip():
                tg["model"] = model.strip()
            if profile and profile.strip():
                tg["profile"] = profile.strip()
            if lang and lang.strip():
                tg["lang"] = lang.strip()
            if tg:
                data["telegram"] = tg
            else:
                data.pop("telegram", None)
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Error saving Telegram overrides: {e}")
            return False

system_service = SystemService()
