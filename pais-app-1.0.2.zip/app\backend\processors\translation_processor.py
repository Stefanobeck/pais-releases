"""
Translation Processor per PAI Premium
Traduci testi e documenti usando il modello translategemma:4b.
Supporta traduzione diretta di file TXT, DOCX, PDF, SRT con Smart Chunking.
"""

import os
import asyncio
import logging
import json
import re
from pathlib import Path
from typing import Awaitable, Callable, Optional, Tuple, Dict, List

logger = logging.getLogger(__name__)

class TranslationProcessor:
    """
    Processa traduzioni di testo e documenti con supporto per Smart Chunking.
    """
    
    # Estensioni file supportate
    SUPPORTED_FORMATS = {'.txt', '.docx', '.pdf', '.srt'}

    def __init__(self):
        self._client = None
        self._load_config()

    @property
    def client(self):
        """Restituisce il client Ollama, inizializzandolo o aggiornandolo se necessario."""
        import ollama
        from backend_config.settings import settings
        
        target_host = settings.OLLAMA_HOST_URL.rstrip('/')
        
        if self._client is None:
            logger.info(f"🎯 Creating Ollama Client with Host: {target_host}")
            self._client = ollama.AsyncClient(host=target_host)
        else:
            current_host = str(self._client._client.base_url).rstrip('/')
            if current_host != target_host:
                logger.info(f"🔄 Updating Ollama Client Host: {current_host} -> {target_host}")
                self._client = ollama.AsyncClient(host=target_host)
        
        return self._client

    def _load_config(self):
        """Carica configurazione modello e prompt."""
        # Carica modello da models.json
        from backend_config.settings import settings
        self.model = getattr(settings, "TRANSLATION_MODEL", "translategemma:4b")
        self.num_ctx = getattr(settings, "TRANSLATION_MODEL_CTX", 131072)

        # Carica prompt (cerca in diverse posizioni possibili per compatibilità)
        root_dir = Path(__file__).parent.parent.parent.parent
        paths = [
            root_dir / "settings" / "translation_prompts.json",
            Path(__file__).parent.parent / "backend_config" / "translation_prompts.json"
        ]
        
        self.prompts = {
            'system_prompt': "You are a professional {source_lang} ({source_code}) to {target_lang} ({target_code}) translator.\nProduce only the {target_lang} translation.\n\n",
            'supported_languages': {}
        }

        for p in paths:
            if p.exists():
                try:
                    with open(p, 'r', encoding='utf-8') as f:
                        self.prompts = json.load(f)
                        logger.info(f"Loaded translation prompts from {p}")
                        break
                except Exception as e:
                    logger.error(f"Error loading translation prompts from {p}: {e}")

    def get_supported_languages(self) -> Dict:
        """Restituisce la mappa delle lingue supportate."""
        return self.prompts.get('supported_languages', {})

    def _build_prompt(self, text: str, source_lang: str, source_code: str, 
                      target_lang: str, target_code: str, is_srt: bool = False) -> str:
        """Costruisce il prompt per translategemma."""
        template = self.prompts.get('system_prompt', '')
        prompt = template.format(
            source_lang=source_lang,
            source_code=source_code,
            target_lang=target_lang,
            target_code=target_code
        )
        if is_srt:
            prompt += "IMPORTANT: This is an SRT subtitle file chunk. PRESERVE all timestamps (e.g. 00:00:00,000 --> 00:00:00,000) and numeric indices. Translate ONLY the subtitle text. DO NOT add any comments or extra text.\n\n"
        
        return prompt + text

    async def translate_text(
        self, 
        text: str, 
        source_lang: str, 
        source_code: str,
        target_lang: str, 
        target_code: str,
        is_srt: bool = False
    ) -> str:
        """Traduce un testo singolo o un chunk."""
        try:
            prompt = self._build_prompt(text, source_lang, source_code, target_lang, target_code, is_srt)
            
            response = await self.client.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                options={
                    "num_ctx": self.num_ctx,
                    "temperature": 0.3,
                    "num_predict": 4096  # Limitiamo l'output per singolo chunk per stabilità
                }
            )
            
            translated = response.get("message", {}).get("content", "").strip()
            return translated if translated else ""
            
        except Exception as e:
            logger.error(f"Translation error: {e}")
            return f"\n[Error translating chunk: {e}]\n"

    def _get_srt_chunks(self, text: str, chunk_size: int = 40) -> List[str]:
        """Divide un file SRT in chunk basati sul numero di blocchi di sottotitoli."""
        # Split per blocchi (doppio a capo è lo standard SRT, ma usiamo regex per robustezza)
        blocks = re.split(r'\n\s*\n', text.strip())
        chunks = []
        for i in range(0, len(blocks), chunk_size):
            chunks.append("\n\n".join(blocks[i:i + chunk_size]))
        return chunks

    def _get_text_chunks(self, text: str, max_chars: int = 3500) -> List[str]:
        """Divide un testo generico in chunk cercando di non spezzare i paragrafi."""
        if len(text) <= max_chars:
            return [text]
        
        chunks = []
        remaining_text = text
        while remaining_text:
            if len(remaining_text) <= max_chars:
                chunks.append(remaining_text)
                break
            
            # Cerca l'ultimo a capo utile entro il limite
            split_idx = remaining_text.rfind('\n', 0, max_chars)
            if split_idx == -1: # Se non c'è a capo, cerca un punto
                split_idx = remaining_text.rfind('. ', 0, max_chars)
            if split_idx == -1: # Fallback estremo
                split_idx = max_chars
                
            chunks.append(remaining_text[:split_idx].strip())
            remaining_text = remaining_text[split_idx:].strip()
            
        return chunks

    async def translate_document(
        self,
        file_path: str,
        source_lang: str,
        source_code: str,
        target_lang: str,
        target_code: str,
        stop_check: Optional[Callable[[], Awaitable[bool]]] = None
    ) -> Tuple[bool, str]:
        """Traduce un documento usando Smart Chunking per superare i limiti di output.

        stop_check: callback async opzionale che ritorna True se il processo deve
        essere abortito (es. client disconnesso). Verificato prima di ogni chunk.
        Se True, ritorna (False, 'ABORTED_BY_CLIENT').
        """
        ext = Path(file_path).suffix.lower()
        # Audit timing
        import time as _time
        _t_start = _time.monotonic()

        try:
            full_content = ""
            if ext in ['.txt', '.srt']:
                # Prova diverse codifiche comuni
                for enc in ['utf-8', 'latin-1', 'cp1252']:
                    try:
                        with open(file_path, 'r', encoding=enc) as f:
                            full_content = f.read()
                        break
                    except: continue
            elif ext == '.docx':
                from docx import Document
                doc = Document(file_path)
                full_content = '\n\n'.join([p.text for p in doc.paragraphs if p.text.strip()])
            elif ext == '.pdf':
                import pypdf
                reader = pypdf.PdfReader(file_path)
                full_content = '\n\n'.join([page.extract_text() or "" for page in reader.pages if (page.extract_text() or "").strip()])
            else:
                return False, f"Formato non supportato: {ext}"
            
            if not full_content:
                return False, "Documento vuoto o testo non estraibile."

            # SMART CHUNKING LOGIC
            chunks = []
            is_srt = (ext == '.srt')
            
            if is_srt:
                chunks = self._get_srt_chunks(full_content)
                logger.info(f"🎞️ SRT Chunking: {len(chunks)} parts created.")
            else:
                chunks = self._get_text_chunks(full_content)
                logger.info(f"📄 Text Chunking: {len(chunks)} parts created.")

            translated_parts = []
            for i, chunk in enumerate(chunks):
                # Cooperative cancellation: controlla se il client si è disconnesso
                # prima di iniziare il chunk successivo. Worst-case latency = 1 chunk.
                if stop_check is not None:
                    try:
                        if await stop_check():
                            logger.info(f"⏹️ Translation aborted by client at chunk {i+1}/{len(chunks)}")
                            return False, "ABORTED_BY_CLIENT"
                    except Exception as e:
                        logger.warning(f"stop_check raised {e}; continuing")
                logger.info(f"🔄 Translating chunk {i+1}/{len(chunks)}...")
                part = await self.translate_text(chunk, source_lang, source_code, target_lang, target_code, is_srt=is_srt)
                if part:
                    translated_parts.append(part)
                # Piccola pausa per non saturare il server Ollama
                await asyncio.sleep(0.1)

            final_translation = "\n\n".join(translated_parts)
            # Audit trail (privacy-safe: solo metadata)
            try:
                from services.audit_service import audit_logger, file_metadata
                audit_logger.log(
                    "utility", "file_processed",
                    processor="translate_ollama",
                    model="translategemma:4b",
                    source_lang_code=source_code,
                    target_lang_code=target_code,
                    chunks_count=len(chunks),
                    duration_ms=int((_time.monotonic() - _t_start) * 1000),
                    output_chars=len(final_translation),
                    success=True,
                    **{f"input_{k}": v for k, v in file_metadata(file_path).items()},
                )
            except Exception:
                pass
            return True, final_translation

        except Exception as e:
            logger.error(f"Document translation error: {e}")
            try:
                from services.audit_service import audit_logger, file_metadata
                audit_logger.log(
                    "utility", "file_processed",
                    processor="translate_ollama",
                    duration_ms=int((_time.monotonic() - _t_start) * 1000),
                    success=False,
                    error=str(e)[:200],
                    **{f"input_{k}": v for k, v in file_metadata(file_path).items()},
                )
            except Exception:
                pass
            return False, str(e)

    def get_output_dir(self) -> Path:
        """Restituisce la cartella TRANSLATION nella cartella output del progetto."""
        from backend_config.project_manager import project_manager
        output_dir = project_manager.get_path("output") / "TRANSLATION"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def save_as_txt(self, text: str, base_name: str, target_lang: str = "") -> str:
        """Salva la traduzione in formato .txt"""
        import time
        timestamp = time.strftime("%H%M%S")
        prefix = f"{target_lang}_" if target_lang else ""
        output_path = self.get_output_dir() / f"{prefix}{base_name}_{timestamp}.txt"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
        return str(output_path)

    def save_as_srt(self, text: str, base_name: str, target_lang: str = "") -> str:
        """Salva la traduzione in formato .srt"""
        import time
        timestamp = time.strftime("%H%M%S")
        prefix = f"{target_lang}_" if target_lang else ""
        output_path = self.get_output_dir() / f"{prefix}{base_name}_{timestamp}.srt"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
        return str(output_path)

    def save_as_docx(self, text: str, base_name: str, target_lang: str = "") -> str:
        """Salva la traduzione in formato .docx"""
        import time
        timestamp = time.strftime("%H%M%S")
        prefix = f"{target_lang}_" if target_lang else ""
        try:
            from docx import Document
            from docx.shared import Pt
            doc = Document()
            for para in text.split('\n\n'):
                if para.strip():
                    p = doc.add_paragraph(para)
                    for run in p.runs: run.font.size = Pt(11)
            output_path = self.get_output_dir() / f"{prefix}{base_name}_{timestamp}.docx"
            doc.save(str(output_path))
            return str(output_path)
        except:
            return self.save_as_txt(text, base_name, target_lang)
