"""Debug a single failing prompt with verbose logging."""
import asyncio, logging, sys, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

INPUT_XLSX = Path(__file__).resolve().parents[3] / "test_runs" / "manipulate_20260512_full" / "inputs" / "employees.xlsx"


async def main():
    # Enable INFO logging on manipulate_service
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    # Quieten other loggers
    for nm in ("httpx", "httpcore", "ollama"):
        logging.getLogger(nm).setLevel(logging.WARNING)

    from services.manipulate_service import ManipulateService
    svc = ManipulateService()

    session_id = f"debug-{uuid.uuid4().hex[:6]}"
    print(f"\n=== upload + memorize ===", flush=True)
    print(await svc.upload_file(str(INPUT_XLSX), INPUT_XLSX.name, session_id, mode="Export to Sheet"))
    print(await svc.memorize_files(session_id, mode="Export to Sheet"))

    print(f"\n=== DuckDB tables in session ===")
    print(list(svc.data_processor.dfs.keys()))

    prompt = "Somma Ore_Straordinario_Mese per mese"
    print(f"\n=== analyze: {prompt!r} ===", flush=True)
    async for ok, msg, files in svc.analyze(query=prompt, session_id=session_id, mode="Export to Sheet"):
        print(f"  ok={ok}  files={files}  msg[:120]={msg[:120]!r}")


if __name__ == "__main__":
    asyncio.run(main())
