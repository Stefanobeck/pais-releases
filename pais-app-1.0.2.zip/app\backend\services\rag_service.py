"""
RAG Service - Smart Retrieval-Augmented Generation per INTERROGATE
Gestisce:
- Smart File Reference Detection (F1, F2, nomi file)
- Context building con chunking per sorgente
- Filtri ChromaDB dinamici
- Metadata injection per awareness
"""
import os
import re
from typing import List, Dict, Optional, Tuple
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class RAGService:
    """
    Servizio per retrieval contestuale intelligente.
    """

    def __init__(self, chroma_collection, uploaded_files: List[Dict], lang: str = "it"):
        """
        Args:
            chroma_collection: Istanza ChromaDB collection
            uploaded_files: Lista file caricati [{name, path, ref, type}]
            lang: Lingua corrente (it, en, es, fr, de)
        """
        self.collection = chroma_collection
        self.uploaded_files = uploaded_files
        self.lang = lang

    def _detect_file_references(self, query: str) -> Optional[Dict]:
        """
        Rileva riferimenti espliciti a file nel messaggio utente.
        
        Supporta:
        - Riferimenti F1, F2, F3... (case insensitive)
        - Nomi file diretti (anche parziali, min 5 char)
        
        Returns:
            Filtro ChromaDB {"source": {"$in": [...]}} o None
        """
        if not self.uploaded_files:
            return None

        # 1. Cerca riferimenti F1, F2, F3...
        ref_matches = re.findall(r'\bF(\d+)\b', query.upper())
        
        if ref_matches:
            found_files = []
            for m in ref_matches:
                idx = int(m) - 1
                if 0 <= idx < len(self.uploaded_files):
                    found_files.append(self.uploaded_files[idx]['name'])
            
            if found_files:
                logger.info(f"🎯 Explicit file reference detected: {found_files}")
                return {"source": {"$in": found_files}}

        # 2. Cerca nomi file diretti (anche parziali)
        matched_by_name = []
        for f in self.uploaded_files:
            # Nome pulito (senza estensione, senza underscore, lowercase)
            clean_name = os.path.splitext(f['name'])[0].replace('_', ' ').lower()
            
            # Se il nome pulito è nel messaggio e è significativo (>5 char)
            if clean_name in query.lower() and len(clean_name) > 5:
                matched_by_name.append(f['name'])
        
        if matched_by_name:
            logger.info(f"🎯 Direct filename mention detected: {matched_by_name}")
            return {"source": {"$in": matched_by_name}}

        return None

    def _get_files_list_str(self) -> str:
        """
        Costruisce stringa elenco file per il modello.
        Formato: "F1: nome.pdf\nF2: dati.xlsx"
        """
        if not self.uploaded_files:
            return ""
        
        return "\n".join([
            f"- {f.get('ref', 'FILE')}: {f['name']}"
            for f in self.uploaded_files
        ])

    async def build_context(
        self,
        query: str,
        n_results: int = 12
    ) -> Tuple[str, str]:
        """
        Costruisci contesto RAG con Hybrid Search (BM25 + Vettoriale + RRF).

        Args:
            query: Messaggio utente
            n_results: Numero di chunk da recuperare (default: 12)

        Returns:
            (context_text, files_list_str)
            - context_text: Contesto RAG formattato con header per file
            - files_list_str: Elenco file per il modello
        """
        files_list_str = self._get_files_list_str()

        if not self.uploaded_files:
            return "", files_list_str

        try:
            # 1. Smart File Reference Detection
            explicit_filter = self._detect_file_references(query)
            target_sources = explicit_filter.get("source", {}).get("$in", None) if explicit_filter else None
            if target_sources is None:
                target_sources = [f['name'] for f in self.uploaded_files]

            # 2. Retrieval Ibrido: BM25 + Vettoriale
            bm25_results = await self._bm25_search(query, target_sources, top_k=n_results * 2)
            vector_results = await self._vector_search(query, target_sources, top_k=n_results * 2)

            logger.info(f"🔍 BM25: {len(bm25_results)} risultati | Vector: {len(vector_results)} risultati")

            # 3. Fusion con Reciprocal Rank Fusion (RRF)
            fused_results = self._reciprocal_rank_fusion(bm25_results, vector_results, top_k=n_results)

            if not fused_results:
                logger.info("No relevant chunks found after hybrid search")
                return "", files_list_str

            # 4. Raggruppa chunk per file sorgente
            chunks_by_source: Dict[str, List[str]] = {}

            for result in fused_results:
                source = result.get('metadata', {}).get('source', 'unknown')
                if source not in chunks_by_source:
                    chunks_by_source[source] = []
                chunks_by_source[source].append(result['text'])

            # 5. Costruisci contesto con header espliciti
            context_parts = []

            for source, chunks in chunks_by_source.items():
                # Trova ref (F1, F2...) per questo file
                ref_id = "FILE"
                for f in self.uploaded_files:
                    if f['name'] == source:
                        ref_id = f.get('ref', 'FILE')
                        break

                header = f"=== DOCUMENT CONTENT OF {ref_id} ({source}) ==="
                content = "\n".join(chunks)
                context_parts.append(f"{header}\n{content}\n")

            context_text = "\n".join(context_parts)
            logger.info(f"✅ Hybrid RAG context built: {len(chunks_by_source)} files, {len(fused_results)} chunks, {len(context_text)} chars")

            return context_text, files_list_str

        except Exception as e:
            logger.error(f"❌ Hybrid RAG Error: {e}")
            # Fallback al solo vector search se hybrid fallisce
            return await self._fallback_vector_search(query, n_results)

    async def _bm25_search(self, query: str, sources: List[str], top_k: int = 20) -> List[Dict]:
        """Cerca con BM25 keyword search."""
        try:
            # Accedi al BM25 manager dal collection
            if hasattr(self.collection, '_client') and hasattr(self.collection._client, 'bm25'):
                results = self.collection._client.bm25.search(query, top_k=top_k, source_filter=sources)
                logger.info(f"📝 BM25 search: {len(results)} results")
                return results
        except Exception as e:
            logger.warning(f"BM25 search failed: {e}")
        return []

    async def _vector_search(self, query: str, sources: List[str], top_k: int = 20) -> List[Dict]:
        """Cerca con similarità vettoriale (ChromaDB)."""
        try:
            query_emb = await self.collection._client.get_embedding(
                model=self.collection._embedding_model,
                texts=[query]
            )

            if not query_emb or len(query_emb) == 0:
                return []

            results = self.collection.query(
                query_embeddings=query_emb,
                n_results=top_k,
                where={"source": {"$in": sources}}
            )

            if not results.get('documents') or not results['documents'][0]:
                return []

            # Converti formato ChromaDB → formato unificato
            unified = []
            for i, doc_text in enumerate(results['documents'][0]):
                meta = results['metadatas'][0][i] if i < len(results['metadatas'][0]) else {}
                distance = results['distances'][0][i] if i < len(results['distances'][0]) else 0
                unified.append({
                    'text': doc_text,
                    'score': 1.0 / (1.0 + distance),  # Converti distanza in score
                    'metadata': meta
                })

            logger.info(f"🔵 Vector search: {len(unified)} results")
            return unified

        except Exception as e:
            logger.warning(f"Vector search failed: {e}")
            return []

    def _reciprocal_rank_fusion(
        self,
        bm25_results: List[Dict],
        vector_results: List[Dict],
        top_k: int = 12,
        k: int = 60
    ) -> List[Dict]:
        """
        Reciprocal Rank Fusion (RRF) per merge risultati BM25 + Vector.

        Formula: RRF(d) = Σ 1 / (k + rank_d)
        k = 60 è il valore standard raccomandato
        """
        # Mappa testo → (score RRF, result originale)
        rrf_scores: Dict[str, float] = {}
        result_map: Dict[str, Dict] = {}

        # BM25 scores
        for rank, result in enumerate(bm25_results):
            text = result['text']
            score = 1.0 / (k + rank + 1)
            rrf_scores[text] = rrf_scores.get(text, 0) + score
            result_map[text] = result

        # Vector scores
        for rank, result in enumerate(vector_results):
            text = result['text']
            score = 1.0 / (k + rank + 1)
            rrf_scores[text] = rrf_scores.get(text, 0) + score
            result_map[text] = result

        # Ordina per RRF score decrescente
        sorted_texts = sorted(rrf_scores.keys(), key=lambda t: rrf_scores[t], reverse=True)

        fused = []
        for text in sorted_texts[:top_k]:
            result = result_map[text].copy()
            result['rrf_score'] = rrf_scores[text]
            fused.append(result)

        logger.info(f"🔀 RRF fusion: {len(bm25_results)} BM25 + {len(vector_results)} Vector → {len(fused)} fused")
        return fused

    async def _fallback_vector_search(self, query: str, n_results: int = 12) -> Tuple[str, str]:
        """Fallback: solo vector search se hybrid fallisce."""
        try:
            files_list_str = self._get_files_list_str()
            target_sources = [f['name'] for f in self.uploaded_files]

            query_emb = await self.collection._client.get_embedding(
                model=self.collection._embedding_model,
                texts=[query]
            )

            if not query_emb:
                return "", files_list_str

            results = self.collection.query(
                query_embeddings=query_emb,
                n_results=n_results,
                where={"source": {"$in": target_sources}}
            )

            if not results.get('documents') or not results['documents'][0]:
                return "", files_list_str

            chunks_by_source: Dict[str, List[str]] = {}
            for i, doc_text in enumerate(results['documents'][0]):
                if i < len(results['metadatas'][0]):
                    source = results['metadatas'][0][i].get('source', 'unknown')
                    if source not in chunks_by_source:
                        chunks_by_source[source] = []
                    chunks_by_source[source].append(doc_text)

            context_parts = []
            for source, chunks in chunks_by_source.items():
                ref_id = "FILE"
                for f in self.uploaded_files:
                    if f['name'] == source:
                        ref_id = f.get('ref', 'FILE')
                        break
                header = f"=== DOCUMENT CONTENT OF {ref_id} ({source}) ==="
                context_parts.append(f"{header}\n{''.join(chunks)}\n")

            return "\n".join(context_parts), files_list_str

        except Exception as e:
            logger.error(f"❌ Fallback vector search also failed: {e}")
            return "", self._get_files_list_str()

    def set_language(self, lang: str):
        """Cambia lingua per localizzazione."""
        self.lang = lang
