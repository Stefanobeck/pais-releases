"""Deterministic compare-changes builder for Compare Mode.

Turns two plain-text document versions into a STRUCTURED list of changes
(modified / added / removed / moved) with the governing article number for
each — computed purely with difflib, NO LLM. The model proved unreliable at
re-deriving article numbers and at not omitting changes; this module is the
deterministic ground truth, rendered as a "values changed" table + a
4-section report.

Reuses the same line-alignment / word-diff primitives as the redline
(`services.redline_docx`) so the output stays in lock-step with
`build_textual_redline` / `build_redline_docx`. Article attribution is exact:
every changed line is mapped to the nearest preceding header in ITS OWN
document, so renumbering between versions never shifts the attribution.
"""
from __future__ import annotations

import re
import difflib
from typing import Optional

from services.redline_docx import (
    _split_into_blocks,
    _tokenize,
    _MOVED_SIMILARITY_THRESHOLD,
    _BOTH_DEMOTE_THRESHOLD,
)


# Header parser: "Articolo 3 — Durata", "Art. 5 - Canone", "ALLEGATO A — …".
# Anchored at line start; body sentences (which never start with these tokens)
# are left untouched. Captures (kind, number/letter, title).
_HEADER_RE = re.compile(
    r'^\s*(articolo|art\.?|allegato|annex|appendice|sezione|capo|titolo|clausola)\b'
    r'\s*([0-9]+|[A-Z])?\s*[—–\-:.]*\s*(.*)$',
    re.IGNORECASE,
)


def _parse_header(line: str) -> Optional[dict]:
    """Return {kind, num, title, raw} if the line looks like an article/section
    header, else None. Headers are short, single-line, and start with a known
    structural keyword."""
    t = (line or '').strip()
    if not t or len(t) > 120:
        return None
    m = _HEADER_RE.match(t)
    if not m:
        return None
    return {"kind": m.group(1), "num": m.group(2), "title": (m.group(3) or "").strip(), "raw": t}


def _article_label(hdr: Optional[dict]) -> str:
    """Short citation label, e.g. 'Art. 3' / 'Allegato A' / '' (preamble)."""
    if not hdr:
        return ""
    kind = hdr["kind"].lower()
    base = "Art." if kind.startswith("art") else hdr["kind"].capitalize()
    return f"{base} {hdr['num']}" if hdr["num"] else base


def _article_full(hdr: Optional[dict]) -> str:
    """Label + title, e.g. 'Art. 3 — Durata e rinnovo'."""
    if not hdr:
        return "Intestazione / Premessa"
    lbl = _article_label(hdr)
    return f"{lbl} — {hdr['title']}" if hdr["title"] else lbl


def _line_article_map(blocks: list[str]) -> list[Optional[dict]]:
    """For each line index, the most recent header at/above it (or None)."""
    out: list[Optional[dict]] = []
    current: Optional[dict] = None
    for line in blocks:
        h = _parse_header(line)
        if h:
            current = h
        out.append(current)
    return out


def _word_similarity(line_a: str, line_b: str) -> float:
    """Token similarity on WORDS only — whitespace tokens excluded, so two short
    sentences don't look similar merely because they share spaces. Used to decide
    whether an aligned pair is a real modification or two distinct clauses."""
    wa = [t for t in _tokenize(line_a) if t.strip()]
    wb = [t for t in _tokenize(line_b) if t.strip()]
    if not wa and not wb:
        return 1.0
    return difflib.SequenceMatcher(None, wa, wb, autojunk=False).ratio()


def _word_change_pairs(line_a: str, line_b: str) -> list[tuple[str, str]]:
    """Word-level (from → to) pairs between two lines. Adjacent changed runs
    separated only by unchanged whitespace are merged into one pair, so
    '36 (trentasei)' → '48 (quarantotto)' stays a single readable row."""
    ta, tb = _tokenize(line_a), _tokenize(line_b)
    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    raw: list[tuple[str, str, bool]] = []  # (from, to, is_equal_ws)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        seg_a, seg_b = "".join(ta[i1:i2]), "".join(tb[j1:j2])
        if tag == "equal":
            raw.append((seg_a, seg_b, seg_a.strip() == ""))
        else:
            raw.append((seg_a, seg_b, False))
    # Merge changed runs bridged by whitespace-only equal segments.
    pairs: list[tuple[str, str]] = []
    buf_a = buf_b = ""
    open_run = False
    for frm, to, is_eq_ws in raw:
        if frm == to and not is_eq_ws:  # genuine unchanged content → close run
            if open_run:
                pairs.append((buf_a, buf_b)); buf_a = buf_b = ""; open_run = False
            continue
        if frm == to and is_eq_ws:  # whitespace bridge: keep run open, carry ws
            if open_run:
                buf_a += frm; buf_b += to
            continue
        # changed segment
        buf_a += frm; buf_b += to; open_run = True
    if open_run:
        pairs.append((buf_a, buf_b))
    # Normalize whitespace and drop empties
    cleaned = []
    for frm, to in pairs:
        f, t = frm.strip(), to.strip()
        if f or t:
            cleaned.append((f, t))
    return cleaned


def build_compare_records(text_a: str, text_b: str) -> dict:
    """Return a deterministic structured diff:
    {
      'modified': [{art, art_f1, art_f2, pairs:[(from,to)], is_header, text_a, text_b}],
      'added':    [{art, text, is_header}],
      'removed':  [{art, text, is_header}],
      'moved':    [{art_f1, art_f2, pairs, text_a, text_b}],
      'renumbered': [{art_f1, art_f2, title}],   # header-only number change
    }
    Article labels come from each line's OWN document header map, so version
    renumbering never misattributes a change.
    """
    blocks_a = _split_into_blocks(text_a)
    blocks_b = _split_into_blocks(text_b)
    map_a = _line_article_map(blocks_a)
    map_b = _line_article_map(blocks_b)

    def blank(s: str) -> bool:
        return not (s or "").strip()

    modified: list[dict] = []
    added: list[dict] = []
    removed: list[dict] = []
    renumbered: list[dict] = []

    def add_removed(i: int):
        removed.append({"art": _article_full(map_a[i]), "text": blocks_a[i].strip(),
                        "is_header": bool(_parse_header(blocks_a[i]))})

    def add_added(j: int):
        added.append({"art": _article_full(map_b[j]), "text": blocks_b[j].strip(),
                      "is_header": bool(_parse_header(blocks_b[j]))})

    def add_modified(i: int, j: int):
        la, lb = blocks_a[i].strip(), blocks_b[j].strip()
        ha, hb = _parse_header(blocks_a[i]), _parse_header(blocks_b[j])
        pairs = _word_change_pairs(la, lb)
        if not pairs:
            return
        # Header line whose ONLY change is the number → renumber (a Move), not a
        # substantive modification — keep it out of the values table.
        if ha and hb and ha["title"].lower() == hb["title"].lower() and ha["num"] != hb["num"]:
            renumbered.append({"art_f1": _article_label(ha), "art_f2": _article_label(hb),
                               "title": hb["title"]})
            return
        modified.append({
            "art": _article_full(ha or map_a[i]),
            "art_f1": _article_full(map_a[i]), "art_f2": _article_full(map_b[j]),
            "pairs": pairs, "is_header": bool(ha or hb),
            "text_a": la, "text_b": lb,
        })

    sm = difflib.SequenceMatcher(a=blocks_a, b=blocks_b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        if tag == "delete":
            for i in range(i1, i2):
                if not blank(blocks_a[i]):
                    add_removed(i)
        elif tag == "insert":
            for j in range(j1, j2):
                if not blank(blocks_b[j]):
                    add_added(j)
        elif tag == "replace":
            na, nb = i2 - i1, j2 - j1
            common = min(na, nb)
            for k in range(common):
                i, j = i1 + k, j1 + k
                if blank(blocks_a[i]) and blank(blocks_b[j]):
                    continue
                if blank(blocks_a[i]):
                    add_added(j); continue
                if blank(blocks_b[j]):
                    add_removed(i); continue
                sim = _word_similarity(blocks_a[i], blocks_b[j])
                if sim < _BOTH_DEMOTE_THRESHOLD:
                    add_removed(i); add_added(j)
                else:
                    add_modified(i, j)
            for k in range(common, na):
                if not blank(blocks_a[i1 + k]):
                    add_removed(i1 + k)
            for k in range(common, nb):
                if not blank(blocks_b[j1 + k]):
                    add_added(j1 + k)

    # Moved: a removed clause whose content reappears (near-identically) as an
    # added clause elsewhere → reclassify the pair as Moved.
    moved: list[dict] = []
    used_add: set[int] = set()
    for r in removed:
        best_idx, best_ratio = None, 0.0
        for idx, a in enumerate(added):
            if idx in used_add:
                continue
            ratio = difflib.SequenceMatcher(None, r["text"], a["text"], autojunk=False).ratio()
            if ratio >= _MOVED_SIMILARITY_THRESHOLD and ratio > best_ratio:
                best_idx, best_ratio = idx, ratio
        if best_idx is not None:
            a = added[best_idx]
            used_add.add(best_idx)
            r["_moved"] = True
            moved.append({
                "art_f1": r["art"], "art_f2": a["art"],
                "pairs": _word_change_pairs(r["text"], a["text"]) if r["text"] != a["text"] else [],
                "text_a": r["text"], "text_b": a["text"],
            })
    removed = [r for r in removed if not r.get("_moved")]
    added = [a for i, a in enumerate(added) if i not in used_add]

    return {"modified": modified, "added": added, "removed": removed,
            "moved": moved, "renumbered": renumbered}


# A "value" change carries a digit, percentage, currency or amount — the rows a
# "values changed" table is about (durate, importi, %, scadenze, massimali, IBAN).
# Pure-prose word swaps from a rewritten clause are kept out of the table (they
# stay in the Modifiche section) so the table reads clean.
_VALUE_RE = re.compile(r'[0-9%€]')


def render_values_table_markdown(records: dict) -> str:
    """Markdown 'values changed' table — one row per atomic from→to change.
    Header lines and pure-prose (no value) changes are excluded."""
    rows = ["| Articolo | Da (F1) | A (F2) |", "| --- | --- | --- |"]

    def emit(art: str, frm: str, to: str):
        if not (_VALUE_RE.search(frm) or _VALUE_RE.search(to)):
            return
        rows.append(f"| {art} | {frm or '—'} | {to or '—'} |")

    for m in records["modified"]:
        if m["is_header"]:
            continue
        art = m["art_f2"] if m["art_f2"] != m["art_f1"] else m["art_f1"]
        for frm, to in m["pairs"]:
            emit(art, frm, to)
    for mv in records["moved"]:
        for frm, to in mv["pairs"]:
            emit(f"{mv['art_f2']} (spostato da {mv['art_f1']})", frm, to)
    return "\n".join(rows)


def render_report_markdown(records: dict, f1_name: str = "F1", f2_name: str = "F2") -> str:
    """Full deterministic 4-section report + the values table."""
    out: list[str] = []
    out.append("# Confronto documenti — report deterministico")
    out.append(f"F1 = {f1_name}  ·  F2 = {f2_name}")
    out.append("")
    out.append("## 📊 Valori modificati (da → a)")
    out.append(render_values_table_markdown(records))
    out.append("")

    # Header lines are structural labels, not content: a header that "changed"
    # means the article was renumbered (→ Moved) or its topic swapped (→ the body
    # is already in Removed + Added). Excluding them removes redundant noise.
    mods = [m for m in records["modified"] if not m["is_header"]]
    adds = [a for a in records["added"] if not a["is_header"]]
    rems = [r for r in records["removed"] if not r["is_header"]]

    out.append("## ✏️ Modifiche")
    if mods:
        for m in mods:
            changes = "; ".join(f'"{f}" → "{t}"' for f, t in m["pairs"])
            out.append(f"- **{m['art']}**: {changes}")
    else:
        out.append("_Nessuna._")
    out.append("")

    out.append("## ➕ Aggiunte (in F2, non in F1)")
    if adds:
        for a in adds:
            out.append(f"- **{a['art']}**: {a['text']}")
    else:
        out.append("_Nessuna._")
    out.append("")

    out.append("## ➖ Rimozioni (in F1, non in F2)")
    if rems:
        for r in rems:
            out.append(f"- **{r['art']}**: {r['text']}")
    else:
        out.append("_Nessuna._")
    out.append("")

    out.append("## 🔀 Spostamenti")
    if records["moved"] or records["renumbered"]:
        for mv in records["moved"]:
            extra = ""
            if mv["pairs"]:
                extra = " — " + "; ".join(f'"{f}" → "{t}"' for f, t in mv["pairs"])
            out.append(f"- {mv['art_f1']} → {mv['art_f2']}{extra}")
        for rn in records["renumbered"]:
            out.append(f"- {rn['art_f1']} → {rn['art_f2']} ({rn['title']}) — sola rinumerazione")
    else:
        out.append("_Nessuno._")
    return "\n".join(out)


def export_compare_xlsx(records: dict, output_path) -> str:
    """Write the deterministic comparison to a 4-sheet .xlsx:
    'Valori modificati' | 'Aggiunte' | 'Rimozioni' | 'Spostamenti'.
    Returns the path written. Uses pandas/xlsxwriter (already deps)."""
    import pandas as pd
    from pathlib import Path

    val_rows = []
    for m in records["modified"]:
        if m["is_header"]:
            continue
        art = m["art_f2"] if m["art_f2"] != m["art_f1"] else m["art_f1"]
        for frm, to in m["pairs"]:
            if _VALUE_RE.search(frm) or _VALUE_RE.search(to):
                val_rows.append({"Articolo": art, "Da (F1)": frm or "—", "A (F2)": to or "—"})
    for mv in records["moved"]:
        for frm, to in mv["pairs"]:
            if _VALUE_RE.search(frm) or _VALUE_RE.search(to):
                val_rows.append({"Articolo": f"{mv['art_f2']} (spostato da {mv['art_f1']})",
                                 "Da (F1)": frm or "—", "A (F2)": to or "—"})

    add_rows = [{"Articolo": a["art"], "Testo aggiunto (F2)": a["text"]}
                for a in records["added"] if not a["is_header"]]
    rem_rows = [{"Articolo": r["art"], "Testo rimosso (F1)": r["text"]}
                for r in records["removed"] if not r["is_header"]]

    mov_rows = []
    for mv in records["moved"]:
        note = "; ".join(f'"{f}" → "{t}"' for f, t in mv["pairs"]) if mv["pairs"] else "(testo invariato)"
        mov_rows.append({"Da (F1)": mv["art_f1"], "A (F2)": mv["art_f2"], "Variazioni": note})
    for rn in records["renumbered"]:
        mov_rows.append({"Da (F1)": rn["art_f1"], "A (F2)": rn["art_f2"],
                         "Variazioni": f"sola rinumerazione ({rn['title']})"})

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(str(output_path), engine="xlsxwriter") as writer:
        def _sheet(name: str, rows: list, cols: list):
            df = pd.DataFrame(rows, columns=cols) if rows else pd.DataFrame(columns=cols)
            df.to_excel(writer, sheet_name=name[:31], index=False)

        _sheet("Valori modificati", val_rows, ["Articolo", "Da (F1)", "A (F2)"])
        _sheet("Aggiunte", add_rows, ["Articolo", "Testo aggiunto (F2)"])
        _sheet("Rimozioni", rem_rows, ["Articolo", "Testo rimosso (F1)"])
        _sheet("Spostamenti", mov_rows, ["Da (F1)", "A (F2)", "Variazioni"])
    return str(output_path)
