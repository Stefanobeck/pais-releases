"""Fetch the PII NER ONNX model into the app directory.

Run once during dev setup or as part of the installer build pipeline:
    python -m scripts.fetch_pii_model

Idempotent: skips download if marker file already exists.

The downloaded files (~1.2GB) live in `pai-premium/backend/models/onnx_pii/<repo>/`
and are intended to be SHIPPED INSIDE the commercial installer (license: MIT,
see pai-premium/NOTICE.md for full attribution).
"""
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

REPO_ID = "onnx-community/multilang-pii-ner-ONNX"
# Commit hash pinato per evitare supply-chain attack: se l'autore HF push una
# versione malevola, l'app continua a scaricare la revisione validata.
# Aggiornare manualmente dopo aver verificato un nuovo commit upstream.
# Override via env per test: PAI_PII_MODEL_REVISION=<hash>
MODEL_REVISION = os.environ.get(
    "PAI_PII_MODEL_REVISION",
    "730c579658f8258600cc8a069b2fad1615289201",
)
ONNX_FILE = os.environ.get("PAI_ONNX_MODEL_FILE", "onnx/model.onnx")

REQUIRED = ["config.json", ONNX_FILE]
OPTIONAL = [
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "sentencepiece.bpe.model",
    "spiece.model",
    "vocab.txt",
]


def fetch(force: bool = False) -> Path:
    backend_dir = Path(__file__).resolve().parent.parent
    repo_short = REPO_ID.split("/")[-1]
    target = backend_dir / "models" / "onnx_pii" / repo_short
    marker = target / ".install_complete"

    if marker.exists() and not force:
        print(f"✅ Already installed at {target}")
        return target

    target.mkdir(parents=True, exist_ok=True)
    if marker.exists():
        marker.unlink()

    from huggingface_hub import hf_hub_download

    print(f"⬇️  Downloading {REPO_ID} (variant: {ONNX_FILE}) → {target}")
    for fname in REQUIRED:
        print(f"  · {fname}")
        hf_hub_download(repo_id=REPO_ID, filename=fname, revision=MODEL_REVISION, local_dir=str(target))

    for fname in OPTIONAL:
        try:
            print(f"  · {fname}")
            hf_hub_download(repo_id=REPO_ID, filename=fname, revision=MODEL_REVISION, local_dir=str(target))
        except Exception as e:
            print(f"    (skipped: {e.__class__.__name__})")

    marker.write_text(f"{REPO_ID}\n{ONNX_FILE}\n", encoding="utf-8")
    print(f"✅ Installed at {target}")
    return target


if __name__ == "__main__":
    force = "--force" in sys.argv
    try:
        fetch(force=force)
    except KeyboardInterrupt:
        print("\n⏹️  Interrupted")
        sys.exit(130)
    except Exception as e:
        print(f"❌ Failed: {e}")
        sys.exit(1)
