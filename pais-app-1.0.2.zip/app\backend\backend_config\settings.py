"""
PAI Premium Backend - Configuration Settings
Configurazione completa per modulo INTERROGATE con RAG.
"""
import os
import json as _json_for_data_dir
from pathlib import Path
from pydantic_settings import BaseSettings
from typing import List, Optional

# matplotlib in modalità HEADLESS (backend 'Agg') — DEVE essere impostato prima
# di qualunque import di matplotlib/seaborn. Senza, su Windows matplotlib sceglie
# TkAgg e crea oggetti Tk (PhotoImage, Variable). Usato dentro i worker thread di
# uvicorn (es. grafici MANIPULATE / "Add Style") va in conflitto col Tk dello
# splash sul main thread → "main thread is not in main loop" → Tcl_AsyncDelete →
# crash dell'intero processo. settings.py è importato all'avvio, prima che charter
# importi matplotlib (lazy), quindi questo è il punto giusto. setdefault: rispetta
# un override esplicito.
os.environ.setdefault("MPLBACKEND", "Agg")

# Auto-update: URL del manifest di rilascio (default che VIAGGIA con l'app, così
# il check parte da solo sul PC del cliente). update_service valida HTTPS + host
# GitHub e rifiuta il download senza sha256. setdefault: un override esplicito
# (dev/test via env) ha la precedenza.
os.environ.setdefault(
    "PAIS_UPDATE_MANIFEST_URL",
    "https://raw.githubusercontent.com/stefanobeck/pais-releases/main/latest.json",
)


def _bundle_playwright_browsers() -> None:
    """Se l'app è distribuita con Chromium bundlato (build portable / installer),
    punta Playwright alla cartella interna `backend/bin/ms-playwright` invece
    della cache per-utente %LOCALAPPDATA%\\ms-playwright — assente su PC ex-novo,
    causa per cui l'export PDF falliva e cadeva in silenzio su DOCX (bug v1.0.1).

    In sviluppo la cartella bundle non esiste → Playwright usa la sua cache
    standard e nulla cambia. `setdefault`: un override esplicito ha la precedenza.
    Vale per TUTTI gli usi di Chromium (export PDF, CONVERT DOCX→PDF, LaTeX→PNG,
    Mermaid→SVG)."""
    try:
        bundled = Path(__file__).resolve().parent.parent / "bin" / "ms-playwright"
        if bundled.is_dir():
            os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(bundled))
    except Exception:
        pass


_bundle_playwright_browsers()


def _read_app_version() -> str:
    """Versione app da SORGENTE UNICA: backend/VERSION — lo stesso file letto da
    installer.iss a compile-time, così APP_VERSION e la versione del setup.exe
    non possono divergere. Fallback a 1.0.1 se il file manca/illeggibile."""
    try:
        v = (Path(__file__).parent.parent / "VERSION").read_text(encoding="utf-8").strip()
        return v or "1.0.1"
    except Exception:
        return "1.0.1"


_APP_VERSION = _read_app_version()


def _resolve_user_data_dir() -> Path:
    """Risolve la cartella radice dei dati utente (progetti, upload, sessioni).

    Priorita':
      1. Env var PAIS_DATA_DIR (settata dall'installer per install custom-dir,
         o dall'utente manualmente)
      2. File ~/.pais/config.json -> chiave "data_dir" (persistito da UI o
         dall'installer come fallback)
      3. Default: ~/Documents/PAI_Files (path tradizionale, Windows-friendly,
         sempre scrivibile senza UAC perche' sotto USERPROFILE)

    Il path scelto viene comunque validato a livello applicativo (esistenza
    + scrittura) da project_manager.set_data_dir() prima di usarlo. Qui
    restituiamo solo l'intenzione: la creazione effettiva avviene dopo.
    """
    # 1. Env var (priorita' massima — usato per test, CI, install custom dir)
    env_dir = os.environ.get("PAIS_DATA_DIR", "").strip()
    if env_dir:
        return Path(env_dir).expanduser()

    # 2. Config file in ~/.pais/config.json (scritto da installer o UI)
    config_path = Path.home() / ".pais" / "config.json"
    try:
        if config_path.exists():
            cfg = _json_for_data_dir.loads(config_path.read_text(encoding="utf-8"))
            cfg_dir = (cfg.get("data_dir") or "").strip()
            if cfg_dir:
                return Path(cfg_dir).expanduser()
    except Exception:
        # Config file corrotto: fallback al default invece di crashare
        pass

    # 3. Default: Documents/PAI_Files (storico, sempre safe)
    return Path.home() / "Documents" / "PAI_Files"


def _pais_config_path() -> Path:
    """~/.pais/config.json — file di preferenze utente (data_dir, lang, ...)."""
    return Path.home() / ".pais" / "config.json"


def get_persisted_language() -> Optional[str]:
    """Lingua scelta dall'utente e persistita in ~/.pais/config.json (chiave
    'lang'). Ritorna il codice lingua (es. 'en') o None se mai impostata /
    file assente / corrotto. NON valida contro le lingue disponibili (lo fa
    il chiamante)."""
    try:
        p = _pais_config_path()
        if p.exists():
            cfg = _json_for_data_dir.loads(p.read_text(encoding="utf-8"))
            lang = (cfg.get("lang") or "").strip().lower()
            return lang or None
    except Exception:
        # Config corrotto/illeggibile: nessuna preferenza, non crashare.
        pass
    return None


def set_persisted_language(lang: str) -> None:
    """Persiste la lingua scelta in ~/.pais/config.json preservando le altre
    chiavi (es. data_dir). Best-effort: errori ignorati (la scelta resta
    comunque attiva in memoria per la sessione corrente)."""
    try:
        p = _pais_config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        cfg = {}
        if p.exists():
            try:
                cfg = _json_for_data_dir.loads(p.read_text(encoding="utf-8"))
            except Exception:
                cfg = {}
        cfg["lang"] = (lang or "").strip().lower()
        p.write_text(
            _json_for_data_dir.dumps(cfg, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # App Info
    APP_NAME: str = "PAIS - Private Artificial Intelligence Suite"
    APP_VERSION: str = _APP_VERSION
    DEBUG: bool = True

    # Server
    HOST: str = "127.0.0.1"
    PORT: int = 8000

    # Ollama Configuration
    OLLAMA_HOST_URL: str = "http://127.0.0.1:11435"  # ← PORTA ISOLATA PAIS
    OLLAMA_BIN_PATH: Path = Path(__file__).parent.parent / "bin" / "ollama.exe"
    OLLAMA_MODELS_DIR: Path = Path(__file__).parent.parent / "models"

    # Models — defaults allineati a backend_config/models.json (single source of truth).
    # Se models.json non si carica, l'app userà questi default invece di morire.
    EMBEDDING_MODEL: str = "qwen3-embedding:0.6b"
    EMBEDDING_CTX: int = 8192
    VISION_MODEL: str = "gemma4:e4b"
    OCR_MODEL: str = "glm-ocr:latest"
    VIDEO_MODEL: str = "gemma4:e4b"
    CHAT_MODEL: str = "gemma4:e4b"
    CHAT_PROFILE: str = "default"
    MANIPULATE_MODEL: str = "qwen3-coder:30b"
    TRANSLATION_MODEL: str = "translategemma:4b"
    ENGINEERING_MODEL: str = "qwen3-coder:30b"
    GRAPHICS_MODEL: str = "qwen3-coder:30b"
    ANALYZE_MODEL: str = "gemma4:e4b"
    SUGGESTION_MODEL: str = "qwen3-coder:30b"

    # Context Sizes (tokens) — tetti semantici per modulo.
    # Sono il LIMITE MASSIMO che il modulo puo' chiedere: il dynamic ctx
    # budget poi riduce in base al peso del prompt corrente (vedi
    # processors/context_budget.py). Anche se il modello supporta 256K, il
    # modulo cappa qui per non sprecare VRAM/latenza su prompts che non
    # ne avrebbero bisogno.
    VISION_CTX: int = 32768       # immagini + vision RAG
    VIDEO_CTX: int = 32768        # frame video
    CHAT_CTX: int = 131072        # chat conversazionale + RAG documenti
    MANIPULATE_CTX: int = 65536   # SQL generation: schema + tech RAG + retry ~5-20K, 65K margine
    TRANSLATION_CTX: int = 131072 # documenti lunghi da tradurre
    SUGGESTION_CTX: int = 16384   # JSON brevi per smart suggestions

    # Database Paths — radice dei dati utente.
    # Override possibile via env var PAIS_DATA_DIR o ~/.pais/config.json
    # (vedi _resolve_user_data_dir sopra). Default: ~/Documents/PAI_Files
    BASE_DIR: Path = _resolve_user_data_dir()

    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "tauri://localhost",
        "http://tauri.localhost",
        "*"  # Allow all for development
    ]

    # Upload
    MAX_UPLOAD_SIZE: int = 100 * 1024 * 1024  # 100MB
    UPLOAD_DIR: Path = Path(__file__).parent / "uploads"

    class Config:
        env_file = ".env"
        case_sensitive = False


# Create settings instance
settings = Settings()

# Load models from models.json to ensure it acts as the single source of truth
try:
    import json
    models_path = Path(__file__).parent / "models.json"
    if models_path.exists():
        with open(models_path, 'r', encoding='utf-8') as f:
            _models = json.load(f)
            
            # Map models.json fields to settings attributes
            if "embedding_model" in _models: settings.EMBEDDING_MODEL = _models["embedding_model"]
            if "embedding_model_ctx" in _models: settings.EMBEDDING_CTX = _models["embedding_model_ctx"]
            if "vision_model" in _models: settings.VISION_MODEL = _models["vision_model"]
            if "ocr_model" in _models: settings.OCR_MODEL = _models["ocr_model"]
            if "video_model" in _models: settings.VIDEO_MODEL = _models["video_model"]
            if "synthesis_model" in _models: settings.CHAT_MODEL = _models["synthesis_model"]
            if "manipulate_model" in _models: settings.MANIPULATE_MODEL = _models["manipulate_model"]
            if "translation_model" in _models: settings.TRANSLATION_MODEL = _models["translation_model"]
            if "engineering_model" in _models: settings.ENGINEERING_MODEL = _models["engineering_model"]
            if "graphics_model" in _models: settings.GRAPHICS_MODEL = _models["graphics_model"]
            if "analyze_model" in _models: settings.ANALYZE_MODEL = _models["analyze_model"]
            if "smart_suggestion_model" in _models: settings.SUGGESTION_MODEL = _models["smart_suggestion_model"]
            
            # Map contexts
            if "vision_model_ctx" in _models: settings.VISION_CTX = _models["vision_model_ctx"]
            if "video_model_ctx" in _models: settings.VIDEO_CTX = _models["video_model_ctx"]
            if "synthesis_model_ctx" in _models: settings.CHAT_CTX = _models["synthesis_model_ctx"]
            if "manipulate_model_ctx" in _models: settings.MANIPULATE_CTX = _models["manipulate_model_ctx"]
            if "translation_model_ctx" in _models: settings.TRANSLATION_CTX = _models["translation_model_ctx"]
            if "smart_suggestion_model_ctx" in _models: settings.SUGGESTION_CTX = _models["smart_suggestion_model_ctx"]
except Exception as e:
    import logging
    logging.error(f"Warning: Could not load models.json - {e}")

# Ensure directories exist
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
settings.BASE_DIR.mkdir(parents=True, exist_ok=True)

# Export BASE_DIR for direct import
BASE_DIR = settings.BASE_DIR
