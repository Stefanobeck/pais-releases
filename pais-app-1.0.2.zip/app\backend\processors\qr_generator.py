"""QR Code Generator — URL, vCard biglietto da visita, WiFi guest.

Output: PNG ad alta risoluzione, già pronto per stampa o invio.
Tutto pure-Python (qrcode + Pillow), zero servizi esterni.
"""
import logging
from pathlib import Path
from typing import Optional, Tuple

import qrcode
from qrcode.image.pil import PilImage
from PIL import Image

logger = logging.getLogger(__name__)


def _escape_vcard_field(s: str) -> str:
    """Escape per vCard 3.0: backslash, virgola, semicolon, newline."""
    if s is None:
        return ""
    return (s.replace("\\", "\\\\")
             .replace(",", "\\,")
             .replace(";", "\\;")
             .replace("\n", "\\n"))


def build_vcard(
    first_name: str = "",
    last_name: str = "",
    organization: str = "",
    title: str = "",
    phone: str = "",
    email: str = "",
    website: str = "",
    address: str = "",
) -> str:
    """Costruisce stringa vCard 3.0 (formato standard MECARD-compatibile)."""
    fn = _escape_vcard_field(f"{first_name} {last_name}".strip())
    n  = f"{_escape_vcard_field(last_name)};{_escape_vcard_field(first_name)};;;"
    lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        f"FN:{fn}",
        f"N:{n}",
    ]
    if organization:
        lines.append(f"ORG:{_escape_vcard_field(organization)}")
    if title:
        lines.append(f"TITLE:{_escape_vcard_field(title)}")
    if phone:
        lines.append(f"TEL;TYPE=CELL:{_escape_vcard_field(phone)}")
    if email:
        lines.append(f"EMAIL:{_escape_vcard_field(email)}")
    if website:
        lines.append(f"URL:{_escape_vcard_field(website)}")
    if address:
        lines.append(f"ADR;TYPE=WORK:;;{_escape_vcard_field(address)};;;;")
    lines.append("END:VCARD")
    return "\n".join(lines)


def build_wifi_payload(ssid: str, password: str = "", security: str = "WPA", hidden: bool = False) -> str:
    """Costruisce payload WiFi standard:  WIFI:T:<auth>;S:<ssid>;P:<pwd>;H:<hidden>;;

    `security`: 'WPA' (WPA/WPA2/WPA3), 'WEP', 'nopass' (rete aperta).
    """
    sec_map = {"WPA": "WPA", "WEP": "WEP", "nopass": "nopass", "none": "nopass"}
    sec = sec_map.get(security, "WPA")
    # Escape per WiFi: backslash, semicolon, virgola, doppio apice, due punti
    def esc(s: str) -> str:
        if s is None:
            return ""
        return (s.replace("\\", "\\\\")
                 .replace(";", "\\;")
                 .replace(",", "\\,")
                 .replace('"', '\\"')
                 .replace(":", "\\:"))
    parts = [f"S:{esc(ssid)}"]
    if sec != "nopass":
        parts.append(f"T:{sec}")
        if password:
            parts.append(f"P:{esc(password)}")
    else:
        parts.append("T:nopass")
    if hidden:
        parts.append("H:true")
    return "WIFI:" + ";".join(parts) + ";;"


def generate_qr_image(
    payload: str,
    output_path: Path,
    size: int = 1024,
    border: int = 4,
    fg_color: str = "black",
    bg_color: str = "white",
) -> None:
    """Genera un PNG QR code dal payload testuale.

    - `size`: lato del PNG in px (default 1024 = stampabile A6).
    - `border`: quiet zone in moduli QR (4 = standard, sotto compromette la lettura).
    - error correction: ERROR_CORRECT_M (15%) — bilancia densità e robustezza.
    """
    if not payload:
        raise ValueError("QR payload cannot be empty")
    qr = qrcode.QRCode(
        version=None,            # auto-fit alla payload
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=border,
    )
    qr.add_data(payload)
    qr.make(fit=True)
    img = qr.make_image(fill_color=fg_color, back_color=bg_color, image_factory=PilImage)
    pil_img: Image.Image = img.get_image() if hasattr(img, "get_image") else img._img  # robusto a versioni
    # Resize al size richiesto (nearest-neighbor per mantenere bordi netti del QR)
    pil_img = pil_img.resize((size, size), Image.NEAREST)
    pil_img.save(str(output_path), "PNG", optimize=True)


def generate_qr(
    qr_type: str,
    payload_data: dict,
    output_root: Path,
    size: int = 1024,
) -> Tuple[str, str]:
    """Dispatcher per il tipo di QR.

    `qr_type`: 'url' | 'vcard' | 'wifi'
    `payload_data`: dict con i campi specifici al tipo.

    Returns: (filename, subfolder_name).
    """
    out_dir = output_root / "QR_CODES"
    out_dir.mkdir(parents=True, exist_ok=True)

    import datetime, re
    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

    if qr_type == "url":
        url = (payload_data.get("url") or "").strip()
        if not url:
            raise ValueError("URL is required")
        # Aggiunge http:// se manca lo scheme (UX-friendly)
        if not url.lower().startswith(("http://", "https://", "mailto:", "tel:", "sms:")):
            url = "https://" + url
        payload = url
        # Filename derivato dal dominio se possibile
        domain = url.split("//", 1)[-1].split("/")[0]
        safe = re.sub(r'[^\w\-\.]', '_', domain)[:40]
        filename = f"QR_URL_{safe}_{ts}.png"

    elif qr_type == "vcard":
        first = payload_data.get("first_name", "").strip()
        last  = payload_data.get("last_name", "").strip()
        if not first and not last:
            raise ValueError("vCard: first_name or last_name required")
        payload = build_vcard(
            first_name=first,
            last_name=last,
            organization=payload_data.get("organization", "").strip(),
            title=payload_data.get("title", "").strip(),
            phone=payload_data.get("phone", "").strip(),
            email=payload_data.get("email", "").strip(),
            website=payload_data.get("website", "").strip(),
            address=payload_data.get("address", "").strip(),
        )
        safe_name = re.sub(r'[^\w\-]', '_', f"{first}_{last}").strip("_")[:40] or "vcard"
        filename = f"QR_vCard_{safe_name}_{ts}.png"

    elif qr_type == "wifi":
        ssid = (payload_data.get("ssid") or "").strip()
        if not ssid:
            raise ValueError("WiFi: ssid required")
        payload = build_wifi_payload(
            ssid=ssid,
            password=payload_data.get("password", ""),
            security=payload_data.get("security", "WPA"),
            hidden=bool(payload_data.get("hidden", False)),
        )
        safe = re.sub(r'[^\w\-]', '_', ssid)[:40]
        filename = f"QR_WiFi_{safe}_{ts}.png"

    else:
        raise ValueError(f"Unknown QR type: {qr_type}")

    output_path = out_dir / filename
    generate_qr_image(payload, output_path, size=size)

    try:
        from services.audit_service import audit_logger
        audit_logger.log(
            "utility", "file_processed",
            processor="qr_generator",
            qr_type=qr_type,
            output_filename=filename,
            success=True,
        )
    except Exception:
        pass

    return filename, "QR_CODES"
