
import logging
import asyncio
from pathlib import Path
from typing import Dict, Optional, Callable
from services.text_advanced_anonymizer import AdvancedTextAnonymizer
from processors.ocr_processor import OCRImgPDFProcessor
from docx import Document
from docx.shared import Pt

logger = logging.getLogger(__name__)

class PDFAnonymizer:
    """Specialized anonymizer for PDF files with OCR support. Outputs to DOCX for layout retention."""
    
    def __init__(self, vault, language="it"):
        self.vault = vault
        self.language = language
        self.text_engine = AdvancedTextAnonymizer(vault, language=language)
        self.ocr_processor = OCRImgPDFProcessor()

    async def process(self, input_path: str, output_path: str, progress_callback: Optional[Callable[[str], None]] = None):
        """Extracts text from PDF (with OCR if needed), anonymizes it, and saves to DOCX."""
        try:
            if progress_callback:
                progress_callback("📑 Extracting text from PDF (OCR analysis if required)...")
            
            # 1. Estrazione testo con OCR integrato
            success, raw_text = await self.ocr_processor.process_pdf(input_path, progress_callback=progress_callback)
            
            if not success:
                raise Exception(f"Failed to extract text from PDF: {raw_text}")

            # 2. Anonimizzazione a blocchi (per preservare la suddivisione per pagina indicata dall'OCR)
            if progress_callback:
                progress_callback("🛡️ Anonymizing extracted text...")
            
            # L'OCRProcessor restituisce testo separato da "**--- Page X/Y ---**"
            # Dividiamo prima per pagina (identificata dagli header)
            lines = raw_text.split("\n")
            anonymized_parts = []
            
            current_block = []
            for line in lines:
                if "--- Page" in line and "---" in line:
                    # Se abbiamo accumulato testo, lo processiamo prima di aggiungere il nuovo header
                    if current_block:
                        text_to_proc = "\n".join(current_block)
                        if text_to_proc.strip():
                            anon_text = await self.text_engine.process(text_to_proc)
                            anonymized_parts.append(anon_text)
                        current_block = []
                    
                    # Aggiungiamo l'header intatto
                    anonymized_parts.append(line)
                else:
                    current_block.append(line)
            
            # Processiamo l'ultimo blocco rimasto
            if current_block:
                text_to_proc = "\n".join(current_block)
                if text_to_proc.strip():
                    anon_text = await self.text_engine.process(text_to_proc)
                    anonymized_parts.append(anon_text)

            # 3. Ricostruzione in DOCX
            if progress_callback:
                progress_callback("💾 Generating anonymized Word file...")
                
            doc = Document()
            for block in anonymized_parts:
                if "--- Page" in block and "---" in block:
                    para = doc.add_paragraph(block.replace("**", "").replace("---", "").strip())
                    for run in para.runs:
                        run.bold = True
                        run.font.size = Pt(11)
                else:
                    doc.add_paragraph(block)

            doc.save(output_path)
            logger.info(f"✅ PDF processed and saved as Word to {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"❌ Error processing PDF file: {e}")
            raise e
