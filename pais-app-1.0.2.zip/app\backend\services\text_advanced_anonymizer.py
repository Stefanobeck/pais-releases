
import logging
import asyncio
import re
import json
import ollama
from pathlib import Path
from typing import List, Dict
from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern, RecognizerRegistry, RecognizerResult
from presidio_analyzer.nlp_engine import SpacyNlpEngine
from backend_config.settings import settings
from services.ner import get_ner_engine, PiiNerRecognizer
from services.anonimyze_patterns import get_it_text_patterns, IT_COMUNI_SET

logger = logging.getLogger(__name__)


def _parse_llm_entity_list(content: str):
    """Parsing tollerante della lista di entità PII restituita dal LLM.

    Il modello, pur invocato con format='json', a volte restituisce JSON
    troncato (lista lunga tagliata a metà dal limite di token) o avvolto in
    code-fence. Un `json.loads` rigido fallisce e l'enrichment LLM viene perso
    silenziosamente per quel file. Qui:
      1. togliamo eventuali ```json ... ``` fence;
      2. proviamo il parse diretto (lista, o dict con una lista dentro);
      3. se fallisce per troncamento, recuperiamo gli oggetti completi
         iniziali troncando all'ultima `}` e richiudendo l'array.

    Returns: list[dict] in caso di successo (anche parziale), oppure None se
    non è recuperabile nulla (il chiamante decide se ritentare).
    """
    if not content or not content.strip():
        return None
    s = content.strip()
    # 1. Strip code-fence markdown (```json ... ``` o ``` ... ```).
    s = re.sub(r'^```(?:json)?\s*', '', s)
    s = re.sub(r'\s*```$', '', s).strip()

    # 2. Parse diretto.
    try:
        data = json.loads(s)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            # format='json' a volte avvolge la lista: {"entities": [...]}.
            for v in data.values():
                if isinstance(v, list):
                    return v
            return []
    except json.JSONDecodeError:
        pass

    # 3. Recupero da troncamento: isola l'array e richiudilo all'ultimo
    #    oggetto completo.
    start = s.find('[')
    last = s.rfind('}')
    if start != -1 and last != -1 and last > start:
        candidate = s[start:last + 1] + ']'
        try:
            data = json.loads(candidate)
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass
    return None

# Italian noise: pronouns, verbs, conjunctions, prepositions, common discourse words
# that the catch-all NER tends to misclassify as PERSON/LOCATION when they appear
# uppercased at sentence start or inside quoted phrases. Match is whole-word lower.
IT_STOPWORDS = {
    # function words
    "il", "lo", "la", "i", "gli", "le", "un", "uno", "una",
    "di", "del", "dello", "della", "dei", "degli", "delle",
    "da", "dal", "dallo", "dalla", "dai", "dagli", "dalle",
    "a", "al", "allo", "alla", "ai", "agli", "alle",
    "in", "nel", "nello", "nella", "nei", "negli", "nelle",
    "con", "su", "sul", "sullo", "sulla", "sui", "sugli", "sulle",
    "per", "tra", "fra",
    "e", "ed", "o", "ma", "se", "che", "non", "ne", "ci", "vi",
    "io", "tu", "lui", "lei", "noi", "voi", "loro",
    "mio", "tuo", "suo", "nostro", "vostro",
    "quello", "questo", "quella", "questa",
    # common verbs / participles
    "è", "sono", "siamo", "siete", "sono", "essere", "stato", "stata",
    "fare", "ho", "ha", "hanno", "abbiamo", "avete",
    "andare", "venire", "stare", "dire", "fare",
    "purtroppo", "tardivo", "ricoverato", "trasportato", "assentarsi",
    "redatto", "concerne", "concludo", "anticipato", "documentata",
    "incaricato", "rappresentarlo", "porgo", "confermare", "tutelare",
    "chiarire", "occorre", "risulta", "segue", "tenere",
    # discourse / boilerplate phrases (multi-token; checked as substrings)
    "egregio", "gentile", "spett", "cordiali", "saluti",
    "oggetto", "prot", "pag",
    # honorifics with optional dot
    "sig", "sig.", "sig.ra", "signor", "signora", "signorina",
    "dott", "dott.", "dottore", "dottoressa",
    "prof", "prof.", "professore", "professoressa",
    "avv", "avv.", "avvocato",
    "ing", "ing.", "ingegnere",
    "rag", "rag.", "geom", "geom.", "arch", "arch.",
    # months
    "gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno",
    "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre",
    # street-type words alone (already covered by ADDRESS_IT pattern)
    "via", "piazza", "corso", "viale", "vicolo", "largo", "piazzale",
    # role / status words
    "erede", "defunto", "defunta", "deceduto", "deceduta", "coniuge",
    "fratello", "sorella", "genitore", "figlio", "figlia", "minorenne",
    "marito", "moglie", "compagno", "compagna", "convivente",
    "assistito", "cliente", "controparte", "parte", "imputato", "attore",
    "denunciante", "destinatario", "mittente", "intestatario", "beneficiario",
    "direttore", "primario", "responsabile",
    # province codes (always 2 chars uppercase → handled by min_length, but keep explicit)
    "mi", "to", "rm", "na", "fi", "bo", "ge", "ve", "pa", "ba",
}

# Italian discourse phrases the LLM and the NER catch-all both tend to surface
# as PERSON. Matched as case-insensitive substring against the detected text.
IT_FALSE_PERSON_PHRASES = [
    "mio assistito", "vie brevi", "per quanto concerne", "come anticipato",
    "grave malore", "stato trasportato", "pesanti terapie", "tensioni domestiche",
    "vostre anagrafiche", "decorso recidivante", "sclerosi multipla",
    "purtroppo redatto", "suo cortese", "cordiali saluti", "tanto che",
    "dopo una serie", "concludo chiedendo", "bonifico bancario",
    "figlio minorenne", "risorse umane", "assenze ingiustificate",
    "stato incaricato", "conto cointestato", "seguenti recapiti",
    "ciclicamente dal", "lavoro dal", "modo tardivo", "occorre chiarire",
    "recupero arretrati", "arretrato pari", "industria meccanica",
    "fratello unilaterale", "sorella unilaterale", "parte dell'unione civile",
    "direzione provinciale", "ufficio territoriale", "registro imprese",
    "agenzia delle entrate", "agenzia entrate", "imposta di successione",
    "imposta ipotecaria", "imposta catastale", "tributi speciali",
    "spese di notifica", "codice tributo", "dati per la notificazione",
    "carta d'identita elettronica", "tessera sanitaria",
]


class AdvancedTextAnonymizer:
    def __init__(self, vault, language="it"):
        self.vault = vault
        self.language = language
        self.ollama_client = ollama.AsyncClient(host=settings.OLLAMA_HOST_URL)
        self.config = self._load_config()
        self.model = self.config.get("ollama_model", "gemma4:e4b")
        self.temp = self.config.get("temperature", 0.0)
        self._analyzer = self._init_presidio()

        # Stopwords / function words that should never be standalone PII.
        self.stopwords = set(s.lower() for s in IT_STOPWORDS)
        # Multi-token Italian phrases that consistently produce false positives.
        self.false_phrases = [p.lower() for p in IT_FALSE_PERSON_PHRASES]
        # Legacy attribute kept for compatibility with any caller still expecting it.
        self.blacklist = list(self.stopwords) + self.false_phrases

    def _load_config(self) -> Dict:
        config_path = Path(__file__).parent.parent / "backend_config" / "text_anonymizer_config.json"
        try:
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load text_anonymizer_config.json: {e}")
        return {"ollama_model": "gemma4:e4b", "temperature": 0.0, "system_prompt": "PII Detector", "analysis_prompt": "{text}"}

    def _init_presidio(self):
        # xx_ent_wiki_sm (MIT) fa solo da tokenizer; il riconoscimento reale viene
        # da PiiNerRecognizer (ONNX MIT) + regex per categorie deterministiche.
        # Estendiamo labels_to_ignore per silenziare entità che spaCy emette con
        # bassa qualità (date numeriche isolate, percentuali, numeri ordinali).
        nlp_engine = SpacyNlpEngine(models=[{
            "lang_code": self.language,
            "model_name": "xx_ent_wiki_sm",
            "ner_model_configuration": {
                "labels_to_ignore": [
                    "PER", "LOC", "ORG", "MISC",
                    "CARDINAL", "ORDINAL", "QUANTITY", "PERCENT",
                    "DATE", "TIME", "MONEY", "GPE", "FAC", "NORP",
                    "EVENT", "WORK_OF_ART", "LAW", "LANGUAGE",
                ]
            }
        }])
        registry = RecognizerRegistry(supported_languages=[self.language])
        registry.load_predefined_recognizers()

        # Pattern IT condivisi con AnonimyzeService (vedi
        # services.anonimyze_patterns) — single source of truth: aggiungi i
        # nuovi pattern lì, non qui.
        text_patterns = get_it_text_patterns()
        for name, regex, score in text_patterns:
            registry.add_recognizer(
                PatternRecognizer(
                    supported_entity=name,
                    supported_language=self.language,
                    patterns=[Pattern(name, regex, score)],
                )
            )

        registry.add_recognizer(PiiNerRecognizer(get_ner_engine(), supported_language=self.language))

        return AnalyzerEngine(registry=registry, nlp_engine=nlp_engine, supported_languages=[self.language])

    async def _get_llm_entities(self, text: str) -> List[Dict]:
        if len(text.strip()) < 5:
            return []
        system_p = self.config.get("system_prompt", "")
        analysis_template = self.config.get("analysis_prompt", "{text}")
        final_prompt = analysis_template.replace("{text}", text)
        messages = [
            {'role': 'system', 'content': system_p},
            {'role': 'user', 'content': final_prompt},
        ]
        # L'enrichment LLM è ADDITIVO: il motore autoritativo resta Presidio
        # (regex IT + ONNX NER). Se il modello restituisce JSON malformato/
        # troncato proviamo a recuperare la lista parziale e, se serve, un
        # secondo tentativo; il fallimento è un degrado di qualità gestito
        # (NON un errore bloccante) → log a WARNING, non ERROR.
        last_raw = ""
        for attempt in range(2):
            try:
                response = await self.ollama_client.chat(
                    model=self.model,
                    messages=messages,
                    format="json", options={"temperature": self.temp},
                )
                last_raw = response['message']['content']
                parsed = _parse_llm_entity_list(last_raw)
                if parsed is not None:
                    return parsed
                logger.warning(
                    f"LLM PII enrichment: unparseable/truncated JSON "
                    f"(attempt {attempt + 1}/2); falling back to Presidio-only."
                )
            except Exception as e:
                logger.warning(
                    f"LLM PII enrichment call failed (attempt {attempt + 1}/2): {e}"
                )
        logger.warning(
            "LLM PII enrichment unavailable for this chunk — Presidio (regex + "
            "ONNX NER) coverage stands. Last raw head: "
            f"{last_raw[:120]!r}"
        )
        return []

    # Honorifics / labels that ride along a PERSON span and signal it's actually
    # boilerplate. Matched case-insensitive, dot-flexible against the first
    # OR last token of the span.
    _PERSON_TITLE_TOKENS = {
        "sig", "sig.", "sig.ra", "signor", "signora", "signorina",
        "dott", "dott.", "dott.ssa", "dottore", "dottoressa",
        "prof", "prof.", "prof.ssa", "professore", "professoressa",
        "avv", "avv.", "avvocato", "avvocata",
        "ing", "ing.", "ingegnere",
        "rag", "rag.", "ragioniere",
        "geom", "geom.", "geometra",
        "arch", "arch.", "architetto",
        "c.f.", "cf", "p.iva", "piva", "p.iva.",
        "spett.le", "spett",
    }
    _PERSON_FIRST_LAST_BOILERPLATE = {
        "dal", "del", "della", "dei", "degli", "delle",
        "in", "a", "presso", "via", "piazza", "corso",
        "ed", "il", "la", "lo", "le", "gli", "un", "una",
        "non",  # "NON PRESENTE" boilerplate from Agenzia Entrate forms
    }
    # If a PERSON span STARTS with one of these corporate / institutional
    # keywords, it's actually an ORGANIZATION the catch-all swept across.
    # Dropping the PERSON tag lets the ORGANIZATION recognizer pick it up,
    # or — if no ORG hit — keeps the document cleaner.
    _CORPORATE_HEAD_TOKENS = {
        "studio", "ospedale", "banca", "centro", "istituto", "ministero",
        "agenzia", "comune", "comunità", "regione", "provincia",
        "università", "scuola", "azienda", "fondazione", "associazione",
        "società", "cooperativa", "consorzio", "gruppo",
        "casa", "clinica", "ambulatorio", "asl", "ats", "usl",
        "tribunale", "corte", "procura", "questura", "stazione",
        "camera", "consiglio", "direzione", "ufficio", "servizio",
        "dipartimento",
    }
    # Italian prepositions/conjunctions that NEVER appear mid-name. If a span
    # tagged as PERSON contains one of these as a whole word, it's not a name —
    # it's a phrase the NER swept across. Keeps the "DE", "DEL", "DELLA",
    # "DI", "LO", "LA", "SAN", "SANTA" particles allowed (they ARE valid
    # surname components in italian names like "Di Mauro" / "Della Valle").
    _PERSON_INNER_FORBIDDEN = {
        "per", "con", "su", "sul", "sulla", "tra", "fra",
        "che", "ma", "se", "non", "ne",
        "il", "lo", "la", "i", "gli", "le", "un", "uno", "una",
        "alla", "alle", "agli", "ai", "allo",
        "nel", "nella", "nei", "negli", "nelle", "nello",
        "dal", "dallo", "dalla", "dai", "dagli", "dalle",
        "dell", "dell'", "del", "dei", "degli", "delle",
        # NOTE: NOT including 'di' / 'de' / 'la' / 'lo' as inner-forbidden —
        # those are valid surname particles. They're only suspect when AT POSITION 0.
    }
    # Italian SECTION TITLES / common nouns / adjectives frequently emitted in
    # UPPERCASE in notarial / legal texts. They sweep the PERSON regex catch-all
    # (0.55 score) but aren't names. Reject if ANY word in an all-uppercase
    # PERSON span is in this set — handles both span-starts ("DISPOSIZIONI
    # GENERALI") and span-middles ("DI QUOTE EREDITARIE": "EREDITARIE" hit).
    # NB: surname particles "DI" / "DEL" / "DELLA" / "DA" are NOT here — they
    # are valid first-tokens for names ("DI MARTINO ANNA", "DELLA VALLE LUIGI").
    # Source: empirical scan of the DENTICE contract (2026-05-13).
    _ITALIAN_SECTION_TITLE_TOKENS = {
        # documenti / atti
        "DISPOSIZIONI", "DISPOSIZIONE", "CONTRATTO", "CONTRATTI",
        "ARTICOLO", "ARTICOLI", "COMMA", "CAPOVERSO",
        "REGISTRO", "REGISTRI", "ATTO", "ATTI",
        "DICHIARAZIONE", "DICHIARAZIONI", "PROCURA", "PROCURE",
        "SCRITTURA", "SCRITTURE", "ROGITO", "ROGITI",
        "TITOLO", "CAPITOLO", "PAGINA", "PAGINE", "DOCUMENTO", "DOCUMENTI",
        # provvedimenti
        "ORDINE", "DELIBERA", "DELIBERE", "DECRETO", "DECRETI", "LEGGE", "LEGGI",
        "NORMA", "NORME", "REGOLAMENTO", "REGOLAMENTI",
        # atti volontari
        "ACCETTAZIONE", "ACCETTAZIONI", "RINUNCIA", "RINUNCE",
        "CONSENSO", "CONSENSI", "OGGETTO", "TERMINE", "TERMINI",
        "PREZZO", "PREZZI", "STIPULA", "STIPULAZIONE",
        "EFFETTI", "EFFETTO", "MODIFICHE", "MODIFICA",
        "ADEMPIMENTI", "ADEMPIMENTO", "ALLEGATO", "ALLEGATI",
        # spese e tasse
        "SPESE", "IMPOSTE", "TASSE", "IMPOSTA",
        # ereditario
        "EREDITARIE", "EREDITARIO", "EREDITA", "EREDITARIETA",
        # cessioni
        "CESSIONE", "CESSIONI", "ACQUISTO", "ACQUISTI",
        "PRELIMINARE", "DEFINITIVO", "DEFINITIVE", "DEFINITIVA",
        # generali
        "GENERALI", "GENERALE", "SPECIALE", "SPECIALI",
        # quote / unità
        "QUOTE", "QUOTA", "PORZIONE", "PORZIONI",
        # geografiche generiche (LOCATION fa il suo)
        "REPUBBLICA", "ITALIANA",
    }

    # ──────────────────────────────────────────────────────────────────────
    # Quality filters applied to raw detections (regex + NER + LLM).
    # Goal: drop high-confidence garbage that the underlying detectors emit.
    # ──────────────────────────────────────────────────────────────────────
    def _is_garbage_span(self, text_full: str, start: int, end: int, entity_type: str) -> bool:
        span = text_full[start:end]
        stripped = span.strip()
        lower = stripped.lower()

        # 1. Too short — fragments like "Via", "MI", "12" or BPE wordpieces.
        # PERSON / LOCATION / ORGANIZATION / ADDRESS_IT must be at least 4 chars
        # to be meaningful; deterministic codes (CF, VAT, IBAN, EMAIL) keep their own
        # length constraints from regex.
        soft_types = {"PERSON", "LOCATION", "ORGANIZATION", "ADDRESS_IT", "DATE_TIME"}
        if entity_type in soft_types and len(stripped) < 4:
            return True
        # PERSON wordpieces from ONNX often leak as 4-char fragments ("Beat",
        # "Gian", "Mor", "Lor") that survive the global min-4 above but are
        # still garbage. Require ≥5 chars for single-token PERSON spans.
        if entity_type == "PERSON":
            tokens_quick = re.findall(r"[\w'’.]+", stripped)
            if len(tokens_quick) == 1 and len(stripped) < 5:
                return True

        # 2. Contains line breaks → for SOFT types (PERSON, LOCATION, DATE_TIME),
        # almost always a multi-line phrase, not an entity. For deterministic
        # categories or structured Italian patterns the PDF extractor often
        # injects "\n" in valid spans:
        #   "BANCA \nWIDIBA S.p.A."          (ORGANIZATION)
        #   "VIA LE IVANOE \nBONOMI"          (ADDRESS_IT)
        #   "libretto di risparmio \npostale n. 000013693872"  (ACCT)
        # so the newline rejection applies ONLY to the soft NER types where
        # multi-line spans are nearly always spurious.
        _newline_reject_types = {"PERSON", "LOCATION", "DATE_TIME"}
        if "\n" in stripped and entity_type in _newline_reject_types:
            return True

        # 3. Stopword / function-word — drop if the WHOLE span is a stopword.
        words = re.findall(r"\w+", lower)
        if not words:
            return True
        # LOCATION sigle-provincia in parens "(NA)", "(RM)" sono LEGITTIME
        # entità geografiche anche se "na"/"rm" sono in stopwords (per evitare
        # falsi positivi PERSON su token isolati come "TO"/"MI"). Il regex
        # \(\s*XX\s*\) è inequivocabile → bypassa lo stopword check qui.
        if entity_type == "LOCATION" and "(" in span and ")" in span:
            pass  # skip stopword rejection for paren-wrapped province codes
        elif all(w in self.stopwords for w in words):
            return True
        elif len(words) == 1 and words[0] in self.stopwords:
            return True

        # 4. Forbidden Italian discourse phrases.
        for phrase in self.false_phrases:
            if phrase in lower:
                return True

        # 5. PERSON-specific filters.
        if entity_type == "PERSON":
            content_words = [w for w in words if len(w) >= 3 and w not in self.stopwords]
            if not content_words:
                return True
            # Reject if every content word is fully lowercase — real PERSON names
            # carry at least one capitalized letter in the original text.
            original_words = re.findall(r"[\w.'’]+", stripped)
            if not original_words:
                return True
            if all(w.islower() for w in original_words):
                return True
            # Reject spans that START or END with an Italian honorific token —
            # almost always the detector swept across a label boundary.
            #   "Dott. Filippo Martelli"  → drop (LLM is asked to emit names only)
            #   "Vertenza legale Sig"     → drop
            #   "Torino dal Prof"         → drop
            first_low = original_words[0].lower()
            last_low = original_words[-1].lower()
            if first_low in self._PERSON_TITLE_TOKENS or last_low in self._PERSON_TITLE_TOKENS:
                return True
            # Span starts with a corporate / institutional keyword → it's an
            # organization, not a person. Drop the PERSON tag; ORGANIZATION
            # recognizer can still pick it up via its own pathway.
            if first_low in self._CORPORATE_HEAD_TOKENS:
                return True
            # Reject spans that start with a connective ("dal", "del", "in", ...)
            # or whose first token is fully lowercase: a real PERSON span always
            # starts with the surname (proper noun, capitalized).
            # EXCEPTION: UPPERCASE forms like "DELLA VALLE", "DEL BO", "DI
            # MARTINO" are valid italian compound surnames — only the
            # lowercase form ("della successione", "del notaio") is a
            # boilerplate phrase to reject.
            if first_low in self._PERSON_FIRST_LAST_BOILERPLATE and not original_words[0].isupper():
                return True
            if original_words[0][0].islower():
                return True
            # Reject if the span contains a known CF/P.IVA-like code (16 chars,
            # mostly letters+digits with uppercase pattern) — that's a fiscal
            # code attached to a label, not a person.
            if re.search(r"\b[A-Z]{6}\d{2}[A-EHLMPR-T]\d{2}[A-Z]\d{3}[A-Z]\b", stripped):
                return True
            # Reject if any INNER token (not first, not last) is a forbidden
            # italian prep/conjunction — a real person name never contains
            # 'per', 'con', 'che', 'su', 'tra'... in the middle.
            inner_words = original_words[1:-1] if len(original_words) >= 3 else []
            for w in inner_words:
                if w.lower() in self._PERSON_INNER_FORBIDDEN:
                    return True
            # Same rule applied to first/last when the span has exactly 2 tokens:
            # "NON PRESENTE", "Per qualsiasi", "IBAN versamento"... all caught
            # because at least one of the 2 tokens is a function word.
            if len(original_words) == 2:
                if any(w.lower() in self._PERSON_INNER_FORBIDDEN for w in original_words):
                    return True
                # Also drop if neither token is a plausible italian proper noun:
                # a heuristic — at least one token must have ≥4 chars AND start
                # with a capital letter.
                if not any(len(w) >= 4 and w[0].isupper() for w in original_words):
                    return True
            # Drop spans where more than half the tokens are lowercase. Real
            # PERSON names are nearly all-caps in italian official documents,
            # or first-letter-capitalized in standard text — either way the
            # capitalized:lowercase ratio is >= 0.5. Catches:
            #   "Dichiarazione di successione presentata"  (1 cap / 4 = 0.25)
            #   "Per qualsiasi necessità"                  (1 cap / 3 = 0.33)
            caps_count = sum(1 for w in original_words if w and w[0].isupper())
            if len(original_words) >= 3 and caps_count < len(original_words) / 2:
                return True
            # Reject ALL-UPPERCASE PERSON spans that contain any Italian
            # section-title token ("DISPOSIZIONI GENERALI", "DI QUOTE
            # EREDITARIE", "CONTRATTO PRELIMINARE"). Common-nouns in caps
            # sweep the catch-all PERSON regex; the section-title set
            # captures them without rejecting legitimate names like
            # "DI MARTINO ANNA".
            if all(w.isupper() for w in original_words if w.isalpha()):
                if any(w.upper().rstrip("',.") in self._ITALIAN_SECTION_TITLE_TOKENS for w in original_words):
                    return True

        # 7. ORGANIZATION-specific: drop single-token short uppercase fragments
        #    ("AGENZIA", "IBAN", "STUDIO" on their own) — proper org names have
        #    at least one descriptive word with ≥6 chars or contain a corporate
        #    keyword (Studio, S.p.A., S.r.l., Centro, Ospedale, Banca, ...).
        if entity_type == "ORGANIZATION":
            if len(words) == 1 and len(stripped) < 8:
                return True

        # 6. LOCATION-specific. Checks for single capitalized words:
        #    a) Italian COMPOUND SURNAME guard — many Italian municipalities
        #       collide with surname stems (DENTICE d'ACCADIA, DELLA VALLE,
        #       DI MARTINO, SAN MARTINO, SANT'AGATA). If a LOCATION span
        #       is immediately preceded by a surname particle (apostrophe
        #       or DE/DEL/DELLA/DEI/DEGLI/DELLE/DI/LO/LA/SAN/SANTA/SANT'/
        #       DELL'/DALL'), it is part of a person's surname → drop it.
        #       This must run BEFORE the comune whitelist: Accadia exists
        #       as a town in FG, but "d'ACCADIA" is never the town.
        #    b) ISTAT whitelist — single-word LOCATION matching a real
        #       Italian comune is trusted even without preposition context.
        #    c) Preposition context — fallback for non-whitelisted spans
        #       (avoids stray UPPERCASE surnames swept as LOCATION).
        if entity_type == "LOCATION":
            # (0) Italian city names are always capitalized — a lowercase
            # single-word LOCATION is always a FP (Presidio compiles the
            # patterns with re.IGNORECASE so "paese" lowercase matches
            # the comune "Paese" alternation; reject these here).
            if len(words) == 1 and stripped and stripped[0].isalpha() and stripped[0].islower():
                return True
            if len(words) == 1 and stripped and stripped[0].isalpha() and stripped[0].isupper():
                win_start = max(0, start - 25)
                pre = text_full[win_start:start]
                # (a) surname particle right before the span.
                if re.search(
                    r"['’]\s*$"  # d'ACCADIA, dell'ARCO, sant'ANGELO
                    r"|(?i:\b(?:de|del|della|dei|degli|delle|di|lo|la|san|santa)\s+$)",
                    pre,
                ):
                    return True
                # (b) ISTAT whitelist.
                if stripped.lower() in IT_COMUNI_SET:
                    pass
                else:
                    # (c) require locative preposition in the immediate prefix.
                    if not re.search(
                        r"\b(?:a|di|in|presso|da|verso|nel|nella|sul|sulla)\s+$",
                        pre.lower(),
                    ):
                        return True

        return False

    def _propagate_consistency(self, results: List[RecognizerResult], text: str) -> List[RecognizerResult]:
        """Case-sensitive propagation of detected entities.

        For each unique entity (text + type), find ALL other case-sensitive
        occurrences in the document and add them as RecognizerResults with
        the same score. Fixes the "NAPOLI tagged in line 5 but not line 4"
        inconsistency seen in long documents where NER confidence varies
        per-occurrence based on local context.

        - LEGAL_REF is skipped: blacklist entities don't need to be propagated
          (they're not replaced).
        - Spans <4 chars are skipped: too short to safely re-find without noise.
        - Already-occupied spans (from initial detection or earlier propagation)
          are not duplicated.
        """
        existing_spans = {(r.start, r.end) for r in results}
        # Unique (text, type) pairs from current detections — sorted longest first
        # so that "DENTICE d'ACCADIA ROBERTO" is propagated before "DENTICE",
        # preventing shorter substring matches inside the longer one.
        seen: Dict[str, str] = {}  # original_text → entity_type
        for r in sorted(results, key=lambda r: -(r.end - r.start)):
            if r.entity_type == "LEGAL_REF":
                continue
            original = text[r.start:r.end]
            if len(original) < 4:
                continue
            # If already seen with different type, keep first (longest) decision.
            seen.setdefault(original, r.entity_type)

        additional: List[RecognizerResult] = []
        for original, etype in seen.items():
            # Find ALL case-sensitive occurrences; skip those already occupied.
            try:
                pat = re.compile(r"\b" + re.escape(original) + r"\b")
            except re.error:
                continue
            for m in pat.finditer(text):
                span = (m.start(), m.end())
                if span in existing_spans:
                    continue
                # Also skip if any existing span OVERLAPS (a longer span already
                # covers this region under a different entity type).
                overlap = any(
                    not (m.end() <= s_start or m.start() >= s_end)
                    for s_start, s_end in existing_spans
                )
                if overlap:
                    continue
                existing_spans.add(span)
                # Reuse the score of the first detection of this text+type.
                # Find it in results to copy score.
                src_score = next(
                    (r.score for r in results if text[r.start:r.end] == original and r.entity_type == etype),
                    0.6,
                )
                additional.append(RecognizerResult(
                    entity_type=etype, start=m.start(), end=m.end(), score=src_score,
                ))
        return results + additional

    async def analyze(self, text: str) -> List[Dict]:
        """Detect entities WITHOUT applying substitutions. Used by the interactive
        review workflow (analyze → review → apply). Returns a list of dicts:

            [{'id', 'type', 'text', 'start', 'end', 'score'}, ...]

        Entities are already filtered against blacklist and deduplicated for
        overlaps. The `id` is stable as long as the input text doesn't change.
        """
        if not text:
            return []
        results = await asyncio.to_thread(
            self._analyzer.analyze, text=text, language=self.language, score_threshold=0.5
        )

        type_map = {
            "PERSON": "PERSON", "LOCATION": "LOCATION", "ADDRESS": "ADDRESS_IT",
            "ORGANIZATION": "ORGANIZATION", "STUDIO": "ORGANIZATION",
        }

        llm_entities = await self._get_llm_entities(text)
        # Whitespace-flexible literal match: the LLM normalizes spaces but the
        # source text may contain stray multi-spaces or line breaks. Escape per
        # word then join with `\s+` so a newline inside a name still matches.
        for ent in llm_entities:
            t = ent.get("text", "").strip()
            etype = ent.get("type", "PERSON").upper()
            if len(t) < 3:
                continue
            words = t.split()
            if not words:
                continue
            flexible_pattern = r'\s+'.join(re.escape(w) for w in words)
            try:
                for m in re.finditer(flexible_pattern, text, re.IGNORECASE):
                    results.append(RecognizerResult(
                        entity_type=type_map.get(etype, "PERSON"),
                        start=m.start(), end=m.end(), score=0.85,
                    ))
            except re.error:
                continue

        # Quality filter: stopwords / forbidden phrases / fragments / multi-line.
        filtered_results = []
        for r in results:
            if self._is_garbage_span(text, r.start, r.end, r.entity_type):
                continue
            filtered_results.append(r)

        # Overlap dedupe — priority order:
        #   1. Deterministic types (CF, VAT, IBAN, EMAIL, PHONE, plus new
        #      Italian categories) always win over soft types (PERSON,
        #      LOCATION, ORGANIZATION) when they overlap.
        #      Stops the LLM from masking a `MRNGLC82E14L219X` fiscal code by
        #      catching it inside a longer `C.F. MRNGLC82E14L219X` PERSON span.
        #      Also stops PHONE_NUMBER from eating ACCT spans like
        #      "libretto … n. 82008270534" (PHONE matched the digit tail).
        #   2. Longer span — keeps `Beatrice Lorenzi` over `Beat` wordpiece.
        #   3. Higher score — tiebreak.
        deterministic_types = {
            "IT_FISCAL_CODE", "IT_VAT_CODE", "IBAN_CODE", "IT_CIE",
            "EMAIL_ADDRESS", "PHONE_NUMBER", "DATE_TIME",
            # Italian categories added 2026-05-13 — these are regex-defined
            # with high specificity, must win over soft NER hits.
            "LEGAL_REF", "NOTAIO_REP", "CATASTO", "ACCT",
            # Corpus atti italiani 2026-05-14 — identificativi numerici
            # specifici che devono battere PHONE_NUMBER quando un loro
            # span li contiene parzialmente.
            "CURRENCY", "IT_POSTAL_CODE", "IT_PROT", "IT_JUDICIAL_REF",
            "IT_CARTELLA_AE", "IT_INPS", "IT_INAIL",
            "IT_INSURANCE_POLICY", "IT_DRIVER_LICENSE", "VEHICLE_VIN",
            "IT_REA", "IT_TESSERA_SANITARIA", "MEDICAL_ICD",
            "LICENSE_PLATE",
        }

        def _sort_key(r):
            return (
                1 if r.entity_type in deterministic_types else 0,
                r.end - r.start,
                r.score,
            )

        filtered_results = sorted(filtered_results, key=_sort_key, reverse=True)
        clean_results = []
        occupied_ranges = []
        for r in filtered_results:
            overlap = False
            for start, end in occupied_ranges:
                if not (r.end <= start or r.start >= end):
                    overlap = True
                    break
            if not overlap:
                clean_results.append(r)
                occupied_ranges.append((r.start, r.end))

        # Case-sensitive propagation across the document. Solves the
        # "NAPOLI tagged in some lines but not others" inconsistency where
        # NER confidence per-occurrence varies with local context.
        # Run AFTER overlap dedupe so we propagate only the cleanest spans,
        # and BEFORE serialization so the output dict list includes all
        # propagated entries (each with its own stable id).
        clean_results = self._propagate_consistency(clean_results, text)

        # Serialize to plain dicts with stable ids.
        out: List[Dict] = []
        for r in clean_results:
            out.append({
                "id": f"{r.entity_type}-{r.start}-{r.end}",
                "type": r.entity_type,
                "text": text[r.start:r.end],
                "start": r.start,
                "end": r.end,
                "score": float(r.score),
            })
        return out

    def apply_selected(self, text: str, entities: List[Dict], selected_ids=None) -> str:
        """Apply substitutions on `text` ONLY for the entities whose `id` is in
        `selected_ids`. If `selected_ids` is None, apply on all entities.

        `entities` is the output of analyze(). Iterates in descending start
        order so character offsets stay valid during replacement.

        LEGAL_REF (riferimenti normativi pubblici) sono in blacklist: vengono
        rilevati per consumare lo span (così altri engine non li sovrascrivono
        come PERSON/ORG) ma NON sostituiti — restano in chiaro nel testo.
        """
        if not text or not entities:
            return text
        sel = None if selected_ids is None else set(selected_ids)
        targets = entities if sel is None else [e for e in entities if e["id"] in sel]
        # Filter out blacklist types BEFORE replacement.
        targets = [e for e in targets if e.get("type") != "LEGAL_REF"]
        targets = sorted(targets, key=lambda e: e["start"], reverse=True)
        anonymized = text
        for e in targets:
            placeholder = self.vault.get_or_create(text[e["start"]:e["end"]], e["type"])
            anonymized = anonymized[:e["start"]] + placeholder + anonymized[e["end"]:]
        return anonymized

    async def process(self, text: str) -> str:
        """Backward-compatible 1-shot entry point: analyze + apply all.
        New code that needs a review step should use analyze() + apply_selected()
        directly instead of process()."""
        if not text:
            return text
        entities = await self.analyze(text)
        return self.apply_selected(text, entities, selected_ids=None)
