"""
Account / License Routes — Lemon Squeezy backed when configured, dummy
fallback otherwise.

When the env vars `LEMON_SQUEEZY_API_KEY` / `STORE_ID` / `WEBHOOK_SECRET`
are populated, `/account/activate` calls the real Lemon Squeezy API
(`POST /v1/licenses/activate`) and the webhook endpoint accepts
revocation events. Without those env vars, activation falls back to the
historic dummy classifier (`_classify_dummy`) so dev/test machines keep
working without external dependencies.

Frontend response shape stays identical in both paths — the FE never
needs to know whether validation went through LS or the dummy.
"""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, Tuple

from backend_config.project_manager import project_manager
from services import user_settings_service as uss
from services import lemon_squeezy_service as ls
from services.identity_service import get_identity
from services.vault_backup_service import VaultBackupService, backup_info_to_dict

logger = logging.getLogger(__name__)

router = APIRouter()

# One service per process — stateless wrt project_manager (queries on demand)
_vault_backup = VaultBackupService(project_manager)


class ActivateRequest(BaseModel):
    license_key: str


class AccountResponse(BaseModel):
    """Schema esteso per supportare il modello a 3 stati (free_trial /
    free_residual / pro). `tier` resta lo stato PERSISTITO (free/pro),
    `effective_tier` è il calcolato runtime che il frontend deve usare.
    """
    valid: bool
    tier: str  # "free" | "pro" (persistito)
    effective_tier: str  # "free_trial" | "free_residual" | "pro" (runtime)
    license_key: Optional[str] = None
    activated_at: Optional[str] = None
    expires_at: Optional[str] = None
    first_install_at: Optional[str] = None
    trial_seconds_total: int = 0
    trial_seconds_left: int = 0
    pro_seconds_left: Optional[int] = None


# Durata licenza PRO in secondi (1 anno).
_PRO_DURATION_SECONDS = 365 * 24 * 60 * 60


def _classify_dummy(license_key: str) -> Optional[str]:
    """Dummy classifier: returns 'pro' if key contains 'PRO', else None.

    Used only when Lemon Squeezy is NOT configured (env vars empty) — keeps
    dev/test workflows working without external dependencies. Production
    builds receive LEMON_SQUEEZY_API_KEY and use the real classifier below.
    """
    if not license_key:
        return None
    if "PRO" in license_key.upper():
        return "pro"
    return None


def _classify_license(license_key: str) -> Tuple[str, Optional[str], Optional[str], Optional[str]]:
    """Validate a license key, picking real Lemon Squeezy when configured
    and falling back to the dummy classifier otherwise.

    Returns a tuple `(tier, expires_at_iso, instance_id, customer_email)`:
      - tier: "pro" on success, "invalid" on failure
      - expires_at_iso: ISO string when LS provides one, None for perpetual
        licenses or dummy keys (caller applies its own _PRO_DURATION_SECONDS)
      - instance_id: LS activation id when real-LS path, None for dummy
      - customer_email: from LS payload, None for dummy
    """
    from datetime import datetime, timezone, timedelta

    if not license_key:
        return ("invalid", None, None, None)

    if ls.is_configured():
        # Real Lemon Squeezy activation. instance_name = HW fingerprint so the
        # activation is bound to this device — prevents license sharing.
        identity = get_identity()
        instance_name = identity.get("device_id") or "unknown-device"
        result = ls.activate_license(license_key, instance_name=instance_name)
        if not result.valid:
            logger.info("LS activation rejected: %s", result.error_message or "unknown reason")
            return ("invalid", None, None, None)
        expires_iso = result.expires_at.isoformat() if result.expires_at else None
        return ("pro", expires_iso, result.instance_id, result.customer_email)

    # Dummy fallback (no env vars configured)
    if _classify_dummy(license_key) == "pro":
        expires_iso = (datetime.now(timezone.utc) + timedelta(seconds=_PRO_DURATION_SECONDS)).isoformat()
        return ("pro", expires_iso, None, None)
    return ("invalid", None, None, None)


def _build_response(valid: bool) -> AccountResponse:
    """Assembla AccountResponse leggendo account persistito + effective_tier."""
    a = uss.get_account()
    eff = uss.compute_effective_tier()
    return AccountResponse(
        valid=valid,
        tier=a.get("tier") or "free",
        effective_tier=eff["effective_tier"],
        license_key=a.get("license_key"),
        activated_at=a.get("activated_at"),
        expires_at=a.get("expires_at"),
        first_install_at=eff.get("first_install_at"),
        trial_seconds_total=eff.get("trial_seconds_total", 0),
        trial_seconds_left=eff.get("trial_seconds_left", 0),
        pro_seconds_left=eff.get("pro_seconds_left"),
    )


@router.get("/account/status", response_model=AccountResponse)
async def get_status():
    """Read account + effective tier. `valid` resta True quando esiste una
    PRO key persistita; il frontend usa `effective_tier` per il gating reale."""
    a = uss.get_account()
    return _build_response(valid=bool(a.get("license_key")))


@router.post("/account/activate", response_model=AccountResponse)
async def activate(req: ActivateRequest):
    """Validate a license key and persist as pro.

    Picks the real Lemon Squeezy `licenses/activate` endpoint when env
    vars are configured, otherwise falls back to the dummy classifier
    (any key containing 'PRO' → 365gg PRO). Invalid keys → 400.
    """
    key = (req.license_key or "").strip()
    if not key:
        raise HTTPException(status_code=400, detail="License key is required")

    tier, expires_at, instance_id, customer_email = _classify_license(key)
    if tier != "pro":
        raise HTTPException(status_code=400, detail="Invalid license key")

    # Apply dummy expiry only when LS didn't provide one (perpetual licenses
    # leave expires_at=None and rely on webhook revocation).
    if not expires_at:
        from datetime import datetime, timezone, timedelta
        expires_at = (datetime.now(timezone.utc) + timedelta(seconds=_PRO_DURATION_SECONDS)).isoformat()

    uss.set_account(
        tier="pro",
        license_key=key,
        expires_at=expires_at,
        instance_id=instance_id,
        customer_email=customer_email,
    )
    return _build_response(valid=True)


@router.post("/account/deactivate", response_model=AccountResponse)
async def deactivate():
    """Reset PRO licence. Il tier effettivo torna automatico a
    free_trial / free_residual in base a first_install_at.

    When Lemon Squeezy is configured AND the account has an `instance_id`,
    we also notify LS to free up the seat for re-activation elsewhere.
    Best-effort: a failed deactivate API call doesn't block local reset.
    """
    account = uss.get_account()
    license_key = account.get("license_key")
    instance_id = account.get("instance_id")
    if ls.is_configured() and license_key and instance_id:
        try:
            ok = ls.deactivate_license(license_key, instance_id)
            if not ok:
                logger.warning(
                    "LS deactivate returned False for instance %s — local state reset anyway.",
                    instance_id,
                )
        except Exception as e:
            logger.warning("LS deactivate raised: %s — local state reset anyway.", e)

    uss.set_account(tier="free", license_key=None, expires_at=None)
    return _build_response(valid=False)


# ──────────────────────────────────────────────────────────────────────
# Lemon Squeezy webhook — revocation events (refund, cancel, expire)
# ──────────────────────────────────────────────────────────────────────

@router.post("/account/webhook/lemon-squeezy")
async def lemon_squeezy_webhook(request: Request):
    """Receive Lemon Squeezy webhook events. Signature is verified via
    HMAC-SHA256 against `LEMON_SQUEEZY_WEBHOOK_SECRET`. Idempotent: each
    LS event_id is processed at most once.

    Revocation events (refund, cancel, expire, payment failed, license
    revoke) immediately reset the local account to free_residual by
    setting `expires_at=now()`. The frontend's adaptive polling will
    pick this up within seconds.

    Reactivation events (payment success, resume) are logged but don't
    auto-flip the account back to PRO — re-activation goes through the
    normal `/account/activate` flow so the instance is rebound to this
    device explicitly.
    """
    if not ls.is_configured():
        # Without LS env vars, this endpoint should not be reachable in
        # production. Refuse rather than silently accept.
        raise HTTPException(status_code=503, detail="Lemon Squeezy is not configured on this host")

    raw_body = await request.body()
    signature = request.headers.get("X-Signature", "")

    if not ls.verify_webhook_signature(raw_body, signature):
        logger.warning("LS webhook signature verification failed (sig prefix=%r)", signature[:16])
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Webhook body is not valid JSON")

    meta = payload.get("meta") or {}
    event_id = str(meta.get("event_id") or "")
    event_name = (meta.get("event_name") or "").lower()

    if event_id and uss.webhook_event_already_processed(event_id):
        logger.info("LS webhook event %s already processed — skipping", event_id)
        return {"received": True, "duplicate": True}

    logger.info("LS webhook event received: %s (id=%s)", event_name, event_id or "n/a")

    if ls.event_is_revoke(event_name):
        from datetime import datetime, timezone
        account = uss.get_account()
        if account.get("license_key"):
            uss.set_account(
                tier="free",
                license_key=None,
                expires_at=datetime.now(timezone.utc).isoformat(),
                instance_id=None,
                customer_email=None,
            )
            logger.warning("PRO revoked via webhook event %s", event_name)
    elif ls.event_is_reactivate(event_name):
        # Don't auto-reactivate — user must explicitly re-enter the key
        # so the instance can be bound to this device.
        logger.info("Reactivation event %s noted but not auto-applied", event_name)

    if event_id:
        uss.mark_webhook_event_processed(event_id)

    return {"received": True, "processed": True, "event": event_name}


# ──────────────────────────────────────────────────────────────────────
# Privacy Vault — backup / restore endpoints
# ──────────────────────────────────────────────────────────────────────
# All routes implicitly target the ACTIVE project. The status + backup
# list + restore are scoped to the current project; the export-all /
# import-all variants iterate every project in the workspace.

class RestoreBackupRequest(BaseModel):
    filename: str   # e.g. "vault_2026-05-13.sqlite"


@router.get("/account/vault/status")
async def vault_status():
    """Vault summary for the active project — used by the UI card."""
    return _vault_backup.vault_status()


@router.get("/account/vault/backups")
async def vault_backups():
    """List of automatic snapshots for the active project, newest first."""
    return [backup_info_to_dict(b) for b in _vault_backup.list_project_backups()]


@router.post("/account/vault/backups/restore")
async def vault_restore_backup(req: RestoreBackupRequest):
    """Replace the active project's vault with one of the automatic snapshots."""
    ok = _vault_backup.restore_project_backup(req.filename)
    if not ok:
        raise HTTPException(status_code=404, detail="Backup not found or restore failed")
    return {"success": True}


@router.get("/account/vault/export")
async def vault_export(background: BackgroundTasks):
    """Download a zip of the active project's vault (privacy_vault.sqlite
    + README.txt + manifest.json)."""
    zip_path = _vault_backup.export_project_vault()
    if not zip_path:
        raise HTTPException(status_code=404, detail="No vault to export (Anonimyze never used on this project)")
    # Cleanup the temp dir after the response is sent
    background.add_task(_cleanup_export, zip_path)
    return FileResponse(
        path=str(zip_path),
        media_type="application/zip",
        filename=zip_path.name,
    )


@router.get("/account/vault/export-all")
async def vault_export_all(background: BackgroundTasks):
    """Download a single zip containing the vault of EVERY project — for
    disaster recovery / PC migration. Projects with no vault yet are
    skipped silently."""
    zip_path = _vault_backup.export_all_vaults()
    if not zip_path:
        raise HTTPException(status_code=404, detail="No vaults to export")
    background.add_task(_cleanup_export, zip_path)
    return FileResponse(
        path=str(zip_path),
        media_type="application/zip",
        filename=zip_path.name,
    )


@router.post("/account/vault/import")
async def vault_import(file: UploadFile = File(...)):
    """Restore the active project's vault from a single-project zip."""
    data = await file.read()
    ok = _vault_backup.import_vault(data)
    if not ok:
        raise HTTPException(status_code=400, detail="Import failed — invalid zip or missing vault file")
    return {"success": True}


@router.post("/account/vault/import-all")
async def vault_import_all(file: UploadFile = File(...)):
    """Restore vaults across every project listed in a global export zip.
    Returns a report listing which projects were restored and which were
    skipped (e.g. project missing locally)."""
    data = await file.read()
    report = _vault_backup.import_all_vaults(data)
    if report.get("error"):
        raise HTTPException(status_code=400, detail=report["error"])
    return report


def _cleanup_export(zip_path: Path) -> None:
    """Cleanup the temp directory used to build an export zip. Runs after
    FastAPI has streamed the file back to the client."""
    try:
        if zip_path.exists():
            zip_path.unlink()
        if zip_path.parent.exists() and zip_path.parent.name.startswith("pais_vault_export_"):
            zip_path.parent.rmdir()
    except Exception as e:
        logger.warning("Vault export cleanup failed for %s: %s", zip_path, e)
