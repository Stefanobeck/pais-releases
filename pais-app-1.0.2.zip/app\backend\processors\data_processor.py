"""
Data Processor - MANIPULATE Module per PAI Premium
Gestisce:
- Upload Excel/CSV con Smart Cleaning
- DuckDB registration
- Pandas DataFrame management
- RAG content generation
"""
import os
import re
import logging
import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from pathlib import Path

from services.sql_manager import SQLManager
from backend_config.settings import BASE_DIR

logger = logging.getLogger(__name__)


def _quote_ident(name: str) -> str:
    """Escape sicuro per identificatori DuckDB (tabelle, colonne).

    DuckDB segue lo standard SQL: una citazione doppia interna si raddoppia.
    Senza questo helper un nome colonna come `evil"; DROP TABLE x; --` (importato
    da un CSV ostile) bypasserebbe il quoting f-string e diventerebbe SQL injection.
    """
    if not isinstance(name, str):
        name = str(name)
    return '"' + name.replace('"', '""') + '"'


def _detect_header_row(probe_df) -> int:
    """Trova la prima riga che assomiglia a un header in un Excel letto SENZA
    header (`header=None`). Ritorna l'indice 0-based della riga da usare come
    header, oppure 0 se nessuna candidata e' chiaramente migliore.

    Euristica (Bug D fix 2026-05-19 dirty-data test):
      - Una row e' header-like se:
          (a) > 80% delle celle sono non-NaN, E
          (b) > 50% dei valori non-NaN sono stringhe alphanum-like
              (parole, accettiamo underscore/numero misti) e nessuno
              dei valori e' un numero "puro" (es: 12345, 1.5).
      - Scansiona le prime 10 righe e ritorna l'indice della prima che soddisfa.
      - Se nessuna scoperta entro 10 righe, fallback a header=0 (status quo).

    Limita la ricerca a 10 righe per evitare di sbagliare su sheets con un
    blocco grosso di metadati: gli Excel "umani" tipici hanno il titolo nella
    riga 0 e l'header entro riga 3.
    """
    import pandas as pd
    if probe_df is None or probe_df.empty:
        return 0

    max_scan = min(10, len(probe_df))
    n_cols = probe_df.shape[1]
    if n_cols < 2:
        return 0

    for r in range(max_scan):
        row = probe_df.iloc[r]
        non_nan = row.dropna()
        if len(non_nan) < n_cols * 0.8:
            continue
        # Conta valori "header-like": stringa, non e' un numero puro.
        header_like = 0
        for v in non_nan:
            if not isinstance(v, str):
                # numeric/datetime/bool — quasi sempre dato, non header
                try:
                    float(v)
                    continue  # numero puro, skip
                except (TypeError, ValueError):
                    pass
                # Accetta solo stringhe per header detection
                continue
            s = v.strip()
            if not s:
                continue
            # Rifiuta valori che sono numeri puri "in stringa".
            try:
                float(s.replace(',', '.'))
                continue
            except ValueError:
                pass
            header_like += 1
        if header_like > len(non_nan) * 0.5:
            return r
    return 0


def _read_excel_with_header_detection(xls_or_path, sheet_name=None):
    """Legge un Excel con auto-detection della riga header.

    Probe + read pattern:
      1. Legge le prime ~12 righe SENZA header (`header=None`).
      2. Chiama `_detect_header_row()` per trovare la riga corretta.
      3. Se header_row > 0, riapre l'Excel con `skiprows=header_row` (la riga
         diventa l'header, le righe sopra vengono saltate).
      4. Altrimenti legge normalmente.

    Mantiene back-compat con `pd.read_excel` default per i fogli "puliti"
    (titolo direttamente nella row 0).
    """
    import pandas as pd
    read_kwargs = {} if sheet_name is None else {"sheet_name": sheet_name}
    # Probe: leggi senza header, max ~12 righe.
    try:
        probe = pd.read_excel(xls_or_path, header=None, nrows=12, **read_kwargs)
    except Exception:
        # Probe fallita — fallback a read normale.
        return pd.read_excel(xls_or_path, **read_kwargs)
    header_row = _detect_header_row(probe)
    if header_row > 0:
        import logging as _logging
        _logging.getLogger(__name__).info(
            f"[SMART] Auto-detected header on row {header_row} "
            f"(skipping {header_row} top rows)"
        )
        return pd.read_excel(xls_or_path, skiprows=header_row, **read_kwargs)
    return pd.read_excel(xls_or_path, **read_kwargs)


# Separatori candidati provati in ordine; il punto-e-virgola è comune negli
# export gestionali italiani (Excel IT usa `;` perché la virgola è il decimale).
_CSV_SEP_CANDIDATES = [",", ";", "\t", "|"]


def _read_csv_robust(file_path: str) -> Tuple[pd.DataFrame, Optional[Dict]]:
    """Legge un CSV scegliendo il separatore che interpreta meglio TUTTO il file,
    non solo la riga di header.

    Il vecchio `pd.read_csv(sep=None)` faceva sniffare il separatore a pandas
    dalla sola prima riga: un file con header `;` ma corpo `,` (o viceversa)
    veniva letto col separatore sbagliato e ~tutte le righe collassavano in
    un'unica colonna piena di NaN — producendo silenziosamente un risultato
    parziale che SEMBRA pulito (es. 1 riga su 33). Qui invece proviamo ogni
    separatore, lo valutiamo sulla densità di celle valorizzate dell'intero
    file, e segnaliamo se una quota rilevante di righe resta non interpretabile.

    Returns:
        (df, warning) — warning è None se il file è stato letto integro,
        altrimenti un dict STRUTTURATO {"lost", "total", "sep"} che il frontend
        localizza via t() (disciplina i18n: niente stringhe IT nel backend).
    """
    best = None  # (score, sep, enc, df)
    for enc in ("utf-8", "latin1"):
        for sep in _CSV_SEP_CANDIDATES:
            try:
                df = pd.read_csv(
                    file_path, sep=sep, engine="python",
                    encoding=enc, on_bad_lines="skip",
                )
            except Exception:
                continue
            if df.shape[1] < 2:
                # Separatore sbagliato: tutto in una colonna. Inutile valutarlo.
                continue
            # Punteggio: n. colonne pesato sulla frazione media di celle non-null.
            # Il separatore giusto massimizza le celle valorizzate; quello
            # sbagliato lascia righe quasi tutte-NaN (padding) → score basso.
            fill = float(df.notna().to_numpy().mean()) if len(df) else 0.0
            score = df.shape[1] * fill
            if best is None or score > best[0]:
                best = (score, sep, enc, df)
        if best is not None:
            break  # un encoding ha funzionato: non serve provare latin1

    if best is None:
        # Nessun separatore produce >1 colonna: ultimo tentativo permissivo
        # (file mono-colonna legittimo o totalmente malformato).
        df = pd.read_csv(file_path, sep=None, engine="python", encoding="utf-8")
        return df, None

    _, sep, _, df = best

    # Trasparenza: conta le righe "degradate" (in un file multi-colonna, una
    # riga con <=1 cella valorizzata non si è separata correttamente) e
    # confronta con le righe-dati grezze del file.
    warning = None
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
            raw_data_lines = max(0, sum(1 for ln in fh if ln.strip()) - 1)  # -1 header
        if df.shape[1] > 1 and len(df) > 0:
            non_null_per_row = df.notna().sum(axis=1)
            degraded = int((non_null_per_row <= 1).sum())
            effective = len(df) - degraded
            lost = max(0, raw_data_lines - effective)
            # Soglia: avvisa solo se si perde una quota non trascurabile (>15%).
            if raw_data_lines > 0 and lost > 0 and lost >= raw_data_lines * 0.15:
                sep_label = {"\t": "TAB"}.get(sep, sep)
                warning = {"lost": lost, "total": raw_data_lines, "sep": sep_label}
    except Exception as e:
        logger.warning(f"CSV ingestion warning check failed: {e}")

    return df, warning


class DataProcessor:
    """
    Processore dati per MANIPULATE.
    Supporta: Excel (XLS, XLSX), CSV
    """

    def __init__(self, lang: str = "it"):
        self.lang = lang
        self.sql_manager = SQLManager()
        
        # DataFrame storage
        self.dfs: Dict[str, pd.DataFrame] = {}
        
        # Table metadata
        self.table_info: Dict[str, Dict] = {}
        
        # RAG content
        self._rag_content: str = ""

        # Ingestion warnings (es. CSV con righe non interpretabili scartate).
        # Accumulato durante load_data, letto e azzerato da chi orchestra il
        # caricamento (memorize_files) per mostrarlo all'utente.
        self.last_ingest_warnings: List[str] = []

    def set_language(self, lang: str):
        self.lang = lang

    def clear_session(self):
        """Pulisce tutti i DataFrame e registraioni DuckDB."""
        try:
            # Drop all tables physically from DuckDB
            for table_name in list(self.dfs.keys()):
                self.sql_manager.con.execute(f"DROP TABLE IF EXISTS {_quote_ident(table_name)}")
                self.sql_manager.con.unregister(table_name)
        except Exception as e:
            logger.warning(f"Error dropping tables during clear: {e}")

        self.dfs.clear()
        self.table_info.clear()
        self._rag_content = ""
        logger.info("Sessione MANIPULATE pulita (DuckDB piallato)")

    def load_data(
        self, 
        file_path: str, 
        table_name: Optional[str] = None,
        mode: str = "Analyze",
        clear_session: bool = False
    ) -> Tuple[bool, str]:
        """
        Carica DataFrame, applica Smart Cleaning e registra in DuckDB.
        
        Args:
            file_path: Percorso file Excel/CSV
            table_name: Nome tabella (opzionale, default: da filename)
            mode: Modalità (Analyze, Export to Sheet, etc.)
            clear_session: Se True, pulisce sessione prima di caricare
            
        Returns:
            (successo, messaggio)
        """
        # Clear previous data se richiesto
        if clear_session:
            self.clear_session()

        if not os.path.exists(file_path):
            return False, f"File non trovato: {file_path}"

        ext = os.path.splitext(file_path)[1].lower()
        filename = os.path.basename(file_path)

        # Determina nome tabella
        if table_name is None:
            table_name = os.path.splitext(filename)[0]
            table_name = re.sub(r'\W|^(?=\d)', '_', table_name).lower()

        logger.info(f"Loading with SMART CLEANING: {filename} (Table: {table_name})")

        try:
            loaded_items: List[Tuple[str, pd.DataFrame]] = []

            # Leggi file
            if ext == '.csv':
                # Separatore scelto valutando tutto il file (non solo l'header)
                # + trasparenza sulle righe non interpretabili (vedi _read_csv_robust).
                new_df, csv_warning = _read_csv_robust(file_path)
                if csv_warning:
                    logger.warning(
                        f"[INGEST] {filename}: {csv_warning['lost']}/{csv_warning['total']} "
                        f"rows unparseable, dropped (detected sep '{csv_warning['sep']}')"
                    )
                    self.last_ingest_warnings.append({"file": filename, **csv_warning})
                loaded_items.append((table_name, new_df))

            elif ext in ['.xlsx', '.xls']:
                xls = pd.ExcelFile(file_path)
                if len(xls.sheet_names) > 1:
                    # Multi-sheet: crea tabella per ogni sheet
                    for sheet in xls.sheet_names:
                        df_sheet = _read_excel_with_header_detection(xls, sheet_name=sheet)
                        safe_sheet = re.sub(r'[^a-zA-Z0-9]', '_', sheet).lower()
                        loaded_items.append((f"{table_name}_{safe_sheet}", df_sheet))
                else:
                    loaded_items.append((table_name, _read_excel_with_header_detection(xls)))
            else:
                return False, f"Formato non supportato: {ext}"

            # SMART CLEANING
            count_loaded = 0
            import unicodedata

            def normalize_col(col):
                s = str(col).strip().replace(' ', '_').replace('.', '')
                s = unicodedata.normalize('NFKD', s).encode('ASCII', 'ignore').decode('utf-8')
                return s

            for df_key, df in loaded_items:
                if df is None or df.empty:
                    continue

                # 1. Normalizza Nomi Colonne
                df.columns = [normalize_col(c) for c in df.columns]

                # 2. Scansione Colonne per Tipo
                for col in df.columns:
                    col_lower = col.lower()

                    if df[col].dtype == 'object':
                        # A. GLOBAL STRING CLEANING
                        df[col] = df[col].apply(lambda x: str(x).strip() if isinstance(x, str) else x)
                        # Replace common text nulls
                        df[col] = df[col].replace(
                            ['N/A', 'n.d.', 'N.A.', '-', 'null', 'nan', ''], 
                            np.nan
                        )

                        sample = df[col].dropna().head(50).astype(str)
                        if sample.empty:
                            continue

                        # B. BOOLEAN MAPPING
                        bool_map = {
                            'sì': True, 'si': True, 'yes': True, 'y': True, 
                            'vero': True, 'true': True, '1': True,
                            'no': False, 'n': False, 'falso': False, 
                            'false': False, '0': False
                        }
                        if all(val.lower() in bool_map for val in sample):
                            df[col] = df[col].map(lambda x: bool_map.get(str(x).lower(), np.nan))
                            logger.info(f"[SMART] Colonna '{col}' convertita in BOOLEAN")
                            continue

                    # C. DATE DETECTION
                    DATE_KEYWORDS = ['data', 'date', 'giorno', 'timestamp', 'signup', 'churn', 'login']
                    NUMERIC_KEYWORDS = ['days', 'lead', 'quantity', 'amount', 'price', 'cost', 'total', 'count', 'valore']

                    should_check_date = any(x in col_lower for x in DATE_KEYWORDS)
                    is_explicitly_numeric = any(x in col_lower for x in NUMERIC_KEYWORDS)

                    if should_check_date and not is_explicitly_numeric:
                        try:
                            if pd.api.types.is_numeric_dtype(df[col]):
                                logger.info(f"[SMART] Column '{col}' already numeric, skipping DATE conversion")
                            else:
                                # First pass: pandas default inference.
                                pass1 = pd.to_datetime(df[col], errors='coerce')
                                n_pass1 = int(pass1.notna().sum())
                                # Bug C fix (2026-05-19 dirty-data test): se la
                                # prima passata copre < 50% dei valori, ritenta
                                # con `format='mixed'` + `dayfirst=True`. Pandas
                                # 2.0+ con format='mixed' applica l'inferenza
                                # per-cella, gestendo dataset con date IT
                                # (06/12/2025) miste a date ISO (2024-12-06).
                                # dayfirst=True risolve l'ambiguita' DD/MM/YYYY
                                # vs MM/DD/YYYY (test empirico: 100% parsing su
                                # dirty test 50/50 ISO+DMY, vs 21% del default).
                                if n_pass1 <= len(df) * 0.5:
                                    try:
                                        pass2 = pd.to_datetime(
                                            df[col], errors='coerce',
                                            format='mixed', dayfirst=True,
                                        )
                                        n_pass2 = int(pass2.notna().sum())
                                    except (TypeError, ValueError):
                                        # `format='mixed'` non supportato (pandas < 2.0).
                                        pass2 = pd.to_datetime(df[col], errors='coerce', dayfirst=True)
                                        n_pass2 = int(pass2.notna().sum())
                                    if n_pass2 > n_pass1 and n_pass2 > len(df) * 0.5:
                                        df[col] = pass2
                                        logger.info(
                                            f"[SMART] Column '{col}' converted to DATE "
                                            f"(mixed+dayfirst, {n_pass2}/{len(df)} parsed; "
                                            f"+{n_pass2 - n_pass1} vs default)"
                                        )
                                    elif n_pass1 > len(df) * 0.5:
                                        df[col] = pass1
                                        logger.info(f"[SMART] Column '{col}' converted to DATE")
                                    # else: entrambi sotto soglia, lascia stringa.
                                elif n_pass1 > len(df) * 0.5:
                                    df[col] = pass1
                                    logger.info(f"[SMART] Column '{col}' converted to DATE")
                        except:
                            pass

                    # D. NUMERIC CONVERSION
                    if pd.api.types.is_numeric_dtype(df[col]):
                        count_loaded += 1
                        continue

                    # Try numeric conversion
                    sample = df[col].dropna().head(50).astype(str)
                    if sample.empty:
                        continue

                    # Pulizia valori numerici
                    def clean_numeric(x):
                        if not isinstance(x, str):
                            return x
                        s = x.strip().replace(' ', '').replace('.', '').replace(',', '.')
                        s = s.replace('€', '').replace('$', '').replace('£', '')
                        s = s.replace('%', '')
                        try:
                            return float(s)
                        except:
                            return np.nan

                    cleaned = df[col].apply(clean_numeric)
                    if cleaned.notna().sum() > len(df) * 0.5:
                        df[col] = cleaned
                        logger.info(f"[SMART] Colonna '{col}' convertita in NUMERIC")
                        count_loaded += 1

                # Registra in DuckDB e crea tabella fisica (Legacy alignment)
                self.dfs[df_key] = df
                try:
                    self.sql_manager.con.register(df_key, df)
                    qkey = _quote_ident(df_key)
                    self.sql_manager.con.execute(f"CREATE OR REPLACE TABLE {qkey} AS SELECT * FROM {qkey}")  # nosec B608 - identifier escaped via _quote_ident
                except Exception as sql_err:
                    logger.warning(f"DuckDB physical table creation error for {df_key}: {sql_err}")
                
                self.table_info[df_key] = self._get_table_info(df_key)
                count_loaded += 1

            # Genera RAG content
            self._rag_content = self.get_rag_content()

            logger.info(f"[SMART] Caricati {count_loaded} DataFrame e create tabelle fisiche DuckDB.")
            return True, f"Caricati {count_loaded} fogli"

        except Exception as e:
            logger.error(f"Errore caricamento dati: {e}")
            return False, str(e)

    def _get_table_info(self, table_name: str) -> Dict:
        """Ottiene info tecniche su una tabella."""
        if table_name not in self.dfs:
            return {}

        df = self.dfs[table_name]
        return {
            'name': table_name,
            'columns': list(df.columns),
            'rows': len(df),
            'dtypes': {col: str(df[col].dtype) for col in df.columns},
            'sample': df.head(3).to_dict('records')
        }

    def get_rag_content(self) -> str:
        """Genera contenuto per RAG (schema + sample)."""
        if not self.dfs:
            return ""

        parts = []
        for table_name, info in self.table_info.items():
            cols_info = ", ".join([f"{c} ({info['dtypes'].get(c, 'unknown')})" for c in info['columns'][:10]])
            parts.append(f"Tabella '{table_name}': {info['rows']} righe, Colonne: {cols_info}")

        return "\n".join(parts)

    # DuckDB/SQL reserved keywords that frequently appear as column names in
    # Italian/EN business data. When emitting the schema for LLM consumption,
    # we wrap these in double quotes so the model copies the quoted form into
    # its generated SQL. Without quoting, the LLM produces e.g. `AVG(Like)`
    # which DuckDB parses as the LIKE operator and fails with
    # `syntax error at or near ")"`.
    _SQL_RESERVED_COL_NAMES = frozenset({
        "like", "order", "group", "join", "from", "where", "select",
        "case", "when", "then", "else", "end", "as", "is", "null", "not",
        "and", "or", "on", "in", "union", "intersect", "except",
        "limit", "offset", "over", "partition", "range", "row", "rows",
        "date", "time", "timestamp", "interval", "type", "user", "comment",
        "value", "key", "name", "default", "all", "any", "between",
        "true", "false", "by", "having", "with", "into", "values",
    })

    @classmethod
    def _display_col(cls, c_name: str) -> str:
        """Wrap a column name in double quotes when it collides with a SQL
        reserved keyword. Used only for schema injection into LLM prompts."""
        return f'"{c_name}"' if c_name.lower() in cls._SQL_RESERVED_COL_NAMES else c_name

    def get_technical_schema(self, table_names: Optional[List[str]] = None) -> str:
        """
        Restituisce la struttura tecnica reale con campioni di dati (Discovery Phase).
        Usa query SQL reali per la massima fedeltà (Legacy alignment).
        """
        if not self.dfs: return "Nessuna tabella caricata."
        lines = ["### REAL DATABASE SCHEMA (TECHNICAL):"]
        
        tables_to_process = self.dfs.keys() if table_names is None else table_names
        
        for table in tables_to_process:
            if table not in self.dfs: continue
            df = self.dfs[table]
            try:
                qtable = _quote_ident(table)
                desc = self.sql_manager.con.execute(f"DESCRIBE {qtable}").df()
                lines.append(f"\nTable '{table}' ({len(df)} rows):")
                for _, row in desc.iterrows():
                    c_name = row['column_name']
                    c_type = row['column_type']
                    qcol = _quote_ident(c_name)

                    # DISCOVERY: Campiona valori reali direttamente da SQL
                    samples = ""
                    upper_type = str(c_type).upper()

                    if "VARCHAR" in upper_type:
                        try:
                            # Prende i 5 valori distinti più frequenti
                            res = self.sql_manager.con.execute(f"SELECT DISTINCT {qcol} FROM {qtable} WHERE {qcol} IS NOT NULL LIMIT 5").df()  # nosec B608 - identifiers escaped via _quote_ident
                            if not res.empty:
                                val_list = res[c_name].astype(str).tolist()
                                samples = f" | Samples: {', '.join(val_list)}"
                        except: pass
                    elif any(x in upper_type for x in ["INT", "DOUBLE", "DECIMAL", "FLOAT"]):
                        try:
                            # Per i numeri, diamo il range per far capire la scala
                            stats = self.sql_manager.con.execute(f"SELECT MIN({qcol}) as min_v, MAX({qcol}) as max_v, AVG({qcol}) as avg_v FROM {qtable}").df()  # nosec B608 - identifiers escaped via _quote_ident
                            if not stats.empty:
                                samples = f" | Range: {stats['min_v'][0]} to {stats['max_v'][0]} (Avg: {round(stats['avg_v'][0], 2)})"
                        except: pass
                    
                    lines.append(f"- {self._display_col(c_name)} ({c_type}){samples}")
            except Exception as e:
                logger.warning(f"Error describing table {table}: {e}")
                lines.append(f"- {table}: Struttura non leggibile.")
        return "\n".join(lines)

    def remove_data(self, filename: str):
        """Rimuovi un DataFrame e deregistra fisicamente da DuckDB (Legacy alignment)."""
        import os
        import re
        
        # Determina il prefisso corretto generato in load_data
        base_name = os.path.splitext(filename)[0]
        expected_prefix = re.sub(r'\W|^(?=\d)', '_', base_name).lower()
        
        # Identifica le tabelle associate a questo file
        tables_to_remove = []
        for t_name, info in self.table_info.items():
            if t_name.startswith(expected_prefix):
                tables_to_remove.append(t_name)
        
        # Se non trovate per nome, rimuovi tutto ciò che è orfano (opzionale)
        if filename in self.dfs:
            tables_to_remove.append(filename)

        for t_name in set(tables_to_remove):
            try:
                # 1. Rimuovi da DuckDB
                self.sql_manager.con.execute(f"DROP TABLE IF EXISTS {_quote_ident(t_name)}")
                self.sql_manager.con.unregister(t_name)
            except: pass
            
            # 2. Rimuovi da memoria Python
            if t_name in self.dfs: del self.dfs[t_name]
            if t_name in self.table_info: del self.table_info[t_name]
            
        self._rag_content = self.get_rag_content()
        logger.info(f"🗑️ Rimossi fisicamente dati e tabelle per: {filename}")
