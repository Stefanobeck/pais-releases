"""
auth_pro — FastAPI dependency per gate moduli PRO-only.

Quattro moduli sono "PRO-only" come da PRICING_PLAN.md §4: Manipulate Sheet,
Anonimyze, Batch, Bot Telegram. Diventano accessibili solo se il tier
effettivo è `free_trial` (primi 30gg) oppure `pro` (licenza attiva).

Dopo i 30gg di trial senza pagare → tier = `free_residual` → blocco.

Risposta 402 PAYMENT_REQUIRED con dettagli per il frontend, che mostra
un overlay friendly invece di un errore generico. La response shape e'
allineata a quello che il frontend si aspetta da useAccount hook.
"""
from __future__ import annotations

from fastapi import HTTPException


def require_pro_or_trial() -> None:
    """FastAPI dependency: solleva 402 se l'utente non e' in pro/trial.

    Usage:
        from backend_config.auth_pro import require_pro_or_trial
        @router.post("/something", dependencies=[Depends(require_pro_or_trial)])
        async def endpoint(...): ...
    """
    from services import user_settings_service as uss
    eff = uss.compute_effective_tier()
    tier = eff.get("effective_tier")
    if tier in ("pro", "free_trial"):
        return
    # 402 PAYMENT_REQUIRED — HTTP standard per "richiede pagamento".
    # Detail come STRINGA pulita (non dict) per evitare [object Object] nel
    # frontend quando viene concatenato come stringa nei toast/alert.
    # Lo status code 402 da solo basta come segnale per il frontend
    # (overlay PRO + redirect a Account tab).
    raise HTTPException(
        status_code=402,
        detail="UPGRADE_REQUIRED: questa funzione richiede una licenza PRO attiva. Interrogate, Vision e Utility restano gratis.",
    )
