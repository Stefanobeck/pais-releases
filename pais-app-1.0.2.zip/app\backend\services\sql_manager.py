"""
SQL Manager - DuckDB Singleton per PAI Premium
Gestisce connessione condivisa al database SQL.
"""
import duckdb
import os
import logging
from pathlib import Path

from backend_config.settings import BASE_DIR

logger = logging.getLogger(__name__)

# HARDENING DuckDB: l'analisi MANIPULATE esegue SQL GENERATA DA UN LLM su dati
# che possono provenire da file non fidati. Senza questa config DuckDB permette
# read_csv()/read_text()/COPY ... TO (lettura/scrittura file ARBITRARI) e
# INSTALL/LOAD httpfs (egress di rete) — sufficiente a esfiltrare/sovrascrivere
# file o a violare la garanzia "100% locale". enable_external_access=False è
# irreversibile a runtime (DuckDB non consente di riabilitarlo nella stessa
# connessione), quindi è una barriera robusta a monte, indipendente dall'LLM.
# L'ingestione legittima usa pandas + relazioni registrate, NON i reader-file
# nativi di DuckDB, quindi non è impattata.
_DUCKDB_HARDENED_CONFIG = {
    "enable_external_access": False,
    "autoinstall_known_extensions": False,
    "autoload_known_extensions": False,
}


class SQLManager:
    """
    Gestisce la connessione condivisa a DuckDB (Singleton).
    """
    _instance = None
    _con = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SQLManager, cls).__new__(cls)
            cls._instance._con = None
        return cls._instance

    @property
    def con(self):
        """Restituisce la connessione attiva."""
        if self._con is None:
            self._init_con()
        return self._con

    def _init_con(self):
        """Inizializza la connessione al database."""
        sql_path = self.get_sql_db_path()
        os.makedirs(os.path.dirname(sql_path), exist_ok=True)

        logger.info(f"Connessione SQL richiesta per: {sql_path}")
        try:
            self._con = duckdb.connect(str(sql_path), config=_DUCKDB_HARDENED_CONFIG)
            logger.info("SQL Engine connesso con successo (external access disabilitato).")
        except Exception as e:
            logger.error(f"ERRORE CRITICO Apertura SQL: {e}")
            self._con = duckdb.connect(":memory:", config=_DUCKDB_HARDENED_CONFIG)
            logger.warning("Uso database temporaneo in memoria (File bloccato).")

    def get_sql_db_path(self) -> Path:
        """Ottiene path del database SQL dal project manager (per-progetto)."""
        try:
            from backend_config.project_manager import project_manager
            if project_manager.active_project_path:
                return project_manager.get_sql_db_path()
        except Exception as e:
            logger.warning(f"Fallback to shared SQL path: {e}")

        # Fallback: usa path condiviso se nessun progetto attivo
        sql_db_dir = BASE_DIR / "sql_db"
        sql_db_dir.mkdir(parents=True, exist_ok=True)
        return sql_db_dir / "business_data.db"

    def reload_project(self):
        """Ricarica il progetto (chiude e riapre connessione)."""
        self.close()

    def close(self):
        """Chiude la connessione a DuckDB e rilascia il file."""
        if self._con:
            try:
                self._con.close()
                logger.info("SQLManager: Connessione chiusa.")
            except:
                pass
        self._con = None
        import gc
        gc.collect()
