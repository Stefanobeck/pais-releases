"""
Auth service per il backend FastAPI di PAIS.

Pattern bearer token a sessione (lifetime = boot-to-shutdown del backend):
  - Al primo accesso, genera UUID4 e persiste in `%USERPROFILE%\\.pais\\api_token`
    con ACL Windows ristretta (solo current user può leggere/scrivere).
  - Il token è recuperabile dal frontend pywebview SOLO tramite JS bridge
    (`window.pywebview.api.get_api_token()`), NON tramite HTTP. Questo
    previene che altri processi locali (curl, malware, altri user OS)
    ottengano il token via richiesta HTTP a 127.0.0.1:8000.
  - In dev mode (Vite dev server senza pywebview), l'endpoint
    `/internal/dev-token` esposto SOLO se env var `PAIS_ALLOW_DEV_TOKEN=1`.

Vedi anche middleware AuthMiddleware in questo file.
"""
import logging
import os
import secrets
import subprocess
import uuid
from pathlib import Path
from typing import Optional

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

# Singleton: il token vive in RAM per tutto il ciclo del backend Python.
# Persistito su disco per garantire stabilità tra restart (così se l'utente
# riavvia il backend ma non il frontend, il token resta coerente).
_TOKEN: Optional[str] = None


def _token_file_path() -> Path:
    """Path del file token: %USERPROFILE%\\.pais\\api_token su Windows,
    ~/.pais/api_token su POSIX. Cartella creata on-demand."""
    home = os.environ.get("USERPROFILE") or str(Path.home())
    return Path(home) / ".pais" / "api_token"


def _secure_file_acl(path: Path) -> None:
    """Restringe le ACL Windows del file token al solo current user.
    Su POSIX usa chmod 600. Errori loggati come warning ma non fatali
    (l'auth funziona comunque, solo la protezione filesystem è più debole)."""
    try:
        if os.name == "nt":
            username = os.environ.get("USERNAME")
            if not username:
                logger.warning("USERNAME env var missing, skipping ACL hardening")
                return
            # /inheritance:r rimuove ereditarietà del padre, /grant:r resetta
            # le ACL al solo current user con full control. capture_output per
            # non sporcare lo stdout del backend.
            result = subprocess.run(
                ["icacls", str(path), "/inheritance:r", "/grant:r", f"{username}:F"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                logger.warning(
                    f"icacls returned {result.returncode}: {result.stderr.strip()[:200]}"
                )
        else:
            os.chmod(path, 0o600)
    except Exception as e:
        logger.warning(f"Failed to secure token file ACL: {e}")


def get_or_create_token() -> str:
    """Ritorna il token API attivo. Genera UUID4 al primo accesso e lo
    persiste con ACL ristretta. Persistente tra restart del backend."""
    global _TOKEN
    if _TOKEN:
        return _TOKEN

    path = _token_file_path()
    # Prova a leggere il token persistito (es. dopo un restart soft del backend)
    try:
        if path.exists():
            existing = path.read_text(encoding="utf-8").strip()
            if existing and len(existing) >= 32:
                _TOKEN = existing
                return _TOKEN
    except Exception as e:
        logger.warning(f"Failed to read existing token file: {e}")

    # Genera nuovo token e persiste
    new_token = uuid.uuid4().hex + uuid.uuid4().hex  # 64 hex chars = 256 bit
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(new_token, encoding="utf-8")
        _secure_file_acl(path)
        logger.info(f"API token generated and persisted to {path}")
    except Exception as e:
        # In caso di errore di write (es. disk full, permessi cartella),
        # teniamo comunque il token in RAM. Il pywebview bridge lo passerà
        # comunque al frontend tramite memoria. Solo le sessioni multiple
        # cross-restart perderanno la persistenza.
        logger.error(f"Failed to persist API token: {e}. Token only in RAM.")

    _TOKEN = new_token
    return _TOKEN


def validate_token(provided: str) -> bool:
    """Verifica costante-temporale del token. Usa secrets.compare_digest
    per prevenire timing attacks."""
    if not provided or not _TOKEN:
        return False
    try:
        return secrets.compare_digest(provided, _TOKEN)
    except Exception:
        return False


# Path che NON richiedono autenticazione bearer:
#   - /health, /api/health: liveness probe (usato dal launcher nativo per
#     verificare che il backend sia in piedi prima di mostrare la finestra)
# Tutte le altre richieste a /api/* richiedono Authorization: Bearer <token>.
# Tutte le richieste che NON iniziano con /api/ sono static/SPA e passano
# liberamente (serving del frontend, assets, help, favicon, ecc.).
_AUTH_EXEMPT_PATHS = frozenset({"/health", "/api/health"})


class AuthMiddleware(BaseHTTPMiddleware):
    """Middleware che richiede Bearer token su tutte le route /api/* eccetto
    health checks. Le route statiche (/, /assets/*, /help/*, /favicon.svg,
    ecc.) sono pubbliche per default — il backend deve poter servire
    index.html senza autenticazione al boot del frontend, prima che questo
    abbia ottenuto il token dal pywebview bridge."""

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Health checks: sempre pubblici (liveness probe)
        if path in _AUTH_EXEMPT_PATHS:
            return await call_next(request)

        # Static + SPA serving: sempre pubblici (qualunque path non /api/)
        # Include: /, /assets/*, /help/*, /favicon.svg, /icons.svg,
        # /internal/dev-token (che si auto-protegge con env var check),
        # e qualunque altra route non-API.
        if not path.startswith("/api/"):
            return await call_next(request)

        # Da qui in giù: tutte le /api/* richiedono Bearer token valido.
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"detail": "Missing or malformed Authorization header"},
                status_code=401,
            )
        token = auth_header[7:].strip()
        if not validate_token(token):
            return JSONResponse(
                {"detail": "Invalid or expired API token"},
                status_code=401,
            )
        return await call_next(request)


class PywebviewBridge:
    """API esposta al JavaScript della WebView embed via
    `window.pywebview.api.<method>`. Funziona SOLO da dentro la WebView
    di pywebview — nessun HTTP coinvolto, nessun altro processo locale
    può chiamare questo bridge."""

    def get_api_token(self) -> str:
        return get_or_create_token()

    def select_folder(self) -> dict:
        """Apre il selettore cartelle nativo di Windows (pywebview FOLDER_DIALOG)
        e ritorna il path scelto. Usato dalla feature "USER LIBRARY" (libreria
        prompt utente) di INTERROGATE/VISION.

        Ritorna {ok: True, path: str} se l'utente sceglie una cartella,
        {ok: True, path: None} se annulla, {ok: False, error} su errore.
        Funziona solo dentro la WebView pywebview (in dev browser → no bridge)."""
        try:
            import webview
            windows = getattr(webview, "windows", None) or []
            if not windows:
                return {"ok": False, "error": "no_window"}
            result = windows[0].create_file_dialog(webview.FOLDER_DIALOG)
            if not result:
                return {"ok": True, "path": None}  # utente ha annullato
            path = result[0] if isinstance(result, (list, tuple)) else result
            return {"ok": True, "path": str(path)}
        except Exception as e:
            logger.error(f"select_folder failed: {e}")
            return {"ok": False, "error": str(e)}

    def quit_app(self) -> bool:
        """Chiude la finestra pywebview → l'app termina pulita (webview.start()
        ritorna → stop_ollama + exit). Usato dall'updater dopo aver lanciato il
        nuovo installer, così i file non restano lockati durante l'upgrade
        in-place. In dev browser (no bridge) non viene chiamato."""
        try:
            import webview
            for w in list(getattr(webview, "windows", []) or []):
                try:
                    w.destroy()
                except Exception:
                    pass
            return True
        except Exception as e:
            logger.error(f"quit_app failed: {e}")
            return False

    def launch_win11_dictation(self) -> dict:
        """Trigger Win+H sulla macchina locale per attivare il pannello di
        Voice Typing nativo di Windows 11. La trascrizione va direttamente
        nell'input focalizzato (es. la textarea della chat). NESSUN audio
        passa per PAIS — è gestito interamente dall'OS.

        PROVVISORIO: usato per test al posto di faster-whisper. Il toggle
        e' in frontend/src/components/DictationButton.tsx (USE_WIN11_DICTATION).

        Funziona solo su Windows. Ritorna {ok, error?} per il frontend.
        """
        import sys
        if sys.platform != "win32":
            return {"ok": False, "error": "win11_dictation_requires_windows"}
        try:
            import ctypes
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            VK_LWIN = 0x5B
            VK_H = 0x48
            KEYEVENTF_KEYDOWN = 0x0000
            KEYEVENTF_KEYUP = 0x0002
            # Sequenza: LWIN down → H down → H up → LWIN up
            user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYDOWN, 0)
            user32.keybd_event(VK_H, 0, KEYEVENTF_KEYDOWN, 0)
            user32.keybd_event(VK_H, 0, KEYEVENTF_KEYUP, 0)
            user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)
            return {"ok": True}
        except Exception as e:
            logger.error(f"launch_win11_dictation failed: {e}")
            return {"ok": False, "error": str(e)}
