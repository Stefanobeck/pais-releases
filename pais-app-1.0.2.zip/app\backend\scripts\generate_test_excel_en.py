"""
Generate a synthetic HR dataset (xlsx) loaded with realistic UK+US PII.

Sister script of generate_test_excel.py (IT). Drives the Anonimyze module's
"EN (Generic)" jurisdiction — exercises:
  - UK_NINO, UK_NHS, UK_PASSPORT
  - US_SSN, US_ITIN, US_EIN, US_PASSPORT, US_DRIVERS_LICENSE,
    US_BANK_ROUTING, US_BANK_ACCOUNT, US_MEDICARE, US_STATE_ZIP, US_ADDRESS
  - Global: IBAN, SWIFT_BIC, CREDIT_CARD, EMAIL, PHONE_INTL, URL, dates

Mix UK/US in one file to verify the EN jurisdiction unification.
"""

import random
import string
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(7)  # reproducible runs

ROWS = 100
LOCALE_WEIGHTS = {"UK": 0.5, "US": 0.5}
OUT_DIR = Path(__file__).resolve().parents[2] / "test_formats"
OUT_PATH = OUT_DIR / "test_hr_dataset_en.xlsx"

# ---------- name pools ----------
UK_FIRST = ["Oliver", "Amelia", "George", "Isla", "Harry", "Olivia", "Jack", "Emily",
            "Noah", "Ava", "Charlie", "Mia", "Thomas", "Sophia", "James", "Grace",
            "William", "Lily", "Henry", "Freya"]
UK_LAST = ["Smith", "Jones", "Taylor", "Brown", "Williams", "Wilson", "Johnson",
           "Davies", "Robinson", "Wright", "Thompson", "Evans", "Walker", "White",
           "Roberts", "Green", "Hall", "Wood", "Jackson", "Clarke"]

US_FIRST = ["Liam", "Emma", "Noah", "Olivia", "Ethan", "Sophia", "Mason", "Isabella",
            "Logan", "Mia", "Lucas", "Charlotte", "Jackson", "Amelia", "Aiden", "Harper",
            "Caleb", "Evelyn", "Owen", "Abigail"]
US_LAST = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
           "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
           "Thomas", "Taylor", "Moore", "Jackson", "Martin"]

# ---------- geo pools ----------
# (city, postcode, county/state, country_label)
UK_CITIES = [
    ("London", "SW1A 1AA", "Greater London"),
    ("Manchester", "M1 1AE", "Greater Manchester"),
    ("Birmingham", "B1 1AA", "West Midlands"),
    ("Edinburgh", "EH1 1YZ", "Lothian"),
    ("Bristol", "BS1 4ST", "Bristol"),
    ("Leeds", "LS1 4DT", "West Yorkshire"),
    ("Glasgow", "G1 1XQ", "Strathclyde"),
    ("Liverpool", "L1 8JQ", "Merseyside"),
]
# (city, state_code, zip)
US_CITIES = [
    ("New York", "NY", "10001"),
    ("Los Angeles", "CA", "90001"),
    ("Chicago", "IL", "60601"),
    ("Houston", "TX", "77001"),
    ("Phoenix", "AZ", "85001"),
    ("Philadelphia", "PA", "19101"),
    ("San Antonio", "TX", "78201"),
    ("Boston", "MA", "02108"),
    ("Seattle", "WA", "98101"),
    ("Miami", "FL", "33101"),
]

UK_STREETS = ["High Street", "Church Lane", "Station Road", "Main Street",
              "Park Road", "Victoria Road", "Queens Road", "King Street"]
US_STREETS = ["Maple Street", "Oak Avenue", "Elm Boulevard", "Cedar Lane",
              "Pine Road", "Washington Drive", "Lincoln Avenue", "Lakeview Court"]

DEPARTMENTS = ["Engineering", "Sales", "Marketing", "HR", "Finance", "Operations",
               "Legal", "R&D", "Customer Success", "Product"]
JOB_TITLES = {
    "Engineering": ["Software Engineer", "Senior SWE", "Tech Lead", "Engineering Manager", "DevOps Engineer", "QA Engineer"],
    "Sales": ["Account Executive", "Sales Manager", "Key Account Manager", "BDR", "Inside Sales Rep"],
    "Marketing": ["Marketing Specialist", "Brand Manager", "Content Strategist", "Growth Lead", "SEO Manager"],
    "HR": ["HR Business Partner", "Recruiter", "HR Director", "People Ops Manager"],
    "Finance": ["Financial Analyst", "Controller", "CFO", "Accountant", "Treasury Manager"],
    "Operations": ["Operations Manager", "Supply Chain Specialist", "Logistics Coordinator"],
    "Legal": ["Legal Counsel", "Paralegal", "Compliance Officer", "GC"],
    "R&D": ["Research Scientist", "Data Scientist", "ML Engineer", "Principal Researcher"],
    "Customer Success": ["CS Manager", "CS Specialist", "Onboarding Lead", "VP Customer Success"],
    "Product": ["Product Manager", "Senior PM", "VP Product", "Associate PM"],
}
CONTRACT_TYPES = ["Permanent", "Fixed-term", "Internship", "Consultant", "Part-time"]
OFFICES = ["London HQ", "New York Office", "San Francisco Office", "Remote",
           "Hybrid-London", "Hybrid-NY", "Boston Office"]
BANKS_UK = ["Barclays", "HSBC UK", "Lloyds Bank", "NatWest", "Santander UK"]
BANKS_US = ["Chase", "Bank of America", "Wells Fargo", "Citibank", "U.S. Bank"]

LANGS = ["EN", "ES", "FR", "DE", "IT", "ZH"]
RATINGS = [1, 2, 3, 4, 5]

# ---------- ID generators ----------
def ssn_us() -> str:
    # Avoid invalid SSA areas (000, 666, 9XX). The latter is reserved for ITINs.
    area = random.randint(1, 665)
    if area == 666:
        area = 100
    group = random.randint(1, 99)
    serial = random.randint(1, 9999)
    return f"{area:03d}-{group:02d}-{serial:04d}"


def itin_us() -> str:
    # ITIN: starts with 9, group in 50-65,70-88,90-92,94-99
    group = random.choice(list(range(50, 66)) + list(range(70, 89)) + list(range(90, 93)) + list(range(94, 100)))
    serial = random.randint(1, 9999)
    return f"9{random.randint(0,9)}{random.randint(0,9)}-{group:02d}-{serial:04d}"


def ein_us() -> str:
    return f"{random.randint(10,99):02d}-{random.randint(0, 9999999):07d}"


def passport_9digit() -> str:
    return f"{random.randint(100000000, 999999999)}"


def drivers_license_us() -> str:
    prefix_len = random.choice([1, 2])
    prefix = "".join(random.choices(string.ascii_uppercase, k=prefix_len))
    digits_len = random.choice([6, 7, 8])
    digits = "".join(random.choices(string.digits, k=digits_len))
    return prefix + digits


def routing_us() -> str:
    return f"{random.randint(100000000, 999999999)}"


def account_us() -> str:
    length = random.randint(8, 12)
    return "".join(random.choices(string.digits, k=length))


def medicare_us() -> str:
    return "".join(random.choices(string.digits, k=10))


def nino_uk() -> str:
    # Two letters (no D, F, I, Q, U, V; nor O at index 1) — simplified to A-Z minus problematic
    valid_first = "ABCEGHJKLMNOPRSTWXYZ"
    valid_second = "ABCEGHJKLMNPRSTWXYZ"
    p = random.choice(valid_first) + random.choice(valid_second)
    digits = f"{random.randint(0,99):02d} {random.randint(0,99):02d} {random.randint(0,99):02d}"
    suffix = random.choice("ABCD")
    return f"{p} {digits} {suffix}"


def nhs_uk() -> str:
    return f"{random.randint(100,999):03d} {random.randint(100,999):03d} {random.randint(1000,9999):04d}"


def iban_uk() -> str:
    bank = "".join(random.choices(string.ascii_uppercase, k=4))
    sort = "".join(random.choices(string.digits, k=6))
    acc = "".join(random.choices(string.digits, k=8))
    return f"GB{random.randint(10,99)}{bank}{sort}{acc}"


def sort_code_uk() -> str:
    return f"{random.randint(10,99):02d}-{random.randint(10,99):02d}-{random.randint(10,99):02d}"


def swift_bic(country: str) -> str:
    bank = "".join(random.choices(string.ascii_uppercase, k=4))
    location = "".join(random.choices(string.ascii_uppercase + string.digits, k=2))
    branch = "".join(random.choices(string.ascii_uppercase + string.digits, k=3)) if random.random() > 0.5 else ""
    return f"{bank}{country}{location}{branch}"


def credit_card_visa() -> str:
    # Visa: starts with 4, 16 digits, but we don't enforce Luhn (the regex doesn't validate it)
    return f"4{random.randint(100, 999):03d} {random.randint(1000, 9999):04d} {random.randint(1000, 9999):04d} {random.randint(1000, 9999):04d}"


def phone_uk() -> str:
    return f"+44 20 {random.randint(1000,9999)} {random.randint(1000,9999)}"


def mobile_uk() -> str:
    return f"+44 7{random.randint(100,999):03d} {random.randint(100000,999999)}"


def phone_us() -> str:
    return f"+1 {random.randint(200,999):03d}-{random.randint(200,999):03d}-{random.randint(0,9999):04d}"


def mobile_us() -> str:
    return f"+1 ({random.randint(200,999):03d}) {random.randint(200,999):03d}-{random.randint(0,9999):04d}"


def random_dob(min_age=22, max_age=62) -> date:
    today = date.today()
    age = random.randint(min_age, max_age)
    return today - timedelta(days=age * 365 + random.randint(0, 364))


def random_hire_date() -> date:
    today = date.today()
    return today - timedelta(days=random.randint(60, 365 * 18))


# ---------- per-locale builder ----------
def build_person(idx: int) -> dict:
    locales = list(LOCALE_WEIGHTS.keys())
    weights = [LOCALE_WEIGHTS[k] for k in locales]
    locale = random.choices(locales, weights=weights)[0]
    sex = random.choice(["M", "F"])
    dob = random_dob()
    hire = random_hire_date()

    if locale == "UK":
        fn = random.choice(UK_FIRST); ln = random.choice(UK_LAST)
        city, postcode, county = random.choice(UK_CITIES)
        street = f"{random.randint(1,200)} {random.choice(UK_STREETS)}"
        country = "United Kingdom"
        tax_id = nino_uk()  # National Insurance Number
        nhs = nhs_uk()
        passport = passport_9digit()
        ssn = ""
        itin = ""
        ein = ""
        drivers = ""
        medicare = ""
        bank_routing = ""
        bank_account = ""
        zip_or_postcode = postcode
        state_or_county = county
        iban = iban_uk()
        bank = random.choice(BANKS_UK)
        bic = swift_bic("GB")
        phone = phone_uk(); mobile = mobile_uk()
        currency = "GBP"
        domain = "company.co.uk"
        country_short = "UK"
    else:
        fn = random.choice(US_FIRST); ln = random.choice(US_LAST)
        city, state, zipc = random.choice(US_CITIES)
        street = f"{random.randint(1,9999)} {random.choice(US_STREETS)}"
        country = "United States"
        tax_id = ssn_us()
        nhs = ""
        passport = passport_9digit()
        ssn = tax_id
        itin = itin_us() if random.random() > 0.85 else ""
        ein = ein_us() if random.random() > 0.7 else ""
        drivers = drivers_license_us()
        medicare = medicare_us() if random.random() > 0.8 else ""
        bank_routing = routing_us()
        bank_account = account_us()
        zip_or_postcode = zipc
        state_or_county = state
        iban = ""  # US doesn't use IBAN domestically
        bank = random.choice(BANKS_US)
        bic = swift_bic("US")
        phone = phone_us(); mobile = mobile_us()
        currency = "USD"
        domain = "company.com"
        country_short = "US"

    dept = random.choice(DEPARTMENTS)
    role = random.choice(JOB_TITLES[dept])
    contract = random.choice(CONTRACT_TYPES)
    rating = random.choice(RATINGS)
    kpi = random.randint(40, 99)
    salary = random.randint(35000, 180000)
    bonus = round(salary * random.uniform(0.0, 0.30))
    years = max(0, (date.today() - hire).days // 365)
    langs_spoken = random.sample(LANGS, k=random.randint(1, 3))

    # Cross-reference PII inside free-text notes
    active = list(LOCALE_WEIGHTS.keys())
    pool_first = sum(([UK_FIRST, US_FIRST][["UK","US"].index(k)] for k in active), [])
    pool_last = sum(([UK_LAST, US_LAST][["UK","US"].index(k)] for k in active), [])
    pool_phone = [{"UK": phone_uk, "US": phone_us}[k] for k in active]

    peer_first = random.choice(pool_first); peer_last = random.choice(pool_last)
    peer_email = f"{peer_first.lower()}.{peer_last.lower()}@{domain}"
    peer_phone = random.choice(pool_phone)()

    manager_first = random.choice(pool_first); manager_last = random.choice(pool_last)
    manager_email = f"{manager_first.lower()}.{manager_last.lower()}@{domain}"

    hr_first = random.choice(pool_first); hr_last = random.choice(pool_last)
    cfo_first = random.choice(pool_first); cfo_last = random.choice(pool_last)

    notes = random.choice([
        f"Reports to {manager_first} {manager_last} ({manager_email}). Strong technical skills, candidate for promotion in Q4 2026.",
        f"Performance review held on {hire + timedelta(days=365):%Y-%m-%d} with HR partner {hr_first} {hr_last} ({hr_first.lower()}.{hr_last.lower()}@{domain}). Compensation revised.",
        f"On parental leave until {date.today() + timedelta(days=120):%Y-%m-%d}. Replacement: {peer_first} {peer_last}, contact {peer_phone}.",
        f"Disciplinary note 2025-11-03: late submission of expense report. Discussed with manager {manager_last}.",
        f"Top performer Q1 2026. Bonus approved by CFO {cfo_first} {cfo_last} ({cfo_first.lower()}.{cfo_last.lower()}@{domain}).",
        "No open issues. Engaged and proactive. Volunteered for diversity committee.",
        f"Customer escalation 2026-03-12: complaint forwarded by client {peer_first} {peer_last}, see SSN reference {ssn_us()}.",
    ])
    feedback = random.choice([
        f"Excellent collaborator. Mentored junior {peer_first} {peer_last} in Q2.",
        f"Needs to improve communication with cross-functional teams. Coaching by {manager_first}.",
        "Domain expert. Goes the extra mile. Frequent positive client feedback.",
        f"Conflict reported by peer {peer_first} {peer_last} on 2026-02-14, resolved via mediation.",
        "Highly engaged. Drives team morale.",
        f"Wire transfer issue on 2026-04-02 — BIC {swift_bic('GB' if locale == 'UK' else 'US')} flagged.",
    ])
    goals = random.choice([
        "Become Tech Lead within 18 months. Take ownership of the data platform migration.",
        f"Complete Executive MBA at {random.choice(['Wharton','LBS','Stanford GSB','MIT Sloan'])} by 2027.",
        f"Relocate to {random.choice(['London','New York','Boston','San Francisco'])} office by end of 2026.",
        "Expand client portfolio in EMEA. Exceed $1.5M ARR.",
        "Lead the SOC 2 Type II compliance initiative.",
        f"Open a corporate Visa card — pre-approved card {credit_card_visa()}.",
    ])

    return {
        "employee_id": f"EMP-{idx:04d}",
        "first_name": fn,
        "last_name": ln,
        "sex": sex,
        "date_of_birth": dob.isoformat(),
        "country_short": country_short,
        "tax_id": tax_id,            # SSN (US) or NINO (UK)
        "ssn": ssn,                  # populated only for US
        "itin": itin,                # rare US ITINs
        "ein": ein,                  # rare US EINs
        "nhs_number": nhs,           # populated only for UK
        "passport_number": passport, # 9 digits (UK + US)
        "drivers_license": drivers,  # populated only for US
        "medicare_id": medicare,     # rare US Medicare IDs
        "email_corporate": f"{fn.lower()}.{ln.lower()}@{domain}",
        "email_personal": f"{fn.lower()}{random.randint(70,99)}@{random.choice(['gmail.com','yahoo.com','outlook.com','protonmail.com'])}",
        "phone_office": phone,
        "phone_mobile": mobile,
        "address": street,
        "city": city,
        "state_or_county": state_or_county,
        "postal_code": zip_or_postcode,
        "country": country,
        "department": dept,
        "job_title": role,
        "manager_name": f"{manager_first} {manager_last}",
        "manager_email": manager_email,
        "hire_date": hire.isoformat(),
        "contract_type": contract,
        "office_location": random.choice(OFFICES),
        "badge_number": f"BDG-{random.randint(10000,99999)}",
        "currency": currency,
        "base_salary": salary,
        "annual_bonus": bonus,
        "iban": iban,                       # populated only for UK
        "bank_routing_us": bank_routing,    # populated only for US
        "bank_account_us": bank_account,    # populated only for US
        "swift_bic": bic,
        "bank_name": bank,
        "credit_card_corporate": credit_card_visa() if random.random() > 0.7 else "",
        "last_review_rating": rating,
        "kpi_score": kpi,
        "languages_spoken": ", ".join(langs_spoken),
        "years_in_company": years,
        "manager_notes": notes,
        "peer_feedback": feedback,
        "career_goals": goals,
    }


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = [build_person(i + 1) for i in range(ROWS)]
    df = pd.DataFrame(rows)

    with pd.ExcelWriter(OUT_PATH, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Employees", index=False)

        dept_summary = (df.groupby("department")
                          .agg(headcount=("employee_id", "count"),
                               avg_salary=("base_salary", "mean"),
                               avg_kpi=("kpi_score", "mean"))
                          .round(0)
                          .reset_index())
        dept_summary.to_excel(writer, sheet_name="DeptSummary", index=False)

    active = [k for k, w in LOCALE_WEIGHTS.items() if w > 0]
    print(f"OK -> {OUT_PATH}")
    print(f"   {len(df)} rows x {len(df.columns)} cols")
    print(f"   Locales active: {', '.join(active)}")
    print(f"   PII fields:")
    print(f"     UK: NINO, NHS, UK passport, UK postcode, GB IBAN, sort code")
    print(f"     US: SSN, ITIN, EIN, US passport, drivers license, ZIP, state,")
    print(f"         routing/account, Medicare, US street address")
    print(f"     Global: SWIFT/BIC, credit card, email, phone, dates, free-text notes")


if __name__ == "__main__":
    main()
