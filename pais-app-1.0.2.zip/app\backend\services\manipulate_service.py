"""
Manipulate Service - Business Logic per MANIPULATE SHEET
Gestisce:
- Upload Excel/CSV con staging (max 2 file)
- Memorizzazione in DuckDB
- SQL generation con qwen3-coder:30b
- Export Excel con formattazione
- Analisi testuale con streaming
"""
import os
import json
import asyncio
import uuid
import time
import re
from typing import List, Dict, Optional, Callable, AsyncGenerator, Tuple
from pathlib import Path
import logging
import pandas as pd

from processors.ollama_client import OllamaClient, AUTO_CTX
from processors.data_processor import DataProcessor

# Coder Manipulate alternativi (HIGH RAM / LOW RAM). Ne basta uno: se quello
# configurato non è installato si fa fallback all'altro (vedi _resolve_coder).
_MANIP_CODERS = ('qwen3-coder:30b', 'qwen2.5-coder:7b')
from processors.document_processor import DocumentProcessor
from processors.charter import ManipulateCharter
from processors.styler import ManipulateStyler
from services.i18n_service import i18n
from services.suggestions_service import SuggestionsService
from backend_config.settings import BASE_DIR, settings
from backend_config.project_manager import project_manager

logger = logging.getLogger(__name__)


# SQL pre-execution controller — blocks known cross-dialect leaks from
# PostgreSQL / MySQL / T-SQL / BigQuery / Oracle that qwen3-coder regularly
# emits despite the DuckDB cheatsheet in the system prompt. Each entry maps
# a regex (case-insensitive) to the user-facing message we feed back as
# error_context for the next retry attempt — the model sees a specific
# fix, not just DuckDB's generic Binder Error.
_DIALECT_FORBIDDEN: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\bdate_part\s*\(", re.I),
     "You used `date_part(...)`. In DuckDB use `EXTRACT(field FROM column)` "
     "(e.g. `EXTRACT(year FROM tx.Date)`). Rewrite."),
    (re.compile(r"\bdate_sub\s*\(", re.I),
     "You used `date_sub(...)` (MySQL). In DuckDB use `col - INTERVAL N DAY`. Rewrite."),
    (re.compile(r"\bdate_add\s*\(", re.I),
     "You used `date_add(...)`. In DuckDB use `col + INTERVAL N DAY`. Rewrite."),
    (re.compile(r"\bDATEADD\s*\(", re.I),
     "You used `DATEADD(...)` (T-SQL/BigQuery). In DuckDB use `col + INTERVAL N DAY`. Rewrite."),
    (re.compile(r"\bDATEDIFF\s*\(", re.I),
     "You used `DATEDIFF(...)` (T-SQL/BigQuery). In DuckDB use `date_diff('day', a, b)`. Rewrite."),
    (re.compile(r"\bSTR_TO_DATE\s*\(", re.I),
     "You used `STR_TO_DATE(...)` (MySQL). In DuckDB use `CAST(col AS DATE)`. Rewrite."),
    (re.compile(r"\bTO_DATE\s*\(", re.I),
     "You used `TO_DATE(...)` (Oracle). In DuckDB use `CAST(col AS DATE)`. Rewrite."),
    (re.compile(r"\bIIF\s*\(", re.I),
     "You used `IIF(...)` (T-SQL). In DuckDB use `CASE WHEN cond THEN a ELSE b END`. Rewrite."),
]


# Reserved keywords that the model occasionally picks as table aliases (often
# from natural-language abbreviation, e.g. "Agent Targets" → `at`). DuckDB
# rejects them with a generic Parser Error from which the model can't recover
# even when told. Cheaper to rewrite them in-place than to retry. Each entry
# maps the bad alias to a safe replacement that does NOT collide with anything
# in the schema we ship — the trailing `x` is enough to make it unique.
_RESERVED_ALIASES: List[Tuple[str, str]] = [
    ("at", "atx"),
    # add more here if other reserved keywords surface as aliases.
]


def _autofix_reserved_aliases(sql: str) -> Tuple[str, List[str]]:
    """Rename any reserved-keyword table alias in `sql` to a safe form.

    Looks for two patterns per (bad, good) pair:
      1. `FROM <table> <bad>` / `JOIN <table> <bad>` / `FROM <table> AS <bad>`
         — the alias declaration.
      2. `<bad>.<column>` — usages of the alias in dotted notation.

    Returns the (possibly rewritten) sql plus the list of renames performed
    (for logging). When no match is found, returns the original sql unchanged.
    """
    renames: List[str] = []
    if not sql:
        return sql, renames
    for bad, good in _RESERVED_ALIASES:
        # alias declarations: FROM/JOIN <table> [AS] <bad>
        decl_pat = re.compile(
            rf"(\b(?:FROM|JOIN)\s+\w+(?:\s+AS)?\s+){bad}\b",
            re.IGNORECASE,
        )
        new_sql, n_decl = decl_pat.subn(rf"\1{good}", sql)
        # alias usages: <bad>.column
        usage_pat = re.compile(rf"\b{bad}\.", re.IGNORECASE)
        new_sql, n_use = usage_pat.subn(f"{good}.", new_sql)
        if n_decl + n_use:
            renames.append(f"{bad}→{good} ({n_decl} decl, {n_use} usages)")
            sql = new_sql
    return sql, renames


def _dialect_check(sql: str) -> Optional[str]:
    """Return a targeted retry message if `sql` contains a known foreign-dialect
    pattern, otherwise None. Runs before DuckDB execution so we can autocorrect
    with a clear hint instead of a generic Binder Error.
    """
    if not sql:
        return None
    for pat, msg in _DIALECT_FORBIDDEN:
        if pat.search(sql):
            return msg
    return None


# SECURITY: blocklist di funzioni/statement DuckDB che toccano filesystem, rete
# o estensioni. L'analisi MANIPULATE deve essere SELECT-only sulle tabelle della
# sessione. Difesa primaria = enable_external_access=False (sql_manager); questo
# è il secondo livello: rifiuto pulito + messaggio chiaro PRIMA dell'esecuzione,
# così la SQL malevola non viene nemmeno tentata e non spreca retry.
#  - read_*( / sniff_csv( / glob( / parquet_scan(  -> lettura file arbitrari
#  - COPY/ATTACH/INSTALL/LOAD/EXPORT/IMPORT/PRAGMA  -> write/extension/db (ancorati
#    a inizio-statement o dopo ';' per non colpire identificatori legittimi)
_DANGEROUS_SQL = re.compile(
    r"\bread_(?:csv|csv_auto|parquet|json|json_auto|ndjson|text|blob)\s*\("
    r"|\b(?:sniff_csv|parquet_scan|read_blob|glob)\s*\("
    r"|(?:^|;)\s*(?:copy|attach|detach|install|load|export|import|pragma)\b",
    re.IGNORECASE,
)


def _reject_dangerous_sql(sql: str) -> Optional[str]:
    """Ritorna il token vietato se la SQL generata tenta accesso file/rete/estensioni,
    altrimenti None. Hard-fail (no retry): indica injection, non un errore di sintassi."""
    if not sql:
        return None
    m = _DANGEROUS_SQL.search(sql)
    return m.group(0).strip() if m else None


# When the user prompt asks for a correlation/relationship/impact between
# two variables, the SQL output MUST include a CORR/COVAR/STDDEV-based
# statistic. The system prompt (rule #7) tells the model to do this, but
# qwen3-coder routinely drops the correlation and returns only the
# aggregates. This check catches the omission and forces a retry with a
# specific hint. Semantic-review evidence: ~10 sample affected across
# Job 1 batches (correlazione richiesta omessa pattern).
_CORR_INTENT_RX = re.compile(
    r"\b(correlaz\w*|correla\b|relazione\s+tra|impatto\s+di|correlation|relationship\s+between)\b",
    re.IGNORECASE,
)
_CORR_FN_RX = re.compile(r"\b(CORR|COVAR|STDDEV|VAR_POP|VAR_SAMP)\s*\(", re.IGNORECASE)


def _correlation_intent_check(prompt: str, sql: str) -> Optional[str]:
    """If the prompt asks for correlation/relationship but the SQL has no
    CORR/COVAR/STDDEV, return a retry hint. Otherwise None.
    """
    if not prompt or not sql:
        return None
    if _CORR_INTENT_RX.search(prompt) and not _CORR_FN_RX.search(sql):
        return (
            "Your SQL doesn't include `CORR(X, Y)` (or COVAR/STDDEV), but the user's "
            "prompt explicitly asks for a correlation/relationship/impact between "
            "variables. In DuckDB, use `CORR(col1, col2)` in the SELECT clause. "
            "If the prompt also says 'per X' / 'for each X', compute one CORR "
            "value per group via subquery or window. Rewrite."
        )
    return None


# Pareto/80-20/ABC analyses systematically stop too early on qwen3-coder
# (training-data bias toward `WHERE cum_pct <= 80`, which excludes the row
# that first crosses the threshold). The system prompt rule #8 documents
# the correct pattern but the model often ignores it. This post-execution
# check is deterministic: it inspects the produced DataFrame and forces a
# retry if the last cum_pct row is below the target. Empirically grounded:
# all 9 Pareto outputs from 2026-05-13 spot test stopped at 40–78%.
_PARETO_INTENT_RX = re.compile(
    r"\b(pareto|80\s*[/-]\s*20|ABC\s+analy|80\s*%|cum_pct|cumulativa|cumulative)\b",
    re.IGNORECASE,
)
_PARETO_THRESHOLD_RX = re.compile(r"\b(\d{2})\s*%")  # captures "80%", "75 %", etc.
_CUM_COL_HINTS = ("cum_pct", "cumulative_pct", "cumulative_percentage",
                  "percentuale_cumulativa", "cum_percent", "cum_perc")


def _pareto_completion_check(prompt: str, result_df) -> Optional[str]:
    """If the prompt is a Pareto/80%/ABC query and the produced output stops
    before reaching the target threshold (default 80), return a retry hint.

    The check is defensive: only fires when (a) the prompt clearly matches
    Pareto intent, (b) the output has a recognizable cum_pct column,
    (c) the max value in that column is strictly below the threshold.
    Otherwise None (no false positives on non-Pareto queries).
    """
    if result_df is None or prompt is None:
        return None
    if not _PARETO_INTENT_RX.search(prompt):
        return None
    # Locate a cum_pct-like column (case-insensitive substring match).
    cum_col = None
    for col in result_df.columns:
        cl = str(col).lower()
        if any(h in cl for h in _CUM_COL_HINTS):
            cum_col = col
            break
    if cum_col is None:
        return None  # not a Pareto-shaped output, leave it alone
    try:
        max_cum = float(result_df[cum_col].max())
    except Exception:
        return None
    # Threshold detection: extract first 2-digit % from prompt (50..95 range
    # is the plausible Pareto/ABC threshold; reject 100 since it's tautological).
    threshold = 80.0
    for m in _PARETO_THRESHOLD_RX.finditer(prompt):
        try:
            v = float(m.group(1))
        except Exception:
            continue
        if 50 <= v < 100:
            threshold = v
            break
    if max_cum >= threshold - 0.01:
        return None  # already crosses, all good
    # B608 false positive: la stringa SQL qui non viene MAI eseguita, è solo
    # testo-prompt mostrato all'LLM come template di rewrite. Nessuna injection
    # possibile, non c'è connessione database in questa funzione.
    return (
        f"Your output's `{cum_col}` column max is {max_cum:.2f}, which is below "  # nosec B608
        f"the target threshold {threshold:.0f}%. A Pareto/80-20 analysis MUST "
        f"include the row that FIRST CROSSES the threshold — otherwise the "
        f"analysis is incomplete. NEVER use `WHERE cum_pct <= {threshold:.0f}` "
        f"(that stops one row too early). Use the prev-cum pattern instead:\n"
        f"    WITH ranked AS (\n"
        f"      SELECT col, value,\n"
        f"             SUM(value) OVER (ORDER BY value DESC) AS cum,\n"
        f"             SUM(value) OVER (ORDER BY value DESC) - value AS prev_cum,\n"
        f"             SUM(value) OVER () AS total\n"
        f"      FROM source)\n"
        f"    SELECT col, value, cum / NULLIF(total,0) * 100 AS cum_pct\n"
        f"    FROM ranked\n"
        f"    WHERE prev_cum / NULLIF(total,0) < {threshold/100:.2f}\n"
        f"    ORDER BY value DESC;\n"
        f"Rewrite the SQL with this pattern."
    )


# Pearson on small groups (n < 3) or degenerate data (constant column) produces
# NaN, ±inf, or values outside [-1, 1] in DuckDB. The model emits these without
# guards, then they show up in the user-facing output as nonsense (e.g. corr
# of -12.99 from yesterday's verify). This check is defensive: only fires when
# a correlation-shaped column is present.
_CORR_COL_HINTS = ("corr", "correlazione", "correlation", "pearson", "spearman")


def _correlation_validity_check(prompt: str, result_df) -> Optional[str]:
    """If the prompt asked for correlation and the output contains NaN / |x|>1
    in a corr-named column, return a retry hint to clean up small-group cases.
    """
    if result_df is None or prompt is None:
        return None
    if not _CORR_INTENT_RX.search(prompt):
        return None
    # Locate correlation column(s).
    corr_cols = [c for c in result_df.columns if any(h in str(c).lower() for h in _CORR_COL_HINTS)]
    if not corr_cols:
        return None
    bad: List[Tuple[str, str]] = []  # (col, reason)
    for col in corr_cols:
        ser = pd.to_numeric(result_df[col], errors="coerce")
        if ser.isna().any():
            bad.append((str(col), "contains NaN values (likely groups with n<3 or constant column)"))
            continue
        try:
            max_abs = float(ser.abs().max())
        except Exception:
            continue
        if max_abs > 1.0001:  # small tolerance for fp noise
            bad.append((str(col), f"contains values with |x| > 1 (max abs {max_abs:.4f}) — Pearson must be in [-1, 1]"))
    if not bad:
        return None
    reasons = "; ".join(f"`{c}` {r}" for c, r in bad)
    return (
        f"Your correlation output has invalid values: {reasons}. "
        "Fix the SQL:\n"
        "  1) For each group, ensure both columns are numeric (CAST AS DOUBLE if needed).\n"
        "  2) Skip groups where COUNT(*) < 3 or STDDEV_POP(col) = 0 — they cannot have a valid Pearson. "
        "Wrap CORR(x,y) in `CASE WHEN COUNT(*) >= 3 AND STDDEV_POP(x) > 0 AND STDDEV_POP(y) > 0 THEN CORR(x,y) ELSE NULL END`.\n"
        "  3) Never report Pearson on a categorical column directly — encode as numeric or drop. Rewrite."
    )


# Generic NaN-dominance check (Controller-stage companion): even when the
# query is not correlation-specific, the output can be dominated by NaN
# (z-score on groups with constant column, division by zero unmasked, MIN
# /MAX over empty filter, etc.) — see audit 2026-05-14 "rotti": 3 of 9 had
# all-NaN main columns. The rule: if the LAST non-key column (the metric
# the user actually asked for) is >50% NaN AND has at least 2 rows, force
# a retry with a hint to add HAVING / NULLIF / sanity filter.
def _nan_dominant_check(prompt: str, result_df) -> Optional[str]:
    if result_df is None or len(result_df) < 2:
        return None
    # Skip when correlation validity check already covers this — avoid
    # double-firing on the same retry attempt.
    if _CORR_INTENT_RX.search(prompt or ""):
        return None
    # Identify the "main" output column: last numeric column in the frame
    # (LLM convention is dimension first, metric last).
    numeric_cols = [c for c in result_df.columns
                    if pd.api.types.is_numeric_dtype(result_df[c])]
    if not numeric_cols:
        return None
    target = numeric_cols[-1]
    ser = pd.to_numeric(result_df[target], errors="coerce")
    nan_ratio = ser.isna().mean()
    if nan_ratio < 0.5:
        return None
    return (
        f"Your SQL output has the main metric column `{target}` with "
        f"{nan_ratio:.0%} NaN values across {len(result_df)} rows — that "
        "is degenerate. Common causes and fixes:\n"
        "  1) Aggregation on groups that don't satisfy a precondition "
        "(STDDEV on n<2, CORR on n<3, division by zero): "
        "add `HAVING COUNT(*) >= 5` and wrap any division denominator in "
        "`NULLIF(..., 0)`.\n"
        "  2) Window function ordered by the wrong dimension (e.g. LAG "
        "across unrelated rows): add a correct `PARTITION BY` clause.\n"
        "  3) Filter that no row satisfies (e.g. status = 'X' that never "
        "occurs): drop or relax the filter, or add a sanity COUNT(*)>0 "
        "check.\n"
        "Rewrite the query so the main metric is computable for the "
        "majority of rows."
    )


# Top-N per group misuse: when the user asks for "top N per X" / "for each X",
# the model often emits a bare `LIMIT N` instead of `ROW_NUMBER() OVER (PARTITION
# BY X ORDER BY ...) AS rn WHERE rn <= N`. The result is N global rows instead
# of N rows per group — silently wrong. This pre-execution check intercepts
# the misuse and forces a retry with the partitioned pattern.
_TOPN_INTENT_RX = re.compile(
    r"\b(?:top|primi|prime)\s+(\d+)\s+(?:per|for\s+(?:each|every)|by|of\s+each)\b",
    re.IGNORECASE,
)
_HAS_LIMIT_RX = re.compile(r"\bLIMIT\s+(\d+)\b", re.IGNORECASE)
_HAS_ROWNUM_PARTITION_RX = re.compile(
    r"ROW_NUMBER\s*\(\s*\)\s*OVER\s*\(\s*PARTITION\s+BY",
    re.IGNORECASE,
)
_HAS_RANK_PARTITION_RX = re.compile(
    r"\b(?:RANK|DENSE_RANK)\s*\(\s*\)\s*OVER\s*\(\s*PARTITION\s+BY",
    re.IGNORECASE,
)


def _top_n_per_group_check(prompt: str, sql: str) -> Optional[str]:
    """If the prompt asks for "top N per X" / "top N for each X" and the SQL
    uses a bare LIMIT N (with N matching) WITHOUT a partitioned window
    function, return a retry hint. Otherwise None.

    Rule of thumb that maps to user expectation:
      "top 3 prodotti per regione" → 3 regions × 3 products = 9 rows
      LIMIT 3 alone → 3 rows globally = WRONG
    """
    if not prompt or not sql:
        return None
    intent_m = _TOPN_INTENT_RX.search(prompt)
    if not intent_m:
        return None
    try:
        n_requested = int(intent_m.group(1))
    except Exception:
        return None
    # If SQL has any partitioned window, we trust the model (could be RANK or
    # ROW_NUMBER over PARTITION BY).
    if _HAS_ROWNUM_PARTITION_RX.search(sql) or _HAS_RANK_PARTITION_RX.search(sql):
        return None
    # Otherwise, look for LIMIT N (with N matching what user asked).
    limit_m = _HAS_LIMIT_RX.search(sql)
    if not limit_m:
        # No LIMIT either — probably aggregated; let downstream checks decide.
        return None
    try:
        n_limit = int(limit_m.group(1))
    except Exception:
        return None
    if n_limit != n_requested:
        return None  # different number — likely a different concern
    return (
        f"Your SQL uses `LIMIT {n_limit}` but the user asked for top {n_requested} "
        f"PER GROUP. A bare LIMIT returns {n_requested} rows globally, not "
        f"{n_requested} per group. Use a partitioned window instead:\n"
        f"    WITH ranked AS (\n"
        f"      SELECT <group_col>, <metric_cols>,\n"
        f"             ROW_NUMBER() OVER (PARTITION BY <group_col> ORDER BY <metric> DESC) AS rn\n"
        f"      FROM <source>\n"
        f"      GROUP BY <group_col>, <other_dims>\n"
        f"    )\n"
        f"    SELECT * FROM ranked WHERE rn <= {n_requested}\n"
        f"    ORDER BY <group_col>, <metric> DESC;\n"
        f"This returns {n_requested} rows per group, which is what the user asked for."
    )


# MoM / month-over-month / quarter-over-quarter: when the user asks for a
# temporal growth (mese su mese, MoM, crescita mensile, month over month),
# the SQL MUST use a LAG() or LEAD() window function ordered by the time
# dimension. Without it, the model often returns just the monthly totals
# and forgets the growth column entirely.
#
# Note: YoY/year-over-year is handled separately by _yoy_intent_check below,
# because the user-expected output shape is different ("one row per group"
# with a manual CASE WHEN pivot — NOT 2 rows per group from a LAG window).
_MOM_INTENT_RX = re.compile(
    r"\b(?:MoM|month[\s\-]?over[\s\-]?month|mese\s+su\s+mese|crescita\s+mensile|QoQ|quarter[\s\-]?over[\s\-]?quarter)\b",
    re.IGNORECASE,
)
_HAS_LAG_LEAD_RX = re.compile(r"\b(?:LAG|LEAD)\s*\(", re.IGNORECASE)


def _mom_intent_check(prompt: str, sql: str) -> Optional[str]:
    """If the prompt asks for MoM/QoQ growth but the SQL has no LAG/LEAD
    window function, return a retry hint. Otherwise None.
    """
    if not prompt or not sql:
        return None
    if not _MOM_INTENT_RX.search(prompt):
        return None
    if _HAS_LAG_LEAD_RX.search(sql):
        return None
    return (
        "Your SQL doesn't include LAG() or LEAD(), but the user asked for "
        "MoM / month-over-month / mese su mese / temporal growth. Use the "
        "LAG pattern over the date column:\n"
        "    WITH monthly AS (\n"
        "      SELECT date_trunc('month', <date_col>) AS month, SUM(<metric>) AS total\n"
        "      FROM <source> GROUP BY 1\n"
        "    )\n"
        "    SELECT month, total,\n"
        "      (total - LAG(total) OVER (ORDER BY month))\n"
        "      / NULLIF(LAG(total) OVER (ORDER BY month), 0) * 100 AS mom_pct\n"
        "    FROM monthly ORDER BY month;\n"
        "The first row's mom_pct will be NULL (no previous month) — that is "
        "correct, do not invent a value."
    )


# YoY / year-over-year: the user typically wants ONE row per group with the
# value for year A, value for year B, and growth % — NOT two rows per group
# from a LAG window. The correct DuckDB pattern is a manual CASE-WHEN pivot.
# Stress test 2026-05-19 had L4-B fail: model produced SQL that yielded an
# empty DataFrame (likely self-cancelling filter like `WHERE year=2024 AND
# year=2025`). This validator catches the missing pivot pattern; the recovery
# rebuilds it from the source in pandas.
_YOY_INTENT_RX = re.compile(
    r"\b(?:YoY|year[\s\-]?over[\s\-]?year|anno\s+su\s+anno|crescita\s+annuale|year[\s\-]?on[\s\-]?year)\b"
    r"|\b(20\d{2})\s*(?:vs\.?|contro|versus|e)\s*(20\d{2})\b",
    re.IGNORECASE,
)
# Patterns we consider "correct" YoY shapes: CASE WHEN year=..., PIVOT
# keyword, or LAG over a year dimension (still acceptable if the user is
# fine with the 2-row-per-group shape).
_HAS_YEAR_PIVOT_RX = re.compile(
    r"CASE\s+WHEN[^()]{0,80}?(?:EXTRACT\s*\(\s*year|YEAR\s*\(|\byear\s*=\s*20\d{2}|\b=\s*20\d{2})",
    re.IGNORECASE | re.DOTALL,
)
_HAS_PIVOT_KEYWORD_RX = re.compile(r"\bPIVOT\b", re.IGNORECASE)


def _yoy_intent_check(prompt: str, sql: str) -> Optional[str]:
    """If the prompt asks for YoY year-over-year comparison and the SQL
    doesn't include a manual pivot (CASE WHEN year=..., PIVOT, or LAG over
    a year dimension), return a retry hint with the canonical pattern.
    """
    if not prompt or not sql:
        return None
    if not _YOY_INTENT_RX.search(prompt):
        return None
    if _HAS_YEAR_PIVOT_RX.search(sql) or _HAS_PIVOT_KEYWORD_RX.search(sql):
        return None
    # LAG over year is also acceptable (gives 2 rows per group).
    if _HAS_LAG_LEAD_RX.search(sql) and re.search(
        r"ORDER\s+BY\s+(?:[a-z_]+\.)?year\b|ORDER\s+BY\s+EXTRACT\s*\(\s*year",
        sql, re.IGNORECASE,
    ):
        return None
    return (
        "Your SQL doesn't include a year-pivot pattern, but the user asked "
        "for year-over-year (YoY) comparison with ONE row per group. Use a "
        "manual pivot with CASE WHEN over the year dimension:\n"
        "    SELECT <group_col>,\n"
        "      SUM(CASE WHEN EXTRACT(year FROM <date_col>) = 2024\n"
        "               THEN <metric> ELSE 0 END) AS metric_2024,\n"
        "      SUM(CASE WHEN EXTRACT(year FROM <date_col>) = 2025\n"
        "               THEN <metric> ELSE 0 END) AS metric_2025,\n"
        "      (SUM(CASE WHEN EXTRACT(year FROM <date_col>) = 2025 THEN <metric> ELSE 0 END)\n"
        "       - SUM(CASE WHEN EXTRACT(year FROM <date_col>) = 2024 THEN <metric> ELSE 0 END))\n"
        "      / NULLIF(SUM(CASE WHEN EXTRACT(year FROM <date_col>) = 2024 THEN <metric> ELSE 0 END), 0)\n"
        "      * 100 AS yoy_pct\n"
        "    FROM <source>\n"
        "    GROUP BY <group_col>\n"
        "    ORDER BY yoy_pct DESC;\n"
        "This produces ONE row per group with year A, year B, and YoY %. "
        "Do NOT use `WHERE year IN (...)` AND `year = ...` combined — that "
        "would self-cancel and return zero rows."
    )


# ─── Two-pass recovery (post-validation pandas) ──────────────────────────────
#
# When the LLM gets the SAME analytical pattern wrong even after retries with
# targeted hints (Pareto threshold inclusion, MoM growth column), it makes
# little sense to keep retrying — the model has a strong bias and the hint
# isn't strong enough to overcome it. Instead, the two-pass recovery takes
# the (partially correct) DataFrame the model produced and rebuilds the
# correct output using pandas + a small "safe template" SQL re-query.
#
# Activation: only when (a) the intent regex matches, (b) the existing
# validator (e.g. _pareto_completion_check) flagged the output as broken,
# (c) all retries were exhausted. Otherwise the normal model output flows
# through unchanged.

def _pareto_two_pass_recovery(query, sql, result_df, sql_connection):
    """Recompute Pareto cumulative analysis in pandas when the model's
    SQL truncated the output below the threshold.

    Strategy:
      1. From the broken result_df, identify the group column (first
         non-numeric column) and the metric column (first numeric column
         that is NOT a cumulative-percentage column).
      2. From the broken SQL, extract the FROM clause (table reference)
         using a tolerant regex.
      3. Re-execute a "safe template" SQL that returns the FULL ranked
         distribution with NO threshold filter.
      4. Compute cum / cum_pct / prev_cum_pct in pandas and apply the
         INCLUSIVE filter `prev_cum_pct < threshold` — which includes
         the row that crosses the threshold.

    Returns the corrected DataFrame, or None if the recovery cannot be
    performed (any of: not a Pareto intent, broken DF unusable, SQL parse
    failure, re-query failure).
    """
    if result_df is None or len(result_df) < 2 or not query or not sql:
        return None
    if not _PARETO_INTENT_RX.search(query):
        return None

    cols = list(result_df.columns)
    cum_col = next(
        (c for c in cols if any(h in str(c).lower() for h in _CUM_COL_HINTS)),
        None,
    )
    group_col = next(
        (c for c in cols if not pd.api.types.is_numeric_dtype(result_df[c])),
        None,
    )
    value_cols = [
        c for c in cols
        if pd.api.types.is_numeric_dtype(result_df[c])
        and c != cum_col
        and "cum" not in str(c).lower()
        and "pct" not in str(c).lower()
        and "perc" not in str(c).lower()
    ]
    if not group_col or not value_cols:
        return None
    value_col = value_cols[0]

    # Extract the source table reference from the original SQL.
    from_match = re.search(
        r"\bFROM\s+([\w.\"]+(?:\s*,\s*[\w.\"]+)*)",
        sql,
        re.IGNORECASE,
    )
    if not from_match:
        return None
    table_ref = from_match.group(1).strip()
    # Refuse multi-table FROM (JOIN) — recovery only handles single-source
    # Pareto. A multi-source Pareto would need to replicate the JOIN, too
    # error-prone to do automatically.
    if "," in table_ref or "join" in sql.lower():
        return None

    # Detect threshold from the prompt (default 80).
    threshold = 80.0
    for m in _PARETO_THRESHOLD_RX.finditer(query):
        try:
            v = float(m.group(1))
            if 50 <= v < 100:
                threshold = v
                break
        except Exception:
            continue

    # Safe template re-query — no WHERE, no LIMIT.
    safe_sql = (
        f'SELECT "{group_col}", SUM("{value_col}") AS "{value_col}" '
        f"FROM {table_ref} "
        f'GROUP BY "{group_col}" '
        f'ORDER BY 2 DESC'
    )
    try:
        full_df = sql_connection.execute(safe_sql).fetchdf()
    except Exception as e:
        logger.warning(f"Pareto recovery re-query failed: {e}")
        return None
    if full_df is None or full_df.empty:
        return None
    total = float(full_df[value_col].sum())
    if total <= 0:
        return None

    full_df = full_df.reset_index(drop=True)
    full_df["cum"] = full_df[value_col].cumsum()
    full_df["cum_pct"] = (full_df["cum"] / total * 100).round(4)
    full_df["prev_cum_pct"] = full_df["cum_pct"].shift(1, fill_value=0.0)
    inclusive = full_df[full_df["prev_cum_pct"] < threshold].drop(
        columns=["prev_cum_pct"]
    ).reset_index(drop=True)
    if inclusive.empty:
        return None
    return inclusive


def _mom_two_pass_recovery(query, sql, result_df):
    """Augment a (period, value) result_df with a `mom_growth_pct` column
    when the model forgot to compute it.

    No re-query needed: we already have the monthly totals from the model's
    output. We just add the LAG-equivalent column with pandas pct_change.
    """
    if result_df is None or len(result_df) < 2 or not query:
        return None
    if not _MOM_INTENT_RX.search(query):
        return None

    # Don't act if the model already produced any growth-like column.
    cols = list(result_df.columns)
    growth_hints = ("growth", "mom", "yoy", "qoq", "change", "crescita", "pct", "%")
    if any(any(h in str(c).lower() for h in growth_hints) for c in cols):
        return None

    # Identify the period column (date/month/mese) and a single numeric metric.
    period_col = next(
        (c for c in cols
         if any(k in str(c).lower() for k in ("month", "mese", "date", "data", "period", "quarter", "trim"))),
        None,
    )
    if period_col is None:
        return None
    numeric_cols = [c for c in cols
                    if pd.api.types.is_numeric_dtype(result_df[c]) and c != period_col]
    if len(numeric_cols) != 1:
        return None  # ambiguous — skip recovery

    value_col = numeric_cols[0]
    augmented = result_df.copy().sort_values(period_col).reset_index(drop=True)
    growth_col = "mom_growth_pct" if "month" in str(period_col).lower() or "mese" in str(period_col).lower() else "growth_pct"
    augmented[growth_col] = (augmented[value_col].pct_change() * 100).round(4)
    return augmented


# YoY recovery (two-pass pandas): when the model's SQL for a year-over-year
# request produces an empty DataFrame (filter self-cancellation) or a DF
# without any growth column, rebuild the canonical "one row per group with
# year A, year B, yoy_pct" output by re-querying a SAFE aggregate template
# and pivoting in pandas.
#
# Activation: YoY intent + (result_df empty OR no growth-like column AND
# fewer than 2 numeric columns that look like year totals).
def _yoy_two_pass_recovery(query, sql, result_df, sql_connection, dfs):
    """Rebuild YoY year-over-year output when the model returned empty or
    a non-pivoted result. Re-queries (year, group, metric) and pivots in
    pandas.

    Strategy:
      1. Detect YoY intent from prompt.
      2. Decide whether recovery is needed (empty df, or no growth column
         AND not already in pivot shape).
      3. Extract single-source FROM from the broken SQL (skip JOINs).
      4. From the source DataFrame in `dfs`, pick:
           - date_col: first datetime-typed column (or name match: date/data).
           - group_col: column whose name appears in the prompt AND is non
             numeric and non-date. Fallback: first non-numeric column.
           - metric_col: numeric column named in the prompt; fallback to
             columns containing 'revenue/amount/total/value'.
      5. Re-execute safe SQL `SELECT EXTRACT(year FROM date), group,
         SUM(metric) GROUP BY 1, 2`.
      6. Pivot in pandas: index=group, columns=year, values=metric;
         compute yoy_pct = (last - first) / first * 100.

    Returns the rebuilt DataFrame, or None if any step fails (unrecognized
    schema, multi-table SQL, fewer than 2 distinct years, etc.).
    """
    if not query or not sql:
        return None
    if not _YOY_INTENT_RX.search(query):
        return None
    # Recovery is needed when: empty result, OR no growth-like column.
    needs_recovery = False
    if result_df is None or result_df.empty:
        needs_recovery = True
    else:
        cols_l = [str(c).lower() for c in result_df.columns]
        has_growth = any(
            ("yoy" in c) or ("growth" in c) or ("crescita" in c)
            or ("pct" in c) or ("%" in c) or ("variazione" in c)
            for c in cols_l
        )
        if not has_growth:
            needs_recovery = True
    if not needs_recovery:
        return None

    # Single-source FROM extraction (skip JOINs — too error-prone to mirror).
    from_match = re.search(
        r"\bFROM\s+([\w.\"]+)",
        sql,
        re.IGNORECASE,
    )
    if not from_match:
        return None
    table_ref = from_match.group(1).strip().strip('"')
    if "join" in sql.lower() or "," in table_ref:
        return None

    # Locate the source DataFrame by (case-insensitive) name.
    df_src = None
    table_key = None
    if dfs:
        for k, df in dfs.items():
            if str(k).lower() == table_ref.lower():
                df_src = df
                table_key = k
                break
    if df_src is None or df_src.empty:
        return None

    # date_col: prefer datetime-typed, fallback to name match.
    date_col = next(
        (c for c in df_src.columns if pd.api.types.is_datetime64_any_dtype(df_src[c])),
        None,
    )
    if date_col is None:
        date_keywords = ("date", "data", "order_date", "transaction_date", "tx_date")
        date_col = next(
            (c for c in df_src.columns
             if any(k in str(c).lower() for k in date_keywords)),
            None,
        )
    if date_col is None:
        return None

    # Validate date_col actually parses as a date (otherwise EXTRACT will fail).
    if not pd.api.types.is_datetime64_any_dtype(df_src[date_col]):
        try:
            _ = pd.to_datetime(df_src[date_col].head(20), errors="raise")
        except Exception:
            return None

    query_lower = query.lower()
    # group_col: prompt-mentioned, non-numeric, non-date.
    group_col = None
    for c in df_src.columns:
        if c == date_col:
            continue
        if pd.api.types.is_numeric_dtype(df_src[c]):
            continue
        if str(c).lower() in query_lower:
            group_col = c
            break
    if group_col is None:
        # Fallback: first non-numeric, non-date column with low cardinality.
        for c in df_src.columns:
            if c == date_col or pd.api.types.is_numeric_dtype(df_src[c]):
                continue
            try:
                if df_src[c].nunique(dropna=True) < 50:
                    group_col = c
                    break
            except Exception:
                continue
    if group_col is None:
        return None

    # metric_col: numeric, prompt-mentioned; fallback to revenue-like.
    metric_col = None
    for c in df_src.columns:
        if not pd.api.types.is_numeric_dtype(df_src[c]):
            continue
        if str(c).lower() in query_lower:
            metric_col = c
            break
    if metric_col is None:
        for hint in ("net_revenue", "revenue", "fatturato", "amount", "total", "value", "importo"):
            for c in df_src.columns:
                if hint in str(c).lower() and pd.api.types.is_numeric_dtype(df_src[c]):
                    metric_col = c
                    break
            if metric_col is not None:
                break
    if metric_col is None or metric_col == group_col:
        return None

    # Safe template re-query.
    safe_sql = (
        f'SELECT EXTRACT(year FROM "{date_col}") AS year, '
        f'"{group_col}", SUM("{metric_col}") AS "{metric_col}" '
        f'FROM "{table_key}" '
        f'GROUP BY 1, "{group_col}"'
    )
    try:
        agg_df = sql_connection.execute(safe_sql).fetchdf()
    except Exception as e:
        logger.warning(f"YoY recovery re-query failed: {e}")
        return None
    if agg_df is None or agg_df.empty:
        return None

    # Pivot in pandas: rows=group, cols=year, vals=metric.
    try:
        pivot_df = agg_df.pivot_table(
            index=group_col, columns="year", values=metric_col,
            aggfunc="sum", fill_value=0,
        ).reset_index()
    except Exception as e:
        logger.warning(f"YoY recovery pivot failed: {e}")
        return None

    year_cols = sorted(
        [c for c in pivot_df.columns
         if isinstance(c, (int, float)) and 2000 <= float(c) <= 2100]
    )
    if len(year_cols) < 2:
        return None
    y_prev = int(year_cols[0])
    y_curr = int(year_cols[-1])
    col_prev = f"{metric_col}_{y_prev}"
    col_curr = f"{metric_col}_{y_curr}"
    pivot_df = pivot_df.rename(columns={y_prev: col_prev, y_curr: col_curr})
    # Drop any intermediate year columns (e.g. 2023) to keep output focused.
    extras = [c for c in year_cols if int(c) not in (y_prev, y_curr)]
    if extras:
        pivot_df = pivot_df.drop(columns=extras, errors="ignore")
    pivot_df["yoy_pct"] = (
        (pivot_df[col_curr] - pivot_df[col_prev])
        / pivot_df[col_prev].replace(0, pd.NA) * 100
    ).astype(float).round(4)
    keep = [group_col, col_prev, col_curr, "yoy_pct"]
    available = [c for c in keep if c in pivot_df.columns]
    return (
        pivot_df[available]
        .sort_values("yoy_pct", ascending=False, na_position="last")
        .reset_index(drop=True)
    )


# Hallucinated-column detection (Tier 4 #5): the model often quotes column
# names that don't exist in the schema (e.g. Valore_Medio_Conversione,
# Stock_Quantity, Costi_Fissi, OEE). Rule #10 in the system prompt asks the
# model to substitute/annotate, but the model frequently still uses silent
# defaults (0, 1, mean) — producing numerically plausible but semantically
# misleading output. This pre-validation scans the prompt for column-like
# tokens and surfaces the mismatch BEFORE the LLM call.

# Column-like identifier: must look like CamelCase or Snake_Case, len>=4,
# contain at least one vowel (excludes acronyms like SQL, ROI, CAC handled
# separately), and start with uppercase. Captures multi-word forms like
# `Valore_Medio_Conversione`, `Stock_Quantity`, `Data_Cessazione`.
_COL_LIKE_RX = re.compile(r"\b[A-Z][a-zA-Z]*(?:_[A-Za-z]+)+\b")
# Common short ALL-CAPS acronyms that should NOT be flagged as columns even
# though they're capitalized (they're metric labels, not column names).
_ACRONYM_WHITELIST = frozenset({
    "ROI", "ROAS", "CAC", "CLV", "CTR", "AOV", "CPC", "CPL", "CPM",
    "OEE", "CAGR", "EBITDA", "DSO", "COGS", "KPI", "SUM", "AVG",
    "MIN", "MAX", "COUNT", "CASE", "WHEN", "THEN", "ELSE", "END",
    "GROUP", "ORDER", "BY", "FROM", "WHERE", "AND", "OR", "NOT",
    "DESC", "ASC", "AS", "ON", "IN", "IS", "NULL", "DISTINCT",
    "MOM", "YOY", "ABC",
})


def _detect_hallucinated_columns(query: str, dfs) -> Optional[str]:
    """If the user prompt names columns that don't exist in any loaded table,
    return a retry/context hint listing the missing names and the available
    columns. Otherwise None.

    `dfs` is `data_processor.dfs`: Dict[table_name, pandas.DataFrame].
    """
    if not query or not dfs:
        return None
    all_cols = set()
    for df in dfs.values():
        try:
            all_cols.update(df.columns)
        except Exception:
            continue
    all_cols_lower = {c.lower() for c in all_cols}
    # Find column-like tokens in the prompt.
    candidates = set()
    for m in _COL_LIKE_RX.finditer(query):
        tok = m.group(0)
        if tok.upper() in _ACRONYM_WHITELIST:
            continue
        candidates.add(tok)
    if not candidates:
        return None
    missing = sorted(t for t in candidates if t.lower() not in all_cols_lower)
    if not missing:
        return None
    return (
        f"⚠️ SCHEMA MISMATCH WARNING: The user prompt mentions {len(missing)} "
        f"column name(s) NOT present in the loaded schema: {', '.join(f'`{m}`' for m in missing)}. "
        f"Available columns across all tables: {sorted(all_cols)}. "
        f"You MUST follow rule #10: do NOT silently default the missing column to 0/1/mean. "
        f"Either (a) substitute the closest semantic equivalent and mark it in the SELECT alias "
        f"(e.g. `Costo_Acquisizione AS Costo_Conversione_proxy`), OR (b) omit that part of the "
        f"formula and annotate the alias accordingly. NEVER fabricate values for missing columns."
    )


# Implicit-filter detection (Tier 4 #7): the model silently adds
# `WHERE Stato='Consegnata'` (and similar) even when the prompt doesn't ask
# for filtering. Result count differs from full-data without the user
# knowing. This post-execution detector parses simple equality literals
# from the WHERE clause(s) and checks whether each literal value appears
# in the prompt; if not, it's an undisclosed filter that we surface to
# the user in the success message.

# Match equality predicates: `<col> = '<value>'` or `<col> = "<value>"`.
# IN-clauses and inequalities are out of scope (handled by inspection in
# the disclosure rather than retry).
_WHERE_LITERAL_RX = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:'([^']+)'|\"([^\"]+)\")",
    re.IGNORECASE,
)


def _detect_implicit_filters(prompt: str, sql: str) -> List[Tuple[str, str]]:
    """Return [(col, value), ...] for equality filters in `sql` whose values
    do not appear (loosely) in `prompt`. These are likely silent filters
    the user did not ask for.

    Loose match: take the first up-to-6 chars of the value and look for the
    prefix in the prompt (case-insensitive). This tolerates Italian
    morphological variants like "consegnate" (prompt) vs "Consegnata"
    (data) and singular/plural forms in general.
    """
    if not prompt or not sql:
        return []
    prompt_lower = prompt.lower()
    found: List[Tuple[str, str]] = []
    seen = set()  # avoid duplicate (col, value) pairs
    for m in _WHERE_LITERAL_RX.finditer(sql):
        col = m.group(1)
        value = m.group(2) or m.group(3) or ""
        if not value:
            continue
        # Skip CASE WHEN context: look at the 12 chars immediately preceding.
        ctx_start = max(0, m.start() - 12)
        ctx = sql[ctx_start:m.start()].upper()
        if "WHEN " in ctx:
            continue
        key = (col, value)
        if key in seen:
            continue
        seen.add(key)
        # Short values (numbers like "1", "5") are too ambiguous to flag;
        # require length >= 3 to consider it a meaningful filter literal.
        if len(value) < 3:
            continue
        # Loose match: prefix of length min(6, len-1) — tolerates Italian
        # gender/number variants ("consegnate" vs "Consegnata").
        prefix_len = min(6, max(3, len(value) - 1))
        prefix = value[:prefix_len].lower()
        if prefix in prompt_lower:
            continue
        found.append((col, value))
    return found


def _adaptive_round_floats(df: pd.DataFrame) -> None:
    """Round every float column to a precision that fits its magnitude.

    Avoids the historical bug where ratios < 1 (e.g. 0.006186 = Shipping_Cost
    / Line_Total) were flattened to 0.01 by a fixed `.round(2)`. Rules per
    column:
      max(|val|) < 1   → 6 decimals (preserves fine ratios)
      max(|val|) < 100 → 4 decimals (scores, retention %, indici 0-100)
      otherwise        → 2 decimals (monetary amounts, large counts)

    Operates in place. Columns with all-NaN values are skipped.
    """
    for col in df.select_dtypes(include=["float64", "float32"]).columns:
        max_abs = df[col].abs().max()
        if pd.isna(max_abs):
            continue
        if max_abs < 1:
            df[col] = df[col].round(6)
        elif max_abs < 100:
            df[col] = df[col].round(4)
        else:
            df[col] = df[col].round(2)


class ManipulateService:
    """
    Servizio principale per MANIPULATE.
    Supporta: Analyze, Export to Sheet, Add Charts, Add Style
    """

    def __init__(self, persist_directory: Optional[str] = None):
        self.ollama = OllamaClient()
        self.data_processor = DataProcessor(lang="it")
        self.charter = ManipulateCharter()
        self.styler = ManipulateStyler()
        self.suggestions_service = SuggestionsService(lang="it")

        self.sessions: Dict[str, List[Dict]] = {}
        self.uploaded_files: Dict[str, List[Dict]] = {}
        self.staged_files: Dict[str, List[Dict]] = {}  # NEW: Staging system
        self.lang = "it"
        self._chroma_path = persist_directory  # Per change detection
        # Lazy DuckDB knowledge base seeding — done on first SQL gen, not at boot.
        self._tech_kb_checked = False

        # ChromaDB per technical RAG (per-progetto)
        self.tech_rag = DocumentProcessor(
            collection_name="technical_sql",
            persist_directory=persist_directory,
            lang="it"
        )

        # Carica prompts e modelli
        self.prompts = self._load_prompts()
        self.models = self._load_models()

    def _load_prompts(self) -> Dict:
        """Carica prompt da file per lingua (prompts_manipulate_{lang}.json)."""
        config_dir = Path(__file__).parent.parent / "backend_config"
        # Prova prima il file per lingua specifica
        prompts_path = config_dir / f"prompts_manipulate_{self.lang}.json"
        if not prompts_path.exists():
            # Fallback a italiano
            prompts_path = config_dir / "prompts_manipulate_it.json"
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading manipulate prompts: {e}")
            return {}

    def _load_models(self) -> Dict:
        """Carica configurazione modelli."""
        models_path = Path(__file__).parent.parent / "backend_config" / "models.json"
        try:
            with open(models_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            return {
                "manipulate_model": "qwen3-coder:30b",
                "manipulate_model_ctx": 131072,
                "engineering_model": "qwen3-coder:30b",
                "smart_suggestion_model": "gemma3:12b"
            }

    async def _installed_coders(self) -> set:
        """Set dei coder Manipulate effettivamente installati. Cache breve (20s)
        per non ripetere list() ad ogni chiamata nello stesso flusso."""
        import time
        now = time.time()
        if getattr(self, '_coder_cache', None) is not None and now - getattr(self, '_coder_cache_ts', 0) < 20:
            return self._coder_cache
        found = set()
        try:
            names = await self.ollama.list_models()
            for coder in _MANIP_CODERS:
                base = coder.split(':', 1)[0]
                if any(n == coder or n.startswith(base) for n in names):
                    found.add(coder)
        except Exception as e:
            logger.warning(f"_installed_coders failed: {e}")
        self._coder_cache = found
        self._coder_cache_ts = now
        return found

    async def _resolve_coder(self, configured: str) -> str:
        """Se il coder configurato non è installato ma l'alternativa sì, usa
        l'alternativa (qwen3-coder:30b ↔ qwen2.5-coder:7b). Così cancellando il
        30B, Manipulate passa al 7B senza che l'utente cambi modello a mano.
        Se nessuno dei due è installato, lascia il configurato (errore esplicito)."""
        if configured not in _MANIP_CODERS:
            return configured
        installed = await self._installed_coders()
        if not installed or configured in installed:
            return configured
        for alt in _MANIP_CODERS:
            if alt != configured and alt in installed:
                logger.info(f"Manipulate coder fallback: '{configured}' non installato → uso '{alt}'")
                return alt
        return configured

    def set_language(self, lang: str):
        self.lang = lang
        self.prompts = self._load_prompts()
        self.data_processor.set_language(lang)
        
        # Aggiorna anche il servizio i18n globale
        from services.i18n_service import i18n
        i18n.set_language(lang)

    def _get_or_create_session(self, session_id: str):
        if session_id not in self.sessions:
            self.sessions[session_id] = []
            self.uploaded_files[session_id] = []
            self.staged_files[session_id] = []
            
            # Carica da file se esiste (Legacy alignment)
            session_file = self._get_session_file(session_id)
            if session_file.exists():
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        self.sessions[session_id] = data.get('history', [])
                        self.uploaded_files[session_id] = [
                            f for f in data.get('files', [])
                            if os.path.exists(f.get('path', ''))
                        ]
                        self.staged_files[session_id] = [
                            f for f in data.get('staged', [])
                            if os.path.exists(f.get('path', ''))
                        ]
                        
                        # Re-ingest files into DuckDB
                        for f_info in self.uploaded_files[session_id]:
                            self.data_processor.load_data(f_info['path'], mode="Export to Sheet", clear_session=False)
                                
                        logger.info(f"Manipulate Session {session_id} loaded from disk")
                except Exception as e:
                    logger.error(f"Error loading manipulate session {session_id}: {e}")
                    
        return self.sessions[session_id]

    def _get_session_file(self, session_id: str) -> Path:
        from backend_config.project_manager import project_manager
        
        if project_manager.active_project_path:
            sessions_dir = project_manager.active_project_path / "sessions"
        else:
            sessions_dir = BASE_DIR / "temp" / "manipulate_sessions"
            
        sessions_dir.mkdir(parents=True, exist_ok=True)
        return sessions_dir / f"manipulate_state_{session_id}.json"

    def _save_session(self, session_id: str):
        session_file = self._get_session_file(session_id)
        data = {
            'history': self.sessions.get(session_id, []),
            'files': self.uploaded_files.get(session_id, []),
            'staged': self.staged_files.get(session_id, []),
            'lang': self.lang
        }
        try:
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving session: {e}")

    async def upload_file(
        self,
        file_path: str,
        filename: str,
        session_id: str,
        mode: str = "Export to Sheet"
    ) -> Dict:
        """
        Carica file Excel/CSV in STAGING (non ancora in DuckDB).
        Max 2 file Excel/CSV per sessione.
        """
        try:
            self._get_or_create_session(session_id)

            # Verifica limite file Excel/CSV — il max e' specifico per sottomodulo:
            #   Merge Sheets: 8 (versione semplice, append in fogli paralleli)
            #   Export to Sheet: 2 (analisi multi-file con SQL)
            #   Add Charts / Add Style: 2 (frontend gestisce replace mode a 1)
            ext = os.path.splitext(filename)[1].lower()
            if ext in ['.xls', '.xlsx', '.csv']:
                if mode == 'Merge Sheets':
                    max_files = 8
                else:
                    max_files = 2
                cur = sum(1 for f in self.uploaded_files.get(session_id, [])
                         if os.path.splitext(f['name'])[1].lower() in ['.xls', '.xlsx', '.csv'])
                stg = len(self.staged_files.get(session_id, []))
                if cur + stg >= max_files:
                    return {
                        "status": "error",
                        "message": i18n.get(
                            'manipulate_errors.limit_reached_n',
                            "Limite raggiunto ({n}/{n}). Massimo {n} file xlsx/CSV per {mode}."
                        ).replace("{n}", str(max_files)).replace("{mode}", mode)
                    }

            # Aggiungi a staged_files
            self.staged_files[session_id].append({
                "name": filename,
                "path": file_path,
                "ext": ext
            })

            self._save_session(session_id)
            logger.info(f"📥 File in staging: {filename} (sessione: {session_id})")

            return {
                "status": "staged",
                "message": i18n.get('manipulate_errors.staged_msg', "'{filename}' in coda. Premi 'Memorizza' per confermare.").replace('{filename}', filename),
                "staged_count": len(self.staged_files[session_id])
            }

        except Exception as e:
            logger.error(f"Error staging file: {e}")
            return {"status": "error", "message": str(e)}

    async def memorize_files(self, session_id: str, mode: str = "Export to Sheet") -> Dict:
        """
        Processa tutti i file in staging e li carica in DuckDB.
        """
        try:
            staged = self.staged_files.get(session_id, [])
            if not staged:
                return {
                    "status": "error",
                    "message": i18n.get('manipulate_errors.no_files_in_queue', "Nessun file in coda.")
                }

            logger.info(f"📥 Memorizzazione di {len(staged)} file...")

            # Reset warning di ingestion: raccoglie eventuali avvisi (es. CSV con
            # righe non interpretabili) emessi da load_data per questo batch.
            self.data_processor.last_ingest_warnings = []

            # Processa ogni file
            for file_info in staged:
                # Traccia tabelle esistenti prima del caricamento
                pre_tables = set(self.data_processor.dfs.keys())
                
                success, message = await asyncio.to_thread(
                    self.data_processor.load_data,
                    file_info['path'],
                    None,  # table_name auto
                    mode,
                    clear_session=False  # Mantieni file multipli
                )

                if success:
                    # Identifica solo le NUOVE tabelle caricate da questo file
                    post_tables = set(self.data_processor.dfs.keys())
                    new_tables = list(post_tables - pre_tables)
                    
                    logger.info(f"🔍 [MEMORIZE] Pre-tables: {list(pre_tables)}")
                    logger.info(f"🔍 [MEMORIZE] Post-tables: {list(post_tables)}")
                    logger.info(f"🔍 [MEMORIZE] Diff (New): {new_tables}")

                    # Se non ci sono nuove tabelle (es. sovrascrittura), prendi tutte quelle corrispondenti
                    if not new_tables:
                        import re
                        import os
                        base_name = os.path.splitext(file_info['name'])[0]
                        expected_prefix = re.sub(r'\W|^(?=\d)', '_', base_name).lower()
                        new_tables = [t for t in post_tables if t.startswith(expected_prefix)]
                        logger.info(f"🔍 [MEMORIZE] Fallback match for '{expected_prefix}': {new_tables}")

                    # Registra come caricato
                    file_ref = f"F{len(self.uploaded_files.get(session_id, [])) + 1}"
                    file_entry = {
                        "name": file_info['name'],
                        "path": file_info['path'],
                        "ref": file_ref,
                        "type": "excel" if file_info['ext'] in ['.xls', '.xlsx'] else "csv",
                        "tables": new_tables
                    }
                    self.uploaded_files.setdefault(session_id, []).append(file_entry)
                    logger.info(f"✅ [MEMORIZE] Registered file: {file_info['name']} with tables: {new_tables}")


            from services.i18n_service import i18n
            
            # Pulisci staged_files
            self.staged_files[session_id] = []
            self._save_session(session_id)

            logger.info(f"✅ Memorizzazione completata. File caricati: {len(self.uploaded_files[session_id])}")

            msg = i18n.get('sidebar.memorized_msg', "Memorizzati {count} file.").replace('{count}', str(len(staged)))

            # Trasparenza ingestion: se un CSV ha avuto righe non interpretabili,
            # avvisa l'utente invece di lasciar passare in silenzio un dataset
            # parziale (vedi _read_csv_robust).
            ingest_warnings = list(getattr(self.data_processor, 'last_ingest_warnings', []))

            return {
                "status": "success",
                "message": msg,
                "uploaded_count": len(self.uploaded_files[session_id]),
                "warnings": ingest_warnings,
            }

        except Exception as e:
            logger.error(f"Error memorizing files: {e}")
            return {"status": "error", "message": str(e)}

    async def _orchestrate_query(self, query: str) -> List[str]:
        """
        Scompone la richiesta dell'utente in 2-3 sotto-task SQL distinti.
        Usato per gestire calcoli complessi (Analyze mode).
        """
        prompts = self.prompts.get('manipulate_stages', {})
        planner_cfg = prompts.get('orchestrator_deep_analysis', {})
        
        sys_planner = planner_cfg.get('system', "You are a Data Analysis Query Planner. Break down user requests into 2-3 SQL tasks in English JSON array.")
        user_template = planner_cfg.get('instruction', "QUERY: {query}")

        try:
            resp = await self.ollama.chat(
                model=await self._resolve_coder(self.models.get('engineering_model', 'qwen3-coder:30b')),
                messages=[
                    {'role': 'system', 'content': sys_planner},
                    {'role': 'user', 'content': user_template.format(query=query)}
                ],
                num_ctx=AUTO_CTX,
                max_ctx=settings.MANIPULATE_CTX,
                temperature=0.1
            )
            
            tasks_json = resp.strip()
            # Pulizia markdown
            tasks_json = re.sub(r'^```(json)?\n?', '', tasks_json, flags=re.MULTILINE)
            tasks_json = re.sub(r'\n?```$', '', tasks_json)
            
            subtasks = json.loads(tasks_json)
            if not isinstance(subtasks, list): subtasks = [query]
            return subtasks[:3] if subtasks else [query]
            
        except Exception as e:
            logger.warning(f"Orchestrator failed: {e}. Fallback to single query.")
            return [query]

    def _calculate_facts(self, df: pd.DataFrame, query: str) -> Dict:
        """Calcola fatti universali in Python per evitare allucinazioni numeriche."""
        facts = {
            'total_rows': len(df),
            'total_cols': len(df.columns)
        }
        
        numeric_cols = df.select_dtypes(include=['float64', 'int64', 'float32']).columns.tolist()
        text_cols = df.select_dtypes(include=['object']).columns.tolist()
        
        if numeric_cols and len(df) > 0:
            col = numeric_cols[0]
            facts['metric_name'] = col
            facts['avg'] = float(df[col].mean())
            facts['min'] = float(df[col].min())
            facts['max'] = float(df[col].max())
            
            if text_cols:
                name_col = text_cols[0]
                try:
                    top_idx = df[col].idxmax()
                    bottom_idx = df[col].idxmin()
                    facts['top_name'] = str(df.loc[top_idx, name_col])
                    facts['bottom_name'] = str(df.loc[bottom_idx, name_col])
                    facts['diff_pct'] = ((facts['max'] - facts['min']) / abs(facts['min']) * 100) if facts['min'] != 0 else 0
                except:
                    pass
        return facts

    async def _maybe_seed_tech_kb(self) -> None:
        """Lazy-seed the DuckDB-specific KB into tech_rag the first time we run
        SQL gen in this project. Idempotent and version-aware (see
        services.duckdb_tech_kb)."""
        if self._tech_kb_checked:
            return
        self._tech_kb_checked = True
        try:
            from services import duckdb_tech_kb
            res = await duckdb_tech_kb.seed(self.tech_rag, force=False)
            if res.get("seeded"):
                logger.info(f"DuckDB tech KB seeded for this project: {res}")
        except Exception as e:
            logger.warning(f"DuckDB tech KB seed failed (continuing without it): {e}")

    async def _generate_sql_query(
        self,
        query: str,
        error_context: str = None,
        mode: str = "analysis",
        session_id: Optional[str] = None,
    ) -> str:
        """Genera SQL query con qwen3-coder:30b e Context Injection.

        Quando `session_id` e' fornito, filtra schema + table_names alle SOLE
        tabelle caricate in questa sessione. Senza il filtro, il modello vede
        tutte le tabelle DuckDB (singleton globale `data_processor.dfs`) e
        puo' scegliere una tabella di una sessione precedente — bug confermato
        nel dirty-data test 2026-05-19 (run #1 con 12/12 falsi positivi tutti
        dirottati a `retail_clean`).
        """
        # Calcola le tabelle della sessione corrente quando session_id e' noto.
        # Fallback: usa tutte le tabelle DuckDB (back-compat per chiamanti che
        # non passano session_id).
        if session_id is not None and session_id in self.uploaded_files:
            session_table_names: List[str] = []
            for f in self.uploaded_files[session_id]:
                session_table_names.extend(f.get('tables', []))
            # Mantieni solo nomi che esistono davvero nel data_processor.
            session_table_names = [t for t in session_table_names
                                    if t in self.data_processor.dfs]
            if session_table_names:
                table_names = session_table_names
                schema = self.data_processor.get_technical_schema(session_table_names)
            else:
                # Sessione senza tabelle valide — fallback completo.
                schema = self.data_processor.get_technical_schema()
                table_names = list(self.data_processor.dfs.keys())
        else:
            schema = self.data_processor.get_technical_schema()
            table_names = list(self.data_processor.dfs.keys())

        prompts = self.prompts.get('manipulate_stages', {})

        # Usa sempre sql_generator per ereditare le formule di business e le regole ferree, come in NiceGUI
        sql_cfg = self.prompts.get('manipulate_stages', {}).get('sql_generator', {})

        # Lazy KB seed (first SQL call per project), then retrieve guidelines.
        await self._maybe_seed_tech_kb()

        # 1. RAG TECNICO (Legacy alignment)
        tech_context = ""
        try:
            # Chiedi al RAG tecnico le regole DuckDB per questa query
            rag_results = await self.tech_rag.get_context(query, limit=3)
            if rag_results:
                tech_context = "\n### 📚 TECHNICAL GUIDELINES (from Knowledge Base):\n" + rag_results
        except Exception as e:
            logger.warning(f"RAG Technical lookup failed: {e}")

        system_prompt = sql_cfg.get('system', 'You are a DuckDB expert.')
        if len(table_names) == 1:
            table_rule = f"1. USE REAL TABLE NAME: '{table_names[0]}'"
            prefix_rule = "2. Use table prefixes optionally."
            relational_rule = ""
        else:
            table_rule = f"1. MULTIPLE TABLES: Use {table_names}."
            prefix_rule = "2. MANDATORY: Use table prefixes (e.g., 'table.column')."
            relational_rule = "3. JOIN LOGIC: Join tables using common keys. Use CTEs for clarity."

        system_prompt = sql_cfg.get('system', 'You are a DuckDB expert.')
        
        # Iniezione Regole e Schema
        user_prompt = f"### ⚖️ MANDATORY TECHNICAL RULES:\n{table_rule}\n{prefix_rule}\n{relational_rule}\n"
        user_prompt += "4. DUCKDB DIALECT: Use native PIVOT/CTEs. NO MARKDOWN. ONLY RAW SQL.\n"
        user_prompt += "5. PERCENTAGES (CRITICAL): Values are 0-1 (e.g. 15% = 0.15). DO NOT divide by 100.\n"
        user_prompt += tech_context  # Iniezione RAG Tecnico
        
        if error_context:
            user_prompt += f"### ⚠️ PREVIOUS ERROR: {error_context}\nFix the query accordingly.\n"

        # Pre-validation: catch column-like names in prompt that don't exist
        # in any loaded table, so the model can substitute / annotate instead
        # of silently defaulting (rule #10 reinforcement).
        schema_warning = _detect_hallucinated_columns(query, self.data_processor.dfs)
        if schema_warning:
            user_prompt += f"\n{schema_warning}\n"
            logger.warning(f"Schema mismatch detected for prompt: {schema_warning[:200]}")

        user_prompt += f"\nBUSINESS REQUEST: {query}\n\n"
        user_prompt += f"### 🔍 REAL DATABASE SCHEMA (MANDATORY):\n{schema}"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        resp = await self.ollama.chat(
            model=await self._resolve_coder(self.models.get('engineering_model', 'qwen3-coder:30b')),
            messages=messages,
            num_ctx=AUTO_CTX,
            max_ctx=settings.MANIPULATE_CTX,
            temperature=0.1
        )

        # Robust SQL Extraction (Dalla versione NiceGUI)
        sql = resp.strip()
        if '```' in sql:
            sql = re.sub(r'^```\w*\n?', '', sql, flags=re.MULTILINE)
            sql = re.sub(r'\n?```', '', sql)
        
        sql = sql.replace('`', '"') # Qwen habit

        # MS-SQL bracket-quoted identifiers ([table], [column]) — qwen3-coder
        # spesso usa questa sintassi per identificatori, ma DuckDB la rifiuta
        # come "syntax error at or near '['". Convertiamo in double quotes,
        # che è la sintassi standard SQL/DuckDB.
        sql = re.sub(r'\[([^\]\n]+)\]', r'"\1"', sql)

        # Reserved-keyword column quoting (Fix #1b complemento allo schema-side
        # _display_col del DataProcessor). Quando il LLM ignora lo schema e
        # scrive `AVG(Like)` invece di `AVG("Like")` DuckDB esplode con
        # "syntax error at or near ')'" perché interpreta `Like` come
        # l'operatore. Quotiamo solo le forme Capitalized (Like, Order, …)
        # perché le forme UPPERCASE (LIKE, ORDER BY) sono convenzionalmente
        # operatori e non column reference.
        _RESERVED_COL_RE = re.compile(
            r'(?<![\w"])'                                       # not after word-char or quote
            r'(Like|Order|Group|Date|Time|Type|User|Name|Key|'
            r'Value|Row|Range|Comment|From|Case|When|Then|'
            r'Select|Where|Join|All|Any|Between|Having|Null|'
            r'Default|Union|Limit|Offset|Over|Partition)'
            r'(?![\w"])'                                        # not before word-char or quote
        )
        sql = _RESERVED_COL_RE.sub(r'"\1"', sql)

        # Prendi solo la prima query
        first_semi = sql.find(';')
        if first_semi != -1:
            sql = sql[:first_semi + 1]

        # Auto-close quotes
        sql_trim = sql.rstrip().rstrip(';').rstrip()
        if sql_trim.count('"') % 2 != 0:
            sql = sql_trim + '";'

        # Auto-correzione nome tabella: se c'è UNA SOLA tabella reale e il
        # modello ha allucinato un nome diverso (es. 'sales_data', 'table1'),
        # riscrivi le occorrenze in FROM/JOIN al nome reale. Loggato per audit.
        # Non interveniamo con più tabelle: lì il modello deve scegliere lui.
        # NB: i nomi delle CTE locali (`WITH name AS (...)`) NON vanno mai
        # riscritti — sono identificatori validi nello scope dello SQL anche
        # se non esistono in DuckDB. Le aggiungiamo all'allow-list locale.
        if len(table_names) == 1:
            real = table_names[0]
            cte_names = set()
            for m in re.finditer(r'(?:\bWITH\s+|,\s*)([A-Za-z_][A-Za-z0-9_]*)\s+AS\s*\(', sql, flags=re.IGNORECASE):
                cte_names.add(m.group(1))
            allowed = {real} | set(self.data_processor.dfs.keys()) | cte_names

            # Some SQL constructs use `FROM` as a keyword inside an expression,
            # not as a clause: `EXTRACT(month FROM col)`, `SUBSTRING(s FROM n)`,
            # `TRIM(LEADING 'x' FROM col)`. A naive `FROM <word>` regex
            # mistreats `col` as a hallucinated table and rewrites it to the
            # real table, producing `EXTRACT(month FROM "<real_table>")` which
            # DuckDB then evaluates as `date_part('month', <table_struct>)`
            # and fails (incident 2026-05-12, MANIPULATE SHEET retest).
            # Stash these expressions so the regex below doesn't see them.
            _stash: list[str] = []

            def _stash_func_with_from(m: re.Match) -> str:
                _stash.append(m.group(0))
                return f"__FROM_STASH_{len(_stash) - 1}__"

            # Match function calls whose body contains the FROM keyword.
            # Body grammar: `(?:[^()]|\([^()]*\))*?` — non-greedy sequence of
            # either non-paren chars OR a single level of balanced parens.
            # This protects `EXTRACT(year FROM CAST(col AS DATE))` from the
            # auto-rewrite below: with a flat `[^()]*?` the inner `CAST(...)`
            # closes the EXTRACT match early, leaving `CAST` exposed to the
            # `FROM <ident>` regex which would rewrite it as a table reference
            # (incident dirty-data test 2026-05-19, L4 YoY on retail_dirty).
            _stash_pat = re.compile(
                r'\b(?:EXTRACT|SUBSTRING|TRIM|OVERLAY)\s*\(\s*'
                r'(?:[^()]|\([^()]*\))*?\bFROM\b(?:[^()]|\([^()]*\))*?\)',
                re.IGNORECASE,
            )
            sql_safe = _stash_pat.sub(_stash_func_with_from, sql)

            referenced = set()
            # Word boundary on BOTH sides so we don't match `e` inside `employees`
            # (see incident 2026-05-12: ref='e' matched `FROM e` inside
            # `FROM employees e`, producing `FROM "employees"mployees e`).
            for m in re.finditer(r'\b(?:FROM|JOIN)\s+"?([A-Za-z_][A-Za-z0-9_]*)"?(?![A-Za-z0-9_])', sql_safe, flags=re.IGNORECASE):
                referenced.add(m.group(1))
            for ref in referenced:
                if ref not in allowed:
                    # Same negative lookahead `(?![A-Za-z0-9_])` after the optional
                    # closing quote: ensures the captured identifier is complete,
                    # not a prefix of a longer one.
                    pattern = rf'(\b(?:FROM|JOIN)\s+)"?{re.escape(ref)}"?(?![A-Za-z0-9_])'
                    sql_safe = re.sub(pattern, rf'\1"{real}"', sql_safe, flags=re.IGNORECASE)
                    logger.warning(f"🔧 SQL table auto-rewrite: '{ref}' → '{real}' (only real table in session)")

            # Restore stashed expressions.
            for i, original in enumerate(_stash):
                sql_safe = sql_safe.replace(f"__FROM_STASH_{i}__", original)
            sql = sql_safe

        logger.info(f"📝 SQL generato e sanitizzato: {sql[:200]}...")
        return sql

    async def get_smart_suggestions(
        self, 
        session_id: str, 
        mode: str = "Analyze", 
        level: str = "Easy", 
        area: str = "General",
        lang: str = "it"
    ) -> List[str]:
        """
        Ottiene suggerimenti contestuali per MANIPULATE (Perfect Logic Port).
        """
        session_files = self.uploaded_files.get(session_id, [])
        logger.info(f"🔍 [SUGGESTIONS] Session: {session_id} | Files found: {len(session_files)}")
        
        if not session_files:
            return []

        # Estrai solo le tabelle associate a questa specifica sessione
        session_table_names = []
        for f in session_files:
            session_table_names.extend(f.get('tables', []))
        
        logger.info(f"🔍 [SUGGESTIONS] Table names: {session_table_names}")
            
        session_dfs = {k: v for k, v in self.data_processor.dfs.items() if k in session_table_names}
        logger.info(f"🔍 [SUGGESTIONS] DFs matched: {list(session_dfs.keys())}")

        # Ottieni schema tecnico per dare contesto al suggeritore
        schema_context = self.data_processor.get_technical_schema(session_table_names)
        
        # Genera suggerimenti categorizzati
        suggestions = await self.suggestions_service.generate_manipulate_suggestions(
            schema_context=schema_context,
            mode=mode,
            level=level,
            area=area,
            dfs=session_dfs,
            lang=lang
        )
        
        logger.info(f"🔍 [SUGGESTIONS] Final suggestions count: {len(suggestions)}")
        
        # PERSISTENZA: Salva i suggerimenti nella cronologia della sessione
        if suggestions:
            history = self._get_or_create_session(session_id)
            history.append({
                "role": "suggestions",
                "content": json.dumps(suggestions) # Salviamo come stringa JSON
            })
            self._save_session(session_id)
            
        return suggestions

    async def analyze(
        self,
        query: str,
        session_id: str,
        mode: str = "Export to Sheet",
        stop_check_callback: Optional[Callable[[], bool]] = None
    ) -> AsyncGenerator[Tuple[bool, str, List], None]:
        """
        Analisi SQL-First (Perfect Logic Port).
        Gestisce: 
        - Export to Sheet: Singola query + Excel (Operativo)
        - Altri sottomoduli: Gestione specifica
        """
        if not self.uploaded_files.get(session_id):
            yield (False, i18n.get('manipulate_errors.no_files_loaded', "⚠️ Nessun file caricato."), [])
            return

        # --- CASO 1: MANIPULATE SHEET (Export to Sheet) ---
        if mode == "Export to Sheet":
            yield (True, i18n.get('manipulate_stages.elaborating_data', "⚙️ Elaborazione trasformazione dati in corso...\n"), [])

            last_error = None
            max_retries = 2

            # Pre-calcolo Whitelist per Soft Validation — filtrata alle SOLE
            # tabelle della sessione corrente (Bug E isolation fix 2026-05-19).
            # Altrimenti il soft-validator potrebbe lasciar passare colonne di
            # una sessione precedente che il modello cita per sbaglio.
            session_files_for_wl = self.uploaded_files.get(session_id, [])
            session_table_names_for_wl: List[str] = []
            for f in session_files_for_wl:
                session_table_names_for_wl.extend(f.get('tables', []))
            session_table_names_for_wl = [t for t in session_table_names_for_wl
                                          if t in self.data_processor.dfs]
            if session_table_names_for_wl:
                table_names = set(session_table_names_for_wl)
                valid_columns = set()
                for t in session_table_names_for_wl:
                    valid_columns.update(self.data_processor.dfs[t].columns)
            else:
                # Sessione senza tabelle valide — fallback (back-compat).
                table_names = set(self.data_processor.dfs.keys())
                valid_columns = set()
                for df in self.data_processor.dfs.values():
                    valid_columns.update(df.columns)
            sql_builtins = {"*", "count", "sum", "avg", "min", "max", "rnk", "rank", "percent_rank"}
            master_whitelist = valid_columns | table_names | sql_builtins

            for attempt in range(max_retries + 1):
                try:
                    # 1. Genera SQL diretto
                    sql = await self._generate_sql_query(
                        query, error_context=last_error, mode="export",
                        session_id=session_id,
                    )

                    # 1b. AUTO-FIX reserved-keyword aliases (e.g. `at` → `atx`).
                    # Stocky models pick reserved DuckDB keywords as aliases from
                    # natural-language abbreviation; the parser error is generic
                    # and the model can't autocorrect. Rewrite in place.
                    sql, alias_renames = _autofix_reserved_aliases(sql)
                    if alias_renames:
                        logger.info(f"Auto-fixed reserved aliases: {', '.join(alias_renames)}")

                    # 2a. DIALECT CHECK — intercept known foreign-dialect leaks
                    # (date_part / date_sub / DATEADD / etc.) before DuckDB sees
                    # them, so the retry gets a targeted hint instead of the
                    # generic Binder Error.
                    dialect_err = _dialect_check(sql)
                    if dialect_err:
                        logger.warning(f"Dialect Check failed (Attempt {attempt+1}): {dialect_err}")
                        if attempt < max_retries:
                            last_error = dialect_err
                            continue

                    # 2a-bis. CORRELATION INTENT CHECK — when the prompt asks for
                    # a correlation but the SQL drops it (qwen3-coder routinely
                    # forgets this part in compound prompts), force a retry with
                    # a targeted hint pointing at CORR(X, Y).
                    corr_err = _correlation_intent_check(query, sql)
                    if corr_err:
                        logger.warning(f"Correlation intent missing (Attempt {attempt+1}): {corr_err}")
                        if attempt < max_retries:
                            last_error = corr_err
                            continue

                    # 2a-ter. TOP-N PER GROUP CHECK — "top 3 per regione" should
                    # use ROW_NUMBER() OVER (PARTITION BY region ...). Model
                    # often falls back to a bare LIMIT N which returns N rows
                    # globally, not N per group.
                    topn_err = _top_n_per_group_check(query, sql)
                    if topn_err:
                        logger.warning(f"Top-N per group misuse (Attempt {attempt+1}): bare LIMIT instead of partitioned window")
                        if attempt < max_retries:
                            last_error = topn_err
                            continue

                    # 2a-quater. MoM/QoQ INTENT CHECK — when the prompt asks
                    # for month-over-month growth and the SQL has no LAG/LEAD,
                    # force a retry with the LAG over date_trunc pattern.
                    mom_err = _mom_intent_check(query, sql)
                    if mom_err:
                        logger.warning(f"MoM intent missing (Attempt {attempt+1}): no LAG/LEAD in SQL")
                        if attempt < max_retries:
                            last_error = mom_err
                            continue

                    # 2a-quinquies. YoY INTENT CHECK — year-over-year requires
                    # a manual CASE-WHEN pivot ("one row per group with year A,
                    # year B, yoy_pct"), not a LAG window. Force a retry with
                    # the CASE WHEN year=YYYY pattern when missing.
                    yoy_err = _yoy_intent_check(query, sql)
                    if yoy_err:
                        logger.warning(f"YoY intent missing (Attempt {attempt+1}): no CASE-WHEN year pivot in SQL")
                        if attempt < max_retries:
                            last_error = yoy_err
                            continue

                    # 2b. SOFT VALIDATION (Allucinazioni colonne)
                    sql_quoted = set(re.findall(r'"([^"]+)"', sql))
                    invalid_cols = [c for c in sql_quoted if c not in master_whitelist]

                    if invalid_cols:
                        error_msg = f"Hallucination detected in columns: {invalid_cols}"
                        logger.warning(f"Soft Validation failed (Attempt {attempt+1}): {error_msg}")
                        if attempt < max_retries:
                            last_error = error_msg
                            continue

                    # 2c. SECURITY — rifiuta SQL con accesso file/rete/estensioni.
                    # DuckDB è anche aperto con enable_external_access=False (difesa
                    # primaria); qui blocchiamo PRIMA dell'esecuzione, senza retry
                    # (un token simile = tentativo di injection, non un errore SQL).
                    sec_token = _reject_dangerous_sql(sql)
                    if sec_token:
                        logger.error(f"[SECURITY] Blocked dangerous SQL in Manipulate analyze (token='{sec_token}'): {sql[:200]}")
                        yield (False, i18n.get('manipulate_errors.unsafe_sql', "⚠️ Operazione non consentita: la query generata accedeva a file/rete, vietato in Manipulate."), [])
                        return

                    # 3. Esegui
                    result_df = self.data_processor.sql_manager.con.execute(sql).fetchdf()

                    # 3a-pre. MoM RECOVERY — if the prompt asked for MoM
                    # but the output has no growth column at all (despite the
                    # _mom_intent_check retry hint failing), augment the DF in
                    # pandas. Idempotent: only runs when the growth column is
                    # missing AND the prompt clearly asks for it.
                    try:
                        mom_recovered = _mom_two_pass_recovery(query, sql, result_df)
                    except Exception as e:
                        logger.warning(f"MoM two-pass recovery raised: {e}")
                        mom_recovered = None
                    if mom_recovered is not None and len(mom_recovered) == len(result_df):
                        logger.info(f"MoM two-pass pandas recovery: added growth column to {len(mom_recovered)} rows")
                        result_df = mom_recovered

                    # 3a-bis. YoY RECOVERY — if the prompt asked for YoY but
                    # the model's SQL produced an empty DF (filter self-
                    # cancellation) or no growth column at all, rebuild the
                    # canonical pivot output in pandas. Activated only when
                    # YoY intent matches AND the result is empty or unpivoted.
                    try:
                        yoy_recovered = _yoy_two_pass_recovery(
                            query, sql, result_df,
                            self.data_processor.sql_manager.con,
                            self.data_processor.dfs,
                        )
                    except Exception as e:
                        logger.warning(f"YoY two-pass recovery raised: {e}")
                        yoy_recovered = None
                    if yoy_recovered is not None and not yoy_recovered.empty:
                        logger.info(
                            f"YoY two-pass pandas recovery: {len(yoy_recovered)} rows "
                            f"with columns {list(yoy_recovered.columns)}"
                        )
                        result_df = yoy_recovered

                    # 3a. PARETO COMPLETION CHECK — qwen3-coder routinely emits
                    # `WHERE cum_pct <= 80` which stops one row before crossing
                    # the threshold. The DataFrame is the only place we can
                    # catch this deterministically. If max(cum_pct) is below
                    # the prompt's target, force a retry with the prev_cum
                    # pattern. Empirically grounded: 9/9 Pareto outputs from
                    # 2026-05-13 spot test stopped at 40–78%.
                    pareto_err = _pareto_completion_check(query, result_df)
                    if pareto_err:
                        logger.warning(f"Pareto completion failed (Attempt {attempt+1}): output stops too early")
                        if attempt < max_retries:
                            last_error = pareto_err
                            continue
                        # Retries exhausted — try the pandas two-pass recovery
                        # as last resort. If it works, replace result_df and
                        # break out of the loop with a success. If it fails,
                        # fall through and let the (broken) result reach the
                        # user — we've done our best.
                        try:
                            recovered = _pareto_two_pass_recovery(
                                query, sql, result_df,
                                self.data_processor.sql_manager.con,
                            )
                        except Exception as e:
                            logger.warning(f"Pareto two-pass recovery raised: {e}")
                            recovered = None
                        if recovered is not None and not recovered.empty:
                            logger.info(
                                f"Pareto two-pass pandas recovery: {len(recovered)} rows, "
                                f"max cum_pct {float(recovered['cum_pct'].max()):.2f}"
                            )
                            result_df = recovered

                    # 3b. CORRELATION VALIDITY CHECK — catches NaN/|x|>1 in
                    # corr-named columns (small groups, constant columns).
                    corr_validity_err = _correlation_validity_check(query, result_df)
                    if corr_validity_err:
                        logger.warning(f"Correlation validity failed (Attempt {attempt+1}): invalid Pearson values")
                        if attempt < max_retries:
                            last_error = corr_validity_err
                            continue

                    # 3c. NaN DOMINANCE CHECK — generic safety net for
                    # outputs where the main metric column is >50% NaN
                    # (e.g. z-score on constant column, division by zero
                    # unmasked, filter that no row satisfies). Audit
                    # 2026-05-14 "rotti" had 3/9 falling in this pattern.
                    nan_err = _nan_dominant_check(query, result_df)
                    if nan_err:
                        logger.warning(f"NaN dominance failed (Attempt {attempt+1}): main metric >50% NaN")
                        if attempt < max_retries:
                            last_error = nan_err
                            continue

                    break # Successo

                except Exception as e:
                    err_str = str(e)
                    # When the model writes `date_part('field', table_or_alias)` —
                    # passing the table struct instead of a date column — DuckDB's
                    # error reports `date_part(STRING_LITERAL, STRUCT(<schema>))`.
                    # The generic "use EXTRACT" hint doesn't surface the real
                    # mistake (wrong second arg). Inject a targeted hint so the
                    # retry knows to pass a date column, not the table reference.
                    if "date_part(STRING_LITERAL, STRUCT" in err_str:
                        last_error = (
                            "You called `date_part('field', <table_or_alias>)` — "
                            "passing the entire table struct as the second argument. "
                            "Pass a DATE/TIMESTAMP COLUMN of the table instead, "
                            "e.g. `EXTRACT(year FROM <alias>.Data_Assunzione)` "
                            "where Data_Assunzione (or another date column) is "
                            "the actual column you want to extract from. Rewrite."
                        )
                    # Comparing a typed column (DATE/TIMESTAMP/numeric) to the
                    # empty string — e.g. `WHERE Data_Cessazione = ''` to model
                    # "blank/active rows". DuckDB stores blank/missing cells of a
                    # typed column as NULL, not '', and reports the failed cast
                    # generically (e.g. "Could not convert string '' to INT64",
                    # where INT64 is the internal repr of a TIMESTAMP). The raw
                    # error isn't actionable, so the model regenerates the same
                    # `= ''` and loops. Steer it to IS NULL explicitly.
                    elif "convert string '' to" in err_str or "Could not convert string ''" in err_str:
                        last_error = (
                            "You compared a typed column (DATE/TIMESTAMP/numeric) "
                            "to the empty string '', e.g. `colonna = ''`. Blank or "
                            "missing cells in a typed column are NULL in this "
                            "database, NOT the empty string. Replace every "
                            "`colonna = ''` with `colonna IS NULL` (and "
                            "`colonna <> ''` with `colonna IS NOT NULL`). Do not "
                            "compare typed columns to ''. Rewrite the SQL."
                        )
                    else:
                        last_error = err_str
                    logger.warning(f"SQL Execution failed (Attempt {attempt+1}): {e}")
                    if attempt >= max_retries:
                        # Mostra messaggio user-friendly. I dettagli tecnici (str(e)) sono già
                        # in `last_error` e già loggati come WARNING via logger.warning sopra.
                        # Non li esponiamo all'utente: stack trace SQL non leggibile da non-tecnici.
                        user_msg = i18n.get(
                            'manipulate_errors.final_sql_error',
                            "❌ Non sono riuscito a completare la richiesta dopo 3 tentativi.\n\n"
                            "1° — Prova prima a riformulare la richiesta in modo più semplice:\n"
                            "• Sii esplicito sulla dimensione di aggregazione (es. \"per Mese\", \"per Categoria\", \"per Agente\")\n"
                            "• Evita termini ambigui (es. \"Vendite\" vs \"Fatturato\" vs \"Profitto\") — usa direttamente i nomi delle colonne del tuo file\n"
                            "• Spezzetta le formule a step multipli in più richieste semplici\n"
                            "• Verifica che i nomi di colonna citati esistano nello schema del tuo file\n\n"
                            "2° — Se anche la riformulazione non basta, considera di:\n"
                            "• Anonimizzare i dati sensibili con il modulo Anonimyze\n"
                            "• Affidare l'analisi a un modello cloud più potente sui dati anonimizzati\n"
                            "• Reimportare i risultati su PAIS per la presentazione finale",
                        )
                        yield (False, user_msg, [])
                        return

            # --- 4. EXPORT EXCEL ---
            try:
                if result_df.empty:
                    yield (False, i18n.get('manipulate_errors.no_results_error', "⚠️ La trasformazione non ha prodotto risultati. Verifica i filtri."), [])
                    return

                # 3. Export Excel — plain, no styler.
                # Product decision (2026-05-11): the "Export to Sheet" output
                # must prioritize numeric fidelity over visual styling. The
                # styler is still used by `analyze_style` for explicit user
                # restyling requests, but not here.
                timestamp = int(time.time())
                filename = f"transformed_data_{timestamp}.xlsx"
                output_dir = project_manager.get_path("output")
                output_dir.mkdir(parents=True, exist_ok=True)
                filepath = output_dir / filename

                _adaptive_round_floats(result_df)
                result_df.to_excel(filepath, index=False, engine="openpyxl")
                
                # 4. Risposta Finale (Asciutta come NiceGUI)
                msg = f"✅ **{i18n.get('manipulate_stages.operation_completed', 'Operazione completata con successo.')}**\n\n"
                msg += f"{i18n.get('manipulate_stages.excel_generated', 'Ho generato un nuovo foglio di calcolo con i dati richiesti.')}\n"
                msg += f"📊 **{i18n.get('manipulate_stages.rows', 'Righe')}:** {len(result_df)} | **{i18n.get('manipulate_stages.cols', 'Colonne')}:** {len(result_df.columns)}\n\n"

                # Implicit-filter disclosure: if the executed SQL has equality
                # filters whose values are NOT mentioned in the prompt, warn the
                # user — these silently restrict the result without the user
                # asking. Rule #9 in the system prompt tries to prevent this
                # but the model still emits silent filters. We don't retry
                # (the SQL is valid), we just surface the choice.
                implicit_filters = _detect_implicit_filters(query, sql)
                if implicit_filters:
                    filters_str = ", ".join(f"`{c}='{v}'`" for c, v in implicit_filters[:5])
                    _title = i18n.get('manipulate_stages.implicit_filters_title', 'Filtri impliciti applicati')
                    _subtitle = i18n.get('manipulate_stages.implicit_filters_subtitle', '(non richiesti dal prompt)')
                    _hint = i18n.get(
                        'manipulate_stages.implicit_filters_hint',
                        "Se vuoi tutti i record senza filtro, riformula esplicitando 'senza filtro' o specifica i valori da includere."
                    )
                    msg += f"ℹ️ **{_title}** {_subtitle}: {filters_str}. {_hint}\n\n"
                    logger.warning(f"Implicit filters disclosed: {implicit_filters}")

                msg += f"📄 {i18n.get('manipulate_stages.file', 'File')}: **{filename}**\n"
                msg += f"<!-- FILE:{filename} -->"

                yield (True, msg, [str(filepath)])
                
                # Salva in sessione
                self.sessions.setdefault(session_id, []).append({"role": "user", "content": query})
                self.sessions[session_id].append({"role": "assistant", "content": msg})
                self._save_session(session_id)
                return

            except Exception as e:
                logger.error(f"Export to Sheet error: {e}")
                yield (False, i18n.get('manipulate_errors.export_error', f"❌ Errore durante l'esportazione: {str(e)}").replace('{error}', str(e)), [])
                return

        # --- CASO 2: ALTRI MODULI ---
        yield (False, f"⚠️ Modalità '{mode}' non ottimizzata nel flusso streaming.", [])

    async def analyze_charts(self, query: str, session_id: str, chart_type: str = "Auto") -> str:
        """
        Gestisce la generazione di grafici (Add Charts).
        Replicata la logica _execute_chart_flow di NiceGUI.
        """
        if not self.uploaded_files.get(session_id):
            return i18n.get('manipulate_errors.no_files_loaded', "⚠️ Nessun file caricato.")

        from services.i18n_service import i18n
        
        # 1. Carica Prompt
        prompts = self.prompts.get('manipulate_stages', {})
        chart_cfg = prompts.get('chart_architect', {})
        
        summary = self.data_processor.get_technical_schema()
        tables_info = ", ".join(self.data_processor.dfs.keys())
        
        sys_prompt = chart_cfg.get('system', 'Design a chart JSON.').replace('{schema}', summary).replace('{tables}', tables_info)
        # Assicurati che l'output sia nella lingua corrente, usando il formato legacy esatto
        lang_map = {'it': 'italian', 'en': 'english', 'es': 'spanish', 'fr': 'french', 'de': 'german'}
        target_lang = lang_map.get(self.lang.lower(), 'english')
        sys_prompt += f" (reply in this language: {target_lang})"
        
        user_msg_content = f"REQUEST: {query}"
        if chart_type and chart_type != "Auto":
            user_msg_content += f"\n\nMANDATORY CHART TYPE: Use '{chart_type}' for the chart configuration."

        messages = [{'role': 'system', 'content': sys_prompt}, {'role': 'user', 'content': user_msg_content}]
        
        attempts = 0
        while attempts < 3:
            try:
                # Usa il modello engineering (qwen3-coder) con dynamic ctx
                resp = await self.ollama.chat(
                    model=await self._resolve_coder(self.models.get('engineering_model', 'qwen3-coder:30b')),
                    messages=messages,
                    num_ctx=AUTO_CTX,
                    max_ctx=settings.MANIPULATE_CTX,
                    temperature=0.1
                )

                raw = resp
                json_match = re.search(r'\{.*\}', raw, re.DOTALL)
                if not json_match:
                    messages.append({'role': 'user', 'content': "Error: Invalid JSON."})
                    attempts += 1
                    continue
                
                design = json.loads(json_match.group(0))
                sql = design.get('sql_query', "").replace('`', '"')
                df_res = self.data_processor.sql_manager.con.execute(sql).fetchdf()
                
                if df_res.empty:
                    messages.append({'role': 'user', 'content': "Query returned no data."})
                    attempts += 1
                    continue

                config = design.get('chart_config', {})
                kind = config.get('kind', 'column')
                title = config.get('title', 'Chart')
                x_col = config.get('x_col') if config.get('x_col') in df_res.columns else df_res.columns[0]
                y_col = config.get('y_cols', [df_res.columns[1] if len(df_res.columns)>1 else df_res.columns[0]])[0]
                
                # 1. Genera Excel con Chart Nativo
                path = await self.charter.tool_create_excel_chart(df_res, x_col=x_col, y_col=y_col, chart_type=kind, title=title)
                
                # 2. Genera PNG Statico (opzionale)
                img_path = self.charter.tool_create_static_chart(df_res, chart_type=kind, x_col=x_col, y_col=y_col, title=title)
                
                if path:
                    fname_xl = os.path.basename(path)
                    fname_img = os.path.basename(img_path) if img_path else None
                    
                    # Messaggio localizzato
                    msg_confirm = i18n.get('chat.chart_created_msg', "Ho generato sia il file xlsx che l'immagine.")
                    
                    msg = f"✅ **{msg_confirm}**\n\n"
                    msg += f"📊 **{i18n.get('manipulate_stages.analysis', 'Analisi')}:** {design.get('reasoning', '')}\n\n"
                    msg += f"📄 {i18n.get('manipulate_stages.file', 'File')} XLSX: **{fname_xl}**\n"
                    if fname_img:
                        msg += f"🖼️ {i18n.get('manipulate_stages.image', 'Immagine')}: **{fname_img}**\n"
                    
                    msg += f"<!-- FILE:{fname_xl} -->"
                    if fname_img:
                        msg += f"<!-- IMG:{fname_img} -->"
                    
                    self.sessions.setdefault(session_id, []).append({"role": "user", "content": query})
                    self.sessions[session_id].append({"role": "assistant", "content": msg})
                    self._save_session(session_id)
                    return msg
                
                return i18n.get('manipulate_errors.chart_excel_error', "❌ Errore nella generazione del grafico Excel.")
                
            except Exception as e:
                logger.error(f"Chart generation error: {e}")
                messages.append({'role': 'user', 'content': f"Error: {e}"})
                attempts += 1
                
        return i18n.get('manipulate_errors.chart_max_attempts', "❌ Impossibile generare il grafico dopo vari tentativi.")

    async def analyze_style(self, session_id: str, excel_style: str = "Corporate Blue", style_options: Optional[dict] = None) -> str:
        """
        Gestisce la stilizzazione (Add Style).
        Replicata la logica _execute_style_only_flow di NiceGUI (Doppio motore).
        style_options: toggle 'cosa includere' (formattazione condizionale, sparkline,
        menu a tendina, freeze, autofilter). Onorati solo nello Scenario B (XlsxWriter);
        nello Scenario A (file con grafici, OpenPyXL) si stila solo l'header e i toggle
        vengono ignorati per non distruggere i grafici esistenti.
        """
        from services.i18n_service import i18n

        self._get_or_create_session(session_id)
        session_files = self.uploaded_files.get(session_id, [])
        
        if not session_files:
            return i18n.get('manipulate_errors.no_files_style_session', "⚠️ Nessun file caricato in questa sessione per la formattazione.")

        try:
            # 1. Prendi l'ULTIMO file caricato in questa specifica sessione
            target_file = session_files[-1]
            original_path = target_file.get('path', '')

            # Recupera solo i DataFrame che appartengono a questo file
            target_tables = target_file.get('tables', [])
            if not target_tables:
                return i18n.get('manipulate_errors.tables_not_found', "⚠️ Errore: tabelle non trovate per il file selezionato. Prova a ricaricarlo.")

            # Filtra sheets_data per includere solo le tabelle di questo file
            sheets_to_style = {}
            for t_name in target_tables:
                if t_name in self.data_processor.dfs:
                    sheets_to_style[t_name] = self.data_processor.dfs[t_name]

            if not sheets_to_style:
                return i18n.get('manipulate_errors.stale_data', "⚠️ Errore: i dati in memoria sono scaduti o non corrispondono al file.")

            import time
            style_suffix = excel_style.replace(' ', '_').lower()
            output_name = f"styled_{style_suffix}_{int(time.time())}.xlsx"

            # 2. SCENARIO A: Preservazione (OpenPyXL) se il file ha grafici
            if original_path and os.path.exists(original_path) and self.styler._has_charts(original_path):
                logger.info(f"[STYLE] Preserving charts for {original_path}")
                # Nota: OpenPyXL in questa versione gestisce un DF alla volta, semplifichiamo al primo
                df_main = list(sheets_to_style.values())[0]
                if style_options:
                    logger.info("[STYLE] Charts present → OpenPyXL header-only path; style_options ignored")
                result = await self.styler.apply_style_with_preservation(
                    original_path, output_name, df_main, excel_style=excel_style
                )
                msg = i18n.get('manipulate_stages.style_applied_preservation', "✅ Stile '{style}' applicato (grafici e macro preservati).\n\n").replace('{style}', excel_style)
                msg += i18n.get('manipulate_stages.style_charts_header_only', "ℹ️ Il file contiene grafici: applicato solo lo stile delle intestazioni (le opzioni avanzate non si applicano per non danneggiare i grafici).\n\n")
            
            # 3. SCENARIO B: Nuova Grafica (XlsxWriter)
            else:
                logger.info(f"[STYLE] Applying advanced XlsxWriter formatting to {len(sheets_to_style)} sheets")
                result = await self.styler.tool_create_report(
                    sheets_data=sheets_to_style,
                    filename=output_name,
                    styling="pro",
                    excel_style=excel_style,
                    style_options=style_options
                )
                msg = i18n.get('manipulate_stages.style_applied_success', "✅ Stile '{style}' applicato con successo.\n\n").replace('{style}', excel_style)
            
            if result:
                fname = os.path.basename(result)
                msg += f"📄 {i18n.get('manipulate_stages.file', 'File')}: **{fname}**\n"
                msg += f"<!-- FILE:{fname} -->"
                
                self.sessions.setdefault(session_id, []).append({"role": "user", "content": f"{i18n.get('manipulate.apply_style', 'Applica stile')}: {excel_style}"})
                self.sessions[session_id].append({"role": "assistant", "content": msg})
                self._save_session(session_id)
                return msg
                
            return i18n.get('manipulate_errors.report_creation_error', "❌ Errore nella creazione del report formattato.")
        except Exception as e:
            logger.error(f"Add Style error: {e}")
            return i18n.get('manipulate_errors.style_application_error', "❌ Errore applicazione stile: {error}").replace('{error}', str(e))

    async def merge_sheets(self, session_id: str) -> str:
        """Merge Sheets (4° sottomodulo Manipulate).

        FEDELTÀ PIENA: copia i fogli DAI FILE ORIGINALI in un unico xlsx
        preservando celle+stili, larghezze, celle unite, freeze, autofilter e
        soprattutto i GRAFICI nativi e le immagini (motore openpyxl). Nessun
        JOIN SQL: ogni foglio sorgente diventa un foglio del file unito (nome =
        nome foglio originale, deduplicato su collisione con riscrittura dei
        riferimenti dei grafici).

        Fallback: CSV, .xls o file non apribili come xlsx vengono uniti in
        modalità "solo dati" (dal DataFrame, senza stile/grafici) e segnalati.
        """
        from services.i18n_service import i18n
        import time
        import re as _re

        self._get_or_create_session(session_id)
        session_files = self.uploaded_files.get(session_id, [])

        if not session_files:
            return i18n.get(
                'manipulate_errors.no_files_loaded',
                "⚠️ Nessun file caricato.",
            )
        if len(session_files) < 2:
            return i18n.get(
                'manipulate_errors.merge_min_files',
                "⚠️ Servono almeno 2 file per il merge. Carica un altro file e riprova.",
            )

        # === MERGE A FEDELTÀ PIENA ============================================
        # Costruisce 1 workbook openpyxl copiando i fogli DAI FILE ORIGINALI
        # (celle + stili + larghezze + celle unite + grafici + immagini) così i
        # grafici nativi e la formattazione NON vengono persi. CSV / .xls / file
        # non apribili → fallback al path "solo dati" (dal DataFrame) per quel file.
        from copy import copy as _copy
        try:
            import openpyxl as _oxl
        except Exception:
            _oxl = None

        used_names: set = set()

        def _uniq_sheet_name(name: str) -> str:
            """Excel sheet name: max 31 char, no [ ] : * ? / \\, unique."""
            safe = _re.sub(r"[\[\]:\*\?/\\]", "_", str(name)).strip()[:31] or "Sheet"
            base, final, i = safe, safe, 2
            while final in used_names:
                suffix = f"_{i}"
                final = base[: 31 - len(suffix)] + suffix
                i += 1
            used_names.add(final)
            return final

        def _copy_cell_style(sc, dc):
            if getattr(sc, "has_style", False):
                dc.font = _copy(sc.font)
                dc.fill = _copy(sc.fill)
                dc.border = _copy(sc.border)
                dc.alignment = _copy(sc.alignment)
                dc.protection = _copy(sc.protection)
                dc.number_format = sc.number_format

        def _rewrite_chart_refs(chart, old: str, new: str):
            """Foglio rinominato (collisione) → riscrive il nome foglio nei
            riferimenti del grafico, sia 'Nome'! che Nome! (best-effort)."""
            if old == new:
                return
            pairs = [(f"'{old}'!", f"'{new}'!"), (f"{old}!", f"{new}!")]

            def _fix(formula):
                if not formula:
                    return formula
                for a, b in pairs:
                    formula = formula.replace(a, b)
                return formula
            try:
                for s in getattr(chart, "series", []) or []:
                    for ref in (getattr(s, "val", None), getattr(s, "cat", None)):
                        if ref is None:
                            continue
                        if getattr(ref, "numRef", None) is not None and ref.numRef.f:
                            ref.numRef.f = _fix(ref.numRef.f)
                        if getattr(ref, "strRef", None) is not None and ref.strRef.f:
                            ref.strRef.f = _fix(ref.strRef.f)
                    tx = getattr(s, "tx", None)
                    if tx is not None and getattr(tx, "strRef", None) is not None and tx.strRef.f:
                        tx.strRef.f = _fix(tx.strRef.f)
            except Exception as _e:
                logger.warning(f"[MERGE] chart ref rewrite failed: {_e}")

        def _copy_sheet_faithful(src_ws, dst_ws):
            for row in src_ws.iter_rows():
                for cell in row:
                    if cell.value is None and not getattr(cell, "has_style", False):
                        continue
                    nc = dst_ws.cell(row=cell.row, column=cell.column, value=cell.value)
                    _copy_cell_style(cell, nc)
            for k, dim in src_ws.column_dimensions.items():
                d = dst_ws.column_dimensions[k]
                if dim.width is not None:
                    d.width = dim.width
                d.hidden = dim.hidden
            for idx, dim in src_ws.row_dimensions.items():
                if dim.height is not None:
                    dst_ws.row_dimensions[idx].height = dim.height
            for mc in list(src_ws.merged_cells.ranges):
                try:
                    dst_ws.merge_cells(str(mc))
                except Exception:
                    pass
            if src_ws.freeze_panes:
                dst_ws.freeze_panes = src_ws.freeze_panes
            if src_ws.auto_filter and src_ws.auto_filter.ref:
                dst_ws.auto_filter.ref = src_ws.auto_filter.ref

        def _write_df_sheet(dst_ws, df):
            """Fallback solo-dati: header + righe, senza stile."""
            dst_ws.append([str(c) for c in df.columns])
            for _, r in df.iterrows():
                dst_ws.append(["" if pd.isna(v) else v for v in r.tolist()])

        if _oxl is None:
            return i18n.get('manipulate_errors.merge_error', "❌ Errore durante il merge: {error}").replace("{error}", "openpyxl non disponibile")

        merged = _oxl.Workbook()
        merged.remove(merged.active)
        n_sheets, n_charts = 0, 0
        degraded = []

        for f in session_files:
            fname = f.get("name", "")
            fpath = f.get("path", "")
            base_name = os.path.splitext(fname)[0] if fname else "Sheet"
            ext = os.path.splitext(fname)[1].lower()

            faithful_ok = False
            if ext == ".xlsx" and fpath and os.path.exists(fpath):
                try:
                    src_wb = _oxl.load_workbook(fpath)
                    for src_ws in src_wb.worksheets:
                        new_name = _uniq_sheet_name(src_ws.title)
                        dst_ws = merged.create_sheet(new_name)
                        _copy_sheet_faithful(src_ws, dst_ws)
                        for ch in list(getattr(src_ws, "_charts", []) or []):
                            _rewrite_chart_refs(ch, src_ws.title, new_name)
                            try:
                                dst_ws.add_chart(ch)  # mantiene ch.anchor (posizione)
                                n_charts += 1
                            except Exception as _e:
                                logger.warning(f"[MERGE] chart copy failed ({fname}/{src_ws.title}): {_e}")
                        for img in list(getattr(src_ws, "_images", []) or []):
                            try:
                                dst_ws.add_image(img)
                            except Exception:
                                pass
                        n_sheets += 1
                    faithful_ok = True
                except Exception as e:
                    logger.warning(f"[MERGE] faithful copy failed for {fname}, fallback to data: {e}")

            if faithful_ok:
                continue

            # FALLBACK solo-dati. Per CSV/.xls è il comportamento ATTESO (non hanno
            # grafici/formattazione → nessuna perdita, niente avviso). Solo un .xlsx
            # finito qui per un errore di copia fedele è una perdita reale → segnala.
            if ext == ".xlsx":
                degraded.append(fname)
            for t_name in f.get("tables", []):
                df = self.data_processor.dfs.get(t_name)
                if df is None:
                    continue
                if t_name.lower().startswith(base_name.lower().replace(" ", "_")) and t_name.lower() != base_name.lower():
                    label = t_name
                else:
                    label = base_name
                _write_df_sheet(merged.create_sheet(_uniq_sheet_name(label)), df)
                n_sheets += 1

        if n_sheets == 0:
            return i18n.get(
                'manipulate_errors.merge_no_data',
                "⚠️ Nessun dato disponibile per il merge. Riprova dopo aver memorizzato i file.",
            )

        try:
            timestamp = int(time.time())
            filename = f"merged_sheets_{timestamp}.xlsx"
            output_dir = project_manager.get_path("output")
            output_dir.mkdir(parents=True, exist_ok=True)
            filepath = output_dir / filename
            merged.save(str(filepath))

            logger.info(
                f"[MERGE] Wrote {n_sheets} sheets ({n_charts} charts) to {filename} "
                f"from {len(session_files)} source files"
            )

            msg = f"✅ **{i18n.get('manipulate_stages.merge_completed', 'Merge completato.')}**\n\n"
            msg += i18n.get(
                'manipulate_stages.merge_summary',
                "Ho unito {n_files} file in un nuovo foglio di calcolo con {n_sheets} fogli."
            ).replace("{n_files}", str(len(session_files))).replace("{n_sheets}", str(n_sheets)) + "\n\n"
            if degraded:
                msg += i18n.get(
                    'manipulate_stages.merge_degraded',
                    "⚠️ Per questi file ho unito solo i dati (CSV o non leggibili come xlsx): {files}.\n\n"
                ).replace("{files}", ", ".join(degraded))
            msg += f"📄 {i18n.get('manipulate_stages.file', 'File')}: **{filename}**\n"
            msg += f"<!-- FILE:{filename} -->"

            self.sessions.setdefault(session_id, []).append({
                "role": "user",
                "content": i18n.get('manipulate.merge_sheets', 'Unisci fogli'),
            })
            self.sessions[session_id].append({"role": "assistant", "content": msg})
            self._save_session(session_id)
            return msg
        except Exception as e:
            logger.error(f"Merge Sheets error: {e}")
            return i18n.get(
                'manipulate_errors.merge_error',
                "❌ Errore durante il merge: {error}",
            ).replace("{error}", str(e))

    async def _generate_interpretation(self, result_df, query: str) -> str:
        """Genera interpretazione business con analyst_prompt."""
        prompts = self.prompts.get('data_analysis', {})
        analyst_prompt = prompts.get('analyst_prompt', '')

        # Converti DataFrame a markdown table
        raw_output = result_df.to_markdown(index=False)

        # Format prompt
        formatted_prompt = analyst_prompt.format(
            query=query,
            raw_output=raw_output,
            db_summary=self.data_processor.get_rag_content(),
            lang_instruction=i18n.get('manipulate_stages.interpretation_lang', "Rispondi in italiano")
        )

        messages = [{"role": "user", "content": formatted_prompt}]

        response = await self.ollama.chat(
            model=await self._resolve_coder(self.models.get('manipulate_model', 'qwen3-coder:30b')),
            messages=messages,
            stream=False,
            num_ctx=AUTO_CTX,
            max_ctx=settings.MANIPULATE_CTX,
            temperature=0.3
        )

        return response

    def get_staged_files(self, session_id: str) -> List[Dict]:
        """Ottieni file in staging."""
        self._get_or_create_session(session_id)
        return self.staged_files.get(session_id, [])

    def get_uploaded_files(self, session_id: str) -> List[Dict]:
        """Ottieni file caricati."""
        self._get_or_create_session(session_id)
        return self.uploaded_files.get(session_id, [])

    def remove_file(self, filename: str, session_id: str, from_staged: bool = False):
        """Rimuovi file da staging o caricati."""
        if from_staged:
            self.staged_files[session_id] = [
                f for f in self.staged_files.get(session_id, [])
                if f['name'] != filename
            ]
        else:
            self.data_processor.remove_data(filename)
            self.uploaded_files[session_id] = [
                f for f in self.uploaded_files.get(session_id, [])
                if f['name'] != filename
            ]
        self._save_session(session_id)

    def clear_session(self, session_id: str):
        """Cancella sessione fisica e logica."""
        if session_id in self.sessions:
            del self.sessions[session_id]
        
        if session_id in self.uploaded_files:
            # Rimuovi fisicamente ogni file e le sue tabelle DuckDB
            for f in list(self.uploaded_files[session_id]):
                self.data_processor.remove_data(f['name'])
            del self.uploaded_files[session_id]
            
        if session_id in self.staged_files:
            del self.staged_files[session_id]

        # Pulisci anche DuckDB (Shared engine cleanup)
        self.data_processor.clear_session()

        session_file = self._get_session_file(session_id)
        if session_file.exists():
            session_file.unlink()
        
        logger.info(f"🗑️ Sessione {session_id} eliminata completamente.")
