"""Adapter Presidio: wrappa un NerEngine come `EntityRecognizer`."""
from presidio_analyzer import EntityRecognizer, RecognizerResult

from .base import NerEngine


class PiiNerRecognizer(EntityRecognizer):
    def __init__(self, ner_engine: NerEngine, supported_language: str):
        super().__init__(
            supported_entities=sorted(ner_engine.supported_entities),
            supported_language=supported_language,
            name="PiiNerRecognizer",
        )
        self._ner = ner_engine

    def load(self) -> None:
        return None

    def analyze(self, text, entities, nlp_artifacts=None):
        spans = self._ner.analyze(text, self.supported_language)
        target = set(entities) if entities else None
        results = []
        for s in spans:
            if target and s.entity_type not in target:
                continue
            results.append(RecognizerResult(
                entity_type=s.entity_type,
                start=s.start,
                end=s.end,
                score=s.score,
                analysis_explanation=None,
                recognition_metadata={"recognizer_name": "PiiNerRecognizer"},
            ))
        return results
