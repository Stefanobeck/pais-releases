"""
Faster-Whisper Processor — motore dedicato per la dettatura push-to-talk.

Ottimizzato per audio brevi della dettatura chat: latenza bassa, no docx/txt
write, no timecode. (NB: il vecchio tool Utility "Transcribe" basato su
openai-whisper è stato rimosso; questo motore faster-whisper resta per la
dettatura da microfono.)

Modello: Systran/faster-whisper-medium (~480MB), int8 CPU.
Download lazy via HuggingFace al primo `_ensure_model_loaded()` o forzato
dal sistema di onboarding (`system_service.install_model`).
"""
import os
import re
import time
import logging
import asyncio
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Singleton module-level — il modello caricato resta in RAM per tutta la vita
# del processo (~700MB con compute_type="int8"). Pattern identico a
# TranscribeProcessor._whisper_model.
_FW_MODEL = None

# Repo HuggingFace ufficiale dei modelli CTranslate2 di faster-whisper.
FW_HF_REPO = "Systran/faster-whisper-medium"

# Regex per intercettare il trigger di invio: la parola "Enter" pronunciata
# alla fine della dettatura. Whisper la trascrive con varie punteggiature
# ("Enter", "Enter!", "Enter."), maiuscola o minuscola. Ancorata a $ per
# evitare di consumare "Enter" detti a metà frase.
_ENTER_TRIGGER_RE = re.compile(r"\s*[Ee]nter[!\.\?\,\;\s]*$")


def _hf_cache_root() -> Path:
    """Path root della cache HuggingFace.
    Rispetta HF_HOME se settato, altrimenti default `~/.cache/huggingface`."""
    hf_home = os.environ.get("HF_HOME")
    if hf_home:
        return Path(hf_home)
    return Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".cache" / "huggingface"


def _legacy_hf_blob_dir() -> Path:
    """Vecchia posizione blob/snapshot generata da snapshot_download() senza
    local_dir. Lasciata SOLO per la cleanup: gli embedded Python su Windows
    non riescono a finalizzare la symlink da blobs/ a snapshots/ -> CTranslate2
    trova snapshots/<sha>/ ma non model.bin, fallisce con "Unable to open file".
    Vedi commit di fix bug Setup 1.0."""
    return _hf_cache_root() / "hub" / "models--Systran--faster-whisper-medium"


# Dimensione del model.bin reale (CTranslate2 int8 di faster-whisper-medium): ~480MB.
# Soglia "complete": >= 400MB = file integro post-download.
# Soglia "incomplete": >= 200MB = file parziale ma riconoscibile, download
# probabilmente interrotto a metà — non valido per inferenza ma ci dice
# "esiste qualcosa in download" (vedi get_install_state).
_FW_MODEL_BIN_COMPLETE_SIZE = 400 * 1024 * 1024
_FW_MODEL_BIN_PARTIAL_SIZE = 200 * 1024 * 1024

# Sentinel file scritto SOLO dopo che il modello è stato caricato con successo
# almeno una volta. Distingue "cartella esiste ma download interrotto" da
# "download completo e verificato". Vedi mark_model_installed() sotto.
_FW_SENTINEL = ".pais_install_complete"


def _fw_model_dir() -> Path:
    """Flat local dir per i pesi faster-whisper. Bypassa il sistema
    blobs/snapshots di HF: WhisperModel(local_dir) apre direttamente
    model.bin senza dipendere da symlink (che falliscono silenziosamente
    nell'embedded Python portable su Windows)."""
    return _hf_cache_root() / "pais-models" / "faster-whisper-medium"


def fw_model_dir() -> Path:
    """Versione pubblica di _fw_model_dir per i chiamanti esterni
    (system_service.install_model). Stesso path."""
    return _fw_model_dir()


def _find_largest_model_bin() -> Optional[Path]:
    """Ritorna il path del piu' grande model.bin nella cache HF, oppure None.
    Usato sia da mark_model_installed (per scrivere sentinel) sia da
    get_install_state (per categorizzare lo stato)."""
    try:
        model_dir = _fw_model_dir()
        if not model_dir.exists():
            return None
        candidates = [p for p in model_dir.rglob("model.bin") if p.is_file()]
        if not candidates:
            return None
        return max(candidates, key=lambda p: p.stat().st_size)
    except Exception:
        return None


def get_install_state() -> str:
    """Stato dettagliato dell'install del modello.

    Returns:
      - "missing":    cartella inesistente, niente da fare
      - "incomplete": file presente ma < 200MB (download interrotto presto)
      - "partial":    file 200-400MB (download interrotto a meta')
      - "ready":      file >= 400MB ma sentinel MANCANTE (non validato da load)
      - "complete":   file >= 400MB E sentinel presente (verificato, usabile)
    """
    bin_path = _find_largest_model_bin()
    if bin_path is None:
        return "missing"
    size = bin_path.stat().st_size
    if size < _FW_MODEL_BIN_PARTIAL_SIZE:
        return "incomplete"
    if size < _FW_MODEL_BIN_COMPLETE_SIZE:
        return "partial"
    sentinel = bin_path.parent / _FW_SENTINEL
    return "complete" if sentinel.exists() else "ready"


def is_model_installed() -> bool:
    """True solo se lo stato e' 'complete' (file integro + sentinel verificato).
    Tutti gli altri stati (missing/incomplete/partial/ready) sono trattati come
    "non installato" -> install_model triggera download/retry."""
    return get_install_state() == "complete"


def mark_model_installed() -> None:
    """Scrive il sentinel `.pais_install_complete` accanto al model.bin.

    Strategia tollerante: usa il piu' grande model.bin disponibile, anche se
    e' "ready" (>= 400MB ma non ancora marked). NON scriviamo sentinel su
    file < 400MB (sarebbero ancora parziali).

    Chiamata SOLO dopo che WhisperModel().load() ha avuto successo (vedi
    system_service.install_model). Idempotente, non solleva."""
    try:
        bin_path = _find_largest_model_bin()
        if bin_path is None:
            logger.warning("mark_model_installed: nessun model.bin in cache HF.")
            return
        size = bin_path.stat().st_size
        if size < _FW_MODEL_BIN_COMPLETE_SIZE:
            logger.warning(
                f"mark_model_installed: model.bin troppo piccolo ({size/1e6:.1f}MB < 400MB), "
                f"sentinel NON scritto. Probabile download incompleto."
            )
            return
        sentinel = bin_path.parent / _FW_SENTINEL
        sentinel.write_text("ok", encoding="ascii")
        logger.info(f"mark_model_installed: sentinel scritto in {sentinel}")
    except Exception as e:
        logger.warning(f"mark_model_installed failed: {e}")


def cleanup_corrupted_install() -> None:
    """Elimina la cartella del modello se corrotta/incompleta. Usata dal
    flow di install per garantire idempotenza: se l'utente preme Reinstall
    su un modello con download interrotto, ripartiamo da zero pulito.
    Pulisce SIA la nuova flat dir SIA la vecchia HF blob/snapshot dir
    (orfani lasciati da tentativi precedenti). Idempotente, non solleva."""
    import shutil
    for d in (_fw_model_dir(), _legacy_hf_blob_dir()):
        try:
            if d.exists():
                shutil.rmtree(d, ignore_errors=True)
                logger.info(f"Cleanup faster-whisper: rimossa cartella {d}")
        except Exception as e:
            logger.warning(f"cleanup_corrupted_install failed for {d}: {e}")


def _ensure_model_loaded() -> bool:
    """Carica il singleton se i pesi esistono in cache. Se mancano, ritorna
    False — il chiamante deve mostrare errore "Scaricalo dall'Onboarding".
    Comportamento allineato a TranscribeProcessor.ensure_model_loaded()."""
    global _FW_MODEL
    if _FW_MODEL is not None:
        return True
    if not is_model_installed():
        logger.warning(
            "faster-whisper-medium missing from HF cache. "
            "Download must happen via Onboarding."
        )
        return False
    try:
        from faster_whisper import WhisperModel
        local_dir = _fw_model_dir()
        logger.info(f"Lazy-loading faster-whisper medium (int8, cpu) from {local_dir}...")
        _FW_MODEL = WhisperModel(str(local_dir), device="cpu", compute_type="int8")
        logger.info("faster-whisper Medium model loaded successfully.")
        return True
    except Exception as e:
        logger.error(f"faster-whisper loading FAILED: {e}")
        _FW_MODEL = None
        return False


async def transcribe_short(audio_path: str, language: Optional[str] = "it") -> dict:
    """Trascrive un audio breve della dettatura. Ritorna dict pronto per JSON.

    Args:
        audio_path: path locale al file audio (webm/opus o wav)
        language: ISO 639-1 (default "it"). None = auto-detect Whisper

    Returns:
        {
          "text": str,               # testo trascritto, con eventuale "Enter" finale rimosso
          "lang": str,               # lingua effettivamente usata
          "duration_s": float,       # durata audio in secondi (da info.duration)
          "infer_s": float,          # tempo di inferenza (telemetria)
          "enter_command": bool,     # True se l'utente ha detto "Enter" in fondo
        }

    Raises:
        RuntimeError se il modello non è caricato (chiamante: HTTP 400 con hint Onboarding).
    """
    if not _ensure_model_loaded():
        raise RuntimeError(
            "Modello faster-whisper non pronto. Scaricalo dall'Onboarding."
        )

    loop = asyncio.get_event_loop()
    t0 = time.perf_counter()

    def _run():
        # beam_size=1 (greedy) per la massima velocità — accettabile su frasi brevi.
        # vad_filter=False: l'audio è già tagliato dall'utente con click STOP.
        # condition_on_previous_text=False: previene la maggior parte delle
        # allucinazioni "completa la frase" che Whisper tende a fare su audio
        # interrotti improvvisamente.
        segments, info = _FW_MODEL.transcribe(
            audio_path,
            language=language,
            beam_size=1,
            vad_filter=False,
            condition_on_previous_text=False,
        )
        # Forza l'iteratore (faster-whisper è lazy)
        seg_texts = [s.text for s in segments]
        return seg_texts, info

    seg_texts, info = await loop.run_in_executor(None, _run)
    infer_s = time.perf_counter() - t0

    raw_text = " ".join(s.strip() for s in seg_texts).strip()
    # Normalizza spazi multipli (Whisper a volte mette doppi spazi tra segmenti)
    raw_text = re.sub(r"\s+", " ", raw_text)

    # Detect trigger "Enter" finale → strip + flag
    enter_command = False
    match = _ENTER_TRIGGER_RE.search(raw_text)
    if match:
        enter_command = True
        raw_text = raw_text[: match.start()].rstrip(",;: ").strip()

    return {
        "text": raw_text,
        "lang": getattr(info, "language", language or "it"),
        "duration_s": float(getattr(info, "duration", 0.0) or 0.0),
        "infer_s": infer_s,
        "enter_command": enter_command,
    }
