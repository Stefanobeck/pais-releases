"""Factory entry-point per i NerEngine. Permette swap futuro via env var PAI_NER_ENGINE."""
import os
from functools import lru_cache

from .base import NerEngine


@lru_cache(maxsize=4)
def get_ner_engine(kind: str | None = None) -> NerEngine:
    resolved = kind or os.environ.get("PAI_NER_ENGINE", "onnx_pii")
    if resolved == "onnx_pii":
        from .onnx_engine import OnnxPiiNerEngine
        return OnnxPiiNerEngine()
    raise ValueError(f"Unknown NerEngine kind: {resolved!r}")
