"""Interfaccia astratta per i NER engine pluggable."""
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True)
class NerSpan:
    entity_type: str
    start: int
    end: int
    score: float
    text: str


class NerEngine(ABC):
    @abstractmethod
    def analyze(self, text: str, language: str) -> list[NerSpan]:
        ...

    @abstractmethod
    def warmup(self) -> None:
        ...

    @property
    @abstractmethod
    def supported_languages(self) -> set[str]:
        ...

    @property
    @abstractmethod
    def supported_entities(self) -> set[str]:
        ...
