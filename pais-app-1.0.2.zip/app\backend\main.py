"""
PAI Premium Backend - FastAPI Application
"""
import os
import sys
import locale

# ──────────────────────────────────────────────────────────────────────────
# CONSOLE ENCODING — forza UTF-8 su stdout/stderr così emoji e accenti nei log
# non diventano "mojibake" nella console di Windows (es. 🚀 → ­ƒÜÇ quando la
# console è su code page cp850). Il launcher .bat imposta `chcp 65001`; qui ci
# assicuriamo che Python SCRIVA in UTF-8. Guarded: in contesti con output
# rediretto/frozen lo stream può non supportare reconfigure.
# ──────────────────────────────────────────────────────────────────────────
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass

# ──────────────────────────────────────────────────────────────────────────
# LOCALE DETECTION precoce — usata SOLO per i messaggi visibili al boot
# (splash status + dialog Ollama). A questo punto del codice il sistema
# i18n di PAIS (labels.json) non è ancora caricato, quindi serve un
# rilevamento autonomo. Il sistema i18n vero della UI subentra appena
# il frontend si carica.
#
# Ordine di precedenza:
#   1. Env var `PAIS_LANG` ("it" o "en") — utile per testing / QA.
#      Su Windows `LANG` standard POSIX non viene letto da
#      `locale.getdefaultlocale()`, quindi serve un nostro override.
#   2. `locale.getdefaultlocale()` — su Windows legge la User Locale
#      del Control Panel ("Regione → Impostazioni amministrative").
#   3. Fallback 'en' se la detection fallisce.
# Regola: se la lingua rilevata inizia per "it" → italiano. Tutto il
# resto → inglese (universale).
# ──────────────────────────────────────────────────────────────────────────
def _read_persisted_lang_early():
    """Legge la lingua scelta dall'utente da ~/.pais/config.json SENZA importare
    backend_config (evita import pesanti prima dello splash). Ritorna 'it'/'en'/
    None. Allineato a backend_config.settings.get_persisted_language."""
    try:
        import json as _json
        from pathlib import Path as _Path
        cfg_path = _Path.home() / ".pais" / "config.json"
        if cfg_path.exists():
            cfg = _json.loads(cfg_path.read_text(encoding="utf-8"))
            lang = (cfg.get("lang") or "").strip().lower()
            return lang or None
    except Exception:
        pass
    return None


# Precedenza: 1) env PAIS_LANG (test/QA)  2) scelta utente persistita
# 3) locale del SO  4) 'en'. Lo splash conosce solo it/en, quindi una lingua
# persistita diversa (es. 'es') ricade sul rilevamento SO per il solo splash —
# la UI vera userà comunque la lingua persistita.
_lang_override = (os.environ.get('PAIS_LANG') or '').lower().strip()
_persisted_lang = _read_persisted_lang_early()
if _lang_override in ('it', 'en'):
    _LANG = _lang_override
elif _persisted_lang in ('it', 'en'):
    _LANG = _persisted_lang
elif _persisted_lang:
    # L'utente ha scelto una lingua non gestita dallo splash (es/fr/de):
    # splash in EN (universale), mai IT a sorpresa.
    _LANG = 'en'
else:
    try:
        _lang_raw = (locale.getdefaultlocale()[0] or '').lower()
        _LANG = 'it' if _lang_raw.startswith('it') else 'en'
    except Exception:
        _LANG = 'en'  # fallback conservativo se locale detection fallisce

_MESSAGES = {
    'it': {
        'splash_initial':          'Avvio in corso...',
        'splash_base_modules':     'Caricamento moduli base...',
        'splash_http_server':      'Caricamento server HTTP...',
        'splash_config':           'Caricamento configurazione...',
        'splash_ai_engine':        'Caricamento motore AI e moduli...',
        'splash_components':       'Caricamento componenti...',
        'splash_check_ollama':     'Verifica processi Ollama...',
        'splash_reserve_port':     'Riservazione porta backend...',
        'splash_start_backend':    'Avvio servizi backend...',
        'splash_ai_loading':       'Caricamento motore AI...',
        'splash_launch_ui':        'Avvio interfaccia...',
        'ollama_dialog_title':     'PAIS · Avvio AI Engine',
        'ollama_dialog_intro':     "PAIS ha rilevato un'istanza Ollama esterna in esecuzione.",
        'ollama_dialog_explain':   "Per avviare il proprio motore AI isolato, PAIS deve chiudere queste istanze:",
        'ollama_dialog_more':      '...e altri',
        'ollama_dialog_yes_hint':  'Premi SÌ per chiuderle e avviare PAIS.',
        'ollama_dialog_no_hint':   "Premi NO per annullare l'avvio di PAIS (le tue istanze Ollama restano attive).",
        'ollama_path_unknown':     'path sconosciuto',
    },
    'en': {
        'splash_initial':          'Starting up...',
        'splash_base_modules':     'Loading base modules...',
        'splash_http_server':      'Loading HTTP server...',
        'splash_config':           'Loading configuration...',
        'splash_ai_engine':        'Loading AI engine and modules...',
        'splash_components':       'Loading components...',
        'splash_check_ollama':     'Checking Ollama processes...',
        'splash_reserve_port':     'Reserving backend port...',
        'splash_start_backend':    'Starting backend services...',
        'splash_ai_loading':       'Loading AI engine...',
        'splash_launch_ui':        'Launching interface...',
        'ollama_dialog_title':     'PAIS · AI Engine Startup',
        'ollama_dialog_intro':     'PAIS detected an external Ollama instance running.',
        'ollama_dialog_explain':   'To start its isolated AI engine, PAIS needs to close these instances:',
        'ollama_dialog_more':      '...and more',
        'ollama_dialog_yes_hint':  'Press YES to close them and start PAIS.',
        'ollama_dialog_no_hint':   'Press NO to cancel PAIS startup (your Ollama instances will keep running).',
        'ollama_path_unknown':     'unknown path',
    },
}


def _t(key: str) -> str:
    """Lookup nel mini-i18n di boot. EN come fallback se la chiave manca in IT."""
    return _MESSAGES.get(_LANG, _MESSAGES['en']).get(key) or _MESSAGES['en'].get(key, key)


# ──────────────────────────────────────────────────────────────────────────
# SPLASH WINDOW EARLY BOOT — DEVE girare PRIMA degli import pesanti.
# Senza questo, FastAPI + torch + transformers + ChromaDB (caricati
# transitivamente da `from routers import ...`) prendono 5-7 secondi
# silenziosi dopo il doppio-click del .bat. tkinter è stdlib (import ~30ms,
# Tk() ~80ms) quindi l'utente vede una finestra entro mezzo secondo.
# ──────────────────────────────────────────────────────────────────────────
_SPLASH_ROOT = None  # type: ignore[var-annotated]


def _splash_update(_msg: str) -> None:
    """No-op fallback. Sovrascritta da una closure reale se la splash è viva."""
    pass


if "--native" in sys.argv:
    try:
        import tkinter as _tk
        from tkinter import ttk as _ttk

        _SPLASH_ROOT = _tk.Tk()
        _SPLASH_ROOT.title("PAIS")
        _SPLASH_ROOT.overrideredirect(True)
        _SPLASH_ROOT.attributes("-topmost", True)

        _w, _h = 380, 210
        _sw = _SPLASH_ROOT.winfo_screenwidth()
        _sh = _SPLASH_ROOT.winfo_screenheight()
        _SPLASH_ROOT.geometry(f"{_w}x{_h}+{(_sw - _w) // 2}+{(_sh - _h) // 2}")

        _BG = "#0f172a"
        _ACCENT = "#3b82f6"
        _SPLASH_ROOT.configure(bg=_BG)

        _border = _tk.Frame(_SPLASH_ROOT, bg="#1e293b", bd=0)
        _border.pack(fill="both", expand=True, padx=1, pady=1)
        _inner = _tk.Frame(_border, bg=_BG)
        _inner.pack(fill="both", expand=True)

        _tk.Label(_inner, text="PAIS", fg="white", bg=_BG,
                  font=("Segoe UI", 36, "bold")).pack(pady=(35, 0))
        _tk.Label(_inner, text="Private AI Suite",
                  fg="#64748b", bg=_BG,
                  font=("Segoe UI", 9)).pack(pady=(2, 22))

        _splash_status_lbl = _tk.Label(_inner, text=_t('splash_initial'),
                                       fg="#94a3b8", bg=_BG,
                                       font=("Segoe UI", 10))
        _splash_status_lbl.pack(pady=(0, 12))

        _style = _ttk.Style(_SPLASH_ROOT)
        try:
            _style.theme_use("clam")
        except _tk.TclError:
            pass
        _style.configure("PAIS.Horizontal.TProgressbar",
                         troughcolor="#1e293b", background=_ACCENT,
                         bordercolor="#1e293b", lightcolor=_ACCENT,
                         darkcolor=_ACCENT, thickness=4)
        _pb = _ttk.Progressbar(_inner, mode="indeterminate", length=280,
                               style="PAIS.Horizontal.TProgressbar")
        _pb.pack(pady=(0, 30))
        _pb.start(12)
        _SPLASH_ROOT.update()

        def _splash_update(msg: str) -> None:  # noqa: F811 (intentional override)
            try:
                _splash_status_lbl.config(text=msg)
                _SPLASH_ROOT.update()
            except Exception:
                pass
    except Exception:
        # tkinter mancante o display non disponibile: continuiamo senza splash
        _SPLASH_ROOT = None


# Ora gli import pesanti — la splash è già visibile e la progressbar gira
_splash_update(_t('splash_base_modules'))
# (os, sys, locale già importati sopra per la locale detection precoce)
import asyncio
import subprocess
import logging
import threading
import time
import socket
import uuid
import json
import urllib.request
import urllib.error
from pathlib import Path

_splash_update(_t('splash_http_server'))
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn

# Stable per-process identity, used to verify the .exe launcher is talking to
# THIS Python process (and not a foreign service squatting on the same port).
INSTANCE_ID: str = str(uuid.uuid4())

# Populated by start_backend() if uvicorn fails to bind — read by wait_for_backend().
backend_error: dict = {}

# Determina directory base
backend_dir = Path(__file__).parent.resolve()
sys.path.insert(0, str(backend_dir))

# Configura logging in modo sicuro
log_file = backend_dir / "pais_system.log"
log_handlers = [logging.FileHandler(log_file, encoding='utf-8')]

# Aggiungi console solo se disponibile (evita crash con pythonw)
if sys.stdout is not None:
    log_handlers.append(logging.StreamHandler(sys.stdout))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=log_handlers
)
logger = logging.getLogger("PAIS")

# Silenzia uvicorn access logs
logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

_splash_update(_t('splash_config'))
from backend_config import settings

_splash_update(_t('splash_ai_engine'))
from routers import interrogate, settings as settings_router, projects as projects_router, vision as vision_router, manipulate as manipulate_router, anonimyze as anonimyze_router, utility as utility_router, dictation as dictation_router, help as help_router, bot_integrations, batch as batch_router, account as account_router, user_library as user_library_router
from contextlib import asynccontextmanager

# Global AI Engine process
ollama_process = None

# Path dell'Ollama.exe bundlato con PAIS. Usato per distinguere "nostri orfani"
# (residui di un PAIS chiuso male, kill silenzioso OK) da "esterni" (utente ha
# Ollama installato separatamente per altri usi — Open WebUI, LM Studio, dev
# session — non possiamo killarli senza chiedere).
PAIS_OLLAMA_PATH = (backend_dir / "bin" / "ollama.exe").resolve()


def _ollama_classify_running() -> tuple[list[dict], list[dict]]:
    """Enumera tutti i processi ollama.exe in esecuzione e li classifica in
    ("nostri orfani", "esterni") in base al path dell'eseguibile.

    Ritorna due liste di dict con chiavi: pid, exe, name. La lista "esterni"
    include anche processi il cui path non è risolvibile (potrebbero essere
    Ollama legittimi ma con permessi che ne nascondono il path) — meglio
    essere conservativi e chiedere conferma.
    """
    nostri: list[dict] = []
    esterni: list[dict] = []
    try:
        import psutil
    except ImportError:
        # psutil non installato: fallback al vecchio comportamento (kill all)
        return nostri, esterni

    pais_path_str = str(PAIS_OLLAMA_PATH).lower()
    for proc in psutil.process_iter(['pid', 'name', 'exe']):
        try:
            name = (proc.info.get('name') or '').lower()
            if name != 'ollama.exe':
                continue
            exe = proc.info.get('exe') or ''
            entry = {'pid': proc.info['pid'], 'exe': exe, 'name': name}
            # Match case-insensitive del path completo (Windows è case-insensitive sui path)
            if exe and exe.lower() == pais_path_str:
                nostri.append(entry)
            else:
                # exe vuoto o path diverso → trattalo come esterno
                esterni.append(entry)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return nostri, esterni


def _ask_user_about_external_ollama(esterni: list[dict], splash_root=None) -> bool:
    """Mostra una MessageBox Windows nativa con la lista delle istanze Ollama
    esterne rilevate e chiede consenso a chiuderle. Pywebview non è ancora
    avviato a questo punto, quindi serve un dialog nativo OS.

    Ritorna True se l'utente clicca Sì, False se No / Annulla.
    Su OS non-Windows o se ctypes fallisce, ritorna False (conservativo).

    Se `splash_root` è passato, la splash viene nascosta (`withdraw`) prima del
    dialog e ripristinata (`deiconify`) dopo. Senza questo trucco la splash —
    che è `-topmost True` — coprirebbe la MessageBox rendendola invisibile.
    """
    if sys.platform != 'win32':
        # Su Linux/Mac PAIS non è ancora distribuito; stampiamo soltanto e
        # conserviamo l'Ollama esterno (no kill).
        logger.warning(
            f"Rilevati {len(esterni)} processi ollama.exe esterni. "
            "Su questo OS non è disponibile il dialog di consenso → PAIS non li toccherà."
        )
        return False

    # Nascondi la splash prima del dialog (evita che il -topmost della splash
    # competa col MB_TOPMOST della MessageBox e finisca per coprirla).
    if splash_root is not None:
        try:
            splash_root.withdraw()
            splash_root.update()
        except Exception:
            pass

    try:
        import ctypes
        lines = [
            _t('ollama_dialog_intro'),
            "",
            _t('ollama_dialog_explain'),
            "",
        ]
        for e in esterni[:5]:  # max 5 per non saturare il dialog
            exe_short = e['exe'] if len(e['exe']) <= 80 else f"...{e['exe'][-77:]}"
            lines.append(f"  • PID {e['pid']}  ({exe_short or _t('ollama_path_unknown')})")
        if len(esterni) > 5:
            lines.append(f"  {_t('ollama_dialog_more')} {len(esterni) - 5}")
        lines += [
            "",
            _t('ollama_dialog_yes_hint'),
            _t('ollama_dialog_no_hint'),
        ]
        body = "\n".join(lines)

        MB_YESNO = 0x04
        MB_ICONWARNING = 0x30
        MB_DEFBUTTON2 = 0x100   # default focus su "No" — conservativo
        MB_TOPMOST = 0x40000    # cintura+bretelle: anche senza withdraw resta sopra
        IDYES = 6
        result = ctypes.windll.user32.MessageBoxW(
            None,
            body,
            _t('ollama_dialog_title'),
            MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2 | MB_TOPMOST,
        )
        consent = (result == IDYES)
    except Exception as e:
        logger.error(f"Cannot show Ollama dialog: {e}. PAIS startup aborted for safety.")
        consent = False

    # Ripristina la splash SOLO se l'utente ha accettato — se ha negato, il
    # caller chiama sys.exit subito dopo e non vale la pena far flickerare.
    if consent and splash_root is not None:
        try:
            splash_root.deiconify()
            splash_root.update()
        except Exception:
            pass

    return consent


def kill_orphaned_ollama(splash_root=None):
    """Chiude in modo selettivo i processi Ollama prima di avviare il nostro.

    Comportamento:
      - "Nostri orfani" (path == pai-premium/backend/bin/ollama.exe): kill silenzioso,
        sono residui di un PAIS precedente chiuso male, l'utente non ha motivo
        di essere consultato.
      - "Esterni" (path diverso o sconosciuto): mostra MessageBox di consenso.
        Sì → kill anche loro. No → exit graceful (PAIS non parte, l'Ollama
        dell'utente sopravvive).

    `splash_root` (opzionale): riferimento alla splash tkinter da nascondere
    durante il dialog di consenso. Senza, il `-topmost True` della splash
    coprirebbe la MessageBox rendendola invisibile.

    Su sistemi senza psutil installato, fallback al vecchio comportamento
    (taskkill totale) per non lasciare PAIS in stato bloccato.
    """
    if sys.platform != 'win32':
        # Su non-Windows non gestiamo kill (PAIS è Windows-first); il chiamante
        # dovrà adattare se mai serve.
        return

    nostri, esterni = _ollama_classify_running()

    if not nostri and not esterni:
        # Caso pulito: niente da fare.
        return

    # Killa silenziosamente gli orfani PAIS — è quello che faceva taskkill prima,
    # solo più chirurgico.
    if nostri:
        logger.info(
            f"🧹 Cleaning up {len(nostri)} stale PAIS Ollama orphan{'s' if len(nostri) != 1 else ''} "
            f"(PID: {[n['pid'] for n in nostri]})"
        )
        for n in nostri:
            try:
                subprocess.run(
                    ['taskkill', '/F', '/T', '/PID', str(n['pid'])],
                    capture_output=True,
                )
            except Exception as e:
                logger.debug(f"Cleanup orphan PID {n['pid']} info: {e}")

    # Se ci sono esterni, chiedi all'utente
    if esterni:
        logger.warning(
            f"⚠️ Detected {len(esterni)} EXTERNAL Ollama instance(s): "
            f"{[(e['pid'], e['exe']) for e in esterni]}"
        )
        consent = _ask_user_about_external_ollama(esterni, splash_root=splash_root)
        if not consent:
            # L'utente ha cliccato No nel dialog di consenso — uscita pulita
            # senza secondo popup. Il dialog stesso ha già detto cosa stava per
            # succedere; un secondo MessageBox sarebbe ridondante e fastidioso.
            logger.info("User declined closing external Ollama instances. PAIS will not start.")
            # Chiudi anche la splash se ancora presente (era già nascosta dal dialog)
            if splash_root is not None:
                try:
                    splash_root.destroy()
                except Exception:
                    pass
            sys.exit(0)

        logger.info("✅ User authorized closing external Ollama instances.")
        for e in esterni:
            try:
                subprocess.run(
                    ['taskkill', '/F', '/T', '/PID', str(e['pid'])],
                    capture_output=True,
                )
            except Exception as ex:
                logger.debug(f"Cleanup external PID {e['pid']} info: {ex}")

    # Margine per il sistema operativo per rilasciare i socket dopo i kill
    if nostri or esterni:
        time.sleep(1)

async def start_ollama():
    """Avvia Ollama isolatamente forzando l'ambiente e la porta.

    NOTA: la pulizia di processi Ollama esistenti (incluso il dialog di consenso
    per istanze esterne) è ora fatta UNA SOLA VOLTA all'inizio di `__main__`
    nel main thread — vedi `if args.native:`. Da qui assumiamo l'ambiente
    pulito e la porta 11435 libera.
    """
    global ollama_process
    from urllib.parse import urlparse

    # 1. Configurazione Porta (Partiamo da 11435 per non toccare la 11434 di sistema se venisse riavviata)
    start_port = 11435
    host = '127.0.0.1'
    found_port = None
    
    for port in range(start_port, start_port + 10):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        if sock.connect_ex((host, port)) != 0:
            found_port = port
            sock.close()
            break
        sock.close()

    if not found_port:
        logger.error("❌ Port range 11435-11445 busy. AI Engine cannot start.")
        return

    # Aggiorna configurazione globale
    new_url = f"http://{host}:{found_port}"
    settings.OLLAMA_HOST_URL = new_url
    
    # 3. Forzatura Ambiente (LA PARTE PIÙ IMPORTANTE)
    ollama_env = os.environ.copy()
    ollama_env["OLLAMA_HOST"] = f"{host}:{found_port}"
    
    # Path assoluto ai modelli confermato. È derivato dinamicamente da
    # `Path(__file__).parent.parent / "models"` in settings.py — quindi si
    # adatta automaticamente a qualsiasi cartella d'installazione. Su un PC
    # nuovo dove la dir non è ancora stata creata (modelli non scaricati o
    # dopo un wipe manuale), la creiamo qui prima di lanciare Ollama:
    # senza dir, ollama serve può crashare al primo download.
    models_dir = settings.OLLAMA_MODELS_DIR.absolute()
    try:
        models_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.warning(f"⚠️ Cannot create models dir at {models_dir}: {e}")
    ollama_env["OLLAMA_MODELS"] = str(models_dir)

    try:
        if settings.OLLAMA_BIN_PATH.exists():
            logger.info(f"🚀 Launching internal AI Engine on port {found_port}...")
            logger.info(f"📁 Models Directory: {models_dir}")

            # A questo punto la dir esiste sempre (la creiamo sopra). Il check
            # vale solo se mkdir è fallito (permessi negati su install in
            # Program Files senza diritti di scrittura).
            if not models_dir.exists():
                logger.error(f"❌ Models directory NOT FOUND at: {models_dir}")
            
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            ollama_process = subprocess.Popen(
                [str(settings.OLLAMA_BIN_PATH), "serve"],
                stdout=subprocess.DEVNULL, 
                stderr=subprocess.DEVNULL, 
                creationflags=flags,
                env=ollama_env
            )
            # Attesa inizializzazione
            await asyncio.sleep(5)
            logger.info(f"✅ AI Engine ready on {new_url} (Isolated Mode)")
        else:
            logger.warning(f"⚠️ Binary missing at: {settings.OLLAMA_BIN_PATH}")
    except Exception as e:
        logger.error(f"❌ Startup error: {e}")

def stop_ollama():
    """Stop Ollama server on shutdown."""
    global ollama_process
    if ollama_process:
        logger.info("⏹️  Shutting down AI Engine...")
        try:
            if sys.platform == 'win32':
                subprocess.run(['taskkill', '/F', '/T', '/PID', str(ollama_process.pid)], capture_output=True)
            else:
                ollama_process.terminate()
            logger.info("✅ AI Engine offline")
        except Exception as e:
            logger.error(f"❌ Shutdown error: {e}")
        ollama_process = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    await start_ollama()

    # Auto-snapshot of the active project's privacy vault, once a week.
    # Silent no-op if Anonimyze has never been used on this project.
    # See services/vault_backup_service.py for the rolling-4 policy.
    try:
        from backend_config.project_manager import project_manager
        from services.vault_backup_service import VaultBackupService
        VaultBackupService(project_manager).maybe_run_weekly_backup()
    except Exception as e:
        logger.warning(f"Vault weekly-backup hook failed: {e}")

    # Auto-resume Telegram bot if it was running at last shutdown.
    # bots_config.json `telegram.enabled` tracks USER INTENT — it's set
    # True by POST /api/bots/telegram/toggle?enable=true and False by
    # toggle?enable=false. If the user closed PAIS without explicitly
    # stopping the bot, the flag stays True, so we restart polling here.
    try:
        from routers.bot_integrations import load_config
        from routers.interrogate import get_chat_service
        from routers.vision import get_vision_service
        from routers.manipulate import get_manipulate_service
        from integrations import bot_telegram

        bot_cfg = (load_config() or {}).get("telegram", {})
        # PRO gate — the Telegram bot is a PRO feature. If the licence has
        # lapsed (trial expired, no PRO) we DON'T auto-resume: the user intent
        # flag stays True so it resumes automatically once PRO is re-activated,
        # but a free_residual user never gets a live bot.
        from services.user_settings_service import compute_effective_tier
        _bot_tier = (compute_effective_tier() or {}).get("effective_tier")
        if bot_cfg.get("enabled") and bot_cfg.get("token") and _bot_tier not in ("pro", "free_trial"):
            logger.info(f"🤖 Telegram bot auto-resume SKIPPED (tier={_bot_tier}, PRO required)")
        elif bot_cfg.get("enabled") and bot_cfg.get("token"):
            logger.info("🤖 Telegram bot was enabled at last shutdown — auto-resuming...")
            bot_telegram.set_chat_service(get_chat_service())
            bot_telegram.set_vision_service(get_vision_service())
            bot_telegram.set_manipulate_service(get_manipulate_service())
            model = getattr(settings, "CHAT_MODEL", None) or bot_cfg.get("model", "gemma4:e4b")
            await bot_telegram.start_bot(
                token=bot_cfg["token"],
                allowed_chat_ids=bot_cfg.get("allowed_chat_ids", []),
                model=model,
                lang=bot_cfg.get("lang", "it"),
            )
            logger.info("✅ Telegram bot resumed")
    except Exception as e:
        # Non-fatal: if token is invalid / network down / Telegram API
        # unreachable, log and continue. The user can re-toggle from the UI.
        logger.warning(f"⚠️ Telegram auto-resume failed (bot stays off): {e}")

    yield

    # Clean shutdown: stop the bot if running, but DO NOT touch the
    # bots_config flag — that way the next start can auto-resume.
    try:
        from integrations import bot_telegram
        if bot_telegram.is_running():
            await bot_telegram.stop_bot()
            logger.info("🤖 Telegram bot stopped on shutdown (config preserved)")
    except Exception as e:
        logger.warning(f"Telegram shutdown error: {e}")

    stop_ollama()

# FastAPI App Setup
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan
)

# CORS strict: solo same-origin del pywebview embed + Vite dev server.
# In production il frontend gira sull'origin del backend (127.0.0.1:8000)
# quindi tecnicamente non servirebbe CORS. La whitelist serve per il dev
# mode (Vite su 5173) e per chiudere lo scenario "pagina web maligna nel
# browser chiama 127.0.0.1:8000 con credentials=true" — con allow_origins=*
# + allow_credentials=True, un sito remoto poteva fare fetch credenziate.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8000",
        "http://localhost:8000",
        "http://127.0.0.1:5173",
        "http://localhost:5173",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)

# Auth bearer token su tutte le route /api/* eccetto /api/health (liveness).
# Frontend ottiene il token via window.pywebview.api.get_api_token() (JS bridge),
# in dev mode via /internal/dev-token (gated da env PAIS_ALLOW_DEV_TOKEN=1).
from services.auth_service import AuthMiddleware, PywebviewBridge, get_or_create_token as _get_api_token
app.add_middleware(AuthMiddleware)

# API Routes
app.include_router(interrogate.router, prefix="/api/interrogate", tags=["Interrogate"])
app.include_router(settings_router.router, prefix="/api", tags=["Settings"])
app.include_router(projects_router.router, prefix="/api", tags=["Projects"])
app.include_router(vision_router.router, prefix="/api/vision", tags=["Vision"])
app.include_router(manipulate_router.router, prefix="/api/manipulate", tags=["Manipulate"])
# Endpoint pubblici di MANIPULATE (catalogo modelli, sola lettura) — non gated,
# così anche un utente free li vede in Impostazioni e può scaricarli per PRO.
app.include_router(manipulate_router.public_router, prefix="/api/manipulate", tags=["Manipulate"])
app.include_router(anonimyze_router.router, prefix="/api/anonimyze", tags=["Anonimyze"])
app.include_router(utility_router.router, prefix="/api/utility", tags=["Utility"])
app.include_router(dictation_router.router, prefix="/api/dictation", tags=["Dictation"])
app.include_router(help_router.router, prefix="/api/help", tags=["Help"])
app.include_router(user_library_router.router, prefix="/api/user-library", tags=["UserLibrary"])
app.include_router(batch_router.router, prefix="/api/batch", tags=["Batch"])
app.include_router(account_router.router, prefix="/api", tags=["Account"])
app.include_router(bot_integrations.router)

@app.get("/health")
async def health_check():
    return {"status": "healthy", "mode": "production" if dist_path.exists() else "dev"}

@app.get("/api/health")
async def api_health():
    # Identity probe used by the native launcher to confirm the backend
    # answering on PORT is THIS Python process. instance_id is a UUID minted
    # at process start; an external squatter cannot guess it.
    return {
        "app": "pai-premium",
        "version": settings.APP_VERSION,
        "instance_id": INSTANCE_ID,
        "pid": os.getpid(),
    }

@app.get("/internal/dev-token")
async def get_dev_token():
    """Espone il bearer token API SOLO se la env var PAIS_ALLOW_DEV_TOKEN=1.
    Usato dal frontend in modalità Vite dev (npm run dev su :5173) quando
    NON gira dentro pywebview e quindi non può usare il JS bridge.
    In production resta 404 — il frontend pywebview ottiene il token dal
    bridge js_api e non da questo endpoint."""
    if os.environ.get("PAIS_ALLOW_DEV_TOKEN") != "1":
        raise HTTPException(status_code=404)
    return {"token": _get_api_token()}

# Frontend & Static Files
dist_path = backend_dir.parent / "frontend" / "dist"
help_path = backend_dir.parent / "PAIS_HELP"

if help_path.exists():
    logger.info(f"📖 Help Portal active: {help_path}")
    app.mount("/help", StaticFiles(directory=str(help_path)), name="help")

if dist_path.exists():
    logger.info(f"📦 Production build active: {dist_path}")
    app.mount("/assets", StaticFiles(directory=str(dist_path / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        if full_path.startswith("api/") or full_path.startswith("exports/") or full_path.startswith("files/"):
            raise HTTPException(status_code=404)
        file_path = dist_path / full_path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(dist_path / "index.html")

def start_backend():
    # NOTA: la pulizia degli Ollama esistenti è fatta dal main thread PRIMA
    # dello spawn di questo thread daemon (vedi blocco `if args.native:`).
    # Qui non chiamiamo più kill_orphaned_ollama: girando in un thread daemon,
    # un eventuale sys.exit terminerebbe SOLO il thread e lascerebbe il main
    # thread in attesa con un timeout error confuso lato launcher.

    # In produzione usiamo 'warning' per non intasare il file di log
    try:
        uvicorn.run(app, host=settings.HOST, port=settings.PORT, log_level="warning")
    except Exception as e:
        backend_error["msg"] = f"{type(e).__name__}: {e}"
        logger.exception("Backend crashed")


def reserve_port(host: str, port: int) -> tuple[bool, str | None]:
    """Try to bind (host, port) exclusively to confirm we own it.

    Closes the socket immediately on success so uvicorn can rebind. On Windows
    we also set SO_EXCLUSIVEADDRUSE to shrink the race window between probe-close
    and uvicorn-bind.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            except OSError:
                pass
        try:
            s.bind((host, port))
        except OSError as e:
            return False, str(e)
        return True, None
    finally:
        s.close()


def wait_for_backend(host: str, port: int, expected_instance_id: str,
                     timeout_s: float = 15.0,
                     on_tick=None) -> tuple[bool, str | None]:
    """Poll /api/health until it returns OUR instance_id, or fail with a reason.

    Detects three conditions:
    - Backend thread crashed (backend_error populated) → bail immediately.
    - Endpoint not reachable yet → keep polling until timeout.
    - Endpoint reachable but identity mismatch → bail (foreign service squatting).

    Parametro `on_tick` (callback opzionale): chiamato ad ogni iterazione PRIMA
    della richiesta HTTP. Usato dal main thread per dare il refresh alla splash
    window tkinter mentre il backend si avvia (l'event loop di Tk altrimenti
    freeze durante il blocking time.sleep).
    """
    deadline = time.time() + timeout_s
    url = f"http://{host}:{port}/api/health"
    last_err: str | None = None

    while time.time() < deadline:
        if on_tick:
            try:
                on_tick()
            except Exception:
                pass  # callback non deve mai bloccare la readiness check
        if backend_error:
            return False, backend_error.get("msg", "backend thread died")
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:  # nosec B310 - url is hardcoded http://127.0.0.1:{settings.PORT}/api/health, never user input
                payload = json.loads(resp.read().decode("utf-8"))
            if payload.get("app") != "pai-premium":
                return False, f"foreign service on port {port}: app={payload.get('app')!r}"
            if payload.get("instance_id") != expected_instance_id:
                return False, f"instance_id mismatch on port {port} (foreign or stale process)"
            return True, None
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, ConnectionError, OSError) as e:
            last_err = str(e)
        time.sleep(0.5)

    return False, last_err or "timeout waiting for /api/health"


def show_error_dialog(title: str, message: str) -> None:
    """Show a native error dialog. Falls back to stderr on non-Windows / failures."""
    if sys.platform == "win32":
        try:
            import ctypes
            MB_ICONERROR = 0x10
            MB_OK = 0x0
            ctypes.windll.user32.MessageBoxW(0, message, title, MB_ICONERROR | MB_OK)
            return
        except Exception:
            pass
    print(f"ERROR: {title}\n{message}", file=sys.stderr if sys.stderr else sys.__stderr__)


def show_splash():
    """Compat wrapper: ritorna la splash già creata al boot del modulo (se attiva).

    La splash vera è inizializzata in cima a `main.py` PRIMA degli import
    pesanti, così appare entro mezzo secondo dal doppio-click del .bat
    (vs i 5-7s di silenzio che si avevano quando era creata qui in __main__).
    """
    return _SPLASH_ROOT, _splash_update


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--native", action="store_true")
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable pywebview DevTools (right-click → Inspect, F12). "
             "Use only for development/QA; do NOT ship to clients.",
    )
    args = parser.parse_args()

    if args.native:
        # Mostra subito una splash window (tkinter, ~30ms di import) per dare
        # feedback all'utente: senza splash il cliente vede il doppio-click +
        # 7-8s di nulla mentre webview/torch/transformers vengono importati.
        splash_root, splash_update = show_splash()

        try:
            splash_update(_t('splash_components'))
            import webview
            logger.info("\n🖥️  PAIS - STARTING NATIVE DESKTOP MODE")

            # 0. Ollama coexistence — gestita nel main thread perché può chiamare
            #    sys.exit(0) se l'utente nega il consenso a chiudere istanze esterne.
            #    Eseguita PRIMA di reserve_port e dello spawn del backend thread
            #    così l'exit chiude l'intero processo pulitamente, senza che il
            #    launcher veda un timeout su /api/health.
            splash_update(_t('splash_check_ollama'))
            kill_orphaned_ollama(splash_root=splash_root)

            # 1. Pre-bind ownership check — refuse to start if port is occupied,
            #    instead of opening a webview that points at a foreign service.
            splash_update(_t('splash_reserve_port'))
            ok, err = reserve_port(settings.HOST, settings.PORT)
            if not ok:
                msg = (
                    f"Cannot start PAIS — port {settings.PORT} is already in use "
                    f"by another application.\n\n"
                    f"Please close the other software using this port (e.g. a local "
                    f"Flask/Node server, or another running instance of PAIS) and try again.\n\n"
                    f"Details: {err}"
                )
                logger.error(msg)
                if splash_root is not None:
                    splash_root.destroy()
                show_error_dialog("PAIS — Port conflict", msg)
                sys.exit(2)

            # 2. Launch the backend
            splash_update(_t('splash_start_backend'))
            t = threading.Thread(target=start_backend, daemon=True)
            t.start()

            # 3. Identity-verified readiness — confirm /api/health returns OUR instance_id
            splash_update(_t('splash_ai_loading'))
            # Tick callback: il main thread è bloccato in wait_for_backend tra
            # un poll e l'altro; senza un repaint la progressbar Tk freeze.
            ready, why = wait_for_backend(
                settings.HOST, settings.PORT, INSTANCE_ID,
                timeout_s=15.0,
                on_tick=(lambda: splash_update(_t('splash_ai_loading'))) if splash_root else None,
            )
            if not ready:
                msg = f"PAIS backend failed to start.\n\nDetails: {why}"
                logger.error(msg)
                if splash_root is not None:
                    splash_root.destroy()
                show_error_dialog("PAIS — Startup failed", msg)
                sys.exit(3)

            # 4. Chiudi splash prima di aprire pywebview (evita doppia finestra)
            splash_update(_t('splash_launch_ui'))
            time.sleep(0.15)  # mostra brevemente l'ultimo stato — UX feel
            if splash_root is not None:
                try:
                    splash_root.destroy()
                except Exception:
                    pass

            logger.info("🚀 Launching Local Architect Window...")

            # Cerca l'icona dell'app
            icon_path = backend_dir.parent / "src-tauri" / "icons" / "icon.ico"
            if not icon_path.exists():
                icon_path = None

            # js_api espone `window.pywebview.api.get_api_token()` al JS del
            # frontend embed. È l'unico canale con cui il frontend ottiene
            # il bearer token: nessun endpoint HTTP pubblico ritorna il
            # token in production. Vedi services/auth_service.py.
            # `maximized=True` opens PAIS already maximized — same effect as
            # clicking the centre Windows button. NOT fullscreen (which hides
            # titlebar + taskbar). width/height stay as the restore-down
            # fallback size if the user un-maximises. Requested 2026-05-18 to
            # avoid the user manually resizing on every launch.
            window = webview.create_window(
                'PAIS - Private Artificial Intelligence Suite',
                f"http://127.0.0.1:{settings.PORT}",
                width=1400, height=900,
                min_size=(1000, 700),
                background_color='#F8FAFC',
                maximized=True,
                js_api=PywebviewBridge(),
            )
            # --debug abilita DevTools nella webview (right-click → Inspect,
            # F12). Lo lasciamo OFF di default in produzione.
            if args.debug:
                logger.info("🛠  pywebview DevTools ENABLED (--debug)")
            webview.start(debug=args.debug)

            logger.info("👋 Window closed. Terminating AI Engine and services...")
            stop_ollama()
            sys.exit(0)
        except ImportError:
            logger.error("❌ pywebview missing. Run: pip install pywebview")
    else:
        start_backend()
