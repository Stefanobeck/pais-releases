"""
Vision Service - Business Logic per modulo VISION
Gestisce SOLO immagini (JPG/PNG/WEBP). Il supporto video è stato rimosso
il 2026-05-08 — il modulo è ora image-only.

Funzionalità:
- Upload immagini con resize non-distruttivo (originale preservato)
- Generazione thumbnail base64
- Analisi con qwen3-vl o gemma4 (modello selezionabile dall'UI)
- RAG su descrizioni testuali generate (qwen3-embedding:0.6b)
- Chat streaming con contesto visivo (l'immagine è ri-allegata al modello
  ad ogni query)
"""
import os
import json
import asyncio
import base64
import uuid
from typing import List, Dict, Optional, Callable, AsyncGenerator
from pathlib import Path
import logging

from processors.ollama_client import OllamaClient, AUTO_CTX
from processors.vision_processor import VisionProcessor
from backend_config.settings import BASE_DIR

logger = logging.getLogger(__name__)


class VisionService:
    """
    Servizio principale per chat con contesto visivo.
    """

    def __init__(self, persist_directory: Optional[str] = None):
        self.ollama = OllamaClient()
        self.vision_processor = VisionProcessor(lang="it")
        # audio_processor + background_progress rimossi insieme al supporto
        # video (2026-05-08). Vision ora analizza immagini sincrono, niente
        # background task da monitorare.
        self.sessions: Dict[str, List[Dict]] = {}
        self.uploaded_files: Dict[str, List[Dict]] = {}
        self.lang = "it"
        self.prompts = self._load_prompts()
        self._chroma_path = persist_directory  # Per change detection

        # ChromaDB per RAG (collection: pai_vision_v2)
        from processors.document_processor import ChromaManager
        self.chroma = ChromaManager(persist_directory)
        self.collection = self.chroma.client.get_or_create_collection(name="pai_vision_v2")

    def set_language(self, lang: str):
        self.lang = lang
        self.prompts = self._load_prompts()
        self.vision_processor.set_language(lang)
        
        # Aggiorna anche il servizio i18n globale
        from services.i18n_service import i18n
        i18n.set_language(lang)

    def _load_prompts(self) -> Dict:
        """Carica prompt da configurazione JSON."""
        # Fix: Punta alla cartella config del backend, non ai documenti utente
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_vision.json"
        try:
            if not prompts_path.exists():
                logger.error(f"Vision prompts file not found at: {prompts_path}")
                return {}
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(self.lang, data.get('it', {}))
        except Exception as e:
            logger.error(f"Error loading vision prompts in Service: {e}")
            return {}

    def _get_or_create_session(self, session_id: str) -> List[Dict]:
        """Ottiene o crea sessione, caricandola da file se necessario."""
        if session_id not in self.sessions:
            self.sessions[session_id] = []
            self.uploaded_files[session_id] = []
            
            session_file = self._get_session_file(session_id)
            if session_file.exists():
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        self.sessions[session_id] = data.get('history', [])
                        self.uploaded_files[session_id] = data.get('files', [])
                        logger.info(f"Vision Session {session_id} loaded from disk")
                except Exception as e:
                    logger.error(f"Error loading vision session {session_id}: {e}")
                    
        return self.sessions[session_id]

    def _get_session_file(self, session_id: str) -> Path:
        """Ottiene path file sessione all'interno del progetto attivo."""
        from backend_config.project_manager import project_manager
        
        if project_manager.active_project_path:
            sessions_dir = project_manager.active_project_path / "sessions"
        else:
            sessions_dir = BASE_DIR / "temp" / "vision_sessions"
            
        sessions_dir.mkdir(parents=True, exist_ok=True)
        return sessions_dir / f"vision_state_{session_id}.json"

    def _save_session(self, session_id: str):
        """Salva sessione su file."""
        session_file = self._get_session_file(session_id)
        data = {
            'history': self.sessions.get(session_id, []),
            'files': self.uploaded_files.get(session_id, []),
            'lang': self.lang
        }
        try:
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving session {session_id}: {e}")

    async def upload_image(self, file_path: str, filename: str, session_id: str) -> Dict:
        """
        Carica e analizza immagine. NON modifica MAI il file originale.

        1. Ridimensiona a max 1024px (ottimizza per qwen3-vl)
        2. Salva versione ottimizzata come `<stem>_proc<ext>` ACCANTO all'originale
        3. Genera thumbnail base64 dalla versione resized
        4. Analizza con il modello vision attivo usando la versione _proc
        5. Indicizza descrizione in ChromaDB
        6. Registra entrambi i path nella session: `path` = originale (immutato),
           `proc_path` = versione _proc usata da analyze + query time
        """
        try:
            self._get_or_create_session(session_id)

            # Ridimensiona in memoria (NON tocca file_path)
            resized_bytes = self.vision_processor._resize_image(file_path)

            from pathlib import Path as _Path
            orig = _Path(file_path)
            # Versione ottimizzata accanto all'originale: <stem>_proc<ext>
            # Pattern non-distruttivo: l'utente può sempre recuperare il file
            # come l'ha caricato. analyze + query time usano _proc per
            # contenere VRAM e tempo, ma l'originale resta intatto sul disco.
            proc_path = orig.with_name(f"{orig.stem}_proc{orig.suffix}")

            if resized_bytes and len(resized_bytes) > 0:
                with open(proc_path, 'wb') as f:
                    f.write(resized_bytes)
                img_bytes = resized_bytes
                analyze_path = str(proc_path)
            else:
                # Fallback se resize fallisce: usa originale per analyze
                with open(file_path, 'rb') as f:
                    img_bytes = f.read()
                analyze_path = file_path

            # Thumbnail base64 dalla versione ottimizzata
            thumb_b64 = base64.b64encode(img_bytes).decode('utf-8')

            # Analizza immagine (usa _proc se disponibile, altrimenti originale)
            description = await self.vision_processor.analyze_image(analyze_path)

            # Indicizza descrizione in ChromaDB
            await self._index_text(description, filename)

            # Registra file: path = originale (mai modificato), proc_path = ridotta
            file_ref = f"F{len(self.uploaded_files[session_id]) + 1}"
            self.uploaded_files[session_id].append({
                "name": filename,
                "path": file_path,
                "proc_path": analyze_path if analyze_path != file_path else None,
                "ref": file_ref,
                "type": "image",
                "thumbnail": thumb_b64,
                "description": description
            })

            self._save_session(session_id)
            logger.info(f"✅ Image uploaded: {filename} | Path: {file_path} | Session files: {len(self.uploaded_files[session_id])}")

            from services.i18n_service import i18n
            msg = i18n.get('sidebar.ready_file', "Pronto: {filename}").replace('{filename}', filename)

            return {
                "status": "success",
                "message": msg,
                "ref": file_ref,
                "description": description,
                "thumbnail": thumb_b64
            }

        except Exception as e:
            logger.error(f"Error uploading image {filename}: {e}")
            return {"status": "error", "message": str(e)}

    # NOTA: il supporto VIDEO è stato RIMOSSO da Vision (2026-05-08).
    # Il modulo accetta ora solo immagini (JPG/PNG/WEBP). Le funzioni
    # `upload_video()`, `_background_video_analysis()` (audio Whisper +
    # estrazione frame chiave) e relativi entry-point sono stati eliminati.
    # Per analisi video usare strumenti dedicati (es. modulo TRANSCRIBE per
    # solo audio).

    async def _index_text(self, text: str, source_name: str):
        """Indicizza testo in ChromaDB."""
        try:
            # Chunking semplice
            chunks = self._create_chunks(text)

            for i, chunk in enumerate(chunks):
                # Usa embeddings() tramite client di vision_processor
                response = await self.vision_processor.client.embeddings(
                    model='qwen3-embedding:0.6b',
                    prompt=chunk
                )
                emb = response.get('embedding') if response else None
                
                if emb:
                    self.collection.add(
                        ids=[f"{source_name}_chunk_{i}"],
                        documents=[chunk],
                        embeddings=[emb],
                        metadatas=[{"source": source_name, "chunk_id": i}]
                    )

            logger.info(f"Indexed {len(chunks)} chunks for {source_name}")

        except Exception as e:
            logger.error(f"Indexing error: {e}")

    def _create_chunks(self, text: str, chunk_size: int = 1000, overlap: int = 100) -> List[str]:
        """Divide testo in chunk sovrapposti."""
        if not text:
            return []
        
        chunks = []
        for i in range(0, len(text), chunk_size - overlap):
            chunks.append(text[i:i + chunk_size])
        return chunks

    async def send_message(
        self,
        message: str,
        session_id: str,
        use_rag: bool = True,
        stop_check_callback: Optional[Callable[[], bool]] = None,
        force_model: Optional[str] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Invia messaggio e ottieni risposta in streaming.
        Supporta immagini inline (base64) se presenti nei file caricati.

        `force_model`: override del settings.VISION_MODEL. Usato dal batch
        executor per garantire snapshot-coherent execution anche se l'utente
        cambia il modello vision tra l'add-to-batch e l'execute.
        """
        history = self._get_or_create_session(session_id)
        history.append({"role": "user", "content": message})
        
        try:
            # Costruisci prompt con RAG
            context_text = ""
            if use_rag:
                context_text = await self._build_vision_context(message, session_id)
            
            from backend_config import settings
            # Costruisci messaggi per Ollama
            messages = self._build_messages(message, context_text, session_id)

            # Stream risposta (dynamic context budget).
            # - num_ctx AUTO_CTX + max_ctx=VISION_CTX: il calcolatore dinamico
            #   sceglie il minimo necessario, ma cap massimo a settings.VISION_CTX
            #   (32768 default) invece del 131072 di default — evita esplosioni
            #   VRAM su chat lunghe con immagini grosse.
            # - num_predict 8192: cap output per prevenire thinking loop infiniti
            #   (Vision modello qwen3-vl può rimanere bloccato in <think> su
            #   immagini ambigue se non capped).
            # - repeat_penalty 1.15 + repeat_last_n 256: stessa configurazione
            #   di chat_service.py per scoraggiare loop di token ripetuti.
            # - top_k 30 / top_p 0.85: leggermente più stretti del default Ollama
            #   (40 / 0.9) per ridurre allucinazioni — coerente con analyze_image.
            # - stop_check_callback: passato a Ollama per cooperative cancel
            #   quando l'utente clicca STOP (frontend chiude la fetch).
            stream = self.ollama.chat_stream(
                model=force_model or settings.VISION_MODEL,
                messages=messages,
                num_ctx=AUTO_CTX,
                max_ctx=settings.VISION_CTX,
                temperature=0.1,
                stop_check_callback=stop_check_callback,
                options={
                    "num_predict": 8192,
                    "repeat_penalty": 1.15,
                    "repeat_last_n": 256,
                    "top_k": 30,
                    "top_p": 0.85,
                },
            )

            full_response = ""
            async for token in stream:
                # Double-check anche qui: se lo stop arriva tra un chunk e
                # l'altro mentre Ollama è bloccato, fermiamo subito il loop.
                if stop_check_callback and stop_check_callback():
                    logger.info("Vision stream interrupted by stop_check")
                    break
                full_response += token
                yield token

            if full_response:
                history.append({"role": "assistant", "content": full_response})
                self._save_session(session_id)
                
        except Exception as e:
            logger.error(f"Error in chat: {e}")
            yield f"\n\n⚠️ Error: {str(e)}"

    async def _build_vision_context(self, query: str, session_id: str) -> str:
        """Costruisci contesto RAG per Vision."""
        files = self.uploaded_files.get(session_id, [])
        if not files:
            return ""

        try:
            # Query embeddings
            response = await self.vision_processor.client.embeddings(
                model='qwen3-embedding:0.6b',
                prompt=query
            )
            query_emb = response.get('embedding') if response else None
            
            if not query_emb:
                return ""
            
            # Query ChromaDB
            results = self.collection.query(
                query_embeddings=[query_emb],
                n_results=12,
                where={"source": {"$in": [f['name'] for f in files]}}
            )
            
            if not results.get('documents') or not results['documents'][0]:
                return ""
            
            # Raggruppa per sorgente
            context_parts = []
            for i, doc_text in enumerate(results['documents'][0]):
                source = results['metadatas'][0][i].get('source', 'unknown')
                context_parts.append(f"=== {source} ===\n{doc_text}")
            
            return "\n\n".join(context_parts)
            
        except Exception as e:
            logger.error(f"RAG Error: {e}")
            return ""

    def _build_messages(self, user_message: str, context_text: str, session_id: str) -> List[Dict]:
        """Costruisci lista messaggi per Ollama - LEGGE IMMAGINI DAL DISCO come NiceGUI."""
        messages = []

        # System prompt - CARICATO DA JSON
        system_prompt = self.prompts.get('analysis', {}).get('system_prompt', "You are a professional image analyst.")
        
        lang_map = {'it': 'Italian', 'en': 'English'}
        session_lang = lang_map.get(self.lang, 'English')
        if self.lang != 'en':
            system_prompt += f" (reply in this language: {session_lang})"
        
        # Iniezione Thinking Token per Gemma 4
        from backend_config import settings
        if "gemma4" in settings.VISION_MODEL.lower():
            system_prompt = f"<|think|>\n{system_prompt}"
            
        messages.append({"role": "system", "content": system_prompt})

        # Ottieni file caricati
        files = self.uploaded_files.get(session_id, [])
        logger.info(f"📂 _build_messages called | session_id={session_id} | files_count={len(files)} | files={files}")

        # Contesto RAG (per descrizioni testuali già generate)
        if context_text:
            user_prompt_template = self.prompts.get('analysis', {}).get('user_prompt_template', "CONTEXT:\n{context_text}\n\nUSER QUESTION:\n{user_message}")
            messages.append({
                "role": "user",
                "content": user_prompt_template.format(context_text=context_text, user_message=user_message)
            })
        
        # Leggi immagini DAL DISCO. Preferisco la versione _proc (ridotta a
        # 1024px) per risparmiare VRAM e tempo del modello. L'originale
        # resta sempre intatto in `path` ma non viene caricato qui — caricarlo
        # full-resolution costerebbe troppo VRAM senza guadagno reale per il
        # modello (qwen3-vl downsampla comunque internamente a patches
        # dinamiche con ceiling intorno a 1568px).
        images_data = []
        for f in files:
            if f.get('type') == 'image':
                # Pref _proc, fallback all'originale se _proc non esiste
                proc = f.get('proc_path')
                file_path = proc if proc and os.path.exists(proc) else f.get('path')
                logger.info(f"🖼️ Checking image: {f.get('name')} | path={file_path} | exists={os.path.exists(file_path) if file_path else False}")
                if file_path and os.path.exists(file_path):
                    try:
                        with open(file_path, 'rb') as img_f:
                            img_bytes = img_f.read()
                        images_data.append(img_bytes)
                        logger.info(f"✅ Loaded image from disk: {file_path} ({len(img_bytes)} bytes)")
                    except Exception as e:
                        logger.error(f"❌ Error reading image {file_path}: {e}")

        # Costruisci messaggio user con immagini
        user_content = user_message
        if context_text:
            user_prompt_template = self.prompts.get('analysis', {}).get('user_prompt_template', "{context_text}\n{user_message}")
            user_content = user_prompt_template.format(context_text=context_text, user_message=user_message)

        user_msg = {"role": "user", "content": user_content}
        if images_data:
            user_msg["images"] = images_data
            logger.info(f"✅ Attached {len(images_data)} image(s) to message (total {sum(len(img) for img in images_data)} bytes)")
        else:
            logger.warning(f"⚠️ No images found in session. Files: {files}")
        
        messages.append(user_msg)

        return messages

    def get_uploaded_files(self, session_id: str) -> List[Dict]:
        """Ottieni lista file caricati."""
        self._get_or_create_session(session_id)
        return self.uploaded_files.get(session_id, [])

    def remove_file(self, filename: str, session_id: str):
        """Rimuovi file dalla sessione."""
        if session_id not in self.uploaded_files:
            return
        
        # Rimuovi da ChromaDB
        try:
            # Filtra per source
            self.collection.delete(where={"source": filename})
        except Exception as e:
            logger.error(f"Error removing from ChromaDB: {e}")
        
        # Rimuovi da lista
        self.uploaded_files[session_id] = [
            f for f in self.uploaded_files[session_id]
            if f['name'] != filename
        ]
        
        self._save_session(session_id)
        logger.info(f"File removed: {filename}")

    def clear_session(self, session_id: str):
        """Cancella sessione fisica e logica."""
        if session_id in self.sessions:
            del self.sessions[session_id]
        if session_id in self.uploaded_files:
            # FIX: Cancella fisicamente i file uploadati (originale + _proc derivata)
            for f in self.uploaded_files[session_id]:
                # Cancella entrambi: originale + versione _proc se esistente.
                # Pattern non-distruttivo all'upload, distruttivo allo clear.
                for path_key in ('path', 'proc_path'):
                    raw = f.get(path_key)
                    if not raw:
                        continue
                    try:
                        fp = Path(raw)
                        if fp.exists():
                            fp.unlink()
                            logger.info(f"🗑️ Deleted physical file ({path_key}): {fp.name}")
                    except Exception as e:
                        logger.warning(f"Failed to delete {path_key} {raw}: {e}")
            del self.uploaded_files[session_id]

        # Reset ChromaDB — wipe all docs in the collection.
        # Newer ChromaDB versions reject the empty `where={}` filter (raises
        # "Expected where to have exactly one operator, got {}"). Use the
        # delete-by-IDs pattern instead: list all current IDs and pass them.
        try:
            all_ids = (self.collection.get() or {}).get('ids') or []
            if all_ids:
                self.collection.delete(ids=all_ids)
        except Exception as e:
            logger.warning(f"Vision ChromaDB wipe failed: {e}")

        session_file = self._get_session_file(session_id)
        if session_file.exists():
            session_file.unlink()

        logger.info(f"Session cleared: {session_id}")
