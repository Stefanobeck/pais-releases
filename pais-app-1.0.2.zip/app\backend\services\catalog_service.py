"""
Catalog Service - User-facing model lists for INTERROGATE (and future modules).

Reads `profiles.json.catalog.<module>` (single source of truth for the
canonical models the user sees in the picker) + merges user-installed custom
Ollama models from `user_settings.json`. Computes the `installed` flag by
re-using the same matching logic as system_service._check_installed.

Schema returned by get_interrogate_catalog():
    {
      "models": [
        {
          "id": str,
          "display_name": str,
          "description": str,        # localized fallback (use description_key client-side)
          "description_key": str | None,
          "quality": int | None,
          "speed": int | None,
          "size_gb": float | None,
          "installed": bool,
          "is_mandatory": bool,
          "recommended": bool,
          "is_custom": bool
        }
      ]
    }
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger("PAIS.Catalog")


def _list_installed_ollama_names(system_service) -> List[str]:
    """Return the list of currently installed Ollama model names.
    Returns [] if Ollama is offline or the call fails.
    """
    import asyncio
    names: List[str] = []
    try:
        client = system_service.get_ollama_client()
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # We're in async context — caller should use the async version.
            # This sync helper is only used for synchronous endpoints.
            raise RuntimeError("event loop running; use _list_installed_ollama_names_async")
        info = loop.run_until_complete(client.list())
    except RuntimeError:
        # Re-raise so async code uses the async helper
        raise
    except Exception as e:
        logger.warning(f"ollama list failed: {e}")
        return []

    if hasattr(info, "models"):
        for m in info.models:
            n = getattr(m, "model", getattr(m, "name", ""))
            if n:
                names.append(n)
    elif isinstance(info, dict) and "models" in info:
        for m in info["models"]:
            if isinstance(m, dict):
                n = m.get("name") or m.get("model", "")
            else:
                n = getattr(m, "model", getattr(m, "name", ""))
            if n:
                names.append(n)
    return names


async def _list_installed_ollama_names_async(system_service) -> List[str]:
    names: List[str] = []
    try:
        client = system_service.get_ollama_client()
        info = await client.list()
    except Exception as e:
        logger.warning(f"ollama list failed: {e}")
        return []

    if hasattr(info, "models"):
        for m in info.models:
            n = getattr(m, "model", getattr(m, "name", ""))
            if n:
                names.append(n)
    elif isinstance(info, dict) and "models" in info:
        for m in info["models"]:
            if isinstance(m, dict):
                n = m.get("name") or m.get("model", "")
            else:
                n = getattr(m, "model", getattr(m, "name", ""))
            if n:
                names.append(n)
    return names


def _is_installed(req: str, installed_names: List[str]) -> bool:
    if not installed_names:
        return False
    for installed in installed_names:
        if not installed:
            continue
        if req == installed or installed.startswith(req + ":") or (":" not in req and installed.startswith(req)):
            return True
    return False


def _canonical_entries(system_service, module: str) -> List[Dict[str, Any]]:
    """Read the canonical catalog for a given module from profiles.json."""
    profiles = getattr(system_service, "profiles", {}) or {}
    catalog = profiles.get("catalog") or {}
    entries = catalog.get(module) or []
    return list(entries)


def _canonical_interrogate_entries(system_service) -> List[Dict[str, Any]]:
    return _canonical_entries(system_service, "interrogate")


async def get_interrogate_catalog(system_service) -> Dict[str, Any]:
    """Interrogate catalog — canonical (gemma4 family + gpt-oss:20b) + user custom."""
    return await _build_module_catalog(system_service, "interrogate")


async def _build_module_catalog(system_service, module: str) -> Dict[str, Any]:
    """Generic catalog builder. Reads canonical entries from profiles.json and
    merges user-defined custom models (from user_settings.json). Computes the
    `installed` flag by querying Ollama once.
    """
    from services import user_settings_service as uss

    canonical = _canonical_entries(system_service, module)
    custom_ids = uss.get_custom_models(module)
    installed_names = await _list_installed_ollama_names_async(system_service)
    model_sizes = getattr(system_service, "model_sizes", {}) or {}

    canonical_ids = {e.get("id") for e in canonical if isinstance(e, dict) and e.get("id")}

    out_models: List[Dict[str, Any]] = []
    for e in canonical:
        if not isinstance(e, dict) or not e.get("id"):
            continue
        mid = e["id"]
        out_models.append({
            "id": mid,
            "display_name": e.get("display_name", mid),
            "description": e.get("description_default", ""),
            "description_key": e.get("description_key"),
            "quality": e.get("quality"),
            "speed": e.get("speed"),
            "size_gb": model_sizes.get(mid),
            "installed": _is_installed(mid, installed_names),
            "is_mandatory": bool(e.get("is_mandatory")),
            "recommended": bool(e.get("recommended")),
            "ram_label": e.get("ram_label"),
            "is_custom": False,
            "requires_terms": e.get("requires_terms"),
        })

    # User-installed custom models — appended after canonical, never duplicated.
    for cid in custom_ids:
        if cid in canonical_ids:
            continue
        out_models.append({
            "id": cid,
            "display_name": cid,
            "description": "",
            "description_key": None,
            "quality": None,
            "speed": None,
            "size_gb": model_sizes.get(cid),
            "installed": _is_installed(cid, installed_names),
            "is_mandatory": False,
            "recommended": False,
            "is_custom": True,
        })

    return {
        "models": out_models,
    }


async def get_manipulate_catalog(system_service) -> Dict[str, Any]:
    """Manipulate catalog — canonical (qwen3-coder:30b, qwen2.5-coder:7b) + user custom."""
    return await _build_module_catalog(system_service, "manipulate")


async def get_vision_catalog(system_service) -> Dict[str, Any]:
    """Vision catalog — canonical (gemma4:e4b mandatory, qwen3-vl:4b optional) + user custom."""
    return await _build_module_catalog(system_service, "vision")


_MODULE_CATALOG_GETTER = {
    "interrogate": get_interrogate_catalog,
    "vision": get_vision_catalog,
    "manipulate": get_manipulate_catalog,
}


async def add_module_custom_model(system_service, module: str, model_id: str) -> Dict[str, Any]:
    """Validate that the model is actually installed in Ollama, then persist it
    as a custom for the given module. Rejects canonical ids and non-installed.
    """
    from services import user_settings_service as uss

    if module not in _MODULE_CATALOG_GETTER:
        raise ValueError(f"Unknown module '{module}'")
    model_id = (model_id or "").strip()
    if not model_id:
        raise ValueError("model_id is required")

    canonical_ids = {e.get("id") for e in _canonical_entries(system_service, module)}
    if model_id in canonical_ids:
        raise ValueError(f"'{model_id}' is already a canonical {module} model — no need to add it as custom")

    installed = await _list_installed_ollama_names_async(system_service)
    if not _is_installed(model_id, installed):
        raise ValueError(
            f"Model '{model_id}' is not installed in Ollama. "
            f"Install it first via /api/system/install?model_type=ollama&model_id={model_id}"
        )
    uss.add_custom_model(module, model_id)

    # AUTO-detect native context_length via Ollama /api/show. Salviamo il
    # valore in user_settings.json (sezione custom_models_ctx) cosi'
    # ollama_client lo usa come tetto per dynamic_ctx, evitando troncatura
    # silente quando il modello custom supporta meno di 128K. Errore = no-op.
    try:
        ollama_client = getattr(system_service, "ollama", None)
        if ollama_client is None:
            from processors.ollama_client import OllamaClient
            ollama_client = OllamaClient()
        ctx = await ollama_client.get_model_context_length(model_id)
        if isinstance(ctx, int) and ctx > 0:
            uss.set_custom_model_ctx(model_id, ctx)
    except Exception as e:
        # Non-fatal: il modello resta utilizzabile, ma con ctx max 128K
        # legacy (Ollama potrebbe troncare se il modello e' piu' piccolo).
        import logging
        logging.getLogger(__name__).warning(
            f"AUTO-detect ctx for custom model {model_id} failed: {e}"
        )

    return await _MODULE_CATALOG_GETTER[module](system_service)


async def remove_module_custom_model(system_service, module: str, model_id: str) -> Dict[str, Any]:
    """Remove a model from the user's custom list for the given module
    (does NOT uninstall from Ollama).
    """
    from services import user_settings_service as uss

    if module not in _MODULE_CATALOG_GETTER:
        raise ValueError(f"Unknown module '{module}'")
    model_id = (model_id or "").strip()
    if not model_id:
        raise ValueError("model_id is required")
    canonical_ids = {e.get("id") for e in _canonical_entries(system_service, module)}
    if model_id in canonical_ids:
        raise ValueError(f"'{model_id}' is a canonical {module} model and cannot be removed via custom-model API")
    removed = uss.remove_custom_model(module, model_id)
    if not removed:
        raise LookupError(f"'{model_id}' is not in the user's {module} custom list")

    # Cleanup ctx cache + persisted ctx. Safe se il modello non era mai stato
    # detectato (entrambe le rimozioni sono no-op silente in quel caso).
    try:
        uss.remove_custom_model_ctx(model_id)
        from processors import ollama_client as _oc
        _oc._MODEL_CTX_CACHE.pop(model_id, None)
    except Exception:
        pass

    return await _MODULE_CATALOG_GETTER[module](system_service)


# Backward-compat thin wrappers (interrogate router still calls these names)
async def add_interrogate_custom_model(system_service, model_id: str) -> Dict[str, Any]:
    return await add_module_custom_model(system_service, "interrogate", model_id)


async def remove_interrogate_custom_model(system_service, model_id: str) -> Dict[str, Any]:
    return await remove_module_custom_model(system_service, "interrogate", model_id)
