"""
Office Utility Processor - Logica per Smart Catalog, File Sanitizer e Smart Splitter.
Supporta: Testo, Office, PDF, Immagini, Audio, Video, Archivi e Progetti Creativi.
"""
import os
import io
import json
import logging
import asyncio
import datetime
import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import pypdf
import openpyxl
from docx import Document
from PIL import Image
from backend_config.settings import settings
from processors.ollama_client import OllamaClient

logger = logging.getLogger(__name__)

class OfficeUtilityProcessor:
    def __init__(self):
        self.ollama = OllamaClient()
        self.models_config = self._load_models_config()
        self.prompts = self._load_prompts_config()
        
        # Configurazione Modelli e CTX
        self.catalog_model = self.models_config.get("catalog_model", "gemma4:e2b")
        self.catalog_ctx = self.models_config.get("catalog_model_ctx", 16384)
        self.vision_model = self.models_config.get("video_model", "gemma4:e4b")
        self.vision_ctx = self.models_config.get("video_model_ctx", 32768)

    def _load_models_config(self) -> Dict[str, Any]:
        try:
            config_path = Path(__file__).parent.parent / "backend_config" / "models.json"
            if config_path.exists():
                with open(config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Error loading models.json: {e}")
        return {}

    def _load_prompts_config(self) -> Dict[str, str]:
        try:
            config_path = Path(__file__).parent.parent / "backend_config" / "prompts_utility.json"
            if config_path.exists():
                with open(config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Error loading prompts_utility.json: {e}")
        return {}

    async def generate_smart_catalog(self, file_paths: List[Path], output_path: Path, lang: str = "it", deep_mode: bool = False) -> str:
        """
        Scansiona i file con logica di Triage Estesa.
        """
        from processors.ocr_processor import OCRImgPDFProcessor
        from services.i18n_service import i18n
        ocr = OCRImgPDFProcessor()
        
        lbl = i18n._labels.get(lang.lower(), i18n._labels.get("it", {})).get("utility", {})
        current_headers = [
            lbl.get("catalog_header_filename", "Nome File"),
            lbl.get("catalog_header_date", "Data Documento"),
            lbl.get("catalog_header_summary", "Oggetto/Sintesi"),
            lbl.get("catalog_header_type", "Tipo Atto"),
            lbl.get("catalog_header_urgency", "Grado di Urgenza")
        ]

        text_files = []
        image_files = []
        scanned_pdfs = []
        media_files = []
        special_files = []
        other_files = []
        
        # 1. TRIAGE ESTESO
        for path in file_paths:
            ext = path.suffix.lower()
            if ext in ['.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tiff']:
                image_files.append(path)
            elif ext in ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mpeg', '.mpg']:
                media_files.append(path)
            elif ext in ['.mp3', '.wav', '.m4a', '.flac', '.aac', '.ogg', '.wma']:
                media_files.append(path)
            elif ext in ['.zip', '.rar', '.7z', '.tar', '.gz', '.iso', '.cab']:
                special_files.append(path)
            elif ext in ['.psd', '.ai', '.aep', '.prproj', '.indd', '.eps', '.svg']:
                special_files.append(path)
            elif ext == '.pdf':
                has_text = False
                try:
                    reader = pypdf.PdfReader(path)
                    for i in range(min(3, len(reader.pages))):
                        if (reader.pages[i].extract_text() or "").strip():
                            has_text = True
                            break
                except: pass
                if has_text: text_files.append(path)
                else: scanned_pdfs.append(path)
            elif ext in ['.txt', '.log', '.json', '.csv', '.srt', '.docx', '.xlsx']:
                text_files.append(path)
            else:
                other_files.append(path)

        results_map = {}
        
        # 2. ELABORAZIONE IMMAGINI E SCANSIONI (Solo se Deep Mode)
        if deep_mode:
            for path in scanned_pdfs:
                logger.info(f"[DEEP] OCR: {path.name}")
                success, extracted_text = await ocr.process_pdf(str(path))
                if success and extracted_text.strip():
                    results_map[path.name] = await self._analyze_metadata(path.name, extracted_text[:3000], lang)
                else:
                    results_map[path.name] = {"date": "N/A", "summary": f"{lbl.get('catalog_pdf_scan', 'PDF scansionato')} ({lbl.get('catalog_no_text', 'Testo non rilevato')})", "type": "PDF Scan", "urgency": "Low"}
            
            for path in image_files:
                logger.info(f"[DEEP] Vision: {path.name}")
                results_map[path.name] = await self._analyze_image_metadata(path, lang)
        else:
            for path in scanned_pdfs:
                results_map[path.name] = {"date": "N/A", "summary": lbl.get('catalog_pdf_scan', 'PDF Scansionato'), "type": "PDF Scan", "urgency": "N/A"}
            for path in image_files:
                results_map[path.name] = {"date": "N/A", "summary": lbl.get('catalog_image', 'Immagine'), "type": "Media", "urgency": "N/A"}

        # 3. ELABORAZIONE MEDIA E FORMATI SPECIALI (Programmatico)
        for path in media_files:
            ext = path.suffix.lower()
            m_type = "Video" if ext in ['.mp4', '.mkv', '.avi', '.mov', '.wmv'] else "Audio"
            results_map[path.name] = {"date": "N/A", "summary": f"{lbl.get('catalog_media', 'File Multimediale')} ({ext.upper()})", "type": m_type, "urgency": "N/A"}

        for path in special_files:
            ext = path.suffix.lower()
            if ext in ['.zip', '.rar', '.7z', '.tar', '.gz']:
                results_map[path.name] = {"date": "N/A", "summary": f"{lbl.get('catalog_archive', 'Archivio Compresso')} ({ext.upper()})", "type": "Archive", "urgency": "N/A"}
            elif ext in ['.psd', '.ai', '.aep', '.prproj', '.indd']:
                results_map[path.name] = {"date": "N/A", "summary": f"{lbl.get('catalog_creative', 'Progetto Creativo Adobe')} ({ext.upper()})", "type": "Creative", "urgency": "N/A"}
            else:
                results_map[path.name] = {"date": "N/A", "summary": f"{lbl.get('catalog_special', 'File Speciale')} ({ext.upper()})", "type": "Special", "urgency": "N/A"}

        # 4. ELABORAZIONE TESTI (Sempre IA)
        for path in text_files:
            logger.info(f"Analysis: {path.name}")
            content_preview = self._extract_text_preview(path)
            results_map[path.name] = await self._analyze_metadata(path.name, content_preview, lang)
            
        for path in other_files:
            results_map[path.name] = {"date": "N/A", "summary": lbl.get("catalog_system", "File di sistema o formato non supportato"), "type": "System", "urgency": "N/A"}

        # 5. CREAZIONE EXCEL
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Smart Catalog"
        ws.append(current_headers)
        
        for cell in ws[1]:
            cell.font = openpyxl.styles.Font(bold=True, color="FFFFFF")
            cell.fill = openpyxl.styles.PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")

        for path in file_paths:
            meta = results_map.get(path.name, {})
            doc_date = meta.get("date", "N/A")
            if doc_date == "N/A" or not doc_date:
                try:
                    mtime = os.path.getmtime(path)
                    doc_date = datetime.datetime.fromtimestamp(mtime).strftime('%d/%m/%Y') + " (File)"
                except: doc_date = "N/A"

            ws.append([
                path.name,
                doc_date,
                meta.get("summary", "N/A"),
                meta.get("type", "N/A"),
                meta.get("urgency", "N/A")
            ])

        for col in ws.columns:
            max_length = 0
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length: max_length = len(str(cell.value))
                except: pass
            ws.column_dimensions[col[0].column_letter].width = min(max_length + 2, 60)

        wb.save(output_path)
        # Audit trail (cataloga è un export aggregato)
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "document_exported",
                processor="smart_catalog",
                deep_mode=bool(deep_mode),
                input_files_count=len(file_paths),
                output=file_metadata(output_path),
            )
        except Exception:
            pass
        return str(output_path)

    def _extract_text_preview(self, path: Path) -> str:
        ext = path.suffix.lower(); text = ""
        try:
            if ext == '.pdf':
                reader = pypdf.PdfReader(path)
                for i in range(min(3, len(reader.pages))): text += reader.pages[i].extract_text() or ""
            elif ext == '.docx':
                doc = Document(path)
                text = "\n".join([p.text for p in doc.paragraphs[:50]])
            elif ext == '.xlsx':
                wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
                ws = wb.active; rows = []
                for row in ws.iter_rows(max_row=20, max_col=10, values_only=True):
                    rows.append("\t".join([str(c) if c is not None else "" for c in row]))
                text = "\n".join(rows)
            elif ext in ['.txt', '.log', '.json', '.csv', '.srt']:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f: text = f.read(5000)
        except: pass
        return text[:3000]

    async def _analyze_metadata(self, filename: str, content: str, lang: str) -> Dict[str, str]:
        lang_name = "Italian" if lang.lower() == "it" else "English"
        base_prompt = self.prompts.get("catalog_text_prompt", "")
        # Rafforzamento lingua "Double-Tap"
        instruction = f"[MANDATORY LANGUAGE: {lang_name.upper()}]\nAll values (summary, type) MUST be written in {lang_name}.\n\n"
        prompt = instruction + base_prompt.replace("{filename}", filename).replace("{content}", content)
        prompt += f"\n\n[FINAL REMINDER]: YOU MUST USE {lang_name.upper()} ONLY. Respond only with a JSON object."
        
        try:
            response = ""
            options = {"num_ctx": self.catalog_ctx, "temperature": 0.1}
            async for chunk in self.ollama.chat_stream(model=self.catalog_model, messages=[{"role": "user", "content": prompt}], options=options):
                response += chunk
            
            clean_response = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL).strip()
            match = re.search(r"\{.*\}", clean_response, re.DOTALL)
            if match:
                try: return json.loads(match.group())
                except:
                    js = match.group(); lb = js.rfind('}'); 
                    if lb != -1: return json.loads(js[:lb+1])
        except Exception as e:
            logger.error(f"IA Metadata error for {filename}: {e}")
        return {}

    async def _analyze_image_metadata(self, path: Path, lang: str) -> Dict[str, str]:
        lang_name = "Italian" if lang.lower() == "it" else "English"
        base_prompt = self.prompts.get("catalog_image_prompt", "")
        instruction = f"[MANDATORY LANGUAGE: {lang_name.upper()}]\nYou MUST write the values (summary, type) in {lang_name}.\n\n"
        prompt = instruction + base_prompt + f"\n\n[FINAL REMINDER]: USE {lang_name.upper()} ONLY."
        try:
            import base64
            with open(path, "rb") as f: img_b64 = base64.b64encode(f.read()).decode('utf-8')
            response = ""
            options = {"num_ctx": self.vision_ctx, "temperature": 0.1}
            async for chunk in self.ollama.chat_stream(model=self.vision_model, messages=[{"role": "user", "content": prompt, "images": [img_b64]}], options=options):
                response += chunk
            clean_response = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL).strip()
            match = re.search(r"\{.*\}", clean_response, re.DOTALL)
            if match:
                try: return json.loads(match.group())
                except:
                    js = match.group(); lb = js.rfind('}'); 
                    if lb != -1: return json.loads(js[:lb+1])
        except Exception as e:
            logger.error(f"Vision error for {path.name}: {e}")
            
        from services.i18n_service import i18n
        lbl = i18n._labels.get(lang.lower(), i18n._labels.get("it", {})).get("utility", {})
        return {"date": "N/A", "summary": lbl.get("catalog_error", "Error"), "type": "Media", "urgency": "N/A"}

    async def sanitize_file(self, input_path: Path, output_path: Path) -> Tuple[bool, List[str]]:
        ext = input_path.suffix.lower()
        success = False
        removed_meta = []
        try:
            if ext == '.pdf':
                reader = pypdf.PdfReader(input_path); writer = pypdf.PdfWriter()
                meta = reader.metadata
                if meta:
                    for k, v in meta.items():
                        if v and str(v).strip():
                            removed_meta.append(f"PDF {k.replace('/', '')}: {str(v)[:50]}")
                for page in reader.pages: writer.add_page(page)
                writer.add_metadata({}) # Clear PDF info dictionary
                with open(output_path, "wb") as f: writer.write(f)
                success = True
            elif ext == '.docx':
                from docx import Document
                doc = Document(input_path); p = doc.core_properties
                if p.author: removed_meta.append(f"Author: {p.author}"); p.author = ""
                if p.title: removed_meta.append(f"Title: {p.title}"); p.title = ""
                if p.subject: removed_meta.append(f"Subject: {p.subject}"); p.subject = ""
                if p.comments: removed_meta.append(f"Comments: {p.comments}"); p.comments = ""
                if p.last_modified_by: removed_meta.append(f"Last Modified By: {p.last_modified_by}"); p.last_modified_by = ""
                doc.save(output_path)
                success = True
            elif ext in ['.xlsx', '.xls', '.ods']:
                import openpyxl
                if ext == '.ods':
                    import shutil
                    shutil.copy2(input_path, output_path)
                else:
                    wb = openpyxl.load_workbook(input_path); p = wb.properties
                    if getattr(p, 'creator', None): removed_meta.append(f"Creator: {p.creator}"); p.creator = ""
                    if getattr(p, 'title', None): removed_meta.append(f"Title: {p.title}"); p.title = ""
                    if getattr(p, 'description', None): removed_meta.append(f"Description: {p.description}"); p.description = ""
                    if getattr(p, 'subject', None): removed_meta.append(f"Subject: {p.subject}"); p.subject = ""
                    if getattr(p, 'lastModifiedBy', None): removed_meta.append(f"Last Modified By: {p.lastModifiedBy}"); p.lastModifiedBy = ""
                    wb.save(output_path)
                success = True
            elif ext in ['.jpg', '.jpeg', '.png', '.webp', '.tiff']:
                img = Image.open(input_path)
                try:
                    exif = img.getexif()
                    if exif:
                        removed_meta.append(f"EXIF Data: {len(exif)} tags removed")
                except: pass
                data = list(img.getdata()); img_no_exif = Image.new(img.mode, img.size); img_no_exif.putdata(data); img_no_exif.save(output_path)
                success = True
            elif ext in ['.csv', '.txt', '.md', '.rtf']:
                import shutil
                shutil.copy2(input_path, output_path)
                success = True
            
            if success:
                import time, os
                try:
                    past_ts = time.mktime((2000, 1, 1, 0, 0, 0, 0, 0, 0))
                    # Read old times
                    stat = os.stat(input_path)
                    old_c = time.ctime(stat.st_ctime)
                    old_m = time.ctime(stat.st_mtime)
                    removed_meta.append(f"Creation Date: {old_c}")
                    removed_meta.append(f"Modification Date: {old_m}")
                    
                    os.utime(output_path, (past_ts, past_ts))
                except Exception as e:
                    logger.warning(f"Failed to reset timestamp: {e}")
                return True, removed_meta
                
            return False, []
        except Exception as e:
            logger.error(f"Sanitize error: {e}"); return False, []

    @staticmethod
    def _parse_page_ranges(spec: str, total_pages: int) -> List[Tuple[int, int]]:
        """Parse '1-3,5,8-10' into [(1,3),(5,5),(8,10)] (1-indexed inclusive).

        Tollerante a spazi e separatori `,` o `;`. Clampa al numero reale di pagine.
        Raises ValueError per range non validi (es. inizio > fine, fuori bounds).
        """
        if not spec or not spec.strip():
            raise ValueError("Empty range specification")
        out: List[Tuple[int, int]] = []
        for token in re.split(r'[;,]', spec):
            token = token.strip()
            if not token:
                continue
            if '-' in token:
                a, b = token.split('-', 1)
                start, end = int(a.strip()), int(b.strip())
            else:
                start = end = int(token)
            if start < 1 or end < 1 or start > end:
                raise ValueError(f"Invalid range '{token}'")
            if start > total_pages:
                continue  # range entirely beyond document — skip
            end = min(end, total_pages)
            out.append((start, end))
        if not out:
            raise ValueError("No valid ranges in specification")
        return out

    async def smart_split_pdf(
        self,
        input_path: Path,
        output_root: Path,
        lang: str = "it",
        mode: str = "per_page",
        pages_per_chunk: int = 1,
        ranges_spec: Optional[str] = None,
        num_parts: int = 2,
        target_size_mb: float = 10.0,
    ) -> Tuple[str, List[str]]:
        """Divide un PDF in più documenti secondo la modalità scelta.

        Modalità supportate:
          - 'per_page'  : 1 pagina per file (default storico)
          - 'chunks'    : ogni `pages_per_chunk` pagine consecutive un file
          - 'ranges'    : range custom, parse di `ranges_spec` (es. "1-3,5,8-10")
          - 'parts'     : divide equamente in `num_parts` file (last part assorbe il resto)
          - 'size'      : chunks con dimensione approssimativa <= `target_size_mb` MB ciascuno
                          (utile per allegati email). Se una singola pagina supera già
                          il target, viene comunque salvata in un file dedicato (warn log).

        L'output è scritto in `output_root / "SPLIT_DOCUMENT_<timestamp>_<stem>" /`.
        Ritorna (subfolder_name, [filenames]) dove subfolder è relativo a output_root.
        """
        reader = pypdf.PdfReader(input_path)
        total_pages = len(reader.pages)
        if total_pages == 0:
            raise ValueError("PDF has no pages")
        base_name = input_path.stem

        # Costruisci la lista di range (1-indexed, inclusive) in base al mode
        chunks: List[Tuple[int, int]] = []
        if mode == "per_page":
            chunks = [(i, i) for i in range(1, total_pages + 1)]
        elif mode == "chunks":
            n = max(1, int(pages_per_chunk))
            chunks = [(i, min(i + n - 1, total_pages)) for i in range(1, total_pages + 1, n)]
        elif mode == "ranges":
            chunks = self._parse_page_ranges(ranges_spec or "", total_pages)
        elif mode == "parts":
            n = max(1, min(int(num_parts), total_pages))
            base_size = total_pages // n
            extra = total_pages % n
            cursor = 1
            for k in range(n):
                size = base_size + (1 if k < extra else 0)
                chunks.append((cursor, cursor + size - 1))
                cursor += size
        elif mode == "size":
            target_bytes = int(float(target_size_mb) * 1024 * 1024)
            if target_bytes <= 0:
                raise ValueError("target_size_mb must be > 0")
            cursor0 = 0  # 0-indexed
            while cursor0 < total_pages:
                writer = pypdf.PdfWriter()
                chunk_pages = 0
                for page_idx in range(cursor0, total_pages):
                    writer.add_page(reader.pages[page_idx])
                    chunk_pages += 1
                    buf = io.BytesIO()
                    writer.write(buf)
                    if buf.tell() > target_bytes and chunk_pages > 1:
                        chunk_pages -= 1  # rollback: l'ultima pagina sfora → nuovo chunk
                        break
                if chunk_pages == 1 and writer is not None:
                    # Pagina singola che supera il target: trasparenza nei log
                    buf2 = io.BytesIO(); writer.write(buf2)
                    if buf2.tell() > target_bytes:
                        logger.warning(
                            f"Page {cursor0 + 1} exceeds target ({buf2.tell()} > {target_bytes} B); "
                            f"saved as standalone file"
                        )
                chunks.append((cursor0 + 1, cursor0 + chunk_pages))
                cursor0 += chunk_pages
        else:
            raise ValueError(f"Unknown split mode: {mode}")

        # Cartella di destinazione: SPLIT_DOCUMENT_<ts>_<stem>/
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        # Sanitize stem per nomefile filesystem-safe
        safe_stem = re.sub(r'[^\w\-]', '_', base_name)[:60]
        subfolder_name = f"SPLIT_DOCUMENT_{timestamp}_{safe_stem}"
        out_dir = output_root / subfolder_name
        out_dir.mkdir(parents=True, exist_ok=True)

        # Padding zero-fill basato sul numero di chunk per ordinamento naturale
        digits = max(2, len(str(len(chunks))))
        generated_files: List[str] = []
        for idx, (start, end) in enumerate(chunks, start=1):
            writer = pypdf.PdfWriter()
            for page_idx in range(start - 1, end):
                writer.add_page(reader.pages[page_idx])
            if mode == "per_page":
                out_name = f"{safe_stem}_Pagina_{str(start).zfill(digits)}.pdf"
            else:
                # Es: <stem>_Parte_01_pagine_01-10.pdf
                pad_pages = max(2, len(str(total_pages)))
                out_name = (
                    f"{safe_stem}_Parte_{str(idx).zfill(digits)}"
                    f"_pagine_{str(start).zfill(pad_pages)}-{str(end).zfill(pad_pages)}.pdf"
                )
            final_out_path = out_dir / out_name
            with open(final_out_path, "wb") as f:
                writer.write(f)
            generated_files.append(out_name)
        # Audit trail
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="smart_split_pdf",
                mode=mode,
                pages_per_chunk=pages_per_chunk if mode == "chunks" else None,
                ranges_spec=ranges_spec if mode == "ranges" else None,
                num_parts=num_parts if mode == "parts" else None,
                target_size_mb=target_size_mb if mode == "size" else None,
                input_total_pages=total_pages,
                output_subfolder=subfolder_name,
                output_files_count=len(generated_files),
                success=True,
                **{f"input_{k}": v for k, v in file_metadata(input_path).items()},
            )
        except Exception:
            pass
        return subfolder_name, generated_files

    # ─────────────────────────────────────────────────────────────────────
    # PDF Toolkit — merge & compress
    # ─────────────────────────────────────────────────────────────────────

    async def pdf_merge(
        self,
        input_paths: List[Path],
        output_root: Path,
        output_name: Optional[str],
        lang: str = "it",
    ) -> Tuple[str, int, List[str]]:
        """Unisce N PDF in un singolo file.

        L'ordine dei file in `input_paths` è quello della merge (i client
        devono inviarli nell'ordine desiderato — FastAPI preserva l'ordine
        dei multipart upload).

        File corrotti o protetti da password vengono saltati e riportati
        nella lista `skipped`. Solleva ValueError solo se *tutti* gli input
        falliscono (così l'utente vede sempre l'output parziale se possibile).
        """
        if not input_paths:
            raise ValueError("No input PDFs provided")

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)

        # Sanitize filename — stessa regex di smart_split_pdf.
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        if output_name and output_name.strip():
            safe_stem = re.sub(r'[^\w\-]', '_', Path(output_name).stem)[:60]
        else:
            safe_stem = f"Merged_{ts}"
        out_filename = f"{safe_stem}.pdf"
        # Evita collisioni con file esistenti (counter _02, _03, …).
        counter = 2
        final_path = out_dir / out_filename
        while final_path.exists():
            out_filename = f"{safe_stem}_{counter:02d}.pdf"
            final_path = out_dir / out_filename
            counter += 1

        writer = pypdf.PdfWriter()
        skipped: List[str] = []
        total_pages = 0
        for path in input_paths:
            try:
                reader = pypdf.PdfReader(str(path))
                if reader.is_encrypted:
                    # Tentativo di decrypt con password vuota — molti PDF "protetti"
                    # in realtà hanno solo flag di permessi senza password.
                    try:
                        reader.decrypt("")
                    except Exception:
                        skipped.append(path.name)
                        logger.warning(f"pdf_merge: skipping encrypted PDF {path.name}")
                        continue
                page_count = len(reader.pages)
                if page_count == 0:
                    skipped.append(path.name)
                    logger.warning(f"pdf_merge: skipping empty PDF {path.name}")
                    continue
                for page in reader.pages:
                    writer.add_page(page)
                total_pages += page_count
            except Exception as e:
                skipped.append(path.name)
                logger.warning(f"pdf_merge: skipping {path.name}: {e}")

        if total_pages == 0:
            raise ValueError("All input PDFs were invalid or encrypted")

        with open(final_path, "wb") as f:
            writer.write(f)

        # Audit
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="pdf_merge",
                input_files_count=len(input_paths),
                skipped_count=len(skipped),
                output_pages=total_pages,
                output_filename=out_filename,
                success=True,
                **{f"output_{k}": v for k, v in file_metadata(final_path).items()},
            )
        except Exception:
            pass

        return out_filename, total_pages, skipped

    async def pdf_compress(
        self,
        input_path: Path,
        output_root: Path,
        quality: str = "medium",
        lang: str = "it",
    ) -> Tuple[str, int, int, bool]:
        """Comprime un PDF ricomprimendo le immagini embedded.

        Preset:
          - low    : DPI target 72,  JPEG quality 60   → file più piccolo
          - medium : DPI target 110, JPEG quality 75
          - high   : DPI target 150, JPEG quality 85   → qualità migliore

        Skippa immagini in formato JBIG2/CCITT (scan B/N — già ottimali).
        Se la compressione non produce un guadagno significativo (≥98% della
        dimensione originale), restituisce una copia dell'originale e segnala
        `no_gain=True` — non consegnamo mai un file più grande dell'input.

        Returns: (filename, original_size, compressed_size, no_gain).
        """
        import shutil as _shutil
        import pikepdf
        from io import BytesIO

        presets = {
            "low":    {"dpi": 72,  "jpeg": 60},
            "medium": {"dpi": 110, "jpeg": 75},
            "high":   {"dpi": 150, "jpeg": 85},
        }
        if quality not in presets:
            raise ValueError(f"Invalid quality preset: {quality}")
        target_dpi = presets[quality]["dpi"]
        jpeg_q = presets[quality]["jpeg"]

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_stem = re.sub(r'[^\w\-]', '_', input_path.stem)[:60]
        out_filename = f"Compressed_{quality}_{safe_stem}.pdf"
        # Evita collisioni
        counter = 2
        final_path = out_dir / out_filename
        while final_path.exists():
            out_filename = f"Compressed_{quality}_{safe_stem}_{counter:02d}.pdf"
            final_path = out_dir / out_filename
            counter += 1

        original_size = input_path.stat().st_size

        try:
            pdf = pikepdf.open(str(input_path))
        except pikepdf.PasswordError:
            raise ValueError("PDF is password-protected")
        except pikepdf._qpdf.PdfError as e:
            raise ValueError(f"Invalid PDF: {e}")

        # Ricompressione immagini pagina per pagina.
        for page_num, page in enumerate(pdf.pages):
            try:
                page_w_pts = float(page.mediabox[2]) - float(page.mediabox[0])
                page_h_pts = float(page.mediabox[3]) - float(page.mediabox[1])
            except Exception:
                page_w_pts = page_h_pts = 612.0  # fallback Letter
            try:
                images = page.images
            except Exception:
                continue
            for name, raw_obj in list(images.items()):
                try:
                    pdfimg = pikepdf.PdfImage(raw_obj)
                    img_filter = str(pdfimg.filters[0]) if pdfimg.filters else ""
                    # Skippa formati di scansione B/N — già ottimali, ricomprimere
                    # come JPEG li peggiora (modello colore + dimensione).
                    if any(f in img_filter for f in ("JBIG2", "CCITT", "RunLength")):
                        continue
                    # Skippa immagini con maschera alfa accoppiata: la maschera ha
                    # le sue dimensioni, e ridimensionando solo l'immagine principale
                    # si rompe l'allineamento col mask → file non più apribile.
                    if "/SMask" in raw_obj or "/Mask" in raw_obj:
                        continue
                    pil_img = pdfimg.as_pil_image()
                    iw, ih = pil_img.size
                    if iw < 8 or ih < 8:
                        continue  # icone/separatori, non vale la pena
                    # DPI effettivo stimato dalla bounding box pagina.
                    # (Se l'immagine non occupa l'intera pagina, è un'over-stima
                    # benigna: skippiamo solo se è davvero a basso DPI.)
                    eff_dpi_x = (iw / page_w_pts) * 72.0 if page_w_pts > 0 else 1000.0
                    eff_dpi_y = (ih / page_h_pts) * 72.0 if page_h_pts > 0 else 1000.0
                    eff_dpi = max(eff_dpi_x, eff_dpi_y)
                    if eff_dpi <= target_dpi * 1.05:
                        continue  # già al/sotto il target → niente da fare
                    scale = target_dpi / eff_dpi
                    new_w = max(8, int(iw * scale))
                    new_h = max(8, int(ih * scale))
                    pil_img = pil_img.resize((new_w, new_h), Image.LANCZOS)
                    # Le immagini con alpha non possono essere salvate JPEG → flatten su bianco.
                    if pil_img.mode in ("RGBA", "LA", "P"):
                        bg = Image.new("RGB", pil_img.size, (255, 255, 255))
                        bg.paste(pil_img, mask=pil_img.split()[-1] if "A" in pil_img.mode else None)
                        pil_img = bg
                    elif pil_img.mode != "RGB":
                        pil_img = pil_img.convert("RGB")
                    buf = BytesIO()
                    pil_img.save(buf, format="JPEG", quality=jpeg_q, optimize=True)
                    # Riscrivi lo stream come JPEG.
                    raw_obj.write(buf.getvalue(), filter=pikepdf.Name.DCTDecode)
                    # CRITICO: aggiorna le entry del dizionario XObject per
                    # matchare il nuovo stream. Senza questo Acrobat fallisce
                    # con "Dati non sufficienti per un'immagine" perché legge
                    # le vecchie dimensioni da /Width × /Height × bpc.
                    raw_obj["/Width"] = new_w
                    raw_obj["/Height"] = new_h
                    raw_obj["/BitsPerComponent"] = 8
                    raw_obj["/ColorSpace"] = pikepdf.Name.DeviceRGB
                    # Pulisci /DecodeParms del vecchio filtro (FlateDecode predictor,
                    # CCITT params, ecc.) — non più validi sotto DCTDecode.
                    if "/DecodeParms" in raw_obj:
                        del raw_obj["/DecodeParms"]
                except Exception as e:
                    logger.debug(f"pdf_compress: skip image {name} on page {page_num + 1}: {e}")
                    continue

        try:
            pdf.save(
                str(final_path),
                compress_streams=True,
                object_stream_mode=pikepdf.ObjectStreamMode.generate,
                linearize=False,
            )
        finally:
            pdf.close()

        compressed_size = final_path.stat().st_size
        no_gain = compressed_size >= original_size * 0.98
        if no_gain:
            # Sostituisci con copia originale — niente file più grandi dell'input.
            try:
                _shutil.copy2(input_path, final_path)
                compressed_size = final_path.stat().st_size
            except Exception as e:
                logger.warning(f"pdf_compress: no_gain copy fallback failed: {e}")

        # Audit
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="pdf_compress",
                quality=quality,
                original_size=original_size,
                compressed_size=compressed_size,
                no_gain=no_gain,
                output_filename=out_filename,
                success=True,
                **{f"input_{k}": v for k, v in file_metadata(input_path).items()},
            )
        except Exception:
            pass

        return out_filename, original_size, compressed_size, no_gain

    # ─────────────────────────────────────────────────────────────────────
    # Mail Merge — DOCX template + CSV/XLSX → N DOCX
    # ─────────────────────────────────────────────────────────────────────

    @staticmethod
    def _read_mail_merge_data(data_path: Path, lang: str = "it"):
        """Carica CSV o XLSX in DataFrame con colonne forzate stringa.

        - Forza dtype=str per evitare `1234.0` su interi e NaN da campi vuoti.
        - Date: pandas riconosce datetime cells in XLSX a prescindere da dtype;
          le formattiamo per locale (dd/mm/yyyy IT, mm/dd/yyyy EN).
        - Normalizza i nomi colonna: trim + spazi→underscore (Jinja2 non
          accetta identificatori con spazi).
        """
        import pandas as pd
        ext = data_path.suffix.lower()
        if ext == ".csv":
            try:
                df = pd.read_csv(data_path, dtype=str, keep_default_na=False, encoding="utf-8")
            except UnicodeDecodeError:
                df = pd.read_csv(data_path, dtype=str, keep_default_na=False, encoding="latin-1")
        elif ext in (".xlsx", ".xls"):
            df = pd.read_excel(data_path, dtype=str, keep_default_na=False, engine="openpyxl")
        else:
            raise ValueError(f"Unsupported data format: {ext}")

        date_fmt = "%d/%m/%Y" if lang.lower().startswith("it") else "%m/%d/%Y"

        def _coerce(v):
            if v is None:
                return ""
            if isinstance(v, (datetime.datetime, datetime.date)):
                return v.strftime(date_fmt)
            try:
                import pandas as _pd
                if isinstance(v, _pd.Timestamp):
                    return v.strftime(date_fmt)
            except Exception:
                pass
            return str(v).strip()

        # `DataFrame.map` rimpiazza `applymap` da pandas 2.1 (deprecato in 3.x)
        df = df.map(_coerce)
        # Normalizza nomi colonne
        df.columns = [str(c).strip().replace(" ", "_") for c in df.columns]
        return df

    async def mail_merge_inspect(
        self,
        template_path: Path,
        data_path: Path,
        lang: str = "it",
    ) -> Dict[str, Any]:
        """Estrae placeholder dal template DOCX e colonne dal data file,
        restituendo l'analisi di matching senza generare nulla.
        """
        from docxtpl import DocxTemplate

        # Estrazione placeholder via Jinja2 meta — gestisce correttamente
        # i "split runs" XML che Word produce su template editati a mano.
        try:
            tpl = DocxTemplate(str(template_path))
            placeholders_set = tpl.get_undeclared_template_variables()
        except Exception as e:
            raise ValueError(f"Invalid DOCX template: {e}")
        placeholders = sorted(placeholders_set)

        df = self._read_mail_merge_data(data_path, lang)
        columns = list(df.columns)
        row_count = len(df)
        sample_row = df.iloc[0].to_dict() if row_count else {}

        cols_set = set(columns)
        ph_set = set(placeholders)
        matches = {
            "matched": sorted(ph_set & cols_set),
            "missing_in_data": sorted(ph_set - cols_set),
            "unused_columns": sorted(cols_set - ph_set),
        }
        return {
            "placeholders": placeholders,
            "columns": columns,
            "row_count": row_count,
            "sample_row": sample_row,
            "matches": matches,
        }

    async def mail_merge_generate(
        self,
        template_path: Path,
        data_path: Path,
        output_root: Path,
        filename_pattern: str,
        lang: str = "it",
    ) -> Tuple[str, List[str], List[Dict[str, Any]]]:
        """Genera N file DOCX, uno per riga del data file.

        - Cap rows: 1000 (raise ValueError oltre).
        - Filename pattern: usa Python str.format ({colonna}). Caratteri
          illegali Windows sostituiti con `_`. Cap 200 char. Collisioni
          risolte con suffisso `_02`, `_03`, ...
        - Placeholder mancanti nei dati → renderizzati come stringa vuota
          (default-empty context, evita Jinja KeyError).
        """
        from docxtpl import DocxTemplate

        # Re-parse: garantisce dati freschi se l'utente ha modificato i file
        # tra inspect e generate (raro, ma corretto).
        df = self._read_mail_merge_data(data_path, lang)
        if len(df) == 0:
            raise ValueError("Data file has no rows")
        if len(df) > 1000:
            raise ValueError("Row limit (1000) exceeded")

        # Estrai placeholder per il default-empty context
        try:
            tpl_for_meta = DocxTemplate(str(template_path))
            placeholders = sorted(tpl_for_meta.get_undeclared_template_variables())
        except Exception as e:
            raise ValueError(f"Invalid DOCX template: {e}")

        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        safe_template_stem = re.sub(r'[^\w\-]', '_', template_path.stem)[:40]
        subfolder_name = f"MAIL_MERGE_{ts}_{safe_template_stem}"
        out_dir = output_root / subfolder_name
        out_dir.mkdir(parents=True, exist_ok=True)

        generated: List[str] = []
        skipped: List[Dict[str, Any]] = []
        used_names: set = set()
        illegal_chars_re = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

        records = df.to_dict(orient="records")
        for idx, row in enumerate(records, start=1):
            ctx = {p: "" for p in placeholders}
            ctx.update(row)
            # Costruisci nome file dal pattern
            try:
                raw_name = filename_pattern.format(**row)
            except (KeyError, IndexError) as e:
                skipped.append({"row": idx, "reason": f"pattern references missing column: {e}"})
                continue
            except Exception as e:
                skipped.append({"row": idx, "reason": f"invalid pattern: {e}"})
                continue

            # Sanitize: chars illegali Windows + trim trailing dots/spaces + cap 200
            cleaned = illegal_chars_re.sub("_", raw_name).rstrip(". ").strip()
            if not cleaned:
                cleaned = f"Documento_{idx:04d}"
            cleaned = cleaned[:200]
            base_name = cleaned
            final_name = f"{base_name}.docx"
            counter = 2
            while final_name in used_names or (out_dir / final_name).exists():
                final_name = f"{base_name}_{counter:02d}.docx"
                counter += 1
            used_names.add(final_name)

            # Render template — DocxTemplate mantiene stato interno, va re-istanziato per ogni riga.
            try:
                tpl = DocxTemplate(str(template_path))
                tpl.render(ctx)
                tpl.save(str(out_dir / final_name))
                generated.append(final_name)
            except Exception as e:
                skipped.append({"row": idx, "reason": f"render error: {e}"})
                logger.warning(f"mail_merge_generate row {idx}: {e}")

        # Audit
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="mail_merge_generate",
                input_rows=len(records),
                generated_count=len(generated),
                skipped_count=len(skipped),
                output_subfolder=subfolder_name,
                success=True,
                **{f"template_{k}": v for k, v in file_metadata(template_path).items()},
            )
        except Exception:
            pass

        return subfolder_name, generated, skipped

    # ─────────────────────────────────────────────────────────────────────
    # PDF Toolkit v2 — rotate, watermark, images↔PDF
    # ─────────────────────────────────────────────────────────────────────

    async def pdf_rotate(
        self,
        input_path: Path,
        output_root: Path,
        angle: int,
        pages_spec: Optional[str] = None,
        lang: str = "it",
    ) -> Tuple[str, int]:
        """Ruota pagine di un PDF.

        - `angle`: 90, 180, 270 (multipli di 90 obbligatori — pypdf lo richiede)
        - `pages_spec`: None = tutte le pagine; oppure "1-3,5,8-10" (1-indexed)

        Returns: (filename, rotated_pages_count).
        """
        if angle not in (90, 180, 270):
            raise ValueError(f"angle must be 90/180/270, got {angle}")

        reader = pypdf.PdfReader(str(input_path))
        if reader.is_encrypted:
            try: reader.decrypt("")
            except Exception:
                raise ValueError("PDF is password-protected")
        total = len(reader.pages)

        # Calcola insieme delle pagine 0-indexed da ruotare
        if pages_spec and pages_spec.strip():
            ranges = self._parse_page_ranges(pages_spec, total)
            target_pages_0idx: set = set()
            for start, end in ranges:
                for p in range(start - 1, end):
                    target_pages_0idx.add(p)
        else:
            target_pages_0idx = set(range(total))

        writer = pypdf.PdfWriter()
        for i, page in enumerate(reader.pages):
            if i in target_pages_0idx:
                page.rotate(angle)
            writer.add_page(page)

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_stem = re.sub(r'[^\w\-]', '_', input_path.stem)[:60]
        out_filename = f"Rotated_{angle}_{safe_stem}.pdf"
        n = 2
        final_path = out_dir / out_filename
        while final_path.exists():
            out_filename = f"Rotated_{angle}_{safe_stem}_{n:02d}.pdf"
            final_path = out_dir / out_filename
            n += 1

        with open(final_path, "wb") as f:
            writer.write(f)

        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log("utility", "file_processed", processor="pdf_rotate",
                             angle=angle, pages_rotated=len(target_pages_0idx),
                             total_pages=total, output_filename=out_filename, success=True,
                             **{f"input_{k}": v for k, v in file_metadata(input_path).items()})
        except Exception:
            pass

        return out_filename, len(target_pages_0idx)

    async def pdf_watermark(
        self,
        input_path: Path,
        output_root: Path,
        text: str,
        position: str = "center",
        opacity: float = 0.2,
        color: str = "red",
        lang: str = "it",
    ) -> Tuple[str, int]:
        """Aggiunge un watermark testuale su tutte le pagine di un PDF.

        - `text`: stringa, max 50 char (cap protezione layout)
        - `position`: 'center' (diagonale -45°) | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'
        - `opacity`: 0.05-0.5 (sotto è invisibile, sopra copre il testo)
        - `color`: 'red' | 'gray' | 'black'

        Returns: (filename, pages_count).
        """
        from io import BytesIO
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.colors import Color

        if not text or not text.strip():
            raise ValueError("Watermark text cannot be empty")
        text = text.strip()[:50]
        if not 0.05 <= opacity <= 0.5:
            raise ValueError("opacity must be between 0.05 and 0.5")
        if position not in ("center", "top-left", "top-right", "bottom-left", "bottom-right"):
            raise ValueError(f"invalid position: {position}")

        color_map = {
            "red":   Color(0.86, 0.15, 0.15, alpha=opacity),
            "gray":  Color(0.40, 0.40, 0.40, alpha=opacity),
            "black": Color(0.10, 0.10, 0.10, alpha=opacity),
        }
        if color not in color_map:
            raise ValueError(f"invalid color: {color}")

        reader = pypdf.PdfReader(str(input_path))
        if reader.is_encrypted:
            try: reader.decrypt("")
            except Exception:
                raise ValueError("PDF is password-protected")

        # Genera un overlay PDF a singola pagina con il testo nella posizione richiesta.
        # Lo applicheremo a TUTTE le pagine del documento (anche quelle con dimensioni diverse:
        # pypdf gestirà lo stretch/posizionamento via merge_page).
        overlay_buf = BytesIO()
        page_w, page_h = A4  # default A4 — il merge si adatta alla pagina target
        c = canvas.Canvas(overlay_buf, pagesize=A4)
        c.setFillColor(color_map[color])

        if position == "center":
            c.saveState()
            c.translate(page_w / 2, page_h / 2)
            c.rotate(45)
            font_size = max(40, int(min(page_w, page_h) / max(8, len(text)) * 1.5))
            c.setFont("Helvetica-Bold", font_size)
            c.drawCentredString(0, 0, text)
            c.restoreState()
        else:
            font_size = 24
            c.setFont("Helvetica-Bold", font_size)
            margin = 40
            if position == "top-left":
                c.drawString(margin, page_h - margin - font_size, text)
            elif position == "top-right":
                c.drawRightString(page_w - margin, page_h - margin - font_size, text)
            elif position == "bottom-left":
                c.drawString(margin, margin, text)
            elif position == "bottom-right":
                c.drawRightString(page_w - margin, margin, text)
        c.save()
        overlay_buf.seek(0)
        overlay_reader = pypdf.PdfReader(overlay_buf)
        overlay_page = overlay_reader.pages[0]

        writer = pypdf.PdfWriter()
        for page in reader.pages:
            page.merge_page(overlay_page)
            writer.add_page(page)

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_stem = re.sub(r'[^\w\-]', '_', input_path.stem)[:60]
        # safe text for filename
        safe_text = re.sub(r'[^\w\-]', '_', text)[:20]
        out_filename = f"Watermark_{safe_text}_{safe_stem}.pdf"
        n = 2
        final_path = out_dir / out_filename
        while final_path.exists():
            out_filename = f"Watermark_{safe_text}_{safe_stem}_{n:02d}.pdf"
            final_path = out_dir / out_filename
            n += 1

        with open(final_path, "wb") as f:
            writer.write(f)

        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log("utility", "file_processed", processor="pdf_watermark",
                             text=text, position=position, color=color, opacity=opacity,
                             output_filename=out_filename, success=True,
                             **{f"input_{k}": v for k, v in file_metadata(input_path).items()})
        except Exception:
            pass

        return out_filename, len(reader.pages)

    # ─── PDF Redaction (pecette nere) ────────────────────────────────────
    # Riusa la pipeline Anonimyze (PII NER) per individuare le entità sensibili,
    # poi disegna rettangoli neri opachi sopra ogni occorrenza usando lo stesso
    # pattern reportlab → pypdf merge_page del watermark.
    # ATTENZIONE: overlay-only — il testo PII originale RESTA nello stream PDF.
    # Limitazione documentata e segnalata all'utente nell'UI.

    @staticmethod
    def _entity_to_rects(start: int, end: int, char_bboxes: List) -> List[Tuple[float, float, float, float]]:
        """Raggruppa i char [start..end) per riga (stessa Y) e ritorna rettangoli
        unione X per ogni riga. Gestisce span che attraversano line break.
        Coordinate in user space PDF (origine bottom-left).
        """
        if start >= end or not char_bboxes:
            return []
        span = [b for b in char_bboxes[start:end] if b is not None]
        if not span:
            return []

        # Group per linea: Y centro con tolerance 3pt.
        lines: List[List[Tuple[float, float, float, float]]] = []
        line_centers: List[float] = []
        TOL = 3.0
        for b in span:
            cy = (b[1] + b[3]) / 2.0
            placed = False
            for i, lc in enumerate(line_centers):
                if abs(cy - lc) <= TOL:
                    lines[i].append(b)
                    line_centers[i] = (lc * len(lines[i]) + cy) / (len(lines[i]) + 1)
                    placed = True
                    break
            if not placed:
                lines.append([b])
                line_centers.append(cy)

        rects: List[Tuple[float, float, float, float]] = []
        for line in lines:
            x_min = min(b[0] for b in line)
            x_max = max(b[2] for b in line)
            y_min = min(b[1] for b in line)
            y_max = max(b[3] for b in line)
            rects.append((x_min, y_min, x_max, y_max))
        return rects

    @staticmethod
    def _normalize_lang_for_redact(lang: Optional[str]) -> str:
        target = (lang or "it").lower()
        if target not in ("it", "en", "es", "fr", "de"):
            target = "it"
        return target

    @staticmethod
    def _filter_redact_entities(results: List[Any]) -> List[Any]:
        """Rimuove i risultati noti per generare troppi falsi positivi nella redaction.

        Esclusioni applicate:
        - PERSON con score < 0.6 → matcha il regex catch-all UPPERCASE di Anonimyze
          (intestazioni in MAIUSCOLO, articoli di legge, organizzazioni). In Anonimyze
          questi entrano poi nel dedupe LLM che pulisce, ma nella redaction non
          c'è LLM cleanup → finiamo per oscurare troppe cose.
        """
        return [r for r in results if not (
            getattr(r, "entity_type", "") == "PERSON" and getattr(r, "score", 0.0) < 0.6
        )]

    @staticmethod
    def _entity_signature(entity_type: str, text: str) -> str:
        """Hash stabile per identificare la stessa entità in occorrenze multiple.

        SHA-1 è usato qui SOLO come ID-hash deterministico (mappa testo→token
        per UI/redaction), non per crittografia o autenticazione. Le collisioni
        sono accettabili (al massimo due entità diverse riceverebbero lo stesso
        token in UI, danno cosmetico). Vedi `# nosec B324` sotto.
        """
        import hashlib
        norm = (text or "").strip().lower()
        h = hashlib.sha1(f"{entity_type}|{norm}".encode("utf-8", errors="ignore"), usedforsecurity=False).hexdigest()[:12]  # nosec B324
        return f"{entity_type[:4].lower()}_{h}"

    @staticmethod
    def _make_context(text: str, start: int, end: int, window: int = 25) -> str:
        """Estrae 25 char prima e dopo l'entità per disambiguare in UI."""
        if not text:
            return ""
        s = max(0, start - window)
        e = min(len(text), end + window)
        prefix = "…" if s > 0 else ""
        suffix = "…" if e < len(text) else ""
        snippet = text[s:start] + "«" + text[start:end] + "»" + text[end:e]
        snippet = re.sub(r"\s+", " ", snippet).strip()
        return f"{prefix}{snippet}{suffix}"

    async def _extract_pdf_entities(
        self, input_path: Path, lang: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Estrae le entità PII dal PDF + bbox per ogni occorrenza, RAGGRUPPATE
        per (type, normalized_text). Non scrive nulla: solo analyze.

        Returns: {
            pages: int,
            pages_with_text: int,
            pages_without_text: int,
            page_sizes: [(w, h), ...],
            entities: [
                {
                    id: str,
                    type: str,
                    text: str,
                    score: float,
                    occurrences: [
                        {page: int (1-based), rects: [[x0,y0,x1,y1], ...], context: str}
                    ]
                },
                ...
            ],
            warning: 'no_text_extractable' | 'partial_text' | None,
        }
        """
        import pypdfium2 as pdfium

        # 1. Apri PDF (per validazione + n_pages).
        reader = pypdf.PdfReader(str(input_path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:
                raise ValueError("PDF is password-protected")

        pdf = pdfium.PdfDocument(str(input_path))

        target_lang = self._normalize_lang_for_redact(lang)

        class _NullVault:
            def get_or_create(self, original, entity_type):
                return f"[{entity_type}]"

        from services.text_advanced_anonymizer import AdvancedTextAnonymizer
        try:
            anon = AdvancedTextAnonymizer(_NullVault(), language=target_lang)
            analyzer = anon._analyzer
        except Exception as e:
            pdf.close()
            raise RuntimeError(f"Anonimyze analyzer init failed: {e}")

        # Aggregazione per (type, normalized_text) → entity_id stabile.
        agg: Dict[str, Dict[str, Any]] = {}
        page_sizes: List[Tuple[float, float]] = []
        pages_with_text = 0
        pages_without_text = 0

        try:
            n_pages = len(pdf)
            for page_idx in range(n_pages):
                page = pdf[page_idx]
                try:
                    page_w, page_h = page.get_size()
                except Exception:
                    page_w, page_h = 612.0, 792.0
                page_sizes.append((page_w, page_h))

                tp = page.get_textpage()
                try:
                    try:
                        n_chars = tp.count_chars()
                    except Exception:
                        n_chars = 0

                    if n_chars <= 0:
                        pages_without_text += 1
                        continue

                    try:
                        page_text = tp.get_text_range(0, n_chars) or ""
                    except Exception:
                        page_text = ""

                    if page_text.strip():
                        pages_with_text += 1
                    else:
                        pages_without_text += 1
                        continue

                    char_bboxes: List[Optional[Tuple[float, float, float, float]]] = []
                    for i in range(min(n_chars, len(page_text))):
                        try:
                            char_bboxes.append(tp.get_charbox(i))
                        except Exception:
                            char_bboxes.append(None)
                finally:
                    try:
                        tp.close()
                    except Exception:
                        pass

                # Analyze.
                try:
                    raw = analyzer.analyze(
                        text=page_text, language=target_lang, score_threshold=0.4,
                    )
                except Exception as e:
                    logger.warning(f"PDF redact analyze failed on page {page_idx + 1}: {e}")
                    raw = []

                results = self._filter_redact_entities(raw)

                for r in results:
                    rects = self._entity_to_rects(r.start, r.end, char_bboxes)
                    if not rects:
                        continue
                    etype = getattr(r, "entity_type", "UNKNOWN")
                    text = page_text[r.start:r.end]
                    sig = self._entity_signature(etype, text)
                    ctx = self._make_context(page_text, r.start, r.end)
                    if sig not in agg:
                        agg[sig] = {
                            "id": sig,
                            "type": etype,
                            "text": text,
                            "score": float(getattr(r, "score", 0.0) or 0.0),
                            "occurrences": [],
                        }
                    else:
                        agg[sig]["score"] = max(agg[sig]["score"], float(getattr(r, "score", 0.0) or 0.0))
                    agg[sig]["occurrences"].append({
                        "page": page_idx + 1,  # 1-based per UI
                        "rects": [list(rc) for rc in rects],
                        "context": ctx,
                    })
        finally:
            try:
                pdf.close()
            except Exception:
                pass

        # Ordinamento: per tipo (alfabetico) poi per testo.
        entities = sorted(agg.values(), key=lambda e: (e["type"], e["text"].lower()))

        warning: Optional[str] = None
        if pages_with_text == 0:
            warning = "no_text_extractable"
        elif pages_without_text > 0:
            warning = "partial_text"

        return {
            "pages": len(reader.pages),
            "pages_with_text": pages_with_text,
            "pages_without_text": pages_without_text,
            "page_sizes": [list(s) for s in page_sizes],
            "entities": entities,
            "warning": warning,
        }

    async def _render_redacted_pdf(
        self,
        input_path: Path,
        output_root: Path,
        page_rects_map: Dict[int, List[Tuple[float, float, float, float]]],
        page_sizes: List[Tuple[float, float]],
        out_filename_prefix: str = "Redacted",
    ) -> Dict[str, Any]:
        """Genera il PDF con overlay rettangoli neri sulle bbox indicate.

        - `page_rects_map`: {page_idx_0based: [(x0,y0,x1,y1), ...]}
        - `page_sizes`: lista di (w, h) per ogni pagina del PDF originale.

        Returns: {filename, pages}.
        """
        from io import BytesIO
        from reportlab.pdfgen import canvas

        reader = pypdf.PdfReader(str(input_path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:
                raise ValueError("PDF is password-protected")

        writer = pypdf.PdfWriter()
        n_pages = len(reader.pages)
        for i in range(n_pages):
            page = reader.pages[i]
            rects = page_rects_map.get(i, [])
            if rects:
                page_w, page_h = page_sizes[i] if i < len(page_sizes) else (612.0, 792.0)
                buf = BytesIO()
                c = canvas.Canvas(buf, pagesize=(page_w, page_h))
                c.setFillColorRGB(0, 0, 0)
                c.setStrokeColorRGB(0, 0, 0)
                pad = 1.0
                for (x0, y0, x1, y1) in rects:
                    w = max(0.0, (x1 - x0)) + 2 * pad
                    h = max(0.0, (y1 - y0)) + 2 * pad
                    c.rect(x0 - pad, y0 - pad, w, h, stroke=0, fill=1)
                c.save()
                buf.seek(0)
                try:
                    overlay = pypdf.PdfReader(buf).pages[0]
                    page.merge_page(overlay)
                except Exception as e:
                    logger.warning(f"PDF redact merge_page failed on {i + 1}: {e}")
            writer.add_page(page)

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_stem = re.sub(r"[^\w\-]", "_", input_path.stem)[:60]
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        out_filename = f"{out_filename_prefix}_{safe_stem}_{timestamp}.pdf"
        final_path = out_dir / out_filename
        n = 2
        while final_path.exists():
            out_filename = f"{out_filename_prefix}_{safe_stem}_{timestamp}_{n:02d}.pdf"
            final_path = out_dir / out_filename
            n += 1
        with open(final_path, "wb") as f:
            writer.write(f)

        return {"filename": out_filename, "pages": n_pages}

    async def pdf_redact_analyze(
        self, input_path: Path, lang: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Step 1 del workflow Analyze→Review→Apply: solo analyze, niente apply.
        Returns: dict con `entities`, `pages`, `pages_with_text`, `pages_without_text`,
        `page_sizes`, `warning`. Da serializzare in JSON e cachare lato server con job_id.
        """
        return await self._extract_pdf_entities(input_path, lang=lang)

    async def pdf_redact_apply_selected(
        self,
        input_path: Path,
        output_root: Path,
        analysis: Dict[str, Any],
        selected_entity_ids: List[str],
    ) -> Dict[str, Any]:
        """Step 2 del workflow: applica pecette solo sulle entità selezionate.
        `analysis` è il dict ritornato da `pdf_redact_analyze`.
        Returns: {filename, pages, entities_count, by_type}.
        """
        selected = set(selected_entity_ids or [])
        page_rects_map: Dict[int, List[Tuple[float, float, float, float]]] = {}
        by_type: Dict[str, int] = {}
        applied_count = 0

        for ent in analysis.get("entities", []):
            if ent["id"] not in selected:
                continue
            applied_count += 1
            etype = ent.get("type", "UNKNOWN")
            by_type[etype] = by_type.get(etype, 0) + 1
            for occ in ent.get("occurrences", []):
                page_idx = max(0, int(occ.get("page", 1)) - 1)
                rects_raw = occ.get("rects") or []
                rects: List[Tuple[float, float, float, float]] = [tuple(r) for r in rects_raw if len(r) == 4]
                if rects:
                    page_rects_map.setdefault(page_idx, []).extend(rects)

        page_sizes_raw = analysis.get("page_sizes") or []
        page_sizes: List[Tuple[float, float]] = [tuple(s) for s in page_sizes_raw if len(s) == 2]

        result = await self._render_redacted_pdf(
            input_path=input_path,
            output_root=output_root,
            page_rects_map=page_rects_map,
            page_sizes=page_sizes,
        )

        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="pdf_redact_apply",
                output_filename=result["filename"],
                entities_count=applied_count,
                by_type=by_type,
                success=True,
                **{f"input_{k}": v for k, v in file_metadata(input_path).items()},
            )
        except Exception:
            pass

        return {
            "filename": result["filename"],
            "pages": result["pages"],
            "entities_count": applied_count,
            "by_type": by_type,
        }

    async def pdf_redact(
        self,
        input_path: Path,
        output_root: Path,
        lang: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Modalità "rapida" 1-click: analyze + apply su TUTTE le entità rilevate.
        Mantenuta per backward compat dell'endpoint legacy `/utility/pdf-redact`.
        Returns: dict { filename, pages, entities_count, by_type, warning, ...}.
        """
        analysis = await self._extract_pdf_entities(input_path, lang=lang)
        all_ids = [e["id"] for e in analysis.get("entities", [])]
        result = await self.pdf_redact_apply_selected(
            input_path=input_path,
            output_root=output_root,
            analysis=analysis,
            selected_entity_ids=all_ids,
        )
        return {
            **result,
            "pages_with_text": analysis.get("pages_with_text", 0),
            "pages_without_text": analysis.get("pages_without_text", 0),
            "warning": analysis.get("warning"),
        }

    async def images_to_pdf(
        self,
        input_paths: List[Path],
        output_root: Path,
        output_name: Optional[str] = None,
        lang: str = "it",
    ) -> Tuple[str, int, List[str]]:
        """Combina N immagini in un singolo PDF, una pagina per immagine.

        - L'ordine di `input_paths` = ordine pagine.
        - File non-immagini o corrotti vengono saltati e segnalati in `skipped`.
        - Ogni immagine viene convertita in RGB (flatten alpha su bianco).

        Returns: (filename, pages_count, skipped_filenames).
        """
        from io import BytesIO

        if not input_paths:
            raise ValueError("No input images provided")

        valid_imgs = []
        skipped: List[str] = []
        for p in input_paths:
            try:
                img = Image.open(p)
                # Flatten alpha → RGB su bianco (PDF non supporta alpha sui formati comuni)
                if img.mode in ("RGBA", "LA"):
                    bg = Image.new("RGB", img.size, (255, 255, 255))
                    bg.paste(img, mask=img.split()[-1])
                    img = bg
                elif img.mode != "RGB":
                    img = img.convert("RGB")
                valid_imgs.append((p.name, img))
            except Exception as e:
                skipped.append(p.name)
                logger.warning(f"images_to_pdf: skipping {p.name}: {e}")

        if not valid_imgs:
            raise ValueError("No valid images to combine")

        out_dir = output_root / "PDF_TOOLKIT"
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        if output_name and output_name.strip():
            safe_stem = re.sub(r'[^\w\-]', '_', Path(output_name).stem)[:60]
        else:
            safe_stem = f"Images_{ts}"
        out_filename = f"{safe_stem}.pdf"
        n = 2
        final_path = out_dir / out_filename
        while final_path.exists():
            out_filename = f"{safe_stem}_{n:02d}.pdf"
            final_path = out_dir / out_filename
            n += 1

        first_img = valid_imgs[0][1]
        rest_imgs = [img for _, img in valid_imgs[1:]]
        first_img.save(
            str(final_path),
            "PDF",
            save_all=True,
            append_images=rest_imgs,
            resolution=150,
        )

        try:
            from services.audit_service import audit_logger
            audit_logger.log("utility", "file_processed", processor="images_to_pdf",
                             input_files_count=len(input_paths), pages=len(valid_imgs),
                             skipped_count=len(skipped), output_filename=out_filename, success=True)
        except Exception:
            pass

        return out_filename, len(valid_imgs), skipped

    async def pdf_to_images(
        self,
        input_path: Path,
        output_root: Path,
        image_format: str = "png",
        dpi: int = 150,
        lang: str = "it",
    ) -> Tuple[str, List[str]]:
        """Esporta ogni pagina del PDF come immagine.

        - `image_format`: 'png' | 'jpg'
        - `dpi`: 72 (low) / 150 (medium, default) / 300 (high)

        Returns: (subfolder_name, [filenames]).
        """
        import pypdfium2 as pdfium

        image_format = image_format.lower()
        if image_format not in ("png", "jpg", "jpeg"):
            raise ValueError(f"Unsupported image format: {image_format}")
        if image_format == "jpeg":
            image_format = "jpg"
        if dpi not in (72, 150, 300):
            raise ValueError(f"dpi must be 72/150/300, got {dpi}")

        # Subfolder dedicata per il batch (ogni pagina diventa un file)
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        safe_stem = re.sub(r'[^\w\-]', '_', input_path.stem)[:60]
        subfolder_name = f"PDF_TOOLKIT_PAGES_{ts}_{safe_stem}"
        out_dir = output_root / subfolder_name
        out_dir.mkdir(parents=True, exist_ok=True)

        pdf = pdfium.PdfDocument(str(input_path))
        try:
            total = len(pdf)
            digits = max(2, len(str(total)))
            # pypdfium2 usa "scale" relativo a 72dpi: scale=dpi/72
            scale = dpi / 72.0
            generated: List[str] = []
            for idx, page in enumerate(pdf, start=1):
                bitmap = page.render(scale=scale)
                pil_img = bitmap.to_pil()
                if image_format == "jpg" and pil_img.mode != "RGB":
                    pil_img = pil_img.convert("RGB")
                fmt_pil = "JPEG" if image_format == "jpg" else "PNG"
                fname = f"{safe_stem}_pagina_{str(idx).zfill(digits)}.{image_format}"
                save_kwargs = {"optimize": True}
                if fmt_pil == "JPEG":
                    save_kwargs["quality"] = 90
                pil_img.save(out_dir / fname, format=fmt_pil, **save_kwargs)
                generated.append(fname)
        finally:
            pdf.close()

        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log("utility", "file_processed", processor="pdf_to_images",
                             format=image_format, dpi=dpi, pages=len(generated),
                             output_subfolder=subfolder_name, success=True,
                             **{f"input_{k}": v for k, v in file_metadata(input_path).items()})
        except Exception:
            pass

        return subfolder_name, generated
