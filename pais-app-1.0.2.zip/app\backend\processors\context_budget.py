"""
Dynamic Context Budget Calculator
Stima il num_ctx ottimale per ogni richiesta Ollama.

Approccio: char/3.5 + budgeting + arrotondamento a potenza di 2
- char/3.5: stima più accurata per lingue latine/inglese
- Budget: sistema + contesto RAG + risposta stimata + margine sicurezza
- Arrotondamento a multiplo di 2048 (preferito da Ollama per KV cache alignment)
- Clamp: min 4096, max modello-specifico
"""
from typing import List, Dict, Optional


def estimate_token_count(text: str) -> int:
    """
    Stima il numero di token da una stringa.
    Usa char/3.5 come approssimazione (più accurata di char/4 per latino/inglese).
    """
    if not text:
        return 0
    return max(1, int(len(text) / 3.5))


def calculate_dynamic_ctx(
    messages: List[Dict[str, str]],
    estimated_response_tokens: int = 4096,
    max_ctx: int = 131072,
    min_ctx: int = 4096,
    rounding: int = 2048
) -> int:
    """
    Calcola il num_ctx minimo necessario per una richiesta.

    Args:
        messages: Lista di messaggi (system, user, assistant)
        estimated_response_tokens: Token stimati per la risposta del modello
        max_ctx: Contesto massimo consentito (default: 128K)
        min_ctx: Contesto minimo garantito (default: 4K)
        rounding: Multipli di arrotondamento (default: 2048)

    Returns:
        num_ctx ottimizzato per la richiesta corrente
    """
    if not messages:
        return min_ctx

    # 1. Conta token del prompt
    total_chars = sum(len(m.get('content', '')) for m in messages)
    prompt_tokens = estimate_token_count('\n\n'.join(m.get('content', '') for m in messages))

    # 2. Budget: prompt + risposta stimata + safety margin (2048 token)
    safety_margin = 2048
    needed_ctx = prompt_tokens + estimated_response_tokens + safety_margin

    # 3. Arrotonda al multiplo di `rounding` più vicino (per allineamento KV cache)
    dynamic_ctx = ((needed_ctx + rounding - 1) // rounding) * rounding

    # 4. Clamp tra min e max
    result = max(min_ctx, min(dynamic_ctx, max_ctx))

    return result


def calculate_ctx_from_context(context_text: str, query: str, estimated_response: int = 4096, max_ctx: int = 131072) -> int:
    """
    Versione semplificata per RAG: calcola ctx da contesto RAG + query.
    Utile quando non si ha la lista completa dei messaggi.

    Args:
        context_text: Testo del contesto RAG
        query: Domanda dell'utente
        estimated_response: Token stimati per la risposta
        max_ctx: Contesto massimo
    """
    # Costruisci messaggio minimale per la stima
    messages = [
        {"role": "system", "content": f"Context:\n{context_text}"},
        {"role": "user", "content": query}
    ]
    return calculate_dynamic_ctx(messages, estimated_response, max_ctx)
