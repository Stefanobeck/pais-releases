"""One-shot driver: load stress_test_input.xlsx, run a single prompt against
MANIPULATE SHEET, save the result + the SQL retry log."""
from __future__ import annotations
import asyncio, json, logging, re, shutil, sys, time, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass


_SQL_FAIL_RX = re.compile(r"^SQL Execution failed \(Attempt (\d+)\): (.+)$", re.DOTALL)
_SOFT_FAIL_RX = re.compile(r"^Soft Validation failed \(Attempt (\d+)\): (.+)$", re.DOTALL)


class Capture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.entries = []

    def emit(self, rec):
        try: m = rec.getMessage()
        except Exception: return
        x = _SQL_FAIL_RX.match(m) or _SOFT_FAIL_RX.match(m)
        if x:
            self.entries.append({"attempt": int(x.group(1)),
                                 "kind": "sql" if m.startswith("SQL") else "soft",
                                 "error": x.group(2).strip()})


async def run(input_path: str, prompt: str, out_dir: Path) -> dict:
    from services.manipulate_service import ManipulateService
    out_dir.mkdir(parents=True, exist_ok=True)

    manipulate = ManipulateService()
    session_id = f"stress-{uuid.uuid4().hex[:8]}"
    fname = Path(input_path).name

    print(f"model:    {manipulate.models.get('manipulate_model','?')}", flush=True)
    print(f"session:  {session_id}", flush=True)
    print(f"prompt:   {prompt[:120]}…", flush=True)

    up = await manipulate.upload_file(input_path, fname, session_id, mode="Export to Sheet")
    if up.get("status") not in ("staged", "success"):
        return {"error": f"upload failed: {up}"}
    mem = await manipulate.memorize_files(session_id, mode="Export to Sheet")
    if mem.get("status") != "success":
        return {"error": f"memorize failed: {mem}"}
    print(f"tables loaded: {list(manipulate.data_processor.dfs.keys())}", flush=True)

    cap = Capture()
    logging.getLogger("services.manipulate_service").addHandler(cap)

    t0 = time.time()
    produced = None; final_msg = None
    try:
        async for ok, msg, files in manipulate.analyze(
            query=prompt, session_id=session_id, mode="Export to Sheet"
        ):
            final_msg = msg
            if files: produced = files[0]
    finally:
        logging.getLogger("services.manipulate_service").removeHandler(cap)

    elapsed = round(time.time() - t0, 2)
    res = {"elapsed_s": elapsed, "retries": cap.entries, "final_msg": (final_msg or "")[:600]}

    if produced:
        # copy from PAIS output (styler writes there, not BASE_DIR/exports)
        srcs = [Path(produced)]
        try:
            root = Path.home() / "Documents" / "PAI_Files"
            if root.exists():
                srcs.extend(root.rglob(Path(produced).name))
        except Exception: pass
        for c in srcs:
            if c.exists():
                target = out_dir / "result.xlsx"
                shutil.copy2(c, target)
                res["output"] = str(target)
                break

    try: manipulate.clear_session(session_id)
    except Exception: pass

    (out_dir / "run.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    return res


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--prompt", required=True)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    r = asyncio.run(run(a.input, a.prompt, Path(a.output)))
    print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
