"""
Chat Service - Business Logic per modulo INTERROGATE
Gestisce:
- Conversazioni con AI (streaming)
- RAG (Retrieval-Augmented Generation)
- Smart File Reference Detection
- Persistenza cronologia
- Multilingua
"""
import os
import re
import json
import asyncio
import uuid
from typing import List, Dict, Optional, Callable, AsyncGenerator, Tuple
from pathlib import Path
import logging

from processors.ollama_client import OllamaClient, AUTO_CTX
from processors.document_processor import DocumentProcessor
from services.rag_service import RAGService
from services.reranker_service import BGEReranker
from services.loading_messages import LoadingMessagesService
from services.audit_service import audit_logger, file_metadata
from backend_config import settings

logger = logging.getLogger(__name__)


class ChatService:
    """
    Servizio principale per chat con contesto RAG.
    """

    def __init__(self, persist_directory: Optional[str] = None):
        self.ollama = OllamaClient()
        self.doc_processor = DocumentProcessor(
            collection_name="pai_chat",
            persist_directory=persist_directory,
            lang="it"
        )
        self.sessions: Dict[str, List[Dict]] = {}
        self.uploaded_files: Dict[str, List[Dict]] = {}  # session_id -> files
        self.lang = "it"
        self._chroma_path = persist_directory  # Per change detection

        # Reranker BGE per fase 2
        self.reranker = BGEReranker(model="bbjson/bge-reranker-base:latest", host=settings.OLLAMA_HOST_URL)

        # Carica prompt
        self.prompts = self._load_prompts()
    
    def _load_prompts(self) -> Dict:
        """Carica prompt da configurazione."""
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_chat.json"
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(self.lang, data.get('it', {}))
        except:
            return self._get_default_prompts()
    
    def _get_default_prompts(self) -> Dict:
        """Prompt di default."""
        return {
            "rag": {
                "system_prompt": "You are PAI - Private Artificial Intelligence Suite.",
                "user_prompt_template": "CONTEXT:\n{context_text}\n\nQUESTION:\n{user_message}",
                "file_list_injection": "\n\nAVAILABLE FILES: {list_str}",
                "no_files_context": "No files uploaded."
            }
        }
    
    def _load_prompts_for_lang(self, lang: str) -> Dict:
        """Carica prompt per una lingua specifica (senza modificare self.lang)."""
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_chat.json"
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(lang, data.get('it', {}))
        except:
            return self._get_default_prompts()

    async def generate_suggestions(self, profile_id: str, profile_name: str, documents: List[str], lang: str, session_id: str = "") -> List[str]:
        """
        Genera 4 suggerimenti contestuali.
        Il modello riceve:
          - system: il FULL system prompt del profilo attivo in INGLESE (sempre),
                    + "(reply in this language: <lang>)" finale — stesso pattern usato in tutta l'app
          - user:   task_instruction EN + estratto reale dei documenti
        """
        import re as _re

        # Sempre EN per il reasoning del modello — lingua dell'output controllata dal suffix
        en_prompts = self._load_prompts_for_lang('en')
        sugg_config = en_prompts.get('rag', {}).get('interrogate_suggestions', {})
        model = sugg_config.get('model', 'gemma4:e4b')
        task_instruction = sugg_config.get('task_instruction', '')
        # Focus specifico per profilo — orienta il tipo di suggestions verso l'angolazione giusta
        # (es. creative_writer → temi/simboli/personaggi, NON analisi linguistica forense)
        profile_focus = sugg_config.get('profile_focus', {}).get(profile_id, '')

        # System message = full EN profile prompt con {files_list} sostituito — identico al chat normale
        all_profiles = en_prompts.get('rag', {}).get('profiles', {})
        # Custom profile resolution
        if profile_id.startswith('custom_'):
            try:
                from services.custom_profiles_service import custom_profiles_service
                cp = custom_profiles_service.get_profile(profile_id)
                profile_system = cp.get('system_prompt') if cp else all_profiles.get('default', '')
            except Exception:
                profile_system = all_profiles.get('default', '')
        else:
            profile_system = all_profiles.get(profile_id, all_profiles.get('default', ''))

        # Costruisce il CURRENT INVENTORY con i ref reali (F1, F2...) come fa la chat normale
        files_list_item = en_prompts.get('rag', {}).get('files_list_item', '- [{ref_id}] {filename}')
        if documents:
            # Prova a recuperare i ref reali dalla sessione; fallback a F1, F2...
            session_files = self.uploaded_files.get(session_id, []) if session_id else []
            ref_map = {f['name']: f.get('ref', f'F{i+1}') for i, f in enumerate(session_files)}
            inventory_lines = []
            for i, fname in enumerate(documents):
                ref = ref_map.get(fname, f'F{i+1}')
                inventory_lines.append(files_list_item.replace('{ref_id}', ref).replace('{filename}', fname))
            files_list_str = '\n'.join(inventory_lines)
        else:
            files_list_str = '(no files)'
        profile_system = profile_system.replace('{files_list}', files_list_str)

        # Aggiungi istruzione lingua — stesso pattern dell'app (chat_service send_message, manipulate_service)
        lang_map = {'it': 'italian', 'en': 'english', 'es': 'spanish', 'fr': 'french', 'de': 'german'}
        target_lang = lang_map.get(lang.lower(), 'english')
        profile_system += f"\n\n(reply in this language: {target_lang})"

        # Recupera contenuto reale dei documenti via ChromaDB.get() — nessun embedding necessario,
        # recupero diretto per source filter: affidabile anche se Ollama è occupato.
        # NESSUN limit: vogliamo TUTTI i chunk, poi facciamo sampling distribuito
        # (inizio + metà + fine) così il modello vede l'intero arco del documento.
        doc_context = ""
        if documents:
            try:
                from collections import defaultdict as _dd
                where_filter = {"source": {"$in": documents}} if len(documents) > 1 else {"source": documents[0]}
                raw = self.doc_processor.collection.get(where=where_filter)
                all_chunks   = raw.get('documents') or []
                all_metas    = raw.get('metadatas')  or [{}] * len(all_chunks)
                logger.info(f"[SUGGESTIONS] ChromaDB.get() → {len(all_chunks)} chunks totali per {documents}")

                # Raggruppa per file (preservando l'ordine di inserimento = ordine pagine)
                src_map: dict = _dd(list)
                for txt, meta in zip(all_chunks, all_metas):
                    src = (meta or {}).get('source', '')
                    src_map[src].append(txt)

                MAX_PER_FILE = 10   # chunk per file
                MAX_TOTAL    = 25   # chunk totali inviati al modello
                MAX_CHARS    = 1500 # caratteri per chunk

                selected = []
                for src, src_chunks in src_map.items():
                    if len(selected) >= MAX_TOTAL:
                        break
                    n = len(src_chunks)
                    if n <= MAX_PER_FILE:
                        picks = src_chunks
                    else:
                        # Sampling distribuito: indici equidistanti su tutta la lunghezza
                        step = n / MAX_PER_FILE
                        picks = [src_chunks[int(i * step)] for i in range(MAX_PER_FILE)]
                    for txt in picks:
                        selected.append(txt[:MAX_CHARS])
                        if len(selected) >= MAX_TOTAL:
                            break

                doc_context = "\n---\n".join(selected)
                logger.info(f"[SUGGESTIONS] Selezionati {len(selected)} chunk distribuiti → {len(doc_context)} chars")
            except Exception as e:
                logger.warning(f"[SUGGESTIONS] ChromaDB.get() failed: {e}")

        # User message sempre in inglese — la lingua dell'output è già nel system prompt
        docs_str = ", ".join(documents) if documents else "no documents attached"

        if profile_focus:
            # profile_focus SOSTITUISCE completamente task_instruction.
            # In questo modo il modello non vede mai la GROUNDING RULE generica che confligge.
            # L'ancoraggio al contenuto è soft: temi/personaggi/eventi reali, NON frasi verbatim.
            user_msg = (
                f"Attached documents: {docs_str}\n\n"
                f"{profile_focus}\n\n"
                "CONTENT ANCHORING: Each suggestion MUST be specific to the actual content you read below "
                "— reference the real topics, characters, events, or themes of the document. "
                "Do NOT use generic placeholders like 'the text' or 'the main concept'. "
                "Name what the document is actually about.\n\n"
                "Reply ONLY with a JSON array of exactly 4 strings, no extra text.\n"
                'Format: ["...", "...", "...", "..."]'
            )
        elif task_instruction:
            user_msg = task_instruction.replace('{documents_list}', docs_str)
            # Inject role-specific preamble so small models don't fall back to generic analysis.
            if profile_name and profile_id != '':
                role_header = (
                    f"ROLE CONTEXT: You are currently operating as \"{profile_name}\".\n"
                    f"Your 4 suggestions MUST be things that ONLY a {profile_name} would suggest — "
                    f"use your role's specific output formats, vocabulary and analytical focus. "
                    f"Do NOT produce generic 'analyze/summarize the document' suggestions.\n\n"
                )
                user_msg = role_header + user_msg
        else:
            # Fallback inline se chiave mancante nel JSON — sempre EN
            user_msg = (
                f"Attached documents: {docs_str}\n\n"
                "Read the document content below. Then, fully embodying your role, generate exactly 4 "
                "requests or questions that A USER should ask you to get the most out of your specific "
                "capabilities on these documents. The suggestions must be consistent with your role (not generic), "
                "specific to the content you read, and immediately usable without modification (max 20 words each).\n"
                "Reply ONLY with a JSON array of 4 strings, no extra text.\n"
                'Format: ["...", "...", "...", "..."]'
            )

        if doc_context:
            user_msg += f"\n\nDocument content excerpt:\n{doc_context}"

        # Rinforza la lingua anche nel messaggio utente — alcuni modelli seguono la lingua
        # del turno user ignorando il suffix nel system prompt
        user_msg += f"\n\n(reply in this language: {target_lang})"

        logger.info("=" * 60)
        logger.info(f"[SUGGESTIONS] model={model}  profile={profile_id}  ctx={len(doc_context)}chars")
        logger.info(f"[SUGGESTIONS] SYSTEM (first 300):\n{profile_system[:300]}")
        logger.info(f"[SUGGESTIONS] USER   (first 500):\n{user_msg[:500]}")
        logger.info("=" * 60)

        try:
            text = await self.ollama.chat(
                model=model,
                messages=[
                    {"role": "system", "content": profile_system},
                    {"role": "user",   "content": user_msg}
                ],
                num_ctx=AUTO_CTX,
                max_ctx=settings.SUGGESTION_CTX,
                temperature=0.7
            )
            logger.info(f"[SUGGESTIONS] RESPONSE:\n{text}")
            logger.info("=" * 60)
            # Parse JSON array
            match = _re.search(r'\[[\s\S]*?\]', text)
            if match:
                try:
                    parsed = json.loads(match.group(0))
                    result = [s.strip() for s in parsed if isinstance(s, str) and len(s.strip()) > 5]
                    if result:
                        return result[:4]
                except json.JSONDecodeError:
                    pass
            # Fallback: righe non vuote senza numerazione
            lines = []
            for l in text.strip().split('\n'):
                l = l.strip().lstrip('0123456789.-) ').strip('"').strip("'").strip()
                if len(l) > 10:
                    lines.append(l)
            return lines[:4]
        except Exception as e:
            logger.error(f"generate_suggestions error: {e}")
            return []

    def set_language(self, lang: str):
        """Cambia lingua."""
        self.lang = lang
        self.prompts = self._load_prompts()
        self.doc_processor.set_language(lang)
        
        # Aggiorna anche il servizio i18n globale per messaggi di sistema tradotti
        from services.i18n_service import i18n
        i18n.set_language(lang)
    
    def _get_or_create_session(self, session_id: str) -> List[Dict]:
        """Ottiene o crea sessione."""
        if session_id not in self.sessions:
            self.sessions[session_id] = []
            self.uploaded_files[session_id] = []
            
            # Carica da file se esiste
            session_file = self._get_session_file(session_id)
            if session_file.exists():
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        self.sessions[session_id] = data.get('history', [])
                        self.uploaded_files[session_id] = data.get('files', [])
                        logger.info(f"Session {session_id} loaded from disk")
                except Exception as e:
                    logger.error(f"Error loading session {session_id}: {e}")
        
        return self.sessions[session_id]
    
    def _get_session_file(self, session_id: str) -> Path:
        """Ottiene path file sessione all'interno del progetto attivo (Legacy alignment)."""
        from backend_config.project_manager import project_manager
        
        # Se c'è un progetto attivo, salva lì. Altrimenti usa cartella temp.
        if project_manager.active_project_path:
            sessions_dir = project_manager.active_project_path / "sessions"
        else:
            sessions_dir = settings.BASE_DIR / "temp" / "chat_sessions"
            
        sessions_dir.mkdir(parents=True, exist_ok=True)
        # Usa un nome file standardizzato per il modulo chat
        return sessions_dir / f"chat_state_{session_id}.json"
    
    def _save_session(self, session_id: str):
        """Salva sessione su file."""
        session_file = self._get_session_file(session_id)
        
        data = {
            'history': self.sessions.get(session_id, []),
            'files': self.uploaded_files.get(session_id, []),
            'lang': self.lang
        }
        
        try:
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving session {session_id}: {e}")
    
    async def upload_file(self, file_path: str, filename: str, session_id: str, is_generated: bool = False) -> Dict:
        """
        Carica e indicizza un file.

        Args:
            file_path: Percorso completo file
            filename: Nome file
            session_id: ID sessione
            is_generated: True se il TXT è stato generato dall'app (Grab Link, OCR PDF/DOCX);
                          abilita l'icona "occhio" nel sidebar e l'endpoint di view sicuro.

        Returns:
            Dict con status e messaggio
        """
        try:
            # Inizializza sessione se nuova
            self._get_or_create_session(session_id)

            # Usa un ref provvisorio per l'indicizzazione — verrà ricalcolato dopo ingest
            provisional_ref = f"F{len(self.uploaded_files[session_id]) + 1}"

            # Indicizza (può durare minuti — la connessione HTTP potrebbe essere stata abortita)
            success, message = await self.doc_processor.ingest_file(file_path, filename, ref_id=provisional_ref)

            if success:
                # GUARD 1 — file cancellato durante l'embedding (abort dell'utente):
                # se il file non è più su disco, l'utente ha annullato → scarta il risultato
                if not Path(file_path).exists():
                    logger.warning(f"⚠️ Upload ghost discarded: {filename} was deleted during embedding (user abort)")
                    return {"status": "error", "message": "Upload cancelled during processing"}

                # GUARD 2 — dedup: stesso file già registrato (doppio upload in race condition)
                already = any(f['name'] == filename for f in self.uploaded_files[session_id])
                if already:
                    logger.warning(f"⚠️ Duplicate upload discarded: {filename} already in session")
                    return {"status": "error", "message": "Duplicate file, already registered"}

                # Ricalcola il ref ADESSO con lo stato corrente della sessione (altri file
                # potrebbero essere stati aggiunti o rimossi durante il lungo ingest)
                file_ref = f"F{len(self.uploaded_files[session_id]) + 1}"

                # Registra file
                self.uploaded_files[session_id].append({
                    "name": filename,
                    "path": file_path,
                    "ref": file_ref,
                    "type": "document",
                    "is_generated": bool(is_generated)
                })
                
                # --- AGGIUNTA MESSAGGIO IN CHAT (Feature richiesta dall'utente) ---
                from .i18n_service import i18n
                # Recupera la stringa tradotta o usa fallback
                msg_template = i18n.get('chat.file_memorized', "Ho memorizzato il file allegato. Ecco l'elenco aggiornato:\n\n{file_list}")
                
                # Crea la lista formattata come nel frontend
                files_list_formatted = "\n".join([f"- [{f.get('ref', 'F')}] **{f['name']}**" for f in self.uploaded_files[session_id]])
                
                final_msg = msg_template.replace('{file_list}', files_list_formatted)
                
                # Aggiungi il messaggio alla history come se fosse l'AI
                self.sessions[session_id].append({
                    "role": "assistant",
                    "content": final_msg
                })

                # Salva sessione
                self._save_session(session_id)

                logger.info(f"✅ File uploaded: {filename} ({message})")
                logger.info(f"📎 File ref: {file_ref}, Session files count: {len(self.uploaded_files[session_id])}")
                # Audit trail (forward-only event log)
                audit_logger.log(
                    "interrogate", "file_uploaded",
                    session_id=session_id,
                    is_generated=bool(is_generated),
                    ref=file_ref,
                    **file_metadata(file_path),
                )
                # Numero immagini embedded (solo PDF) → il client offre l'arricchimento
                # OCR opt-in di tabelle/figure. 0 per tutti gli altri formati.
                images_count = getattr(self.doc_processor, "_last_pdf_image_count", 0) or 0
                return {"status": "success", "message": message, "ref": file_ref, "chat_message": final_msg, "is_generated": bool(is_generated), "filename": filename, "images_count": images_count}
            else:
                logger.warning(f"File upload failed: {filename} - {message}")
                return {"status": "error", "message": message}

        except Exception as e:
            logger.error(f"Error uploading file {filename}: {e}")
            return {"status": "error", "message": str(e)}
    
    def remove_file(self, filename: str, session_id: str):
        """Rimuove file dalla sessione."""
        # CRITICAL: load session from disk FIRST — if the service was just recreated
        # (after _reset_all_services), self.uploaded_files is empty and the old guard
        # would early-return without doing anything.
        self._get_or_create_session(session_id)

        if session_id not in self.uploaded_files:
            # Session still empty after load attempt → treat as orphan-only deletion
            self.uploaded_files[session_id] = []

        # Recupera path fisico PRIMA di rimuovere dalla lista
        file_info = next((f for f in self.uploaded_files[session_id] if f['name'] == filename), None)

        # Rimuovi da ChromaDB
        self.doc_processor.delete_file_from_db(filename)

        # Rimuovi da lista in memoria
        self.uploaded_files[session_id] = [
            f for f in self.uploaded_files[session_id]
            if f['name'] != filename
        ]

        # Cancella file fisico dal disco (evita che auto-sync lo re-inserisca)
        if file_info:
            try:
                file_path = Path(file_info.get('path', ''))
                if file_path.exists():
                    file_path.unlink()
                    logger.info(f"🗑️ Deleted physical file from disk: {filename}")
            except Exception as e:
                logger.warning(f"Failed to delete physical file {filename}: {e}")
        else:
            # File orfano: upload fallito → non era in sessione ma il file fisico
            # potrebbe essere rimasto su disco. Cerca direttamente nella cartella uploads.
            try:
                from backend_config.project_manager import project_manager
                if project_manager.active_project_path:
                    orphan_path = project_manager.get_path("uploads") / "interrogate" / filename
                    if orphan_path.exists():
                        orphan_path.unlink()
                        logger.info(f"🗑️ Deleted orphaned file from disk: {filename}")
            except Exception as e:
                logger.warning(f"Failed to delete orphaned file {filename}: {e}")

        # Salva sessione aggiornata su disco
        self._save_session(session_id)

        # --- MESSAGGIO IN CHAT con elenco aggiornato ---
        from .i18n_service import i18n
        remaining = self.uploaded_files.get(session_id, [])
        if remaining:
            files_list_formatted = "\n".join(
                [f"- [{f.get('ref', 'F?')}] **{f['name']}**" for f in remaining]
            )
            chat_msg = (
                i18n.get('chat.file_removed', "Ho rimosso **{filename}** dalla sessione. Documenti attivi ({count}):\n\n{file_list}")
                .replace('{filename}', filename)
                .replace('{count}', str(len(remaining)))
                .replace('{file_list}', files_list_formatted)
            )
        else:
            chat_msg = i18n.get('chat.file_removed_all', "Tutti i documenti sono stati rimossi. La sessione è vuota.")

        # Aggiungi alla history come messaggio assistant
        if session_id in self.sessions:
            self.sessions[session_id].append({"role": "assistant", "content": chat_msg})
            self._save_session(session_id)

        logger.info(f"✅ File removed: {filename} — memory, ChromaDB, disk")
        # Audit trail: right-to-be-forgotten trace
        audit_logger.log("interrogate", "file_deleted", session_id=session_id, filename=filename)
        return {"status": "success", "chat_message": chat_msg}

    def clear_history(self, session_id: str):
        """Svuota la *cronologia conversazionale* della sessione, mantenendo
        i file caricati e l'indice ChromaDB.

        Casi d'uso:
        - Cambio profilo: il nuovo system prompt non funziona se le risposte
          vecchie restano in contesto (il modello mima lo stile della
          history). Azzerare la history forza un fresh start senza perdere
          i documenti uploadati né dover re-indicizzare.
        - Reset rapido di una conversazione lunga senza perdere il setup.

        Differisce da `clear_session()` che invece elimina anche file fisici,
        uploaded_files state e ChromaDB.
        """
        if session_id in self.sessions:
            self.sessions[session_id] = []
        # Aggiorna il file su disco mantenendo la struttura ma con history vuota.
        # Se la sessione non era ancora persistita, il save crea il file vuoto
        # in modo coerente.
        if session_id in self.sessions or session_id in self.uploaded_files:
            self._save_session(session_id)
        logger.info(f"Session history cleared (files preserved): {session_id}")
        try:
            audit_logger.log(
                "interrogate", "history_cleared",
                session_id=session_id,
                reason="profile_switch_or_user_request",
            )
        except Exception:
            pass

    def clear_session(self, session_id: str):
        """Cancella sessione fisica e logica."""
        # Snapshot dei file da cancellare per audit BEFORE deletion
        files_about_to_delete = [f.get('name', '') for f in self.uploaded_files.get(session_id, [])]

        if session_id in self.sessions:
            del self.sessions[session_id]
        if session_id in self.uploaded_files:
            # FIX: Cancella fisicamente i file uploadati dalla cartella uploads
            for f in self.uploaded_files[session_id]:
                try:
                    file_path = Path(f.get('path', ''))
                    if file_path.exists():
                        file_path.unlink()
                        logger.info(f"🗑️ Deleted physical file: {f['name']}")
                except Exception as e:
                    logger.warning(f"Failed to delete file {f.get('name')}: {e}")
            del self.uploaded_files[session_id]

        # Reset ChromaDB
        self.doc_processor.reset_database()

        # Elimina file sessione
        session_file = self._get_session_file(session_id)
        if session_file.exists():
            session_file.unlink()

        logger.info(f"Session cleared: {session_id}")
        # Audit trail: right-to-be-forgotten trace
        audit_logger.log(
            "interrogate", "session_cleared",
            session_id=session_id,
            files_deleted_count=len(files_about_to_delete),
            files_deleted=files_about_to_delete,
        )
    
    async def send_message(
        self,
        message: str,
        session_id: str,
        use_rag: bool = True,
        stop_check_callback: Optional[Callable[[], bool]] = None,
        force_model: Optional[str] = None,
        force_profile: Optional[str] = None,
        force_direct_mode: Optional[bool] = None,
        temperature: Optional[float] = None,
        seed: Optional[int] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Invia messaggio e ottieni risposta in streaming.

        Args:
            message: Messaggio utente
            session_id: ID sessione
            use_rag: Se True, usa contesto RAG
            stop_check_callback: Callback per stop utente
            force_model: Override per il modello LLM (default: settings.CHAT_MODEL).
                         Usato dal bot Telegram e dal batch executor.
            force_profile: Override per il profilo/system-prompt (default: settings.CHAT_PROFILE).
                           Usato dal bot Telegram e dal batch executor. Compare Mode è derivato
                           interamente da questo parametro (force_profile='document_compare').
            force_direct_mode: Override per Direct (print-ready) Mode (default: legge da
                               user_settings.interrogate_direct_mode). Usato dal batch executor
                               per garantire snapshot-coherent execution anche se l'utente cambia
                               il global toggle tra l'add e l'execute.

        Yields:
            Chunk di testo (con thinking blocks)
        """
        # Inizializza sessione
        history = self._get_or_create_session(session_id)

        # Aggiungi messaggio utente
        history.append({"role": "user", "content": message})

        # Audit timing
        import time as _time
        _t_start = _time.monotonic()

        try:
            # Document Compare uses DIFF EVIDENCE (injected into the system prompt)
            # as the SOLE source of truth — not RAG chunks. Mixing both representations
            # of the documents makes the model loop trying to reconcile them.
            _profile_for_rag = force_profile or getattr(settings, 'CHAT_PROFILE', 'default')
            _use_rag_effective = use_rag and _profile_for_rag != 'document_compare'

            # Costruisci prompt con RAG
            if _use_rag_effective:
                context_text, files_list = await self._build_rag_context(message, session_id)
                logger.info(f"📋 RAG context: context_text_len={len(context_text)}, files_list='{files_list}'")
            else:
                context_text = ""
                files_list = self._get_files_list(session_id)
                if _profile_for_rag == 'document_compare':
                    logger.info(f"📋 Compare mode: RAG disabled, DIFF EVIDENCE will be used. files_list='{files_list}'")
                else:
                    logger.info(f"📋 No RAG: files_list='{files_list}'")

            # Costruisci messaggi per Ollama (passa eventuale force_profile + batch overrides)
            messages = self._build_messages(
                message, context_text, files_list, session_id,
                force_profile=force_profile,
                force_direct_mode=force_direct_mode,
            )
            logger.info(f"📝 Messages built: {len(messages)} messages")
            if len(messages) > 0:
                logger.info(f"📝 System prompt first 200 chars: {messages[0]['content'][:200]}...")

            # Risolvi modello effettivo: override (es. dal bot Telegram) o default desktop.
            effective_model = force_model or settings.CHAT_MODEL

            # Stream risposta (dynamic context budget)
            # num_predict: cap a 16K token per prevenire thinking loop infiniti
            # think abilitato: per documenti legali complessi il ragionamento migliora la qualità
            # Per document_compare i modelli reasoning (es. gemma3:27b) tendono a entrare
            # in loop di self-correction *dentro* <think>: i cicli sono lunghi 150-300 token
            # e sfuggono alla finestra di repeat_last_n=256. Allarghiamo a 2048 e alziamo
            # repeat_penalty per troncare il loop prima che esaurisca il budget di output.
            _active_profile = force_profile or getattr(settings, 'CHAT_PROFILE', 'default')
            if _active_profile == 'document_compare':
                _opts = {"num_predict": 16384, "repeat_penalty": 1.2, "repeat_last_n": 2048}
            else:
                _opts = {"num_predict": 16384, "repeat_penalty": 1.15, "repeat_last_n": 256}
            # Per-request creativity override (CREATIVITY chip):
            # temperature=None → deterministic default 0.1; seed=None → no override
            # (Ollama picks). Fixed seed (commonly 0) makes output reproducible.
            _effective_temp = temperature if temperature is not None else 0.1
            if seed is not None:
                _opts["seed"] = int(seed)
            full_response = ""
            async for chunk in self.ollama.chat_stream(
                model=effective_model,
                messages=messages,
                num_ctx=AUTO_CTX,
                max_ctx=settings.CHAT_CTX,
                temperature=_effective_temp,
                stop_check_callback=stop_check_callback,
                options=_opts
            ):
                full_response += chunk
                yield chunk

            # Aggiungi risposta AI alla storia
            if full_response:
                history.append({"role": "assistant", "content": full_response})
                self._save_session(session_id)

            # Audit trail: model invoked (privacy: solo lunghezze char, NO contenuto).
            # Logga il modello/profilo *effettivamente usati* (con eventuali override).
            audit_logger.log(
                "interrogate", "model_invoked",
                session_id=session_id,
                model_id=effective_model,
                profile=force_profile or getattr(settings, 'CHAT_PROFILE', 'default'),
                prompt_chars=sum(len(m.get('content', '')) for m in messages),
                response_chars=len(full_response),
                duration_ms=int((_time.monotonic() - _t_start) * 1000),
                use_rag=_use_rag_effective,
                temperature=_effective_temp,
                seed=seed,
                success=True,
            )

        except Exception as e:
            logger.error(f"Error in chat: {e}")
            audit_logger.log(
                "interrogate", "model_invoked",
                session_id=session_id,
                model_id=settings.CHAT_MODEL,
                duration_ms=int((_time.monotonic() - _t_start) * 1000),
                success=False,
                error=str(e)[:200],
            )
            yield f"\n\n⚠️ Error: {str(e)}"

    def get_loading_message(self) -> str:
        """Ottiene messaggio di loading ironico localizzato."""
        return LoadingMessagesService.get_random(self.lang)
    
    async def _build_rag_context(self, query: str, session_id: str) -> tuple:
        """
        Costruisci contesto RAG con Smart File Reference Detection.

        Returns:
            (context_text, files_list)
        """
        files = self.uploaded_files.get(session_id, [])
        
        logger.info(f"📂 _build_rag_context: session_id={session_id}, files_count={len(files)}")
        if files:
            logger.info(f"📂 Files in session: {[f['name'] + ' (F' + str(f.get('ref', '0')) + ')' for f in files]}")

        if not files:
            logger.warning("⚠️ No files in session, returning empty context")
            return "", ""

        files_list = self._get_files_list(session_id)
        logger.info(f"📋 files_list generated: '{files_list}'")
        
        try:
            # Smart File Reference Detection
            explicit_filter = self._detect_file_references(query, files)
            target_sources = explicit_filter.get("source", {}).get("$in", None) if explicit_filter else None
            if target_sources is None:
                target_sources = [f['name'] for f in files]

            # Hybrid Search: BM25 + Vector
            bm25_results = self._bm25_search(query, target_sources, top_k=16)
            vector_results = await self._vector_search(query, target_sources, top_k=16)

            logger.info(f"🔍 Hybrid: BM25={len(bm25_results)} + Vector={len(vector_results)}")

            # Reciprocal Rank Fusion
            fused = self._reciprocal_rank_fusion(bm25_results, vector_results, top_k=12)

            # Reranking: Top 12 → BGE rerank → Top 12
            fused = await self.reranker.rerank(query, fused, top_k=12)

            logger.info(f"🔄 After rerank+compress: {len(fused)} docs")

            if not fused:
                logger.warning("No relevant chunks after hybrid search")
                return "", files_list

            # Raggruppa per file sorgente con DEDUPLICAZIONE (Legacy alignment)
            chunks_by_source = {}
            for result in fused:
                source = result.get('metadata', {}).get('source', 'unknown')
                if source not in chunks_by_source:
                    chunks_by_source[source] = []
                chunk_text = result['text']
                page_start = result.get('metadata', {}).get('page_start', 0)
                page_end = result.get('metadata', {}).get('page_end', 0)
                entry = (chunk_text, page_start, page_end)
                if chunk_text not in [e[0] for e in chunks_by_source[source]]:
                    chunks_by_source[source].append(entry)

            # Costruisci contesto con header espliciti (FORMATO ESATTO COME NICEGUI)
            context_parts = []
            for source, chunk_entries in chunks_by_source.items():
                # Trova ref (F1, F2...)
                ref_id = "FILE"
                for f in files:
                    if f['name'] == source:
                        ref_id = f.get('ref', 'FILE')
                        break

                # Costruisci blocchi con marker di pagina inline
                blocks = []
                for chunk_text, page_start, page_end in chunk_entries:
                    if page_start > 0:
                        page_label = f"[p.{page_start}]" if page_start == page_end or page_end == 0 else f"[p.{page_start}-{page_end}]"
                        blocks.append(f"{page_label}\n{chunk_text}")
                    else:
                        blocks.append(chunk_text)

                # FORMATO ESATTO NICEGUI: === DOCUMENT CONTENT OF F1 (filename.txt) ===
                header = f"=== DOCUMENT CONTENT OF {ref_id} ({source}) ==="
                content = "\n".join(blocks)
                context_parts.append(f"{header}\n{content}\n")

            context_text = "\n".join(context_parts)
            logger.info(f"✅ Hybrid RAG context built: {len(context_parts)} files, {len(fused)} chunks, {len(context_text)} chars")

            return context_text, files_list

        except Exception as e:
            logger.error(f"❌ Hybrid RAG Error: {e}")
            # Fallback al solo vector search
            return await self._fallback_vector_search(query, files, files_list)

    def _bm25_search(self, query: str, sources: List[str], top_k: int = 16) -> List[Dict]:
        """BM25 keyword search."""
        try:
            return self.doc_processor.bm25.search(query, top_k=top_k, source_filter=sources)
        except Exception as e:
            logger.warning(f"BM25 search failed: {e}")
            return []

    async def _vector_search(self, query: str, sources: List[str], top_k: int = 16) -> List[Dict]:
        """Vector similarity search."""
        try:
            query_emb = await self.doc_processor.chroma.get_embedding(query)
            if not query_emb:
                return []

            results = self.doc_processor.collection.query(
                query_embeddings=[query_emb],
                n_results=top_k,
                where={"source": {"$in": sources}}
            )

            if not results.get('documents') or not results['documents'][0]:
                return []

            unified = []
            for i, doc_text in enumerate(results['documents'][0]):
                meta = results['metadatas'][0][i] if i < len(results['metadatas'][0]) else {}
                distance = results['distances'][0][i] if i < len(results['distances'][0]) else 0
                unified.append({
                    'text': doc_text,
                    'score': 1.0 / (1.0 + distance),
                    'metadata': meta
                })
            return unified
        except Exception as e:
            logger.warning(f"Vector search failed: {e}")
            return []

    def _reciprocal_rank_fusion(self, bm25: List[Dict], vector: List[Dict], top_k: int = 8, k: int = 60) -> List[Dict]:
        """RRF fusion: merge BM25 + Vector results."""
        rrf_scores: Dict[str, float] = {}
        result_map: Dict[str, Dict] = {}

        for rank, r in enumerate(bm25):
            t = str(r.get('text', ''))[:500]  # Usa stringa hashable
            rrf_scores[t] = rrf_scores.get(t, 0) + 1.0 / (k + rank + 1)
            result_map[t] = r

        for rank, r in enumerate(vector):
            t = str(r.get('text', ''))[:500]  # Usa stringa hashable
            rrf_scores[t] = rrf_scores.get(t, 0) + 1.0 / (k + rank + 1)
            result_map[t] = r

        sorted_texts = sorted(rrf_scores.keys(), key=lambda t: rrf_scores[t], reverse=True)

        fused = []
        for t in sorted_texts[:top_k]:
            r = result_map[t].copy()
            r['rrf_score'] = rrf_scores[t]
            fused.append(r)

        logger.info(f"🔀 RRF: {len(bm25)} BM25 + {len(vector)} Vector → {len(fused)} fused")
        return fused

    async def _fallback_vector_search(self, query: str, files: List[Dict], files_list: str) -> tuple:
        """Fallback: solo vector search se hybrid fallisce."""
        try:
            target_sources = [f['name'] for f in files]
            query_emb = await self.doc_processor.chroma.get_embedding(query)
            if not query_emb:
                return "", files_list

            results = self.doc_processor.collection.query(
                query_embeddings=[query_emb],
                n_results=8,
                where={"source": {"$in": target_sources}}
            )

            if not results.get('documents') or not results['documents'][0]:
                return "", files_list

            chunks_by_source = {}
            for i, doc_text in enumerate(results['documents'][0]):
                if i < len(results['metadatas'][0]):
                    meta = results['metadatas'][0][i]
                    source = meta.get('source', 'unknown')
                    page_start = meta.get('page_start', 0)
                    page_end = meta.get('page_end', 0)
                    if source not in chunks_by_source:
                        chunks_by_source[source] = []
                    if doc_text not in [e[0] for e in chunks_by_source[source]]:
                        chunks_by_source[source].append((doc_text, page_start, page_end))

            context_parts = []
            for source, chunk_entries in chunks_by_source.items():
                ref_id = "FILE"
                for f in files:
                    if f['name'] == source:
                        ref_id = f.get('ref', 'FILE')
                        break
                blocks = []
                for chunk_text, page_start, page_end in chunk_entries:
                    if page_start > 0:
                        page_label = f"[p.{page_start}]" if page_start == page_end or page_end == 0 else f"[p.{page_start}-{page_end}]"
                        blocks.append(f"{page_label}\n{chunk_text}")
                    else:
                        blocks.append(chunk_text)
                header = f"=== DOCUMENT CONTENT OF {ref_id} ({source}) ==="
                context_parts.append(f"{header}\n{''.join(blocks)}\n")

            return "\n".join(context_parts), files_list
        except Exception as e:
            logger.error(f"Fallback also failed: {e}")
            return "", files_list

    async def _compress_context(self, query: str, documents: List[Dict], max_tokens: int = 3000) -> List[Dict]:
        """
        Context Compression: estrai solo le frasi più rilevanti da ogni chunk.
        Riduce il contesto del ~40% mantenendo solo le informazioni utili.
        """
        compressed = []
        total_chars = 0

        for doc in documents:
            text = doc.get('text', '')
            if not text:
                continue

            # Split per frasi
            sentences = re.split(r'(?<=[.!?])\s+', text)

            # Estrai frasi che contengono keyword della query
            query_words = set(query.lower().split())
            relevant_sentences = []

            for sentence in sentences:
                sent_lower = sentence.lower()
                # Score: quante parole della query sono presenti
                score = sum(1 for w in query_words if w in sent_lower)

                # Frasi con almeno 1 keyword match o frasi strutturali
                if score > 0 or any(kw in sent_lower for kw in ['articolo', 'sezione', 'capitolo', 'importo', 'penale']):
                    relevant_sentences.append(sentence)

            if relevant_sentences:
                compressed_text = " ".join(relevant_sentences)
                total_chars += len(compressed_text)

                if total_chars > max_tokens * 4:  # ~4 chars per token
                    break

                doc_copy = doc.copy()
                doc_copy['text'] = compressed_text
                doc_copy['compressed'] = True
                doc_copy['original_len'] = len(text)
                doc_copy['compressed_len'] = len(compressed_text)
                compressed.append(doc_copy)
            else:
                # Tieni il testo originale se nessuna frase è rilevante
                compressed.append(doc)

        if compressed:
            orig_total = sum(d.get('original_len', len(d.get('text', ''))) for d in compressed)
            comp_total = sum(d.get('compressed_len', len(d.get('text', ''))) for d in compressed)
            reduction = ((orig_total - comp_total) / orig_total * 100) if orig_total > 0 else 0
            logger.info(f"🗜️ Context compression: {orig_total} → {comp_total} chars ({reduction:.0f}% reduction)")

        return compressed
    
    def _detect_file_references(self, query: str, files: List[Dict]) -> Optional[Dict]:
        """
        Rileva riferimenti espliciti a file (F1, F2, o nomi diretti).
        
        Returns:
            Filtro ChromaDB o None
        """
        # Cerca riferimenti F1, F2
        import re
        ref_matches = re.findall(r'\bF(\d+)\b', query.upper())
        
        if ref_matches:
            found_files = []
            for m in ref_matches:
                idx = int(m) - 1
                if 0 <= idx < len(files):
                    found_files.append(files[idx]['name'])
            
            if found_files:
                logger.info(f"Explicit file references detected: {found_files}")
                return {"source": {"$in": found_files}}
        
        # Cerca nomi file diretti
        for f in files:
            clean_name = os.path.splitext(f['name'])[0].replace('_', ' ').lower()
            if clean_name in query.lower() and len(clean_name) > 5:
                logger.info(f"Direct filename mention detected: {f['name']}")
                return {"source": {"$in": [f['name']]}}
        
        return None
    
    def _get_files_list(self, session_id: str) -> str:
        """Ottiene lista file formattata."""
        files = self.uploaded_files.get(session_id, [])
        if not files:
            return ""

        return "\n".join([f"- {f.get('ref', 'FILE')}: {f['name']}" for f in files])

    def get_session_documents_text(self, session_id: str) -> List[Tuple[str, str]]:
        """Return [(filename, plain_text), ...] for every doc in the session,
        ordered by upload (same order as `uploaded_files[session_id]`).

        Reads chunks from ChromaDB and concatenates them in `chunk_id` order so
        the resulting text follows the original document flow as closely as the
        chunker allows. Used by Compare Mode for both the in-prompt diff
        evidence and the redline DOCX export.

        Returns an empty list if the session has no files. Filenames with no
        retrievable text yield an empty string (caller decides how to handle).
        """
        files = self.uploaded_files.get(session_id, [])
        if not files:
            return []
        result: List[Tuple[str, str]] = []
        for f in files:
            name = f.get('name', '')
            if not name:
                result.append(('', ''))
                continue

            # Preferred source: the ORIGINAL file on disk, read with no RAG
            # chunking — no 150-char overlap duplication, original line structure
            # intact. This is what Compare Mode needs for a clean redline/diff.
            # Falls back to the chunk reconstruction below if the file is gone or
            # its format isn't plain-text-extractable.
            clean = self.doc_processor.extract_plain_text(f.get('path', ''))
            if clean:
                result.append((name, clean))
                continue

            try:
                raw = self.doc_processor.collection.get(where={"source": name})
                chunks = raw.get('documents') or []
                metas = raw.get('metadatas') or [{}] * len(chunks)
                ordered = []
                for txt, meta in zip(chunks, metas):
                    cid = (meta or {}).get('chunk_id', None)
                    ordered.append((cid, txt))
                ordered.sort(key=lambda x: (x[0] is None, x[0] if x[0] is not None else 0))
                result.append((name, "\n".join(txt for _, txt in ordered)))
            except Exception as e:
                logger.warning(f"[get_session_documents_text] failed for {name}: {e}")
                result.append((name, ''))
        return result

    def _build_compare_diff_evidence(self, session_id: str) -> Optional[str]:
        """Pre-compute a paragraph-aligned, word-level diff between the 2 docs.

        Output uses explicit markers ([F1-ONLY]/[F2-ONLY]/[BOTH] block tags +
        inline [-removed-]/[+added+] inside [BOTH]) that the LLM can parse
        unambiguously. Same pipeline as the visual DOCX redline (build_redline_docx)
        — see redline_docx.build_textual_redline.

        Falls back to the legacy unified_diff implementation if anything fails,
        so a regression in the new path never strips diff evidence from the prompt.
        """
        files = self.uploaded_files.get(session_id, [])
        if len(files) != 2:
            return None
        try:
            from services.redline_docx import build_textual_redline
            docs = self.get_session_documents_text(session_id)
            if len(docs) != 2 or not all(d[0] for d in docs):
                return None
            text_a, text_b = docs[0][1], docs[1][1]
            if not text_a or not text_b:
                return None

            # collapse_unchanged=True: only changes + heading anchors enter the
            # evidence; the unchanged bulk (the majority of a long contract) is
            # folded into compact [UNCHANGED ×N] markers. This keeps the prompt
            # small for the local model AND ensures no real change is ever lost
            # to the size cap below (previously a long doc could push a middle
            # change past MAX_CHARS and the head+tail truncation dropped it).
            evidence = build_textual_redline(
                text_a, text_b, f1_label="F1", f2_label="F2",
                collapse_unchanged=True,
            )
            if not evidence.strip():
                return None

            # Truncation guard — now a rare last resort: it only fires if the
            # CHANGES alone exceed the budget (a document revised almost in full).
            # Head + tail preservation stays so the model still sees breadth.
            MAX_CHARS = 16000
            if len(evidence) > MAX_CHARS:
                half = MAX_CHARS // 2
                evidence = (
                    evidence[:half]
                    + "\n\n[... DIFF EVIDENCE TRUNCATED — showing head + tail ...]\n\n"
                    + evidence[-half:]
                )
            logger.info(f"[COMPARE] textual redline built: {len(evidence)} chars")
            return evidence
        except Exception as e:
            logger.warning(f"[COMPARE] textual redline failed, falling back to unified_diff: {e}")
            return self._build_compare_diff_evidence_legacy(session_id)

    def _build_compare_diff_evidence_legacy(self, session_id: str) -> Optional[str]:
        """Legacy line-level unified_diff. Kept as fallback for the word-level path.

        Originally the only implementation: line-by-line `+`/`-` deltas from
        `difflib.unified_diff` with n=1 context. Worked but suffered from
        modifications-buried-in-long-lines (e.g. a single date change inside
        an 80-word sentence shows up as the whole line removed + the whole
        line added, forcing the LLM to "diff the diff" mentally).
        """
        files = self.uploaded_files.get(session_id, [])
        if len(files) != 2:
            return None
        try:
            import difflib
            docs = self.get_session_documents_text(session_id)
            if len(docs) != 2:
                return None
            names = [d[0] for d in docs]
            if not all(names):
                return None
            text_a = docs[0][1]
            text_b = docs[1][1]
            if not text_a or not text_b:
                return None

            diff_iter = difflib.unified_diff(
                text_a.splitlines(),
                text_b.splitlines(),
                fromfile=f"F1: {names[0]}",
                tofile=f"F2: {names[1]}",
                n=1,
                lineterm=''
            )
            delta_lines = []
            for line in diff_iter:
                if line.startswith('---') or line.startswith('+++') or line.startswith('@@'):
                    continue
                if line.startswith('+') or line.startswith('-'):
                    delta_lines.append(line)

            if not delta_lines:
                return None

            joined = "\n".join(delta_lines)
            MAX_DIFF_CHARS = 12000
            if len(joined) > MAX_DIFF_CHARS:
                half = MAX_DIFF_CHARS // 2
                joined = (
                    joined[:half]
                    + f"\n\n[... DIFF TRUNCATED — {len(delta_lines)} total delta lines ...]\n\n"
                    + joined[-half:]
                )
            logger.info(f"[COMPARE-LEGACY] line-level diff built: {len(delta_lines)} delta lines, {len(joined)} chars")
            return joined
        except Exception as e:
            logger.warning(f"[COMPARE-LEGACY] line-level diff build failed: {e}")
            return None

    def _build_messages(
        self,
        user_message: str,
        context_text: str,
        files_list: str,
        session_id: str,
        force_profile: Optional[str] = None,
        force_direct_mode: Optional[bool] = None,
    ) -> List[Dict]:
        """Costruisci lista messaggi per Ollama.

        Override params (None = read global setting):
        - `force_profile`: usa quel profilo invece di settings.CHAT_PROFILE.
                           Compare Mode è derivato (force_profile='document_compare').
        - `force_direct_mode`: True/False forza il toggle Direct Mode, None = leggi da user_settings.

        Gli override sono usati dal batch executor per riprodurre lo stato
        snapshot-ato al momento del "Add to Batch", indipendentemente dal global
        setting corrente.
        """
        messages = []

        # System prompt — sempre EN (single source of truth). La lingua di output è
        # gestita dal suffix "(reply in this language: ...)" più sotto. Stesso pattern
        # già usato da generate_suggestions (riga 94). Modelli locali piccoli
        # ragionano meglio in inglese; manutenzione singola invece di IT+EN parallele.
        rag_prompts = self.prompts.get('rag', {})  # resta per templates non-profilo
        en_rag = self._load_prompts_for_lang('en').get('rag', {})
        profiles = en_rag.get('profiles', {})
        active_profile = force_profile or getattr(settings, 'CHAT_PROFILE', 'default')
        # Custom profile resolution: ID con prefisso 'custom_' → cerca nei custom universali
        if active_profile.startswith('custom_'):
            try:
                from services.custom_profiles_service import custom_profiles_service
                cp = custom_profiles_service.get_profile(active_profile)
                if cp and cp.get('system_prompt'):
                    system_prompt = cp['system_prompt']
                else:
                    # Custom eliminato (sessione persistita con id non più esistente)
                    logger.warning(f"Custom profile '{active_profile}' not found; falling back to default")
                    system_prompt = profiles.get('default') or en_rag.get('system_prompt', "You are PAI - Private Artificial Intelligence Suite.")
            except Exception as e:
                logger.error(f"Custom profile lookup failed for {active_profile}: {e}")
                system_prompt = profiles.get('default') or en_rag.get('system_prompt', "You are PAI - Private Artificial Intelligence Suite.")
        else:
            system_prompt = profiles.get(active_profile) or en_rag.get('system_prompt', "You are PAI - Private Artificial Intelligence Suite.")

        # Inietta la file list
        if files_list:
            system_prompt = system_prompt.replace("{files_list}", files_list)
        else:
            system_prompt = system_prompt.replace("{files_list}", "No files currently uploaded.")

        # Localizzazione (Legacy alignment)
        lang_map = {'it': 'italian', 'en': 'english', 'es': 'spanish', 'fr': 'french', 'de': 'german'}
        target_lang = lang_map.get(self.lang.lower(), 'english')
        system_prompt += f"\n\n(reply in this language: {target_lang})"

        # Regola Mermaid (sempre attiva, ~50 token): il parser Mermaid 11 rompe se
        # le etichette dei nodi contengono ( ) : / non quotate — caso frequentissimo
        # coi diagrammi storici/processi generati dall'AI. Quotare le risolve.
        system_prompt += (
            "\n\nMERMAID DIAGRAMS: when you output a ```mermaid block, ALWAYS wrap a node "
            'label in double quotes if it contains parentheses, colons or slashes — e.g. '
            'A["Congresso di Vienna (1815)"], never A[Congresso di Vienna (1815)]. '
            "Unquoted special characters break the Mermaid parser."
        )

        # Direct Output Mode (toggle utente in user_settings.json, default ON).
        # Impone al modello di produrre solo il deliverable richiesto, senza
        # preamboli/restatement/meta-commentary/closing remarks. Effetto: la
        # risposta è già print-ready per l'export Word/PDF.
        # Disabilitato per document_compare: il prompt di compare richiede un
        # pre-step di reasoning interno multi-fase (topic-index A/B → pair →
        # categorize) che si scontra con la regola "no preamble".
        try:
            if force_direct_mode is not None:
                direct_mode_active = bool(force_direct_mode)
            else:
                from services import user_settings_service as uss
                direct_mode_active = uss.get_interrogate_direct_mode()
            if direct_mode_active and active_profile != 'document_compare':
                system_prompt += (
                    "\n\nDIRECT OUTPUT MODE: Reply with the requested deliverable directly, "
                    "in final print-ready form. Do not include preambles, restatements of "
                    "the user's request, meta-commentary about your reasoning, self-references, "
                    "or closing offers of further help. Output only the document body content."
                )
        except Exception as e:
            logger.warning(f"direct_mode lookup failed: {e}")

        # Document Compare → DIFF EVIDENCE injection.
        # When the active profile is 'document_compare' and exactly 2 documents are
        # attached, pre-compute a paragraph-aligned word-level diff and append it
        # to the system prompt as ground truth. Marker schema is identical to
        # the visual DOCX redline so the model "sees" what the human sees.
        if active_profile == 'document_compare':
            try:
                diff_evidence = self._build_compare_diff_evidence(session_id)
                if diff_evidence:
                    system_prompt += (
                        "\n\n=== DIFF EVIDENCE (deterministic, paragraph-aligned, word-level) ===\n"
                        "Below is the pre-computed diff between F1 and F2, grouped by paragraph.\n"
                        "Read the markers literally:\n"
                        "  [F1-ONLY]…[/F1-ONLY]   = paragraph present in F1 only (REMOVED in F2)\n"
                        "  [F2-ONLY]…[/F2-ONLY]   = paragraph present in F2 only (ADDED in F2)\n"
                        "  [BOTH]…[/BOTH]         = paragraph in both. Inside, [-x-] = removed words, [+y+] = added words.\n"
                        "  [UNCHANGED ×N]         = N consecutive identical paragraphs omitted for brevity (no differences there).\n"
                        "  [MOVED]…[/MOVED]       = paragraph in BOTH F1 and F2 with near-identical content but different\n"
                        "                            position. Already detected by the system. The block contains two\n"
                        "                            lines `F1: …` and `F2: …` showing how the article number changes.\n"
                        "                            List these directly under Moved — never under Added or Removed.\n"
                        "Use this as ground truth: every Added/Removed/Modified/Moved item in your output MUST be backed "
                        "by a marker here. Do not invent.\n\n"
                        f"{diff_evidence}\n=== END DIFF EVIDENCE ==="
                    )
            except Exception as e:
                logger.warning(f"[COMPARE] diff evidence injection failed: {e}")

        messages.append({"role": "system", "content": system_prompt})

        # Storia conversazione (ultimi 10 messaggi, escluso l'ultimo che aggiungiamo dopo con contesto)
        history = self.sessions.get(session_id, [])
        past_history = history[:-1] if len(history) > 0 else []
        
        for msg in past_history[-10:]:
            if msg['role'] in ['user', 'assistant']:
                messages.append({"role": msg['role'], "content": msg['content']})

        # User prompt con contesto (Questo è l'ULTIMO messaggio user)
        user_template = rag_prompts.get('user_prompt_template', "AVAILABLE CONTEXT:\n{context_text}\n\nUSER QUESTION:\n{user_message}")
        user_content = user_template.format(
            context_text=context_text if context_text else "None",
            user_message=user_message
        )

        # Awareness Metadati
        injection_tpl = rag_prompts.get('file_list_injection', "")
        if injection_tpl and files_list:
            user_content += injection_tpl.replace("{list_str}", files_list)

        messages.append({"role": "user", "content": user_content})

        return messages
    
    def get_history(self, session_id: str) -> List[Dict]:
        """Ottieni storia conversazione."""
        self._get_or_create_session(session_id)
        return self.sessions.get(session_id, [])
    
    def get_uploaded_files(self, session_id: str) -> List[Dict]:
        """Ottieni lista file caricati con auto-sync dalla cartella uploads."""
        self._get_or_create_session(session_id)
        
        # --- CONSISTENCY GUARD (read-only, no re-add) ---
        # The session JSON is the single source of truth for registered files.
        # We only prune entries whose physical file is gone so the UI list stays clean.
        # We do NOT re-add files found on disk: a file present on disk but absent from the
        # session was either successfully deleted (physical removal + session update) or is
        # an orphan from a failed upload — in both cases it must NOT reappear.
        try:
            registered = self.uploaded_files.get(session_id, [])
            still_present = [f for f in registered if Path(f.get('path', '')).exists()]
            if len(still_present) != len(registered):
                removed_names = [f['name'] for f in registered if f not in still_present]
                logger.info(f"🧹 Pruned {len(removed_names)} missing-on-disk entries from session: {removed_names}")
                self.uploaded_files[session_id] = still_present
                self._save_session(session_id)
        except Exception as e:
            logger.error(f"Error during consistency guard: {e}")
            
        return self.uploaded_files.get(session_id, [])
