"""Batch driver: load stress_test_input.xlsx ONCE, then run a list of prompts
against MANIPULATE SHEET, saving outputs in q01/, q02/... under --output.

Used to stress-test 20 analytics prompts against a 7-sheet workbook so we can
verify SQL correctness against a pandas ground truth in a follow-up pass.
"""
from __future__ import annotations
import asyncio, json, logging, re, shutil, sys, time, uuid
from pathlib import Path
from typing import List, Dict

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass


_SQL_RX  = re.compile(r"^SQL Execution failed \(Attempt (\d+)\): (.+)$", re.DOTALL)
_SOFT_RX = re.compile(r"^Soft Validation failed \(Attempt (\d+)\): (.+)$", re.DOTALL)


class Capture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.entries: List[Dict[str, str]] = []
    def emit(self, rec):
        try: m = rec.getMessage()
        except Exception: return
        x = _SQL_RX.match(m) or _SOFT_RX.match(m)
        if x:
            self.entries.append({"attempt": int(x.group(1)),
                                 "kind": "sql" if m.startswith("SQL") else "soft",
                                 "error": x.group(2).strip()})


def _locate_produced(produced: str) -> Path | None:
    p = Path(produced)
    if p.exists(): return p
    try:
        root = Path.home() / "Documents" / "PAI_Files"
        if root.exists():
            for c in root.rglob(p.name):
                if c.exists(): return c
    except Exception: pass
    return None


async def run_batch(input_path: str, prompts: List[str], out_dir: Path) -> List[dict]:
    from services.manipulate_service import ManipulateService
    out_dir.mkdir(parents=True, exist_ok=True)

    manipulate = ManipulateService()
    session_id = f"stress-batch-{uuid.uuid4().hex[:8]}"
    fname = Path(input_path).name

    print(f"model:   {manipulate.models.get('manipulate_model','?')}", flush=True)
    print(f"session: {session_id}", flush=True)

    up = await manipulate.upload_file(input_path, fname, session_id, mode="Export to Sheet")
    if up.get("status") not in ("staged", "success"):
        raise RuntimeError(f"upload failed: {up}")
    mem = await manipulate.memorize_files(session_id, mode="Export to Sheet")
    if mem.get("status") != "success":
        raise RuntimeError(f"memorize failed: {mem}")
    print(f"tables:  {list(manipulate.data_processor.dfs.keys())}", flush=True)

    svc_logger = logging.getLogger("services.manipulate_service")
    results: List[dict] = []

    for idx, prompt in enumerate(prompts, 1):
        q_dir = out_dir / f"q{idx:02d}"
        q_dir.mkdir(parents=True, exist_ok=True)
        cap = Capture()
        svc_logger.addHandler(cap)

        print(f"\n--- q{idx:02d} --- {prompt[:110]!r}", flush=True)
        t0 = time.time()
        produced = None; final_msg = None; exc = None
        try:
            async for ok, msg, files in manipulate.analyze(
                query=prompt, session_id=session_id, mode="Export to Sheet"
            ):
                final_msg = msg
                if files: produced = files[0]
        except Exception as e:
            exc = f"{type(e).__name__}: {e}"
        finally:
            svc_logger.removeHandler(cap)

        elapsed = round(time.time() - t0, 2)
        success = bool(produced)
        out_path: str | None = None
        if produced:
            src = _locate_produced(produced)
            if src:
                target = q_dir / "result.xlsx"
                try:
                    shutil.copy2(src, target)
                    out_path = str(target.relative_to(out_dir))
                except Exception as e:
                    exc = f"copy failed: {e}"
                    success = False

        entry = {
            "index": idx,
            "prompt": prompt,
            "success": success,
            "output": out_path,
            "elapsed_s": elapsed,
            "retries": cap.entries,
            "final_msg": (final_msg or "")[:600],
            "exception": exc,
        }
        results.append(entry)
        # Persist incrementally so a crash mid-run still leaves usable data.
        (out_dir / "batch_results.json").write_text(
            json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        tag = "OK " if success else "FAIL"
        print(f"   {tag}  ({elapsed}s, retries={len(cap.entries)})", flush=True)

    try: manipulate.clear_session(session_id)
    except Exception: pass

    return results


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--prompts-json", required=True,
                   help="Path to a JSON file containing a list of prompts.")
    p.add_argument("--output", required=True)
    a = p.parse_args()

    with open(a.prompts_json, "r", encoding="utf-8") as f:
        prompts = json.load(f)
    res = asyncio.run(run_batch(a.input, prompts, Path(a.output)))
    print(f"\nDONE: {sum(1 for r in res if r['success'])}/{len(res)} ok")
