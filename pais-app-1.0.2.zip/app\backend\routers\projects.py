"""
Projects Routes - API per gestione progetti
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional, Any

from backend_config.project_manager import project_manager

router = APIRouter()


def _reset_all_services():
    """Annulla le istanze globali dei service per forzare la ri-creazione
    al prossimo request con il corretto ChromaDB path del nuovo progetto.
    I getter (get_chat_service, get_vision_service, get_manipulate_service)
    rilevano il cambio di path e istanziano automaticamente nuovi service."""
    import routers.interrogate as _int
    import routers.vision as _vis
    import routers.manipulate as _man

    _int._chat_service = None
    _int._suggestions_service = None
    _vis._vision_service = None
    _man._manipulate_service = None

    print("✅ All service instances nulled — will reinitialize with new project ChromaDB path")


class ProjectCreateRequest(BaseModel):
    name: str


class ProjectSaveAsRequest(BaseModel):
    new_name: str


class ProjectOpenRequest(BaseModel):
    project_folder: str


class ProjectListResponse(BaseModel):
    projects: List[Dict]


class ProjectActionResponse(BaseModel):
    success: bool
    message: str
    error: str = ""


@router.get("/projects/list", response_model=ProjectListResponse)
async def list_projects():
    """Ottieni lista di tutti i progetti."""
    try:
        projects = project_manager.list_projects()
        return {"projects": projects}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/projects/create", response_model=ProjectActionResponse)
async def create_project(request: ProjectCreateRequest):
    """Crea un nuovo progetto e lo attiva automaticamente."""
    try:
        folder_name = project_manager.create_project(request.name)
        _reset_all_services()
        return ProjectActionResponse(
            success=True,
            message=f"Progetto '{request.name}' creato con successo!",
            error=""
        )
    except Exception as e:
        return ProjectActionResponse(
            success=False,
            message="Errore creazione progetto",
            error=str(e)
        )


@router.post("/projects/save_as", response_model=ProjectActionResponse)
async def save_project_as(request: ProjectSaveAsRequest):
    """Salva il workspace corrente come un nuovo progetto (clonazione)."""
    try:
        # Prima del salvataggio, forziamo il flush delle sessioni attive
        sid = project_manager.get_short_id()
        if sid:
            try:
                from routers.interrogate import get_chat_service
                get_chat_service()._save_session(sid)
            except Exception as e:
                print(f"Warning: flush chat session failed: {e}")
            try:
                from routers.vision import get_vision_service
                get_vision_service()._save_session(sid)
            except Exception as e:
                print(f"Warning: flush vision session failed: {e}")
            try:
                from routers.manipulate import get_manipulate_service
                get_manipulate_service()._save_session(sid)
            except Exception as e:
                print(f"Warning: flush manipulate session failed: {e}")

        success, result = project_manager.save_current_as(request.new_name)

        if success:
            # Il nuovo progetto è ora attivo: azzera i service per riagganciarli al nuovo ChromaDB
            _reset_all_services()
            return ProjectActionResponse(
                success=True,
                message=f"Progetto salvato come '{request.new_name}'!",
                error=""
            )
        else:
            return ProjectActionResponse(
                success=False,
                message="Errore durante il salvataggio",
                error=str(result)
            )
    except Exception as e:
        return ProjectActionResponse(
            success=False,
            message="Errore interno al server",
            error=str(e)
        )


@router.post("/projects/open", response_model=ProjectActionResponse)
async def open_project(request: ProjectOpenRequest):
    """Apri un progetto esistente (resetta sessioni in-memory)."""
    try:
        project_manager.set_active_project(request.project_folder)
        _reset_all_services()
        # Snapshot del vault del nuovo progetto attivo, se è passata >= 1 sett.
        # Garantisce che ogni progetto venga "toccato" da un backup recente
        # anche se l'utente switcha spesso senza riavviare PAIS.
        try:
            from services.vault_backup_service import VaultBackupService
            VaultBackupService(project_manager).maybe_run_weekly_backup()
        except Exception as e:
            print(f"Vault backup hook (post open) failed: {e}")
        return ProjectActionResponse(
            success=True,
            message=f"Progetto '{request.project_folder}' aperto con successo!",
            error=""
        )
    except Exception as e:
        return ProjectActionResponse(
            success=False,
            message="Errore apertura progetto",
            error=str(e)
        )


@router.delete("/projects/delete", response_model=ProjectActionResponse)
async def delete_project(project_folder: str):
    """Elimina un progetto."""
    try:
        # Azzera i service prima della cancellazione per rilasciare handle su file
        # (ChromaDB su Windows può tenere lock su file nella cartella del progetto)
        _reset_all_services()
        success = project_manager.delete_project(project_folder)
        if success:
            return ProjectActionResponse(
                success=True,
                message=f"Progetto '{project_folder}' eliminato con successo!",
                error=""
            )
        else:
            return ProjectActionResponse(
                success=False,
                message=f"Impossibile eliminare '{project_folder}'. File in uso.",
                error=""
            )
    except Exception as e:
        return ProjectActionResponse(
            success=False,
            message="Errore eliminazione progetto",
            error=str(e)
        )


@router.delete("/projects/delete_all", response_model=ProjectActionResponse)
async def delete_all_projects_endpoint():
    """Elimina tutti i progetti tranne il DEFAULT_WORKSPACE E quello
    attualmente attivo. Risponde con il conteggio dei progetti eliminati
    e ripristina il progetto attivo pre-bulk se possibile."""
    try:
        # Azzera i service prima del bulk delete per rilasciare i lock
        # (ChromaDB/DuckDB su Windows possono tenere file aperti).
        _reset_all_services()
        deleted = project_manager.delete_all_projects()
        return ProjectActionResponse(
            success=True,
            message=f"{deleted} progetti eliminati (default e progetto attivo preservati).",
            error=""
        )
    except Exception as e:
        return ProjectActionResponse(
            success=False,
            message="Errore bulk delete progetti",
            error=str(e)
        )


@router.get("/projects/current")
async def get_current_project():
    """Ottieni progetto corrente."""
    return {
        "name": project_manager.active_project_name,
        "folder": project_manager.active_project_path.name if project_manager.active_project_path else None,
        "short_id": project_manager.get_short_id()
    }


@router.post("/projects/open_output_folder")
async def open_output_folder(subfolder: str = None):
    """Apre la cartella di output del progetto corrente in Windows Explorer."""
    try:
        import os
        import subprocess
        
        output_dir = project_manager.get_path("output")
        if subfolder:
            output_dir = output_dir / subfolder
            
        if not output_dir.exists():
            output_dir.mkdir(parents=True, exist_ok=True)
            
        path_str = str(output_dir.absolute())
        
        if os.name == 'nt': # Windows
            os.startfile(path_str)
        else: # macOS/Linux
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])
            
        return {"success": True, "message": "Cartella aperta"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/projects/download_file/{filename}")
async def download_project_file(filename: str):
    """Scarica un file dalla cartella output del progetto attivo."""
    from fastapi.responses import FileResponse
    import os
    
    try:
        output_dir = project_manager.get_path("output")
        file_path = output_dir / filename
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"File {filename} non trovato")
            
        return FileResponse(
            path=str(file_path),
            filename=filename,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=str(e))


# Set degli scope ammessi per l'audit log. "all" = backward-compat (report cross-modulo).
# Gli altri valori filtrano events + integrity-fingerprint al solo modulo richiesto.
# "system" è incluso perché audit_logger.log("system", "audit_generated", ...) marca le
# auto-generazioni di report: vanno mostrate quando scope=all e quando scope=system.
_AUDIT_SCOPES = {"all", "interrogate", "vision", "manipulate", "anonimyze", "utility", "system"}


def _redact_filename(name: str) -> str:
    """Oscura un nome file mantenendo i primi 2 char + estensione.

    Esempi:
      'contratto_acme_2026.pdf' -> 'co***.pdf'
      'vendite.xlsx'            -> 've***.xlsx'
      'a.csv'                   -> '***.csv'
      'no_ext'                  -> 'no***'

    Privacy-safety: un avvocato che apre il report davanti a un cliente non vede
    in chiaro i nomi degli altri suoi clienti. Il filename pieno è disponibile
    nel JSON allegato per uso forensic interno.
    """
    if not name:
        return "***"
    stem, dot, ext = name.rpartition(".")
    if not dot:
        # Nessuna estensione
        return (name[:2] + "***") if len(name) > 2 else "***"
    visible = stem[:2] if len(stem) >= 2 else ""
    return f"{visible}***.{ext}" if visible else f"***.{ext}"


@router.post("/projects/audit_log")
async def generate_audit_log(lang: str = "it", scope: str = "all", redact: bool = False):
    """
    Local Activity Report — 3 sezioni: Activity Log + Local Processing Proof + File Inventory.
    Output: HTML pretty + JSON machine-readable, entrambi salvati in output/.
    Self-signed via SHA256 dell'HTML per tamper detection.

    Genera SEMPRE 2 versioni HTML (full + redacted) accanto, così l'utente può
    passare dall'una all'altra via link filesystem nel report. Il parametro
    `redact` decide solo quale aprire nel browser di sistema come primaria.

    Parametri:
      lang   — lingua dei testi i18n ("it" / "en", default "it")
      scope  — modulo di scope ("all" / "interrogate" / "vision" / "manipulate" /
               "anonimyze" / "utility" / "system"). Filtra events e file inventory.
      redact — se True apre la versione redacted come primaria nel browser. La
               versione full viene comunque generata accanto. Default False.
    """
    try:
        import hashlib
        import datetime
        import json as _json
        import platform
        import socket
        from html import escape as _esc
        from backend_config import settings
        from services.i18n_service import i18n
        from services.audit_service import audit_logger, file_sha256

        # ─── 0. Validate scope ───────────────────────────────────────────────
        scope = (scope or "all").lower().strip()
        if scope not in _AUDIT_SCOPES:
            raise HTTPException(
                status_code=422,
                detail=f"Invalid scope '{scope}'. Allowed: {sorted(_AUDIT_SCOPES)}"
            )

        # ─── 1. Metadata progetto ────────────────────────────────────────────
        project_name = project_manager.active_project_name
        sid = project_manager.get_short_id()
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
        timestamp_compact = now.strftime("%Y%m%d_%H%M%S")

        # ─── 2. Activity Timeline (event log forward-only) ───────────────────
        events_all = audit_logger.read_all()
        events_all.sort(key=lambda e: e.get("ts", ""))
        # Filter by scope se richiesto. "system" eventi (audit_generated) sempre inclusi
        # quando lo scope è quello specifico modulo per cui il report è stato generato:
        # questo permette di vedere "chi/quando ha emesso un report" nello scope cliente.
        if scope == "all":
            events = events_all
        else:
            events = [e for e in events_all if e.get("module") == scope]

        # Aggregati per riepilogo veloce
        actions_count: Dict[str, int] = {}
        modules_count: Dict[str, int] = {}
        for ev in events:
            actions_count[ev.get("action", "?")] = actions_count.get(ev.get("action", "?"), 0) + 1
            modules_count[ev.get("module", "?")] = modules_count.get(ev.get("module", "?"), 0) + 1

        # ─── 3. Sovereignty Proof: Ollama list + endpoint + OS ───────────────
        sovereignty: Dict[str, Any] = {
            "ollama_host": settings.OLLAMA_HOST_URL,
            "ollama_localhost": settings.OLLAMA_HOST_URL.startswith(("http://127.0.0.1", "http://localhost", "https://127.0.0.1", "https://localhost")),
            "ollama_models_loaded": [],
            "ollama_unreachable": False,
            "os": f"{platform.system()} {platform.release()}",
            "python": platform.python_version(),
            "hostname": socket.gethostname(),
            "egress_claim": "Local-only inference. PAIS architecture does not perform outbound network calls to 3rd-party AI providers. Only Ollama on localhost is contacted.",
        }
        try:
            import httpx
            with httpx.Client(timeout=2.0) as client:
                r = client.get(f"{settings.OLLAMA_HOST_URL.rstrip('/')}/api/tags")
                if r.status_code == 200:
                    data = r.json()
                    for m in data.get("models", []):
                        sovereignty["ollama_models_loaded"].append({
                            "name": m.get("name", ""),
                            "size_bytes": m.get("size", 0),
                            "digest": (m.get("digest", "") or "")[:64],
                            "modified_at": m.get("modified_at", ""),
                        })
                else:
                    sovereignty["ollama_unreachable"] = True
        except Exception as _ole:
            sovereignty["ollama_unreachable"] = True
            sovereignty["ollama_error"] = str(_ole)[:200]

        # ─── 4. Integrity Fingerprint: hash file processati ──────────────────
        # Estrai dagli eventi tutti gli SHA256 dei file in input + file di output ancora su disco
        seen_hashes: Dict[str, Dict[str, Any]] = {}  # sha256 -> info
        for ev in events:
            details = ev.get("details", {}) or {}
            # input file
            sha = details.get("input_sha256") or details.get("sha256")
            fname = details.get("input_filename") or details.get("filename")
            if sha and fname and sha not in seen_hashes:
                seen_hashes[sha] = {
                    "filename": fname,
                    "size_bytes": details.get("input_size_bytes") or details.get("size_bytes", 0),
                    "first_seen": ev.get("ts", ""),
                    "module": ev.get("module", ""),
                }

        # ─── 5. Render HTML ─────────────────────────────────────────────────
        # Activity table (limita ai 200 eventi più recenti per leggibilità; il JSON ha tutto)
        recent_events = events[-200:]
        activity_rows = ""
        for ev in recent_events:
            ts = _esc(ev.get("ts", ""))
            module = _esc(ev.get("module", ""))
            action = _esc(ev.get("action", ""))
            details = ev.get("details", {}) or {}
            # Filtra dettagli salienti per readability
            salient_keys = ("filename", "input_filename", "model_id", "model", "processor",
                            "duration_ms", "output_filename", "output_files_count", "success", "error",
                            "files_deleted_count", "mode", "target_lang_code", "deep_mode", "report_hash")
            salient = {k: details[k] for k in salient_keys if k in details}
            details_str = ", ".join(f"<b>{_esc(k)}</b>=<code>{_esc(str(v))}</code>" for k, v in salient.items())
            activity_rows += f"<tr><td><code>{ts}</code></td><td>{module}</td><td><b>{action}</b></td><td>{details_str}</td></tr>"
        if not activity_rows:
            activity_rows = f"<tr><td colspan='4' style='text-align:center; padding:20px; color:#94a3b8;'>{_esc(i18n.get('audit.no_events', 'No tracked events yet.'))}</td></tr>"

        # Sovereignty section
        models_rows = ""
        for m in sovereignty["ollama_models_loaded"]:
            size_gb = m["size_bytes"] / (1024**3) if m["size_bytes"] else 0
            models_rows += f"<tr><td><code>{_esc(m['name'])}</code></td><td>{size_gb:.2f} GB</td><td><code>{_esc(m['digest'][:16])}…</code></td></tr>"
        if not models_rows:
            models_rows = f"<tr><td colspan='3' style='text-align:center; padding:20px; color:#94a3b8;'>{_esc(i18n.get('audit.ollama_unreachable', 'Ollama unreachable or no models loaded.'))}</td></tr>"

        # Integrity table (file hashes) — generata in 2 versioni:
        #   - full: filename pieni + SHA256 64 char (default, audit interno)
        #   - redacted: filename mascherati + SHA256 troncato a 16 char (per condivisione esterna)
        # Il JSON allegato resta sempre full a uso forense.
        def _make_integrity_rows(redact_flag: bool) -> str:
            rows = ""
            for sha, info in sorted(seen_hashes.items(), key=lambda kv: kv[1]["first_seen"]):
                size_mb = info["size_bytes"] / (1024**2) if info["size_bytes"] else 0
                if redact_flag:
                    fname_cell = _redact_filename(info["filename"])
                    sha_cell = sha[:16] + "…" if len(sha) > 16 else sha
                else:
                    fname_cell = info["filename"]
                    sha_cell = sha
                rows += (
                    f"<tr><td><code>{_esc(fname_cell)}</code></td>"
                    f"<td>{size_mb:.2f} MB</td>"
                    f"<td>{_esc(info['module'])}</td>"
                    f"<td><code style='font-size:9px'>{_esc(sha_cell)}</code></td></tr>"
                )
            if not rows:
                rows = f"<tr><td colspan='4' style='text-align:center; padding:20px; color:#94a3b8;'>{_esc(i18n.get('audit.no_files', 'No files processed yet.'))}</td></tr>"
            return rows

        integrity_rows_full = _make_integrity_rows(redact_flag=False)
        integrity_rows_redacted = _make_integrity_rows(redact_flag=True)

        # Counters per riepilogo
        events_count = len(events)
        files_processed_count = len(seen_hashes)

        # Etichetta human-readable dello scope (per meta-grid e <title>)
        scope_label_human = (
            i18n.get("audit.scope_all", "All modules") if scope == "all"
            else scope.upper()
        )

        # Filename delle due versioni HTML — calcolati qui per poter cross-linkare.
        scope_tag = "" if scope == "all" else f"_{scope.upper()}"
        log_filename_html_full = f"AUDIT{scope_tag}_{timestamp_compact}.html"
        log_filename_html_redacted = f"AUDIT{scope_tag}_REDACTED_{timestamp_compact}.html"
        log_filename_json_full = f"AUDIT{scope_tag}_{timestamp_compact}.json"
        log_filename_json_redacted = f"AUDIT{scope_tag}_REDACTED_{timestamp_compact}.json"

        # ─── 5. Render HTML — builder che produce SIA la versione full SIA la redacted.
        # Le due versioni differiscono solo in: (a) integrity_rows, (b) integrity_subtitle,
        # (c) banner/link di cross-reference all'altra versione, (d) tag REDACTED nel <title>.
        def _build_html(redact_flag: bool, twin_html_filename: str) -> str:
            # Integrity table rows + subtitle in base al flag
            integrity_rows = integrity_rows_redacted if redact_flag else integrity_rows_full
            if redact_flag:
                integrity_subtitle = i18n.get(
                    "audit.integrity_subtitle_redacted",
                    "SHA256 hashes — filenames and hashes partially redacted for external sharing. Full version available on the same disk."
                )
                title_suffix = " [REDACTED]"
            else:
                integrity_subtitle = i18n.get(
                    "audit.integrity_subtitle",
                    "Hash SHA256 dei file processati. Il report è firmato in coda per rilevare manomissioni."
                )
                title_suffix = ""

            # Cross-link block: banner rosso visibile se redacted, link discreto se full
            if redact_flag:
                banner_title = _esc(i18n.get("audit.redacted_banner_title", "Redacted version"))
                banner_desc = _esc(i18n.get("audit.redacted_banner_desc", "Filenames and hashes are partially redacted in this copy."))
                view_full_btn = _esc(i18n.get("audit.view_full_btn", "← Open full version with filenames"))
                cross_link_html = (
                    f'<div style="margin-bottom:20px; padding:16px 20px; background:#fef2f2; border:2px solid #dc2626; border-radius:12px;">'
                    f'<div style="font-size:12px; font-weight:900; color:#991b1b; text-transform:uppercase; letter-spacing:2px; margin-bottom:6px;">⚠ {banner_title}</div>'
                    f'<p style="font-size:11px; color:#7f1d1d; margin:0 0 10px 0; line-height:1.5;">{banner_desc}</p>'
                    f'<a href="{_esc(twin_html_filename)}" style="display:inline-block; font-size:11px; font-weight:700; color:#0f172a; text-decoration:underline;">{view_full_btn}</a>'
                    f'</div>'
                )
            else:
                view_redacted_btn = _esc(i18n.get("audit.view_redacted_btn", "Redacted version for external sharing →"))
                cross_link_html = (
                    f'<div style="margin-bottom:16px; text-align:right;">'
                    f'<a href="{_esc(twin_html_filename)}" style="font-size:10px; font-weight:600; color:#64748b; text-decoration:none; border-bottom:1px dashed #cbd5e1; padding-bottom:1px;">{view_redacted_btn}</a>'
                    f'</div>'
                )

            return f"""<!DOCTYPE html>
<html lang="{_esc(lang)}">
<head>
<meta charset="UTF-8">
<title>PAIS Local Activity Report — {_esc(project_name)} — {_esc(scope_label_human)}{title_suffix} — {_esc(timestamp)}</title>
<style>
body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.5; color: #1e293b; padding: 32px; background: #f8fafc; }}
.container {{ max-width: 1100px; margin: auto; background: white; padding: 40px; border-radius: 20px; border: 1px solid #e2e8f0; box-shadow: 0 4px 20px rgba(0,0,0,0.04); }}
.header {{ border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-end; }}
.logo {{ font-weight: 900; font-size: 24px; letter-spacing: -1px; color: #0f172a; }}
.title {{ text-transform: uppercase; font-size: 11px; font-weight: 900; letter-spacing: 3px; color: #64748b; }}
h1 {{ font-size: 26px; margin: 5px 0 0 0; color: #0f172a; }}
h2 {{ font-size: 16px; margin: 40px 0 12px 0; padding-bottom: 8px; border-bottom: 1px solid #e2e8f0; color: #0f172a; }}
.meta-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; background: #f1f5f9; padding: 20px; border-radius: 12px; font-size: 12px; }}
.meta-item b {{ display: block; text-transform: uppercase; font-size: 9px; color: #64748b; margin-bottom: 4px; letter-spacing: 1px; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 11px; }}
th {{ text-align: left; background: #f8fafc; padding: 8px 10px; border-bottom: 1px solid #e2e8f0; text-transform: uppercase; font-size: 9px; color: #64748b; letter-spacing: 1px; }}
td {{ padding: 8px 10px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }}
code {{ background: #f1f5f9; padding: 1px 5px; border-radius: 3px; font-size: 10px; word-break: break-all; }}
.statement {{ background: #0f172a; color: white; padding: 22px 26px; border-radius: 12px; margin-top: 30px; }}
.statement h3 {{ margin-top: 0; font-size: 14px; color: #38bdf8; }}
.statement p {{ font-size: 12px; opacity: 0.9; margin-bottom: 0; }}
.footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 10px; color: #94a3b8; }}
.badge {{ display: inline-block; padding: 3px 10px; border-radius: 99px; font-weight: 900; font-size: 9px; letter-spacing: 1px; }}
.badge.green {{ background: #dcfce7; color: #166534; }}
.badge.red {{ background: #fee2e2; color: #991b1b; }}
.hash-block {{ background: #f1f5f9; padding: 14px; border-radius: 8px; font-family: monospace; font-size: 11px; word-break: break-all; margin-top: 12px; border: 1px dashed #cbd5e1; }}
.print-btn {{ display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; background: #0f172a; color: white; border: none; border-radius: 8px; font-size: 11px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; cursor: pointer; transition: opacity 0.2s; }}
.print-btn:hover {{ opacity: 0.85; }}
@media print {{
  body {{ background: white; padding: 0; }}
  .container {{ box-shadow: none; border: none; padding: 16px; max-width: 100%; border-radius: 0; }}
  .print-btn, .print-bar {{ display: none !important; }}
  .statement {{ break-inside: avoid; }}
  table {{ break-inside: avoid-page; }}
  h2 {{ break-after: avoid; }}
}}
</style>
</head>
<body>
<div class="container">

{cross_link_html}
<div class="print-bar" style="display:flex; justify-content:flex-end; margin-bottom:16px;">
<button class="print-btn" onclick="window.print()" title="{_esc(i18n.get('audit.print_btn_tooltip', 'Stampa il report o salvalo come PDF tramite il browser'))}">🖨 {_esc(i18n.get('audit.print_btn', 'Stampa / Salva come PDF'))}</button>
</div>

<div class="header">
<div>
<div class="title">{_esc(i18n.get('audit.report_title', 'PAIS Compliance Report'))}</div>
<h1>{_esc(i18n.get('audit.report_subtitle', 'Activity · Sovereignty · Integrity'))}</h1>
</div>
<div class="logo">PAIS</div>
</div>

<div class="meta-grid" style="grid-template-columns: repeat(5, 1fr);">
<div class="meta-item"><b>{_esc(i18n.get('audit.project_name', 'Project'))}</b> {_esc(project_name)}</div>
<div class="meta-item"><b>{_esc(i18n.get('audit.scope_label', 'Scope'))}</b> {_esc(scope_label_human)}</div>
<div class="meta-item"><b>{_esc(i18n.get('audit.session_id', 'Session ID'))}</b> {_esc(sid)}</div>
<div class="meta-item"><b>{_esc(i18n.get('audit.report_date', 'Report Date'))}</b> {_esc(timestamp)}</div>
<div class="meta-item"><b>{_esc(i18n.get('audit.events_total', 'Total Events'))}</b> {events_count}</div>
</div>

<h2>{_esc(i18n.get('audit.activity_title', '1. Activity Timeline'))}</h2>
<p style="font-size:12px;color:#64748b;margin:6px 0 12px 0;">{_esc(i18n.get('audit.activity_subtitle', 'Cronologia delle operazioni eseguite. Ultimi 200 eventi mostrati qui; il JSON allegato contiene la lista completa.'))}</p>
<table>
<thead><tr><th>{_esc(i18n.get('audit.timestamp', 'Timestamp (UTC)'))}</th><th>{_esc(i18n.get('audit.module', 'Module'))}</th><th>{_esc(i18n.get('audit.action', 'Action'))}</th><th>{_esc(i18n.get('audit.details', 'Details'))}</th></tr></thead>
<tbody>{activity_rows}</tbody>
</table>

<h2>{_esc(i18n.get('audit.sovereignty_title', '2. Sovereignty Proof'))}</h2>
<p style="font-size:12px;color:#64748b;margin:6px 0 12px 0;">{_esc(i18n.get('audit.sovereignty_subtitle', "Prova tecnica che l'inferenza è avvenuta solo localmente, su modelli installati su questa macchina."))}</p>
<div class="meta-grid" style="grid-template-columns: 1fr 1fr;">
<div class="meta-item"><b>{_esc(i18n.get('audit.ollama_host', 'Ollama Endpoint'))}</b> <code>{_esc(settings.OLLAMA_HOST_URL)}</code> <span class="badge {'green' if sovereignty['ollama_localhost'] else 'red'}">{_esc('LOCAL' if sovereignty['ollama_localhost'] else 'REMOTE!')}</span></div>
<div class="meta-item"><b>{_esc(i18n.get('audit.host', 'Host'))}</b> {_esc(sovereignty['os'])} · {_esc(sovereignty['hostname'])} · Python {_esc(sovereignty['python'])}</div>
</div>
<h3 style="font-size:13px;margin-top:20px;color:#475569;">{_esc(i18n.get('audit.models_loaded', 'Modelli installati localmente (Ollama)'))}</h3>
<table>
<thead><tr><th>{_esc(i18n.get('audit.model_name', 'Model'))}</th><th>{_esc(i18n.get('audit.size', 'Size'))}</th><th>{_esc(i18n.get('audit.digest', 'Digest'))}</th></tr></thead>
<tbody>{models_rows}</tbody>
</table>
<div class="statement">
<h3>🛡️ {_esc(i18n.get('audit.egress_claim_title', 'Egress Claim'))}</h3>
<p>{_esc(sovereignty['egress_claim'])}</p>
</div>

<h2>{_esc(i18n.get('audit.integrity_title', '3. Integrity Fingerprint'))}</h2>
<p style="font-size:12px;color:#64748b;margin:6px 0 12px 0;">{_esc(integrity_subtitle)}</p>
<table>
<thead><tr><th>{_esc(i18n.get('audit.filename', 'File'))}</th><th>{_esc(i18n.get('audit.size', 'Size'))}</th><th>{_esc(i18n.get('audit.module', 'Module'))}</th><th>{_esc(i18n.get('audit.hash_full', 'SHA256'))}</th></tr></thead>
<tbody>{integrity_rows}</tbody>
</table>

<div class="footer">
{_esc(i18n.get('audit.footer_text', 'PAIS — Private Artificial Intelligence Suite · For Informational Purposes Only'))}<br>
<b>{_esc(i18n.get('audit.report_hash_label', 'Report Self-Hash (SHA256)'))}:</b>
<div class="hash-block" id="report-hash">__REPORT_HASH_PLACEHOLDER__</div>
</div>

</div>
</body>
</html>"""

        # ─── 6. Genera e firma ENTRAMBE le versioni HTML ─────────────────────
        # Cross-link: ogni versione punta all'altra via filename relativo (stesso dir).
        html_full_unsigned = _build_html(redact_flag=False, twin_html_filename=log_filename_html_redacted)
        html_redacted_unsigned = _build_html(redact_flag=True, twin_html_filename=log_filename_html_full)
        report_hash_full = hashlib.sha256(html_full_unsigned.encode("utf-8")).hexdigest()
        report_hash_redacted = hashlib.sha256(html_redacted_unsigned.encode("utf-8")).hexdigest()
        html_signed_full = html_full_unsigned.replace("__REPORT_HASH_PLACEHOLDER__", report_hash_full)
        html_signed_redacted = html_redacted_unsigned.replace("__REPORT_HASH_PLACEHOLDER__", report_hash_redacted)

        # ─── 7. Salva HTML + JSON ────────────────────────────────────────────
        output_dir = project_manager.get_path("output")
        output_dir.mkdir(parents=True, exist_ok=True)
        log_path_html_full = output_dir / log_filename_html_full
        log_path_html_redacted = output_dir / log_filename_html_redacted
        log_path_json_full = output_dir / log_filename_json_full
        log_path_json_redacted = output_dir / log_filename_json_redacted

        with open(log_path_html_full, "w", encoding="utf-8") as f:
            f.write(html_signed_full)
        with open(log_path_html_redacted, "w", encoding="utf-8") as f:
            f.write(html_signed_redacted)

        # Alias per compatibilità col resto della funzione (return value, log evento).
        log_filename_html = log_filename_html_redacted if redact else log_filename_html_full
        log_filename_json = log_filename_json_redacted if redact else log_filename_json_full
        log_path_html = log_path_html_redacted if redact else log_path_html_full
        log_path_json = log_path_json_redacted if redact else log_path_json_full
        report_hash = report_hash_redacted if redact else report_hash_full

        # JSON con TUTTI gli eventi + sovereignty + integrity (machine-readable).
        # Sia il JSON full sia quello redacted contengono dati pieni (filename completi,
        # SHA full 64 char): il JSON è uso forense interno, mai pensato per condivisione.
        # L'unica differenza è il report_hash_sha256 nel meta, che pinpoint la specifica
        # versione HTML cui il JSON si accompagna.
        def _make_report_json(hash_for_meta: str) -> dict:
            return {
                "report_meta": {
                    "project_name": project_name,
                    "session_id": sid,
                    "report_date": timestamp,
                    "report_hash_sha256": hash_for_meta,
                    "scope": scope,
                    "events_total": events_count,
                    "files_processed_total": files_processed_count,
                },
                "activity_summary": {
                    "by_action": actions_count,
                    "by_module": modules_count,
                },
                "activity_events": events,
                "sovereignty": sovereignty,
                "integrity_fingerprints": [
                    {"sha256": sha, **info} for sha, info in seen_hashes.items()
                ],
            }

        with open(log_path_json_full, "w", encoding="utf-8") as f:
            _json.dump(_make_report_json(report_hash_full), f, indent=2, ensure_ascii=False, default=str)
        with open(log_path_json_redacted, "w", encoding="utf-8") as f:
            _json.dump(_make_report_json(report_hash_redacted), f, indent=2, ensure_ascii=False, default=str)

        # ─── 8. Loga sé stesso ───────────────────────────────────────────────
        # Logga la versione effettivamente aperta nel browser (governata da `redact`).
        try:
            audit_logger.log(
                "system", "audit_generated",
                report_hash=report_hash,
                scope=scope,
                redact=redact,
                output_html=log_filename_html,
                output_json=log_filename_json,
                output_html_twin=(log_filename_html_full if redact else log_filename_html_redacted),
                events_in_report=events_count,
                files_in_report=files_processed_count,
            )
        except Exception:
            pass

        # ─── 9. Apri il report HTML nel browser di sistema (non nel webview interno).
        # Si apre la versione richiesta da `redact` (default = full). L'altra versione
        # è salvata accanto e linkata dentro l'HTML stesso.
        try:
            import os as _os
            if _os.name == 'nt':
                _os.startfile(str(log_path_html))
            else:
                import subprocess as _sp
                opener = "open" if _os.uname().sysname == "Darwin" else "xdg-open"
                _sp.Popen([opener, str(log_path_html)])
        except Exception as e:
            print(f"⚠️  Audit log generated but failed to open browser: {e}")

        return {
            "success": True,
            "filename": log_filename_html,           # backward-compat (vecchi client)
            "filepath": str(log_path_html),
            "filename_html": log_filename_html,
            "filename_json": log_filename_json,
            "filename_html_full": log_filename_html_full,
            "filename_html_redacted": log_filename_html_redacted,
            "filename_json_full": log_filename_json_full,
            "filename_json_redacted": log_filename_json_redacted,
            "report_hash": report_hash,
            "report_hash_full": report_hash_full,
            "report_hash_redacted": report_hash_redacted,
            "redact": redact,
            "events_total": events_count,
            "opened_in_browser": True,
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/projects/open_file/{filename}")
async def open_project_file(filename: str, subfolder: Optional[str] = None):
    """Apre fisicamente un file dalla cartella output del progetto attivo usando l'app predefinita del sistema.

    Se `subfolder` è specificato, il file viene cercato dentro `output/<subfolder>/`.
    Subfolder è validato: niente '..' o slash che permettano path traversal.
    """
    import os
    import subprocess

    try:
        output_dir = project_manager.get_path("output")
        if subfolder:
            # Sanity: niente path traversal, no slash interni — accetta solo nomi semplici
            if '..' in subfolder or '/' in subfolder or '\\' in subfolder:
                raise HTTPException(status_code=400, detail="Invalid subfolder")
            output_dir = output_dir / subfolder
        file_path = output_dir / filename

        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"File {filename} non trovato")
            
        path_str = str(file_path.absolute())
        
        if os.name == 'nt': # Windows
            os.startfile(path_str)
        else: # macOS/Linux
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])

        return {"success": True, "message": f"File {filename} aperto"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
