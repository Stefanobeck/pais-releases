"""Debug: re-run one prompt that we suspect has implicit filter, with INFO
logging enabled so we can see the actual SQL generated."""
import asyncio, logging, sys, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[3]
INP = ROOT / "test_runs" / "manipulate_20260512_full" / "inputs" / "logistica.xlsx"


async def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    for nm in ("httpx", "httpcore", "ollama"):
        logging.getLogger(nm).setLevel(logging.WARNING)

    from services.manipulate_service import ManipulateService, _detect_implicit_filters
    svc = ManipulateService()

    session_id = f"debug-impl-{uuid.uuid4().hex[:6]}"
    await svc.upload_file(str(INP), INP.name, session_id, mode="Export to Sheet")
    await svc.memorize_files(session_id, mode="Export to Sheet")

    prompt = "Ottimizzare la distribuzione dei pacchi tra i magazzini di partenza analizzando i tempi di consegna e i costi associati a ciascun punto di origine"
    print(f"\n=== PROMPT: {prompt} ===\n", flush=True)

    final_msg = None
    sql_captured = []

    class SqlCapture(logging.Handler):
        def emit(self, record):
            try:
                m = record.getMessage()
            except Exception:
                return
            if "SQL generato e sanitizzato" in m:
                sql_captured.append(m)

    sql_cap = SqlCapture()
    logging.getLogger("services.manipulate_service").addHandler(sql_cap)

    async for ok, msg, files in svc.analyze(query=prompt, session_id=session_id, mode="Export to Sheet"):
        final_msg = msg

    logging.getLogger("services.manipulate_service").removeHandler(sql_cap)

    print(f"\nCAPTURED SQL(s):")
    for i, s in enumerate(sql_captured):
        # Get just the SQL (first 1000 chars from after the marker)
        idx = s.find("SQL generato e sanitizzato:")
        if idx >= 0:
            txt = s[idx + len("SQL generato e sanitizzato:"):].strip()
            print(f"\n--- Attempt {i+1} ---")
            print(txt[:2000])
            # Test detector
            filters = _detect_implicit_filters(prompt, txt)
            print(f"\n>>> _detect_implicit_filters({prompt[:30]!r}, sql): {filters}")


if __name__ == "__main__":
    asyncio.run(main())
