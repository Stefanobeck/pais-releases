"""
HTTP API for the BATCH module.

Endpoints:
  POST   /api/batch/add          → snapshot files + queue a new item
  GET    /api/batch/list         → list queued items (optionally filtered)
  DELETE /api/batch/item/{id}    → remove a pending item
  POST   /api/batch/execute      → start sequential execution of the queue
  POST   /api/batch/stop         → request graceful stop after current item
  GET    /api/batch/status       → executor state + progress (UI polling)
  GET    /api/batch/history      → past executions (folder, counts, timestamps)
"""
from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel

from backend_config.auth_pro import require_pro_or_trial
from services.batch_queue_service import (
    STATUS_PENDING,
    get_batch_queue_service,
)
from services.batch_executor import get_batch_executor

logger = logging.getLogger(__name__)
# Gate PRO-only: BATCH executor richiede pro/free_trial.
router = APIRouter(dependencies=[Depends(require_pro_or_trial)])


# ─── Schemas ──────────────────────────────────────────────────────────────────


class BatchSnapshot(BaseModel):
    """Mirror of the per-module settings frozen at "Add to Batch" time."""
    model: Optional[str] = None
    profile: Optional[str] = None
    direct_mode: Optional[bool] = None
    # Vision-specific (currently same as `model`, kept for forward-compat):
    vision_model: Optional[str] = None
    # Output formatting: 'plain' (default) or 'studio' — the latter renders
    # the DOCX with the studio-identity branded header/footer (logo, name,
    # address, phone, email, VAT, ...) read from user_settings at execution time.
    export_style: Optional[str] = None  # 'plain' | 'studio'


class AddBatchRequest(BaseModel):
    """Payload for `POST /api/batch/add`. Files are referenced by NAME only —
    the backend resolves them by looking under the project's per-module
    uploads folder (`<project>/uploads/<module>/`). This avoids exposing
    absolute paths to the frontend and is robust against project moves.
    """
    module: str  # interrogate | vision | manipulate_charts | manipulate_style
    prompt: str = ""
    snapshot: BatchSnapshot
    file_names: List[str] = []  # plain filenames relative to the module's uploads dir


class BatchItemOut(BaseModel):
    id: str
    module: str
    status: str
    created_at: str
    prompt: str
    snapshot: Dict[str, Any]
    snapshot_folder: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


# ─── Routes ───────────────────────────────────────────────────────────────────


def _resolve_module_upload_folder(module: str) -> Path:
    """Map a batch module id to the project's per-module uploads folder."""
    from backend_config.project_manager import project_manager
    if not project_manager.active_project_path:
        raise RuntimeError("No active project")
    uploads = project_manager.get_path("uploads")
    if module == "manipulate_sheet":
        return uploads / "manipulate"
    return uploads / module  # interrogate, vision


@router.post("/add")
async def add_batch_item(req: AddBatchRequest):
    """Snapshot the request and append to the queue. Returns the created item."""
    try:
        upload_dir = _resolve_module_upload_folder(req.module)
        # Resolve filename → absolute path. Skip silently any name that
        # doesn't exist (the snapshot will record only what was actually
        # copyable; the caller sees the final list in the returned item).
        source_paths: List[Path] = []
        for name in (req.file_names or []):
            p = upload_dir / name
            if p.exists() and p.is_file():
                source_paths.append(p)
            else:
                logger.warning(f"Batch add: file '{name}' not found in {upload_dir}")

        queue = get_batch_queue_service()
        item = queue.add_item(
            module=req.module,
            prompt=req.prompt,
            snapshot=req.snapshot.model_dump(exclude_none=True),
            source_files=source_paths,
        )
        return {"status": "success", "item": item}
    except ValueError as ve:
        # Validation / queue-full → return a clean 400.
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"Batch add failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/list")
async def list_batch_items(status: Optional[str] = None):
    """List queued items. `status` query param optionally filters by status."""
    try:
        queue = get_batch_queue_service()
        items = queue.list_items(status=status) if status else queue.list_items()
        return {"status": "success", "items": items, "count": len(items)}
    except Exception as e:
        logger.error(f"Batch list failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/item/{batch_id}")
async def remove_batch_item(batch_id: str):
    """Remove an item from the queue. Refuses if the item is currently running."""
    try:
        queue = get_batch_queue_service()
        ok = queue.remove_item(batch_id)
        if not ok:
            raise HTTPException(status_code=404, detail="Item not found or running")
        return {"status": "success", "id": batch_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Batch remove failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/execute")
async def execute_batch():
    """Start sequential execution of all pending items. The actual work runs
    in the background; the caller polls /status for progress.
    """
    try:
        executor = get_batch_executor()
        result = await executor.start()
        if not result.get("started"):
            raise HTTPException(status_code=409, detail=result.get("reason", "Cannot start"))
        return {"status": "success", **result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Batch execute failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_batch():
    """Request a graceful stop after the current item finishes."""
    try:
        executor = get_batch_executor()
        executor.request_stop()
        return {"status": "success", "state": executor.state}
    except Exception as e:
        logger.error(f"Batch stop failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status")
async def batch_status():
    """Executor state + progress (for UI polling during execution)."""
    try:
        executor = get_batch_executor()
        return executor.get_status()
    except Exception as e:
        logger.error(f"Batch status failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history")
async def batch_history():
    """List past executions."""
    try:
        queue = get_batch_queue_service()
        return {"status": "success", "executions": queue.list_executions()}
    except Exception as e:
        logger.error(f"Batch history failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class OpenFolderRequest(BaseModel):
    """Open a batch-related folder in the OS file manager.

    The path is validated against the active project's `output/` directory —
    we refuse to open anything outside it. Used by the UI to reveal the
    execution folder of a completed/failed batch item.
    """
    path: str


@router.post("/open-folder")
async def open_batch_folder(req: OpenFolderRequest):
    """Reveal a batch execution folder in the OS file manager (Explorer on
    Windows, Finder on macOS, xdg-open on Linux). The requested path must
    sit inside the active project's `output/` tree — any traversal attempt
    is rejected.
    """
    import os
    import subprocess
    from backend_config.project_manager import project_manager

    if not project_manager.active_project_path:
        raise HTTPException(status_code=400, detail="No active project")

    try:
        target = Path(req.path).resolve()
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid path: {e}")

    # Safety: only allow paths inside <project>/output/.
    output_root = project_manager.get_path("output").resolve()
    try:
        target.relative_to(output_root)
    except ValueError:
        raise HTTPException(status_code=403, detail="Path outside project output folder")

    if not target.exists():
        raise HTTPException(status_code=404, detail="Folder not found")
    if target.is_file():
        target = target.parent

    try:
        path_str = str(target)
        if os.name == "nt":
            os.startfile(path_str)
        elif os.uname().sysname == "Darwin":
            subprocess.call(["open", path_str])
        else:
            subprocess.call(["xdg-open", path_str])
        return {"status": "success", "path": path_str}
    except Exception as e:
        logger.error(f"Batch open-folder failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
