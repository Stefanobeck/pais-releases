"""Vault Backup Service.

Manages snapshot copies of the per-project privacy_vault.sqlite under
`<project>/db/backups/vault_YYYYMMDD.sqlite`. The vault contains the
placeholder ↔ original mapping (e.g. `[DFT-PERS-3]` → `Mario Rossi`)
produced by Anonimyze; losing it makes every previously-exported
anonymized document irreversibly unreadable. The user should never
have to think about this — the backup runs weekly on its own.

Features:
  - `maybe_run_weekly_backup()` → invoked at backend boot and after
    every project switch. Rolling window of 4 snapshots (≈ 1 month).
  - Per-project export to zip (privacy_vault.sqlite + README.txt) and
    import from zip for migration / disaster recovery.
  - Global export-all bundles the vault of every project into a single
    zip with a `manifest.json`, so a user moving to a new PC can carry
    a single file.
  - Restore from a specific local backup (the user picks one of the 4
    automatic snapshots via the UI).
"""
from __future__ import annotations

import io
import json
import logging
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)

VAULT_FILENAME = "privacy_vault.sqlite"
BACKUP_DIRNAME = "backups"
ROLLING_KEEP = 4               # automatic snapshots to retain per project
MIN_BACKUP_INTERVAL_DAYS = 7   # weekly cadence

README_SINGLE = """PAI Premium — Privacy Vault Backup
================================================

This zip contains a snapshot of the privacy_vault.sqlite for the PAI
project that produced it. The vault maps anonymized placeholders
(e.g. [DFT-PERS-3]) back to the original text (e.g. "Mario Rossi").

WITHOUT THIS FILE, any document anonymized with PAI is irreversibly
unreadable — the placeholders become meaningless tokens.

How to restore on a fresh PAI install:
  1. Open PAI → Settings → Privacy Vault → Importa backup
  2. Select this .zip file
  3. The vault of the matching project (see manifest.json below) is
     replaced. Confirm and you're done.

Manual restore (if PAI is broken):
  Replace the file located at
    ~/Documents/PAI_Files/projects/<project>/db/privacy_vault.sqlite
  with the privacy_vault.sqlite extracted from this zip.

Project info:  {project_info}
Generated:     {timestamp}
"""


@dataclass
class BackupInfo:
    filename: str          # e.g. "vault_2026-05-13.sqlite"
    date_iso: str          # "2026-05-13"
    size_bytes: int


class VaultBackupService:
    """All operations are project-aware. `project_manager` is injected at
    construction so we don't import it directly (avoids circular imports
    in main.py lifespan)."""

    def __init__(self, project_manager) -> None:
        self.pm = project_manager

    # ─────────────────────────────────────────────────────────────────
    # Internal path helpers
    # ─────────────────────────────────────────────────────────────────
    def _vault_path(self, project_folder: Optional[str] = None) -> Path:
        """Return the live vault path for `project_folder` (or the active
        project if None)."""
        if project_folder is None:
            if not self.pm.active_project_path:
                raise RuntimeError("No active project")
            return self.pm.active_project_path / "db" / VAULT_FILENAME
        return self.pm.PROJECTS_ROOT_DIR / project_folder / "db" / VAULT_FILENAME

    def _backup_dir(self, project_folder: Optional[str] = None) -> Path:
        """Return the backup directory for `project_folder`, ensuring it
        exists."""
        vault = self._vault_path(project_folder)
        backup_dir = vault.parent / BACKUP_DIRNAME
        backup_dir.mkdir(parents=True, exist_ok=True)
        return backup_dir

    def _project_info(self, project_folder: str) -> dict:
        """Pull display name + short_id from the project_config.json."""
        cfg_path = self.pm.PROJECTS_ROOT_DIR / project_folder / "project_config.json"
        if cfg_path.exists():
            try:
                return json.loads(cfg_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {"name": project_folder, "short_id": "???"}

    # ─────────────────────────────────────────────────────────────────
    # 1. Automatic weekly backup (rolling 4)
    # ─────────────────────────────────────────────────────────────────
    def maybe_run_weekly_backup(self, project_folder: Optional[str] = None) -> Optional[Path]:
        """Snapshot the vault if ≥ 7 days have passed since the most recent
        backup. Returns the new backup path, or None if skipped/failed.

        Should be called:
          - at backend boot (lifespan startup)
          - right after every project switch (so the freshly-active
            project gets a backup even if the user rarely reboots)
        """
        try:
            vault = self._vault_path(project_folder)
        except RuntimeError:
            return None
        if not vault.exists():
            # No anonimyze done yet on this project → nothing to back up
            return None

        backup_dir = self._backup_dir(project_folder)
        existing = self._list_backup_files(backup_dir)

        if existing:
            most_recent_date = self._date_from_filename(existing[0].name)
            if most_recent_date:
                age_days = (date.today() - most_recent_date).days
                if age_days < MIN_BACKUP_INTERVAL_DAYS:
                    logger.debug(
                        "Vault backup skipped — last backup %d days old (< %d)",
                        age_days, MIN_BACKUP_INTERVAL_DAYS,
                    )
                    return None

        # Take the snapshot
        today = date.today().isoformat()
        new_file = backup_dir / f"vault_{today}.sqlite"
        try:
            shutil.copy2(vault, new_file)
        except Exception as e:
            logger.warning("Vault backup copy failed: %s", e)
            return None
        logger.info("🔐 Vault backup created: %s", new_file)

        # Rolling: keep only the most recent ROLLING_KEEP
        self._prune_old_backups(backup_dir)
        return new_file

    def _list_backup_files(self, backup_dir: Path) -> List[Path]:
        """Return backup files sorted newest first."""
        if not backup_dir.exists():
            return []
        files = [p for p in backup_dir.glob("vault_*.sqlite") if p.is_file()]
        files.sort(key=lambda p: p.name, reverse=True)
        return files

    @staticmethod
    def _date_from_filename(name: str) -> Optional[date]:
        # name like "vault_2026-05-13.sqlite"
        try:
            stem = name.replace("vault_", "").replace(".sqlite", "")
            return datetime.strptime(stem, "%Y-%m-%d").date()
        except Exception:
            return None

    def _prune_old_backups(self, backup_dir: Path) -> None:
        files = self._list_backup_files(backup_dir)
        for old in files[ROLLING_KEEP:]:
            try:
                old.unlink()
                logger.debug("Pruned old vault backup: %s", old)
            except Exception as e:
                logger.warning("Failed to prune %s: %s", old, e)

    # ─────────────────────────────────────────────────────────────────
    # 2. List + restore of automatic backups
    # ─────────────────────────────────────────────────────────────────
    def list_project_backups(self, project_folder: Optional[str] = None) -> List[BackupInfo]:
        backup_dir = self._backup_dir(project_folder)
        out: List[BackupInfo] = []
        for f in self._list_backup_files(backup_dir):
            d = self._date_from_filename(f.name)
            out.append(BackupInfo(
                filename=f.name,
                date_iso=d.isoformat() if d else "",
                size_bytes=f.stat().st_size,
            ))
        return out

    def restore_project_backup(
        self, backup_filename: str, project_folder: Optional[str] = None
    ) -> bool:
        backup_dir = self._backup_dir(project_folder)
        src = backup_dir / backup_filename
        if not src.exists() or not src.is_file():
            logger.warning("Restore failed — backup not found: %s", src)
            return False
        try:
            vault = self._vault_path(project_folder)
            vault.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, vault)
            logger.info("🔐 Vault restored from %s", src)
            return True
        except Exception as e:
            logger.error("Vault restore failed: %s", e)
            return False

    # ─────────────────────────────────────────────────────────────────
    # 3. Export / Import single project
    # ─────────────────────────────────────────────────────────────────
    def export_project_vault(self, project_folder: Optional[str] = None) -> Optional[Path]:
        """Build a zip with privacy_vault.sqlite + README.txt and return
        its path (in a temp dir). Caller is responsible for serving it
        and cleaning up."""
        vault = self._vault_path(project_folder)
        if not vault.exists():
            return None
        info = self._project_info(project_folder or self.pm.active_project_name)
        out_dir = Path(tempfile.mkdtemp(prefix="pais_vault_export_"))
        out_zip = out_dir / f"pais_vault_{info.get('short_id','XXX')}_{date.today().isoformat()}.zip"
        with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(vault, VAULT_FILENAME)
            readme = README_SINGLE.format(
                project_info=json.dumps(info, ensure_ascii=False),
                timestamp=datetime.now().isoformat(timespec="seconds"),
            )
            zf.writestr("README.txt", readme)
            manifest = {
                "kind": "pais_vault_single",
                "project_folder": project_folder or self.pm.active_project_name,
                "project_info": info,
                "exported_at": datetime.now().isoformat(timespec="seconds"),
            }
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        return out_zip

    def import_vault(self, uploaded_zip: bytes, project_folder: Optional[str] = None) -> bool:
        """Restore the vault of `project_folder` (or the active project)
        from a single-project zip produced by `export_project_vault`."""
        try:
            with zipfile.ZipFile(io.BytesIO(uploaded_zip)) as zf:
                if VAULT_FILENAME not in zf.namelist():
                    logger.warning("Import vault: %s missing in zip", VAULT_FILENAME)
                    return False
                vault_bytes = zf.read(VAULT_FILENAME)
                vault = self._vault_path(project_folder)
                vault.parent.mkdir(parents=True, exist_ok=True)
                vault.write_bytes(vault_bytes)
                logger.info("🔐 Vault imported to %s (%d bytes)", vault, len(vault_bytes))
                return True
        except Exception as e:
            logger.error("Vault import failed: %s", e)
            return False

    # ─────────────────────────────────────────────────────────────────
    # 4. Export / Import all projects (global migration)
    # ─────────────────────────────────────────────────────────────────
    def export_all_vaults(self) -> Optional[Path]:
        """Build a zip with one folder per project containing its vault,
        plus a `manifest.json` listing them. Skips projects with no vault
        yet (Anonimyze never used)."""
        out_dir = Path(tempfile.mkdtemp(prefix="pais_vault_export_all_"))
        out_zip = out_dir / f"pais_vault_all_{date.today().isoformat()}.zip"
        included: list[dict] = []
        skipped: list[str] = []
        with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for project in self.pm.list_projects():
                folder = project["folder"]
                vault = self._vault_path(folder)
                if not vault.exists():
                    skipped.append(folder)
                    continue
                arcname = f"{folder}/{VAULT_FILENAME}"
                zf.write(vault, arcname)
                included.append({
                    "folder": folder,
                    "name": project.get("name", folder),
                    "short_id": project.get("short_id", ""),
                    "size_bytes": vault.stat().st_size,
                })
            manifest = {
                "kind": "pais_vault_all",
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "included": included,
                "skipped": skipped,
            }
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            zf.writestr("README.txt", README_SINGLE.format(
                project_info=f"ALL projects ({len(included)} vaults)",
                timestamp=datetime.now().isoformat(timespec="seconds"),
            ))
        if not included:
            # Nothing to back up
            out_zip.unlink(missing_ok=True)
            return None
        return out_zip

    def import_all_vaults(self, uploaded_zip: bytes) -> dict:
        """Restore vaults for every project listed in the zip's manifest.
        Returns a report:
            {restored: [folder, ...], skipped: [{folder, reason}, ...]}
        Skips projects that don't exist locally — the user must create
        them first (we don't auto-create to avoid name collisions)."""
        restored: list[str] = []
        skipped: list[dict] = []
        try:
            with zipfile.ZipFile(io.BytesIO(uploaded_zip)) as zf:
                if "manifest.json" not in zf.namelist():
                    return {"error": "Missing manifest.json", "restored": [], "skipped": []}
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
                if manifest.get("kind") != "pais_vault_all":
                    return {"error": "Not a global vault export", "restored": [], "skipped": []}
                for entry in manifest.get("included", []):
                    folder = entry["folder"]
                    if not (self.pm.PROJECTS_ROOT_DIR / folder).is_dir():
                        skipped.append({"folder": folder, "reason": "project not found locally"})
                        continue
                    arcname = f"{folder}/{VAULT_FILENAME}"
                    if arcname not in zf.namelist():
                        skipped.append({"folder": folder, "reason": "vault missing from zip"})
                        continue
                    try:
                        vault_bytes = zf.read(arcname)
                        target = self._vault_path(folder)
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(vault_bytes)
                        restored.append(folder)
                    except Exception as e:
                        skipped.append({"folder": folder, "reason": str(e)})
                return {"restored": restored, "skipped": skipped}
        except Exception as e:
            logger.error("import_all_vaults failed: %s", e)
            return {"error": str(e), "restored": [], "skipped": []}

    # ─────────────────────────────────────────────────────────────────
    # 5. Status summary (for UI header card)
    # ─────────────────────────────────────────────────────────────────
    def vault_status(self, project_folder: Optional[str] = None) -> dict:
        """Lightweight summary used by the Settings UI to render the
        'Privacy Vault' card. Never raises — returns safe defaults if
        the vault doesn't exist yet."""
        try:
            vault = self._vault_path(project_folder)
        except RuntimeError:
            return {"has_vault": False, "size_bytes": 0, "mappings": 0,
                    "last_backup_iso": None, "backup_count": 0}
        if not vault.exists():
            return {"has_vault": False, "size_bytes": 0, "mappings": 0,
                    "last_backup_iso": None, "backup_count": 0}

        # Count mappings (single SELECT COUNT on the vault sqlite)
        mappings = 0
        try:
            import sqlite3
            conn = sqlite3.connect(vault)
            try:
                row = conn.execute("SELECT COUNT(*) FROM pii_mapping").fetchone()
                mappings = int(row[0]) if row else 0
            finally:
                conn.close()
        except Exception:
            pass

        backups = self.list_project_backups(project_folder)
        last = backups[0].date_iso if backups else None
        return {
            "has_vault": True,
            "size_bytes": vault.stat().st_size,
            "mappings": mappings,
            "last_backup_iso": last,
            "backup_count": len(backups),
        }


def backup_info_to_dict(b: BackupInfo) -> dict:
    return asdict(b)
