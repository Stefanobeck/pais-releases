"""Spot test for Tier 2 (discount + ratio direction glossary) and
Tier 3 (Pearson validity check + no-implicit-filter + no-hallucinated-cols
rules). 12 prompts that previously failed on these patterns.
"""
from __future__ import annotations
import asyncio, json, logging, re, shutil, sys, time, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "test_runs" / "manipulate_20260512_full" / "_spot_test_tier23.json"
INPUTS_DIR = ROOT / "test_runs" / "manipulate_20260512_full" / "inputs"
OUT_DIR = ROOT / "test_runs" / "manipulate_20260513_tier23_spot"
OUT_DIR.mkdir(parents=True, exist_ok=True)


_FAIL_PATTERNS = [
    (re.compile(r"^SQL Execution failed \(Attempt (\d+)\):"), "sql"),
    (re.compile(r"^Dialect Check failed \(Attempt (\d+)\):"), "dialect"),
    (re.compile(r"^Correlation intent missing \(Attempt (\d+)\):"), "corr_intent"),
    (re.compile(r"^Correlation validity failed \(Attempt (\d+)\):"), "corr_validity"),
    (re.compile(r"^Pareto completion failed \(Attempt (\d+)\):"), "pareto"),
    (re.compile(r"^Soft Validation failed \(Attempt (\d+)\):"), "soft"),
]


class CaptureHandler(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.INFO)
        self.entries = []
    def emit(self, record):
        try:
            m = record.getMessage()
        except Exception:
            return
        for rx, kind in _FAIL_PATTERNS:
            if rx.match(m):
                self.entries.append({"kind": kind, "msg": m[:250]})
                return


async def main():
    prompts = json.load(SOURCE.open(encoding="utf-8"))
    print(f"Loaded {len(prompts)} prompts\n", flush=True)

    from services.manipulate_service import ManipulateService
    svc = ManipulateService()
    print(f"model: {svc.models.get('manipulate_model', 'unknown')}\n", flush=True)

    # Group by file
    by_file = {}
    for p in prompts:
        by_file.setdefault(p["file"], []).append(p)

    results = []
    for file_name, entries in by_file.items():
        input_path = INPUTS_DIR / file_name
        if not input_path.exists():
            print(f"INPUT MISSING: {input_path}", flush=True)
            continue
        session_id = f"tier23-{uuid.uuid4().hex[:6]}"
        print(f"\n=== {file_name} (session {session_id}) ===", flush=True)
        up = await svc.upload_file(str(input_path), file_name, session_id, mode="Export to Sheet")
        if up.get("status") not in ("staged", "success"):
            print(f"upload failed: {up}", flush=True); continue
        mem = await svc.memorize_files(session_id, mode="Export to Sheet")
        if mem.get("status") != "success":
            print(f"memorize failed: {mem}", flush=True); continue

        for p in entries:
            print(f"\n[{p['area']} / {p['level']}] src={p['source']}#{p['src_idx']}", flush=True)
            print(f"  prompt: {p['prompt'][:140]!r}", flush=True)
            cap = CaptureHandler()
            svc_logger = logging.getLogger("services.manipulate_service")
            svc_logger.addHandler(cap)
            t0 = time.time()
            produced = None
            try:
                async for ok, msg, files in svc.analyze(query=p['prompt'], session_id=session_id, mode="Export to Sheet"):
                    if files:
                        produced = files[0]
            except Exception as e:
                print(f"  EXC: {e}", flush=True)
            finally:
                svc_logger.removeHandler(cap)
            dt = time.time() - t0
            ok = produced is not None
            print(f"  → {'OK ' if ok else 'FAIL'} ({dt:.1f}s, retries={len(cap.entries)})", flush=True)
            kinds = [e["kind"] for e in cap.entries]
            if kinds:
                print(f"     retry-kinds: {kinds}", flush=True)
            if ok and produced:
                safe = re.sub(r"[^\w\-]+", "_", f"{p['source']}_{p['src_idx']}").strip("_")
                target = OUT_DIR / f"{safe}.xlsx"
                for src in [Path(produced), *(Path.home() / "Documents" / "PAI_Files").rglob(Path(produced).name)]:
                    if src.exists():
                        try:
                            shutil.copy2(src, target)
                            break
                        except Exception:
                            pass
            results.append({
                "source": p["source"], "src_idx": p["src_idx"],
                "file": p["file"], "area": p["area"], "level": p["level"],
                "prompt": p["prompt"], "ok": ok, "duration_s": round(dt, 2),
                "retries": len(cap.entries), "retry_kinds": kinds,
            })
        try:
            svc.clear_session(session_id)
        except Exception:
            pass

    (OUT_DIR / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    n_ok = sum(1 for r in results if r["ok"])
    # Retry kind breakdown
    kind_count = {}
    for r in results:
        for k in r["retry_kinds"]:
            kind_count[k] = kind_count.get(k, 0) + 1
    print(f"\n{'='*80}\nSUMMARY: {n_ok}/{len(results)} OK\nRetry breakdown: {kind_count}\n{'='*80}", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
