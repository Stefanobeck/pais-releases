"""
Generate a synthetic HR dataset (xlsx) loaded with realistic EU PII.

Purpose: feed the Anonimyze module with a realistic test file so we can:
  1. Anonymize → push to Claude/Gemini for complex analysis
  2. Receive AI output back → deanonymize and verify identities are restored

Mix of IT/DE/FR identities to exercise the multilang ONNX NER engine.
"""

import random
import string
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)  # reproducible runs

ROWS = 100
# Locale weights — only locales the NER engine fully covers.
# DE Steuer-ID and FR NIR are not yet recognized → keep 0 to avoid PII leaks.
LOCALE_WEIGHTS = {"IT": 1.0, "DE": 0.0, "FR": 0.0}
OUT_DIR = Path(__file__).resolve().parents[2] / "test_formats"
OUT_PATH = OUT_DIR / "test_hr_dataset.xlsx"

# ---------- name pools ----------
IT_FIRST = ["Marco", "Giulia", "Luca", "Sofia", "Alessandro", "Chiara", "Matteo", "Francesca",
            "Davide", "Elena", "Andrea", "Martina", "Lorenzo", "Valentina", "Simone", "Beatrice"]
IT_LAST = ["Rossi", "Bianchi", "Romano", "Ferrari", "Esposito", "Russo", "Conti", "Galli",
           "De Luca", "Greco", "Marini", "Costa", "Ricci", "Bruno", "Gallo", "Lombardi"]

DE_FIRST = ["Hans", "Anna", "Klaus", "Julia", "Stefan", "Petra", "Thomas", "Sabine",
            "Michael", "Birgit", "Andreas", "Kerstin", "Wolfgang", "Heike"]
DE_LAST = ["Müller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner",
           "Becker", "Schulz", "Hoffmann", "Schäfer", "Koch", "Bauer", "Richter"]

FR_FIRST = ["Pierre", "Marie", "Jean", "Camille", "Antoine", "Léa", "Nicolas", "Emma",
            "Julien", "Chloé", "Maxime", "Sarah", "Hugo", "Manon"]
FR_LAST = ["Dubois", "Laurent", "Martin", "Bernard", "Petit", "Robert", "Richard",
           "Durand", "Moreau", "Fournier", "Girard", "Roux", "Vincent", "Lefèvre"]

# ---------- geo pools ----------
IT_CITIES = [("Milano", "20121", "MI"), ("Roma", "00184", "RM"), ("Torino", "10121", "TO"),
             ("Bologna", "40121", "BO"), ("Napoli", "80121", "NA"), ("Firenze", "50121", "FI")]
DE_CITIES = [("Berlin", "10115", "BE"), ("München", "80331", "BY"), ("Hamburg", "20095", "HH"),
             ("Frankfurt", "60311", "HE"), ("Köln", "50667", "NW"), ("Stuttgart", "70173", "BW")]
FR_CITIES = [("Paris", "75001", "75"), ("Lyon", "69001", "69"), ("Marseille", "13001", "13"),
             ("Toulouse", "31000", "31"), ("Nice", "06000", "06"), ("Bordeaux", "33000", "33")]

IT_STREETS = ["Via Roma", "Via Garibaldi", "Corso Italia", "Via Manzoni", "Piazza Duomo", "Viale Europa"]
DE_STREETS = ["Hauptstraße", "Bahnhofstraße", "Goethestraße", "Schillerstraße", "Lindenallee"]
FR_STREETS = ["Rue de la Paix", "Avenue des Champs", "Boulevard Haussmann", "Rue Lafayette", "Rue Victor Hugo"]

DEPARTMENTS = ["Engineering", "Sales", "Marketing", "HR", "Finance", "Operations", "Legal", "R&D", "Customer Success"]
JOB_TITLES = {
    "Engineering": ["Software Engineer", "Senior SWE", "Tech Lead", "Engineering Manager", "DevOps Engineer"],
    "Sales": ["Account Executive", "Sales Manager", "Key Account Manager", "BDR"],
    "Marketing": ["Marketing Specialist", "Brand Manager", "Content Strategist", "Growth Lead"],
    "HR": ["HR Business Partner", "Recruiter", "HR Director", "People Ops"],
    "Finance": ["Financial Analyst", "Controller", "CFO", "Accountant"],
    "Operations": ["Operations Manager", "Supply Chain Specialist", "Logistics Coord."],
    "Legal": ["Legal Counsel", "Paralegal", "Compliance Officer"],
    "R&D": ["Research Scientist", "Data Scientist", "ML Engineer"],
    "Customer Success": ["CS Manager", "CS Specialist", "Onboarding Lead"],
}
CONTRACT_TYPES = ["Permanent", "Fixed-term", "Internship", "Consultant"]
OFFICES = ["Milano HQ", "Berlin Office", "Paris Office", "Remote", "Hybrid-Milano", "Hybrid-Berlin"]
BANKS_IT = ["Intesa Sanpaolo", "UniCredit", "Banco BPM", "BPER Banca"]
BANKS_DE = ["Deutsche Bank", "Commerzbank", "Sparkasse", "DKB"]
BANKS_FR = ["BNP Paribas", "Société Générale", "Crédit Agricole", "LCL"]

LANGS = ["IT", "EN", "DE", "FR", "ES"]
RATINGS = [1, 2, 3, 4, 5]


# ---------- ID generators ----------
def codice_fiscale(first: str, last: str, dob: date, sex: str = "M") -> str:
    cons = lambda s: "".join(c for c in s.upper() if c in "BCDFGHJKLMNPQRSTVWXYZ")
    vow = lambda s: "".join(c for c in s.upper() if c in "AEIOU")
    def chunk(s):
        c = cons(s) + vow(s) + "XXX"
        return c[:3]
    months = "ABCDEHLMPRST"
    day = dob.day + (40 if sex == "F" else 0)
    code = chunk(last) + chunk(first) + str(dob.year)[-2:] + months[dob.month - 1] + f"{day:02d}"
    code += "H501"  # Roma placeholder
    code += random.choice(string.ascii_uppercase)
    return code


def steuer_id() -> str:
    return "".join(random.choices(string.digits, k=11))


def nir_fr(dob: date, sex: str = "M") -> str:
    s = "1" if sex == "M" else "2"
    yy = f"{dob.year % 100:02d}"
    mm = f"{dob.month:02d}"
    dept = f"{random.randint(1, 95):02d}"
    town = f"{random.randint(1, 999):03d}"
    serial = f"{random.randint(1, 999):03d}"
    key = f"{random.randint(1, 97):02d}"
    return f"{s} {yy} {mm} {dept} {town} {serial} {key}"


def iban_it() -> str:
    cin = random.choice(string.ascii_uppercase)
    abi = "".join(random.choices(string.digits, k=5))
    cab = "".join(random.choices(string.digits, k=5))
    acc = "".join(random.choices(string.digits, k=12))
    return f"IT{random.randint(10,99)}{cin}{abi}{cab}{acc}"


def iban_de() -> str:
    blz = "".join(random.choices(string.digits, k=8))
    acc = "".join(random.choices(string.digits, k=10))
    return f"DE{random.randint(10,99)}{blz}{acc}"


def iban_fr() -> str:
    bank = "".join(random.choices(string.digits, k=5))
    branch = "".join(random.choices(string.digits, k=5))
    acc = "".join(random.choices(string.ascii_uppercase + string.digits, k=11))
    key = "".join(random.choices(string.digits, k=2))
    return f"FR{random.randint(10,99)}{bank}{branch}{acc}{key}"


def phone_it() -> str:
    return f"+39 0{random.randint(2,9)} {random.randint(1000000,9999999)}"


def mobile_it() -> str:
    return f"+39 3{random.randint(20,99)} {random.randint(1000000,9999999)}"


def phone_de() -> str:
    return f"+49 {random.randint(30,89)} {random.randint(1000000,9999999)}"


def mobile_de() -> str:
    return f"+49 1{random.randint(50,79)} {random.randint(10000000,99999999)}"


def phone_fr() -> str:
    return f"+33 1 {random.randint(10,99)} {random.randint(10,99)} {random.randint(10,99)} {random.randint(10,99)}"


def mobile_fr() -> str:
    return f"+33 6 {random.randint(10,99)} {random.randint(10,99)} {random.randint(10,99)} {random.randint(10,99)}"


def random_dob(min_age=22, max_age=62) -> date:
    today = date.today()
    age = random.randint(min_age, max_age)
    return today - timedelta(days=age * 365 + random.randint(0, 364))


def random_hire_date() -> date:
    today = date.today()
    return today - timedelta(days=random.randint(60, 365 * 18))


# ---------- per-locale builder ----------
def build_person(idx: int) -> dict:
    locales = list(LOCALE_WEIGHTS.keys())
    weights = [LOCALE_WEIGHTS[k] for k in locales]
    locale = random.choices(locales, weights=weights)[0]
    sex = random.choice(["M", "F"])
    dob = random_dob()
    hire = random_hire_date()

    if locale == "IT":
        fn = random.choice(IT_FIRST); ln = random.choice(IT_LAST)
        city, cap, prov = random.choice(IT_CITIES)
        street = f"{random.choice(IT_STREETS)} {random.randint(1,200)}"
        country = "Italia"
        tax_id = codice_fiscale(fn, ln, dob, sex)
        iban = iban_it(); bank = random.choice(BANKS_IT)
        phone = phone_it(); mobile = mobile_it()
        domain = "azienda.it"
    elif locale == "DE":
        fn = random.choice(DE_FIRST); ln = random.choice(DE_LAST)
        city, cap, prov = random.choice(DE_CITIES)
        street = f"{random.choice(DE_STREETS)} {random.randint(1,200)}"
        country = "Deutschland"
        tax_id = steuer_id()
        iban = iban_de(); bank = random.choice(BANKS_DE)
        phone = phone_de(); mobile = mobile_de()
        domain = "firma.de"
    else:
        fn = random.choice(FR_FIRST); ln = random.choice(FR_LAST)
        city, cap, prov = random.choice(FR_CITIES)
        street = f"{random.randint(1,200)} {random.choice(FR_STREETS)}"
        country = "France"
        tax_id = nir_fr(dob, sex)
        iban = iban_fr(); bank = random.choice(BANKS_FR)
        phone = phone_fr(); mobile = mobile_fr()
        domain = "societe.fr"

    dept = random.choice(DEPARTMENTS)
    role = random.choice(JOB_TITLES[dept])
    contract = random.choice(CONTRACT_TYPES)
    rating = random.choice(RATINGS)
    kpi = random.randint(40, 99)
    salary = random.randint(28000, 120000)
    bonus = round(salary * random.uniform(0.0, 0.25))
    years = max(0, (date.today() - hire).days // 365)
    langs_spoken = random.sample(LANGS, k=random.randint(1, 3))

    # Free-text cross-references — keep them in the same locale pools that are active,
    # otherwise we reintroduce the international trap inside the notes.
    active = [k for k, w in LOCALE_WEIGHTS.items() if w > 0]
    pool_first = sum(([IT_FIRST, DE_FIRST, FR_FIRST][["IT","DE","FR"].index(k)] for k in active), [])
    pool_last = sum(([IT_LAST, DE_LAST, FR_LAST][["IT","DE","FR"].index(k)] for k in active), [])
    pool_phone = [{"IT": phone_it, "DE": phone_de, "FR": phone_fr}[k] for k in active]

    peer_first = random.choice(pool_first)
    peer_last = random.choice(pool_last)
    peer_email = f"{peer_first.lower()}.{peer_last.lower().replace(' ', '')}@{domain}"
    peer_phone = random.choice(pool_phone)()

    manager_first = random.choice(pool_first)
    manager_last = random.choice(pool_last)
    manager_email = f"{manager_first.lower()}.{manager_last.lower().replace(' ', '')}@{domain}"

    hr_first = random.choice(pool_first); hr_last = random.choice(pool_last)
    cfo_first = random.choice(pool_first); cfo_last = random.choice(pool_last)

    notes = random.choice([
        f"Reports to {manager_first} {manager_last} ({manager_email}). Strong technical skills, candidate for promotion in Q4 2026.",
        f"Performance review held on {hire + timedelta(days=365):%Y-%m-%d} with HR partner {hr_first} {hr_last} ({hr_first.lower()}.{hr_last.lower().replace(' ', '')}@{domain}). Compensation revised.",
        f"On parental leave until {date.today() + timedelta(days=120):%Y-%m-%d}. Replacement: {peer_first} {peer_last}, contact {peer_phone}.",
        f"Disciplinary note 2025-11-03: late submission of expense report. Discussed with manager {manager_last}.",
        f"Top performer Q1 2026. Bonus approved by CFO {cfo_first} {cfo_last} ({cfo_first.lower()}.{cfo_last.lower().replace(' ', '')}@{domain}).",
        "No open issues. Engaged and proactive. Volunteered for diversity committee.",
    ])
    feedback = random.choice([
        f"Excellent collaborator. Mentored junior {peer_first} {peer_last} in Q2.",
        f"Needs to improve communication with cross-functional teams. Coaching by {manager_first}.",
        "Domain expert. Goes the extra mile. Frequent positive client feedback.",
        f"Conflict reported by peer {peer_first} {peer_last} on 2026-02-14, resolved via mediation.",
        "Highly engaged. Drives team morale.",
    ])
    goals = random.choice([
        "Become Tech Lead within 18 months. Take ownership of the data platform migration.",
        "Complete MBA at Bocconi by 2027. Move into product management.",
        f"Relocate to {random.choice(['Berlin', 'Paris', 'Milano'])} office by end of 2026.",
        "Expand client portfolio in DACH region. Exceed 1.5M€ ARR.",
        "Lead the GDPR compliance refresh project.",
    ])

    return {
        "employee_id": f"EMP-{idx:04d}",
        "first_name": fn,
        "last_name": ln,
        "sex": sex,
        "date_of_birth": dob.isoformat(),
        "nationality": country,
        "tax_id": tax_id,
        "email_corporate": f"{fn.lower()}.{ln.lower().replace(' ', '')}@{domain}",
        "email_personal": f"{fn.lower()}{random.randint(70,99)}@{random.choice(['gmail.com','yahoo.it','outlook.com','protonmail.com'])}",
        "phone_office": phone,
        "mobile_phone": mobile,
        "address": street,
        "city": city,
        "postal_code": cap,
        "province_state": prov,
        "country": country,
        "department": dept,
        "job_title": role,
        "manager_name": f"{manager_first} {manager_last}",
        "manager_email": manager_email,
        "hire_date": hire.isoformat(),
        "contract_type": contract,
        "office_location": random.choice(OFFICES),
        "badge_number": f"BDG-{random.randint(10000,99999)}",
        "base_salary_eur": salary,
        "annual_bonus_eur": bonus,
        "iban": iban,
        "bank_name": bank,
        "last_review_rating": rating,
        "kpi_score": kpi,
        "languages_spoken": ", ".join(langs_spoken),
        "years_in_company": years,
        "manager_notes": notes,
        "peer_feedback": feedback,
        "career_goals": goals,
    }


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = [build_person(i + 1) for i in range(ROWS)]
    df = pd.DataFrame(rows)

    with pd.ExcelWriter(OUT_PATH, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Employees", index=False)

        # Tiny lookup sheet — useful for cross-sheet analyses
        dept_summary = (df.groupby("department")
                          .agg(headcount=("employee_id", "count"),
                               avg_salary=("base_salary_eur", "mean"),
                               avg_kpi=("kpi_score", "mean"))
                          .round(0)
                          .reset_index())
        dept_summary.to_excel(writer, sheet_name="DeptSummary", index=False)

    active = [k for k, w in LOCALE_WEIGHTS.items() if w > 0]
    print(f"OK -> {OUT_PATH}")
    print(f"   {len(df)} rows x {len(df.columns)} cols")
    print(f"   Locales active: {', '.join(active)}")
    print(f"   PII fields: name, email, phone, tax_id, iban, address, free-text notes with embedded PII")


if __name__ == "__main__":
    main()
