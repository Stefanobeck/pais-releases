"""
Audit Event Logger — append-only JSON-Lines event log for Compliance Reports.

Salva in `output/<active_project>/audit_events.jsonl`. Ogni riga = 1 evento JSON.
Forward-only: gli eventi sopravvivono a clear_session / file_deleted perché l'audit
deve documentare anche le cancellazioni (right-to-be-forgotten trace).

Privacy by design: NESSUN contenuto file/prompt/response viene loggato.
Solo metadata (filename, size, hash, timestamp, model_id, duration, char counts).

Thread-safe via lock interno su append. Errori swallowed (try/except) per non
rompere mai l'operazione utente.
"""

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class AuditEventLogger:
    """Singleton event logger per compliance trace."""

    _instance: Optional["AuditEventLogger"] = None
    _instance_lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._init()
        return cls._instance

    def _init(self):
        self._write_lock = threading.Lock()

    def _get_log_path(self) -> Path:
        """Path di audit_events.jsonl nel progetto attivo. Crea dir se manca."""
        try:
            from backend_config.project_manager import project_manager
            output_dir = project_manager.get_path("output")
        except Exception:
            # Fallback se project_manager non risolve (avvio precoce, no progetto)
            from backend_config.settings import settings
            output_dir = settings.BASE_DIR / "audit_fallback"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir / "audit_events.jsonl"

    def get_path(self) -> Path:
        return self._get_log_path()

    def log(self, module: str, action: str, *, session_id: str = "", **details: Any) -> None:
        """Append un evento al jsonl. Errori solo loggati, mai rilanciati."""
        try:
            event = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "module": module,
                "action": action,
                "session_id": session_id,
                "details": details,
            }
            line = json.dumps(event, ensure_ascii=False, default=str)
            path = self._get_log_path()
            with self._write_lock:
                with open(path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
        except Exception as e:
            logger.warning(f"Audit log append failed (action={action}): {e}")

    def read_all(self) -> List[Dict]:
        """Legge tutti gli eventi del progetto attivo. Eventi corrotti skipped."""
        path = self._get_log_path()
        if not path.exists():
            return []
        events: List[Dict] = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                for raw in f:
                    raw = raw.strip()
                    if not raw:
                        continue
                    try:
                        events.append(json.loads(raw))
                    except json.JSONDecodeError:
                        continue  # skip corrupted entry
        except Exception as e:
            logger.error(f"Audit log read failed: {e}")
        return events


# Singleton globale, importabile dai processor/services
audit_logger = AuditEventLogger()


# ─── Helpers ─────────────────────────────────────────────────────────────

def file_sha256(file_path) -> str:
    """SHA256 hex completo di un file. Ritorna stringa vuota su errore."""
    import hashlib
    try:
        path = Path(file_path) if not isinstance(file_path, Path) else file_path
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception as e:
        logger.warning(f"file_sha256 failed for {file_path}: {e}")
        return ""


def file_metadata(file_path) -> Dict[str, Any]:
    """Metadata sicuri da loggare per un file: filename, size, sha256, mime estimated."""
    try:
        path = Path(file_path) if not isinstance(file_path, Path) else file_path
        size = path.stat().st_size if path.exists() else 0
        return {
            "filename": path.name,
            "size_bytes": size,
            "sha256": file_sha256(path),
            "ext": path.suffix.lower().lstrip("."),
        }
    except Exception:
        return {"filename": str(file_path), "size_bytes": 0, "sha256": "", "ext": ""}
