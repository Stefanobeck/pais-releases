# PAI Premium Backend

FastAPI backend for PAI Premium - Private Artificial Intelligence Suite.

## Quick Start

### 1. Create Virtual Environment

```bash
cd pai-premium/backend
python -m venv venv
venv\Scripts\activate  # Windows
# source venv/bin/activate  # Linux/Mac
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment

```bash
# Copy example env file
copy .env.example .env  # Windows
# cp .env.example .env  # Linux/Mac

# Edit .env and adjust paths if needed
```

### 4. Run Backend

```bash
# Development mode (auto-reload)
python main.py

# Or with uvicorn directly
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

### 5. Test API

Open browser to:
- **API Docs:** http://127.0.0.1:8000/docs
- **Health Check:** http://127.0.0.1:8000/health

## API Endpoints

### Interrogate Module

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/interrogate/chat` | Send chat message |
| POST | `/api/interrogate/upload` | Upload document |
| GET | `/api/interrogate/history/{session_id}` | Get chat history |
| DELETE | `/api/interrogate/history/{session_id}` | Clear history |
| WS | `/ws/interrogate/{session_id}` | WebSocket streaming |

## Project Structure

```
backend/
├── main.py              # FastAPI application entry point
├── config/
│   ├── __init__.py
│   └── settings.py      # Configuration and environment
├── routers/
│   ├── __init__.py
│   └── interrogate.py   # Chat API routes
├── services/            # Business logic (TODO)
├── processors/          # Document processing (TODO)
├── uploads/             # Uploaded files (gitignored)
├── requirements.txt     # Python dependencies
└── .env.example         # Environment template
```

## Development

### Hot Reload

Backend auto-reloads on code changes when run with `--reload`:

```bash
uvicorn main:app --reload
```

### CORS

CORS is configured to allow requests from:
- `http://localhost:5173` (Vite dev server)
- `tauri://localhost` (Tauri production)

Add more origins in `.env`:
```
CORS_ORIGINS=http://localhost:5173,http://other-origin.com
```

## Next Steps

### TODO: Implement Real AI Logic

1. **Copy Processors** from root directory:
   - `processors.py` → `backend/processors/document_processor.py`
   - `smart_router.py` → `backend/services/chat_service.py`

2. **Add RAG Support**:
   - ChromaDB integration
   - Document embeddings
   - Vector search

3. **Add Ollama Integration**:
   - Real chat completions
   - Streaming responses
   - Model selection

4. **Database**:
   - Persistent chat history
   - Document metadata
   - User preferences

## Troubleshooting

### Ollama Not Starting

Check if Ollama is already running:
```bash
netstat -ano | findstr 11435
```

Kill existing process or change port in `.env`.

### Port Already in Use

Change port in `.env`:
```
PORT=8001
```

Update frontend API URL accordingly.

### Import Errors

Make sure virtual environment is activated:
```bash
venv\Scripts\activate
pip install -r requirements.txt
```

## License

Private - All rights reserved
