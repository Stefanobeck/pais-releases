"""One-shot generator dei 4 file di esempio Mail Merge.

Esegue lo stesso codice dell'endpoint vecchio (ora rimosso) ma scrive i
file su disco invece di servirli via HTTP. I file finiscono in
`pai-premium/frontend/public/examples/` e da lì vengono serviti
statici dal Vite/dist (zero round-trip al backend).

Lanciabile manualmente quando si vogliono rigenerare i file:
  ../../venv/Scripts/python.exe scripts/generate_mail_merge_examples.py
"""
import sys
from io import BytesIO
from pathlib import Path

# Assicura che il package backend sia importabile (per riusare le librerie)
sys.path.insert(0, str(Path(__file__).parent.parent))

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment


def make_template(out_path: Path, lang: str):
    is_en = lang == "en"
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # Data + città (allineato a destra)
    p_date = doc.add_paragraph()
    p_date.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_date.add_run("{{città}}, {{data}}" if not is_en else "{{city}}, {{date}}")

    doc.add_paragraph()

    # Destinatario
    doc.add_paragraph("Spettabile" if not is_en else "Dear")
    p_name = doc.add_paragraph()
    run = p_name.add_run("{{nome}} {{cognome}}" if not is_en else "{{first_name}} {{last_name}}")
    run.bold = True

    doc.add_paragraph()

    # Oggetto
    p_subj = doc.add_paragraph()
    run_subj = p_subj.add_run(
        "Oggetto: Conferma ordine n. {{numero_ordine}}"
        if not is_en
        else "Subject: Order confirmation n. {{order_number}}"
    )
    run_subj.bold = True

    doc.add_paragraph()

    # Corpo
    if not is_en:
        doc.add_paragraph("Gentile cliente,")
        doc.add_paragraph(
            "la confermiamo l'avvenuto ricevimento del Suo ordine "
            "n. {{numero_ordine}} per un importo totale di € {{importo}}."
        )
        doc.add_paragraph(
            "Il documento sarà evaso entro 48 ore lavorative dalla data odierna."
        )
        doc.add_paragraph()
        doc.add_paragraph("Cordiali saluti,")
        doc.add_paragraph("La Direzione")
    else:
        doc.add_paragraph("Dear customer,")
        doc.add_paragraph(
            "we confirm the receipt of your order "
            "n. {{order_number}} for a total amount of € {{amount}}."
        )
        doc.add_paragraph(
            "The order will be processed within 48 working hours."
        )
        doc.add_paragraph()
        doc.add_paragraph("Kind regards,")
        doc.add_paragraph("Management")

    doc.save(str(out_path))


def make_data(out_path: Path, lang: str):
    is_en = lang == "en"
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Clienti" if not is_en else "Customers"

    if not is_en:
        headers = ["nome", "cognome", "città", "numero_ordine", "importo", "data", "email", "telefono"]
        rows = [
            ["Mario", "Rossi", "Milano", "1001", "250,00", "08/05/2026", "mario.rossi@example.com", "333-1234567"],
            ["Giulia", "Bianchi", "Roma", "1002", "89,50", "08/05/2026", "g.bianchi@example.com", "339-9876543"],
            ["Luca", "Verdi", "Torino", "1003", "1200,00", "09/05/2026", "luca.verdi@example.com", "347-5556677"],
        ]
    else:
        headers = ["first_name", "last_name", "city", "order_number", "amount", "date", "email", "phone"]
        rows = [
            ["John", "Smith", "London", "1001", "250.00", "05/08/2026", "john.smith@example.com", "+44 20 7946 0958"],
            ["Emma", "Brown", "New York", "1002", "89.50", "05/08/2026", "e.brown@example.com", "+1 212 555 0173"],
            ["Liam", "Wilson", "Sydney", "1003", "1200.00", "05/09/2026", "liam.wilson@example.com", "+61 2 8014 4500"],
        ]

    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="334155")
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for row_idx, row in enumerate(rows, start=2):
        for col_idx, val in enumerate(row, start=1):
            ws.cell(row=row_idx, column=col_idx, value=val)
    for col_idx in range(1, len(headers) + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = 18
    ws.row_dimensions[1].height = 24

    # Foglio istruzioni
    ws_help = wb.create_sheet("ISTRUZIONI" if not is_en else "INSTRUCTIONS")
    if not is_en:
        help_lines = [
            "COME USARE QUESTO FILE",
            "",
            "1. Le INTESTAZIONI della prima riga (nome, cognome, città, ...)",
            "   devono corrispondere ai placeholder del template DOCX.",
            "",
            "2. Aggiungi una riga per ogni documento da generare.",
            "   Mail Merge produrrà N file DOCX, uno per riga.",
            "",
            "3. Le colonne non referenziate dal template (es. email, telefono)",
            "   saranno mostrate come 'Colonne non usate' — innocue, non rompono nulla.",
            "",
            "4. Limite: 1000 righe per esecuzione.",
        ]
    else:
        help_lines = [
            "HOW TO USE THIS FILE",
            "",
            "1. The HEADER row (first_name, last_name, city, ...) must match",
            "   the placeholders in the DOCX template.",
            "",
            "2. Add one row per document to generate. Mail Merge will produce",
            "   N DOCX files, one per row.",
            "",
            "3. Columns NOT referenced by the template (e.g. email, phone) will",
            "   show up as 'Unused columns' — harmless, nothing breaks.",
            "",
            "4. Limit: 1000 rows per run.",
        ]
    for i, line in enumerate(help_lines, start=1):
        cell = ws_help.cell(row=i, column=1, value=line)
        if i == 1:
            cell.font = Font(bold=True, size=14)
    ws_help.column_dimensions["A"].width = 80

    wb.save(str(out_path))


if __name__ == "__main__":
    examples_dir = Path(__file__).parent.parent.parent / "frontend" / "public" / "examples"
    examples_dir.mkdir(parents=True, exist_ok=True)

    files = [
        ("esempio_template.docx", "it", make_template),
        ("esempio_dati.xlsx",     "it", make_data),
        ("example_template.docx", "en", make_template),
        ("example_data.xlsx",     "en", make_data),
    ]
    for fname, lang, fn in files:
        out = examples_dir / fname
        fn(out, lang)
        print(f"  ✓ {fname} ({out.stat().st_size} bytes)")

    print(f"\n📁 Generati in: {examples_dir}")
