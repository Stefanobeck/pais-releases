@echo off
REM ============================================
REM PAI Premium Backend - Run Script
REM ============================================
REM Avvia il backend FastAPI con ambiente virtuale
REM ============================================

echo.
echo ============================================
echo   PAI Premium Backend - Avvio
echo ============================================
echo.

REM Verifica che ambiente virtuale esista
if not exist "venv" (
    echo [ERRORE] Ambiente virtuale non trovato!
    echo Esegui prima: setup.bat
    echo.
    pause
    exit /b 1
)

echo [INFO] Attivazione ambiente virtuale...
call venv\Scripts\activate.bat

echo [OK] Ambiente virtuale attivato
echo.

echo [INFO] Avvio server FastAPI...
echo.
echo API Docs: http://127.0.0.1:8000/docs
echo Health:   http://127.0.0.1:8000/health
echo.
echo Premi Ctrl+C per fermare il server
echo.

REM Avvia FastAPI con uvicorn
python main.py
