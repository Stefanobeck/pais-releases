"""
Smart Suggestions Service - Genera suggerimenti contestuali per chat.
Supporta:
- 3 livelli: Easy, Expert, Pro
- 12 categorie professionali
- Output JSON array di 4 stringhe
"""
import json
import asyncio
import pandas as pd
from typing import List, Dict, Optional
from pathlib import Path
import logging

from processors.ollama_client import OllamaClient, AUTO_CTX
from backend_config import settings

logger = logging.getLogger(__name__)


class SuggestionsService:
    """
    Servizio per generazione smart suggestions.
    """
    
    CATEGORIES = {
        "General": "General",
        "Legal & Compliance": "Legal & Compliance",
        "HR & People Management": "HR & People Management",
        "Technical & R&D": "Technical & R&D",
        "Marketing & Copywriting": "Marketing & Copywriting",
        "Sales & Tender Management": "Sales & Tender Management",
        "Strategy & Governance": "Strategy & Governance",
        "Creative Writing & Publishing": "Creative Writing & Publishing",
        "Education & Academic Research": "Education & Academic Research",
        "Healthcare & Pharma": "Healthcare & Pharma",
        "Content Creation & Digital Media": "Content Creation & Digital Media",
        "Finance & Accounting": "Finance & Accounting",
        "Operations & Supply Chain": "Operations & Supply Chain"
    }
    
    LEVELS = ["Basic", "Advanced"]
    
    # Nome NATIVO della lingua (non il codice ISO): i modelli rispettano molto
    # meglio "ITALIANO" che "it". Usato sia nella sostituzione {lang} del
    # template sia nell'istruzione finale.
    LANG_NATIVE = {
        'it': 'ITALIANO', 'en': 'ENGLISH', 'es': 'ESPAÑOL',
        'fr': 'FRANÇAIS', 'de': 'DEUTSCH',
    }

    def _lang_word(self, lang: str) -> str:
        return self.LANG_NATIVE.get((lang or 'it').lower(), 'ITALIANO')

    def _get_localized_instruction(self, prompt: str, lang: str) -> str:
        """Istruzione finale FORTE: forza la lingua (nome nativo) e impone
        suggerimenti in LINGUAGGIO NATURALE. Niente SINTASSI SQL/codice, ma le
        domande DEVONO essere ANCORATE alle colonne realmente presenti nello
        schema (può citarne i nomi): senza questo aggancio il modello inventa
        metriche inesistenti (ROI, conversion rate, tempo di consegna) e lo
        step di generazione SQL a valle restituisce zero righe."""
        lw = self._lang_word(lang)
        rules_by_lang = {
            'it': (f"Scrivi i 4 suggerimenti ESCLUSIVAMENTE in {lw}, come DOMANDE di business "
                   "in linguaggio naturale comprensibili a un manager "
                   "(es. \"Qual è il budget medio per centro di costo?\"). "
                   "PUOI citare i nomi reali delle colonne/campi presenti nello schema per essere precisa, "
                   "ma NON usare sintassi SQL o codice (niente SELECT/GROUP BY/JOIN, niente snake_case grezzo). "
                   "Ogni domanda DEVE riguardare SOLO colonne effettivamente presenti nello schema: "
                   "NON inventare metriche o colonne assenti (es. ROI, conversion rate, tempo di consegna, "
                   "valutazioni di performance) se le colonne necessarie non esistono. "
                   "EVITA filtri sul periodo 'corrente' (mese corrente, trimestre corrente, ultimo trimestre, oggi): "
                   "usa solo i periodi realmente presenti nei dati."),
        }
        default_rule = (f"Write the 4 suggestions ONLY in {lw}, as natural-language business "
                        "QUESTIONS understandable by a manager "
                        "(e.g. \"What is the average budget per cost center?\"). "
                        "You MAY reference the real column/field names present in the schema to stay precise, "
                        "but do NOT use SQL syntax or code (no SELECT/GROUP BY/JOIN, no raw snake_case). "
                        "Every question MUST concern ONLY columns actually present in the schema: "
                        "do NOT invent metrics or columns that do not exist (e.g. ROI, conversion rate, "
                        "delivery time, performance ratings) unless the required columns exist. "
                        "AVOID 'current period' filters (current month, current quarter, last quarter, today): "
                        "use only periods actually present in the data.")
        rule = rules_by_lang.get((lang or 'it').lower(), default_rule)
        return f"{prompt}\n\n[OUTPUT] {rule}"

    def _get_enhanced_summary(self, dfs: Dict[str, pd.DataFrame]) -> str:
        """Riassunto dei DataFrame con preview dei valori (Legacy get_summary)."""
        summary = []
        if not dfs: return "No data available."
        for name, df in dfs.items():
            rows, cols = df.shape
            summary.append(f"TABLE: {name} ({rows} righe, {cols} colonne)")
            col_details = []
            for c in df.columns:
                dtype = str(df[c].dtype)
                sample_vals = ""
                try:
                    unique_count = df[c].nunique()
                    if unique_count < 15 and dtype == 'object':
                        vals = df[c].dropna().unique().tolist()
                        sample_vals = f" [Vals: {', '.join(map(str, vals[:5]))}...]"
                    elif pd.api.types.is_numeric_dtype(df[c]):
                        mn, mx = df[c].min(), df[c].max()
                        sample_vals = f" [Range: {mn:.2f} - {mx:.2f}]"
                except: pass
                col_details.append(f"  - {c} ({dtype}){sample_vals}")
            summary.append("\n".join(col_details))
        return "\n\n".join(summary)

    def __init__(self, lang: str = "it"):
        self.ollama = OllamaClient()
        self.lang = lang
        self.prompts = self._load_prompts()
    
    def _load_prompts(self) -> Dict:
        """Carica prompt da configurazione."""
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_chat.json"
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(self.lang, data.get('it', {}))
        except:
            return self._get_default_prompts()
    
    def _get_default_prompts(self) -> Dict:
        """Prompt di default."""
        return {
            "smart_suggestions": {
                "easy": "You are a curious reader. I have these documents:\n{context}\n\nGenerate 4 simple questions to ask about these documents to understand their main content.\n\nRULES:\n1. Questions must be answerable from the text.\n2. Keep them short and direct.\n3. Focus on summary, main topics, and key definitions.\n\nEXAMPLES:\n- 'What is the main topic of the document?'\n- 'Summarize the key points of the introduction'\n- 'Who is the author of the text?'\n\nOUTPUT: JSON array of 4 strings.",
                "expert": "You are a researcher. I have these documents:\n{context}\n\nGenerate 4 specific questions to analyze details and relationships in the text.\n\nRULES:\n1. Focus on specific sections, comparisons, or cause-effect relationships.\n2. Ask to extract lists or data points.\n\nEXAMPLES:\n- 'List the main requirements described in section 3'\n- 'Compare the solution proposed in document A vs document B'\n- 'What are the risks mentioned in the conclusion?'\n\nOUTPUT: JSON array of 4 strings.",
                "pro": "You are a Strategic Analyst. I have these documents:\n{context}\n\nGenerate 4 sophisticated questions/prompts to synthesize insights and strategic value.\n\nRULES:\n1. Focus on implications, critical analysis, and synthesis.\n2. Ask for SWOC analysis, action plans, or executive summaries.\n\nEXAMPLES:\n- 'Generate a SWOC analysis based on the report'\n- 'Draft an executive summary of the project proposal'\n- 'Identify potential contradictions between the documents'\n\nOUTPUT: JSON array of 4 strings."
            },
            "variable_suggestions_chat": {
                "Legal & Compliance": {
                    "easy": "You are a Legal Assistant. Generate 4 simple questions related to legal or compliance aspects.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Senior Lawyer. Generate 4 detailed questions about legal clauses and risks.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a General Counsel. Generate 4 strategic legal questions.\nOUTPUT: JSON array of 4 strings."
                },
                "HR & People Management": {
                    "easy": "You are an HR Assistant. Generate 4 simple questions related to HR or people management.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are an HR Manager. Generate 4 detailed questions about workforce planning and talent management.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a CHRO. Generate 4 strategic HR questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Technical & R&D": {
                    "easy": "You are a Junior Engineer. Generate 4 simple questions related to technical or R&D aspects.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Senior Engineer. Generate 4 detailed questions about technical feasibility and innovation.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a CTO. Generate 4 strategic R&D questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Marketing & Copywriting": {
                    "easy": "You are a Copywriter. Generate 4 simple questions related to marketing or copywriting.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Marketing Manager. Generate 4 detailed questions about campaign performance and content strategy.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a CMO. Generate 4 strategic marketing questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Sales & Tender Management": {
                    "easy": "You are a Sales Assistant. Generate 4 simple questions related to sales or tenders.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Tender Manager. Generate 4 detailed questions about proposal quality and competitive advantage.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a Sales Director. Generate 4 strategic sales questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Strategy & Governance": {
                    "easy": "You are a Strategy Analyst. Generate 4 simple questions related to strategy or governance.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Strategy Manager. Generate 4 detailed questions about strategic alignment and execution.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a CSO. Generate 4 strategic governance questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Creative Writing & Publishing": {
                    "easy": "You are an Editor. Generate 4 simple questions related to creative writing or publishing.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Senior Editor. Generate 4 detailed questions about narrative structure and style.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a Publisher. Generate 4 strategic publishing questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Education & Academic Research": {
                    "easy": "You are a Professor. Generate 4 simple questions related to education or academic research.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Dean. Generate 4 detailed questions about research validity and contribution.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a University President. Generate 4 strategic academic questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Healthcare & Pharma": {
                    "easy": "You are a Health Assistant. Generate 4 simple questions related to healthcare or pharma.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Doctor. Generate 4 detailed questions about diagnosis and treatment.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a Medical Director. Generate 4 strategic healthcare questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Content Creation & Digital Media": {
                    "easy": "You are a Social Media Manager. Generate 4 simple questions related to content creation for social and digital media.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Content Strategist. Generate 4 detailed questions about engagement and reach.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a Digital Media Director. Generate 4 strategic media questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Finance & Accounting": {
                    "easy": "You are an Accounting Assistant. Generate 4 simple questions related to finance or accounting.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are a Financial Analyst. Generate 4 detailed questions about financial performance and metrics.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a CFO. Generate 4 strategic financial questions.\nOUTPUT: JSON array of 4 strings."
                },
                "Operations & Supply Chain": {
                    "easy": "You are an Operations Assistant. Generate 4 simple questions related to operations or supply chain.\nOUTPUT: JSON array of 4 strings.",
                    "expert": "You are an Operations Manager. Generate 4 detailed questions about process optimization and logistics.\nOUTPUT: JSON array of 4 strings.",
                    "pro": "You are a COO. Generate 4 strategic operations questions.\nOUTPUT: JSON array of 4 strings."
                }
            }
        }
    
    def set_language(self, lang: str):
        """Cambia lingua."""
        self.lang = lang
        self.prompts = self._load_prompts()
    
    async def generate_suggestions(
        self,
        context: str,
        level: str = "Easy",
        category: str = "General"
    ) -> List[str]:
        """
        Genera 4 suggerimenti basati su contesto, livello e categoria.
        
        Args:
            context: Contesto documenti (opzionale)
            level: Livello (Easy, Expert, Pro)
            category: Categoria professionale
        
        Returns:
            Lista di 4 stringhe (suggerimenti)
        """
        try:
            # Ottieni prompt
            if category == "General":
                prompt_template = self.prompts.get('smart_suggestions', {}).get(level.lower(), '')
            else:
                category_prompts = self.prompts.get('variable_suggestions_chat', {}).get(category, {})
                prompt_template = category_prompts.get(level.lower(), '')
            
            if not prompt_template:
                # Fallback a prompt generico
                prompt_template = self.prompts.get('smart_suggestions', {}).get('easy', '')
            
            # Inserisci contesto
            context_text = context if context else "No documents uploaded yet."
            prompt = prompt_template.format(context=context_text)
            
            # Chiama Ollama
            messages = [
                {"role": "system", "content": "You are a helpful assistant that generates suggestions in JSON format. Output ONLY a JSON array of 4 strings."},
                {"role": "user", "content": prompt}
            ]
            
            response = await self.ollama.chat(
                model=settings.SUGGESTION_MODEL if hasattr(settings, 'SUGGESTION_MODEL') else settings.CHAT_MODEL,
                messages=messages,
                num_ctx=AUTO_CTX,
                max_ctx=settings.SUGGESTION_CTX,
                stream=False,
                temperature=0.7
            )
            
            # Parsing JSON
            suggestions = self._parse_json_response(response)
            
            if len(suggestions) < 4:
                # Fallback a suggerimenti generici
                suggestions = self._get_fallback_suggestions(level, category)
            
            return suggestions[:4]
        
        except Exception as e:
            logger.error(f"Error generating suggestions: {e}")
            return self._get_fallback_suggestions(level, category)
    
    def _parse_json_response(self, response: str) -> List[str]:
        """Parsing risposta JSON."""
        try:
            # Trova JSON nella risposta
            import re
            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                data = json.loads(json_str)
                if isinstance(data, list):
                    return [str(s) for s in data if s]
        except Exception as e:
            logger.warning(f"JSON parsing failed: {e}")
        
        return []
    
    async def generate_manipulate_suggestions(
        self,
        schema_context: str,
        mode: str = "Analyze",
        level: str = "Easy",
        area: str = "General",
        dfs: Dict[str, pd.DataFrame] = None,
        lang: str = "it"
    ) -> List[str]:
        """
        Genera suggerimenti contestuali per MANIPULATE (Perfect Logic Port).
        Include logica Multi-Sheet per rilevamento Join automatico.
        """
        try:
            # Carica prompt specifici per lingua
            config_dir = Path(__file__).parent.parent / "backend_config"
            prompts_path = config_dir / f"prompts_manipulate_{lang}.json"
            if not prompts_path.exists():
                prompts_path = config_dir / "prompts_manipulate_it.json"
            with open(prompts_path, 'r', encoding='utf-8') as f:
                prompts_block = json.load(f)

            # Usa riassunto potenziato con preview valori se disponibili DF (Legacy alignment)
            current_context = self._get_enhanced_summary(dfs) if dfs else schema_context

            # Normalizzazione mode per evitare bug di confronto (es: 'Export to Sheet' vs 'ExporttoSheet')
            m_norm = mode.lower().replace(" ", "")

            prompt_template = ""
            # Default model per suggerimenti MANIPULATE
            target_model = settings.SUGGESTION_MODEL

            if "chart" in m_norm:
                prompt_template = prompts_block.get("smart_suggestions_charts", {}).get('prompt', "")
                target_model = settings.GRAPHICS_MODEL
            elif "sheet" in m_norm or "export" in m_norm:
                # LOGICA PREMIUM: Usa suggerimenti per area, default 'Generalist'
                vars_sugg = prompts_block.get('variable_suggestions', {})
                area_sugg = vars_sugg.get(area.strip(), vars_sugg.get('Generalist', {}))
                prompt_template = area_sugg.get(level.lower(), "")

                # Se ancora vuoto (es. area non trovata), fallback a Generalist Pro/Expert/Easy
                if not prompt_template:
                    area_sugg = vars_sugg.get('Generalist', {})
                    prompt_template = area_sugg.get(level.lower(), "")

                target_model = settings.ENGINEERING_MODEL
            else:
                # ANALYZE o altro
                vars_sugg = prompts_block.get('analyze_variable_suggestions', {})
                area_sugg = vars_sugg.get(area.strip(), vars_sugg.get('Generalist', {}))
                prompt_template = area_sugg.get(level.lower(), "")

                target_model = settings.ANALYZE_MODEL

            if not prompt_template:
                prompt_template = "You are a data analyst. Generate 4 brief analysis prompts for these data:\n{data_ctx}"

            # Inserimento contesto e LINGUA — usa il nome NATIVO (ITALIANO), non
            # il codice 'it', così il template "Reply in this language: {lang}"
            # diventa una direttiva forte e non ambigua.
            prompt = prompt_template.replace("{data_ctx}", current_context).replace("{lang}", self._lang_word(lang))

            # Applica istruzione di lingua ferrea (LEGACY KEY)
            prompt = self._get_localized_instruction(prompt, lang)
            
            # DEBUG LOGS (Executive Tracing)
            logger.info(f"--- SUGGESTIONS DEBUG START ---")
            logger.info(f"MODE: {mode} | LEVEL: {level} | AREA: {area}")
            logger.info(f"TARGET MODEL: {target_model}")
            logger.info(f"FINAL PROMPT:\n{prompt}")
            logger.info(f"--- END PROMPT ---")
            
            # System prompt for strict JSON output — DOMANDE in linguaggio naturale
            # ANCORATE alle colonne reali (può citarne i nomi), ma senza sintassi SQL
            # e senza inventare metriche/colonne assenti dallo schema.
            system_msg = (
                "You output ONLY a raw JSON array of exactly 4 strings (no markdown, no intro/outro). "
                "Each string MUST be a natural-language business QUESTION in the language requested in the prompt. "
                "You MAY reference the real column/field names that appear in the schema, but do NOT use SQL syntax or code. "
                "Do NOT invent metrics or columns that are not present in the schema."
            )
            
            # Chiama Ollama (Usa solo messaggio User come in NiceGUI)
            messages = [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt}
            ]

            response = await self.ollama.chat(
                model=target_model,
                messages=messages,
                num_ctx=AUTO_CTX,
                max_ctx=settings.SUGGESTION_CTX,
                temperature=0.3
            )
            
            logger.info(f"RAW LLM RESPONSE: {response}")
            
            suggestions = self._parse_json_response(response)
            logger.info(f"PARSED SUGGESTIONS: {suggestions}")
            
            if not suggestions: 
                logger.warning(f"LLM returned no suggestions or parsing failed. Raw response: {response}")
                # Fallback intelligenti basati su area
                if area == "Finance & Accounting":
                    suggestions = ["Analisi flussi di cassa", "Riepilogo scadenze", "Calcolo margini operativi", "Analizza variazioni"]
                else:
                    suggestions = ["Mostra riepilogo dati", "Analizza trend principali", "Estrai insight chiave", "Crea tabella pivot"]

            logger.info(f"--- SUGGESTIONS DEBUG END ---")
            return suggestions[:4]
            if dfs and len(dfs) >= 2:
                import itertools
                # Assicurati di usare SOLO le chiavi presenti nel dizionario filtrato passato
                table_names = [t for t in dfs.keys() if t in dfs]
                multisheet_prompts = []
                
                for t1, t2 in itertools.combinations(table_names, 2):
                    if t1 not in dfs or t2 not in dfs: continue
                    cols1 = {c.lower(): c for c in dfs[t1].columns}
                    cols2 = {c.lower(): c for c in dfs[t2].columns}
                    common_keys = set(cols1.keys()).intersection(set(cols2.keys()))
                    
                    # Filtra chiavi valide
                    valid_keys = [cols1[k] for k in common_keys if not k.startswith('unnamed')]

                    if valid_keys:
                        key = valid_keys[0]
                        if lang == 'it':
                            multisheet_prompts.append(f"Incrocia '{t1}' e '{t2}' tramite '{key}' per un'analisi comparativa")
                            multisheet_prompts.append(f"Crea un report unito tra '{t1}' e '{t2}' usando '{key}' come chiave di join")
                        else:
                            multisheet_prompts.append(f"Merge '{t1}' and '{t2}' on '{key}' for comparative analysis")

                # Inserisci i suggerimenti multifile in cima
                suggestions = multisheet_prompts[:2] + suggestions
            
            return [str(s) for s in suggestions if s][:6]

        except Exception as e:
            logger.error(f"Error generating suggestions: {e}")
            return ["Mostra riepilogo dati", "Analizza trend"]

        except Exception as e:
            logger.error(f"Error generating suggestions: {e}")
            return ["Mostra riepilogo dati", "Analizza trend"]
