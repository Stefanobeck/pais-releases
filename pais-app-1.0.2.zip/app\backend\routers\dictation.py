"""
Router per la dettatura vocale push-to-talk.

Endpoint snello dedicato ad audio brevi della chat Interrogate (≤10MB).
NON tocca il modulo Utility (`routers/utility.py:/transcribe/file`) che
resta su openai-whisper con docx/timecode/traduzioni.

Motore: faster-whisper medium int8 cpu (vedi processors/faster_whisper_processor.py).
"""
import os
import logging
import shutil
import tempfile
from pathlib import Path

from fastapi import APIRouter, UploadFile, File, HTTPException

from processors.faster_whisper_processor import transcribe_short

router = APIRouter()
logger = logging.getLogger(__name__)

# Audio brevi: il push-to-talk ha senso fino a qualche minuto. 10MB di
# WebM/Opus ≈ 10 minuti di voce — abbondante per qualunque dettatura.
MAX_AUDIO_BYTES = 10 * 1024 * 1024


@router.post("/transcribe")
async def transcribe_dictation(audio: UploadFile = File(...)):
    """Trascrive un breve audio della dettatura.

    Input: multipart `audio` (webm/opus o wav, ≤10MB).
    Output: {success, text, lang, duration_s, infer_s, enter_command}.

    `enter_command=True` quando l'utente ha pronunciato "Enter" come ultima
    parola — il frontend interpreta questo flag come "manda subito il messaggio".
    """
    # Validazione mime — accetta audio/* e application/octet-stream
    # (MediaRecorder Chrome a volte manda octet-stream se il codec non è
    # riconosciuto immediatamente).
    ctype = (audio.content_type or "").lower()
    if not (ctype.startswith("audio/") or ctype == "application/octet-stream" or ctype == ""):
        raise HTTPException(
            status_code=400,
            detail=f"Content-Type non audio: {audio.content_type!r}",
        )

    # Salva in temp file. Estensione preservata se possibile per aiutare
    # ffmpeg/decoder di faster-whisper a scegliere il demuxer giusto.
    suffix = ".webm"
    if audio.filename:
        _, ext = os.path.splitext(audio.filename)
        if ext.lower() in (".webm", ".wav", ".ogg", ".mp3", ".m4a", ".flac"):
            suffix = ext.lower()

    tmp_fd, tmp_path = tempfile.mkstemp(suffix=suffix, prefix="dictation_")
    written = 0
    try:
        with os.fdopen(tmp_fd, "wb") as out:
            while True:
                chunk = await audio.read(1024 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > MAX_AUDIO_BYTES:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Audio troppo grande (>{MAX_AUDIO_BYTES // (1024*1024)}MB)",
                    )
                out.write(chunk)

        if written == 0:
            raise HTTPException(status_code=400, detail="Audio vuoto")

        try:
            result = await transcribe_short(tmp_path, language="it")
        except RuntimeError as e:
            # Modello non caricato (manca dall'onboarding) → 400 con hint
            raise HTTPException(status_code=400, detail=str(e))

        logger.info(
            f"Dictation OK — audio={result['duration_s']:.2f}s "
            f"infer={result['infer_s']:.2f}s "
            f"chars={len(result['text'])} enter={result['enter_command']}"
        )
        return {
            "success": True,
            "text": result["text"],
            "lang": result["lang"],
            "duration_s": result["duration_s"],
            "infer_s": result["infer_s"],
            "enter_command": result["enter_command"],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Errore dettatura: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        try:
            Path(tmp_path).unlink(missing_ok=True)
        except Exception:
            pass
