"""
Manipulate Charter - Generazione Grafici per PAI Premium
Supporta:
- Excel Charts (XlsxWriter)
- Static PNG Charts (Matplotlib/Seaborn)
"""
import os
import time
import logging
import pandas as pd
from typing import Optional
from pathlib import Path

from backend_config.project_manager import project_manager

logger = logging.getLogger(__name__)


class ManipulateCharter:
    """
    Generazione grafici per MANIPULATE.
    """

    def __init__(self):
        self.detected_currency = "€"

    async def tool_create_excel_chart(
        self, 
        df: pd.DataFrame, 
        x_col: str, 
        y_col: str, 
        chart_type: str = 'column', 
        sheet_name: str = 'Chart', 
        title: Optional[str] = None
    ) -> Optional[str]:
        """
        Crea un grafico Excel nativo (XlsxWriter).
        Sempre salvato nella cartella 'output' del progetto attivo.
        """
        output_dir = project_manager.get_path("output")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_path = output_dir / f"Chart_{int(time.time())}.xlsx"

        logger.info(f"[TOOL CALL] create_excel_chart | x: {x_col} | y: {y_col} | type: {chart_type}")

        import re
        safe_sheet_name = re.sub(r'[^a-zA-Z0-9]', '_', str(sheet_name))
        if not safe_sheet_name:
            safe_sheet_name = 'Chart'

        writer = None
        try:
            writer = pd.ExcelWriter(str(output_path), engine='xlsxwriter')
            df.to_excel(writer, sheet_name=safe_sheet_name, index=False)

            # Normalizzazione tipo per XlsxWriter
            xl_type = chart_type.lower()
            if 'radar' in xl_type:
                xl_type = 'radar'
            elif 'box' in xl_type:
                xl_type = 'column'  # Fallback
            elif xl_type not in ['area', 'bar', 'column', 'doughnut', 'line', 'pie', 'radar', 'scatter', 'stock']:
                xl_type = 'column'

            chart = writer.book.add_chart({'type': xl_type})

            cols = list(df.columns)
            if x_col in cols and y_col in cols:
                x_idx = cols.index(x_col)
                y_idx = cols.index(y_col)
                max_row = len(df)

                chart.add_series({
                    'name': [safe_sheet_name, 0, y_idx],
                    'categories': [safe_sheet_name, 1, x_idx, max_row, x_idx],
                    'values': [safe_sheet_name, 1, y_idx, max_row, y_idx]
                })

                if title:
                    chart.set_title({'name': title})
                else:
                    chart.set_title({'name': f'{y_col} vs {x_col}'})

                chart.set_x_axis({'name': x_col})
                chart.set_y_axis({'name': y_col, 'major_gridlines': {'visible': True}})

                # Inserisci grafico a destra dei dati
                insert_col_letter = chr(min(ord("A") + len(cols) + 1, ord("Z")))
                writer.sheets[safe_sheet_name].insert_chart(f'{insert_col_letter}2', chart)

            writer.close()
            logger.info(f"Excel chart created: {output_path}")
            return str(output_path)

        except Exception as e:
            logger.error(f"Errore generazione chart Excel: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
        finally:
            if writer and hasattr(writer, 'close'):
                try:
                    writer.close()
                except:
                    pass

    def tool_create_static_chart(
        self, 
        df: pd.DataFrame, 
        chart_type: str = 'bar', 
        x_col: Optional[str] = None, 
        y_col: Optional[str] = None, 
        title: str = "Grafico"
    ) -> Optional[str]:
        """
        Crea un grafico statico PNG (Matplotlib/Seaborn).
        Allineato alla logica XlsxWriter (Porting NiceGUI).
        """
        logger.info(f"[TOOL CALL] create_static_chart | type: {chart_type}")
        
        try:
            # Backend headless OBBLIGATORIO: questo codice gira nei worker thread di
            # uvicorn, non sul main thread. Con TkAgg (default Windows) matplotlib
            # crea oggetti Tk → "main thread is not in main loop" / Tcl_AsyncDelete →
            # crash. 'Agg' non tocca Tk. (Ridondante con MPLBACKEND in settings.py,
            # tenuto qui come difesa locale.)
            import matplotlib
            matplotlib.use("Agg", force=True)
            import matplotlib.pyplot as plt
            import seaborn as sns

            plt.figure(figsize=(10, 6))
            sns.set_theme(style="whitegrid")
            
            # Normalizzazione tipo come in Excel
            ctype = chart_type.lower()
            
            # Forza l'uso di x_col e y_col corretti
            if not x_col: x_col = df.columns[0]
            if not y_col: y_col = df.columns[1] if len(df.columns) > 1 else df.columns[0]

            # Utilizziamo pandas plot per una corrispondenza perfetta 1:1 con la logica riga-per-riga di Excel
            # invece di Seaborn, che esegue aggregazioni e usa sfumature (hue) diverse.
            plot_df = df.dropna(subset=[x_col, y_col])
            color_theme = "#4F81BD" # Blu tipico di Excel

            if ctype in ['column']:
                plot_df.plot.bar(x=x_col, y=y_col, ax=plt.gca(), legend=False, color=color_theme)
            elif ctype == 'bar':
                # In Excel, il grafico "Bar" è orizzontale, mentre "Column" è verticale.
                plot_df.plot.barh(x=x_col, y=y_col, ax=plt.gca(), legend=False, color=color_theme)
            elif ctype == 'line':
                plot_df.plot.line(x=x_col, y=y_col, ax=plt.gca(), legend=False, marker='o', color=color_theme)
            elif ctype in ['pie', 'doughnut']:
                wedgeprops = {'width': 0.4} if ctype == 'doughnut' else None
                plot_df.set_index(x_col).plot.pie(y=y_col, autopct='%1.1f%%', ax=plt.gca(), legend=False, startangle=140, wedgeprops=wedgeprops, ylabel='')
            elif ctype == 'area':
                plot_df.plot.area(x=x_col, y=y_col, ax=plt.gca(), legend=False, alpha=0.4, color=color_theme)
            elif ctype == 'scatter':
                plot_df.plot.scatter(x=x_col, y=y_col, ax=plt.gca(), s=100, color=color_theme)
            else:
                plot_df.plot.bar(x=x_col, y=y_col, ax=plt.gca(), legend=False, color=color_theme)

            plt.title(title)
            plt.xticks(rotation=45)
            plt.tight_layout()

            # Salva PNG nel progetto attivo
            output_dir = project_manager.get_path("output")
            output_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = int(time.time())
            img_name = f"Chart_{timestamp}.png"
            img_path = output_dir / img_name

            plt.savefig(str(img_path))
            plt.close()

            logger.info(f"Static chart created: {img_path}")
            return str(img_path)

        except Exception as e:
            logger.error(f"Errore grafico statico PNG: {e}")
            return None
