@echo off
REM ============================================
REM PAI Premium Backend - Setup Script
REM ============================================
REM Questo script crea l'ambiente virtuale e installa le dipendenze
REM ============================================

echo.
echo ============================================
echo   PAI Premium Backend - Setup
echo ============================================
echo.

REM Verifica che Python sia installato
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRORE] Python non e' installato o non e' nel PATH
    echo Scarica Python da: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [OK] Python trovato
python --version
echo.

REM Crea ambiente virtuale se non esiste
if not exist "venv" (
    echo [INFO] Creazione ambiente virtuale...
    python -m venv venv
    
    if errorlevel 1 (
        echo [ERRORE] Fallita creazione ambiente virtuale
        pause
        exit /b 1
    )
    
    echo [OK] Ambiente virtuale creato in: venv\
) else (
    echo [OK] Ambiente virtuale gia' esistente
)

echo.
echo [INFO] Attivazione ambiente virtuale...

REM Attiva ambiente virtuale e installa dipendenze
call venv\Scripts\activate.bat

echo [OK] Ambiente virtuale attivato
echo.

echo [INFO] Installazione dipendenze...
pip install --upgrade pip
pip install -r requirements.txt

if errorlevel 1 (
    echo [ERRORE] Fallita installazione dipendenze
    pause
    exit /b 1
)

echo.
echo [INFO] Download tokenizer multilingua spaCy (xx_ent_wiki_sm, ~11MB, MIT)...
python -m spacy download xx_ent_wiki_sm
if errorlevel 1 (
    echo [WARN] Download xx_ent_wiki_sm fallito - puo' essere installato successivamente
)

echo.
echo [INFO] Download modello PII NER ONNX (~1.1GB, MIT)...
echo         Bundle nella source tree per inclusione nell'installer commerciale.
python -m scripts.fetch_pii_model
if errorlevel 1 (
    echo [WARN] Download PII NER fallito - puo' essere ri-eseguito con: python -m scripts.fetch_pii_model
)

echo.
echo ============================================
echo   Setup Completato!
echo ============================================
echo.
echo Per avviare il backend:
echo   1. Attiva ambiente: venv\Scripts\activate
echo   2. Esegui: python main.py
echo.
echo Oppure usa: run.bat
echo.
pause
