"""
Renamer Processor — Fast (regex/string transforms) + Smart (AI content-aware).

Pipeline:
  build_rename_plan(files, mode, schema)  →  [{old, new, error?}, ...]
  apply_rename_plan(files, plan, output_dir) → copies into output/Renamed/<id>/

The processor never modifies the user's original files. Renamed copies go
into `output/Renamed/<timestamp>/` along a JSON log that lists every
old→new mapping, allowing a future Undo to restore names.
"""
import asyncio
import datetime
import json
import logging
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from PIL import Image, ExifTags
from processors.ollama_client import OllamaClient
from backend_config.settings import settings

logger = logging.getLogger(__name__)

# Characters not allowed in Windows filenames; replaced with `-`.
_INVALID_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def _sanitize_filename(s: str, max_len: int = 80) -> str:
    """Make a string safe for use as a filename component."""
    s = _INVALID_CHARS_RE.sub("-", s)
    s = re.sub(r"\s+", "-", s.strip())
    s = re.sub(r"-{2,}", "-", s)
    s = s.strip("-._ ")
    if len(s) > max_len:
        s = s[:max_len].rstrip("-._ ")
    return s or "unnamed"


def _get_exif_date(path: Path) -> Optional[datetime.datetime]:
    """Read DateTimeOriginal from EXIF, fall back to file mtime if missing."""
    try:
        if path.suffix.lower() not in (".jpg", ".jpeg", ".tif", ".tiff", ".heic", ".heif"):
            return None
        img = Image.open(path)
        exif = getattr(img, "_getexif", lambda: None)()
        if not exif:
            return None
        tagmap = {ExifTags.TAGS.get(k, k): v for k, v in exif.items()}
        # Try the canonical tags in order of trustworthiness.
        for tag in ("DateTimeOriginal", "DateTimeDigitized", "DateTime"):
            val = tagmap.get(tag)
            if val:
                try:
                    return datetime.datetime.strptime(val, "%Y:%m:%d %H:%M:%S")
                except ValueError:
                    continue
    except Exception as e:
        logger.debug(f"EXIF read failed for {path.name}: {e}")
    return None


def _get_fs_date(path: Path) -> datetime.datetime:
    """File system modification time as datetime."""
    try:
        return datetime.datetime.fromtimestamp(path.stat().st_mtime)
    except Exception:
        return datetime.datetime.now()


def _resolve_date_for_file(path: Path, source: str) -> Optional[datetime.datetime]:
    """source ∈ {'exif', 'fs', 'auto'} — return a datetime or None."""
    if source == "exif":
        return _get_exif_date(path) or _get_fs_date(path)
    if source == "fs":
        return _get_fs_date(path)
    # auto: prefer exif when available, fs otherwise.
    return _get_exif_date(path) or _get_fs_date(path)


def _sort_files(file_paths: List[Path], sort_by: str) -> List[Path]:
    """Order files before numbering. sort_by ∈ {name, exif, fs, size}."""
    if sort_by == "exif":
        return sorted(file_paths, key=lambda p: (_get_exif_date(p) or _get_fs_date(p), p.name.lower()))
    if sort_by == "fs":
        return sorted(file_paths, key=lambda p: (_get_fs_date(p), p.name.lower()))
    if sort_by == "size":
        return sorted(file_paths, key=lambda p: (p.stat().st_size if p.exists() else 0, p.name.lower()))
    return sorted(file_paths, key=lambda p: p.name.lower())


# ──────────────────────────────────────────────────────────────────────────
# FAST presets — pure string/file-stat transforms, no AI.
# ──────────────────────────────────────────────────────────────────────────
def _fast_lowercase(stem: str, ext: str, *_a, **_kw) -> str:
    return f"{stem.lower()}{ext.lower()}"


def _fast_uppercase(stem: str, ext: str, *_a, **_kw) -> str:
    return f"{stem.upper()}{ext.lower()}"


def _fast_replace_spaces(stem: str, ext: str, *_a, **_kw) -> str:
    return f"{stem.replace(' ', '_')}{ext}"


def _fast_find_replace(stem: str, ext: str, schema: Dict, *_a, **_kw) -> str:
    find = schema.get("find", "") or ""
    repl = schema.get("replace", "") or ""
    if not find:
        return f"{stem}{ext}"
    return f"{stem.replace(find, repl)}{ext}"


def _fast_add_prefix(stem: str, ext: str, schema: Dict, path: Path, *_a, **_kw) -> str:
    prefix = schema.get("prefix", "") or ""
    suffix = schema.get("suffix", "") or ""
    date_str = ""
    if schema.get("include_date"):
        dt = _resolve_date_for_file(path, schema.get("date_source", "fs"))
        if dt:
            date_str = dt.strftime("%Y-%m-%d") + "_"
    return f"{prefix}{date_str}{stem}{suffix}{ext}"


def _fast_sequence(stem: str, ext: str, schema: Dict, path: Path, idx: int, *_a, **_kw) -> str:
    """Sequence-based numbering: {prefix}{date}_{NNN}.{ext}"""
    prefix = schema.get("prefix", "frame_") or "frame_"
    padding = int(schema.get("padding", 3))
    start = int(schema.get("start", 1))
    step = int(schema.get("step", 1))
    number = start + idx * step
    num_str = str(number).zfill(padding)

    date_str = ""
    if schema.get("include_date"):
        dt = _resolve_date_for_file(path, schema.get("date_source", "fs"))
        if dt:
            date_str = dt.strftime("%Y-%m-%d") + "_"

    return f"{prefix}{date_str}{num_str}{ext.lower()}"


_FAST_PRESETS = {
    "lowercase": _fast_lowercase,
    "uppercase": _fast_uppercase,
    "replace_spaces": _fast_replace_spaces,
    "find_replace": _fast_find_replace,
    "add_prefix": _fast_add_prefix,
    "sequence": _fast_sequence,
}


# ──────────────────────────────────────────────────────────────────────────
# SMART preset — calls the catalog LLM to extract semantic metadata,
# then composes a name from a template like "{date}_{type}_{subject}".
# ──────────────────────────────────────────────────────────────────────────
def _extract_text_for_smart(path: Path, max_chars: int = 4000) -> str:
    """Best-effort text extraction for AI metadata extraction. Returns empty
    string for unsupported types; caller falls back to filename-based naming."""
    ext = path.suffix.lower()
    try:
        if ext == ".pdf":
            import pypdf
            reader = pypdf.PdfReader(str(path))
            if getattr(reader, "is_encrypted", False):
                try:
                    reader.decrypt("")
                except Exception:
                    return ""
            chunks = []
            total = 0
            for page in reader.pages[:5]:
                try:
                    t = page.extract_text() or ""
                except Exception:
                    t = ""
                chunks.append(t)
                total += len(t)
                if total >= max_chars:
                    break
            return "\n".join(chunks)[:max_chars]
        if ext == ".docx":
            from docx import Document
            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs)[:max_chars]
        if ext in (".txt", ".md", ".csv", ".log"):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read(max_chars)
    except Exception as e:
        logger.debug(f"Smart text extraction failed for {path.name}: {e}")
    return ""


_SMART_PROMPT = """Estrai METADATA da questo documento per costruire un nome file. Restituisci SOLO un oggetto JSON valido con queste chiavi:

- "date": data del documento in formato AAAA-MM-GG. Cerca date interne al testo (es. "in data 14/05/2024" → "2024-05-14"). Se non trovi date interne, lascia null.
- "type": tipo di atto in 1 parola minuscola. Valori tipici: "fattura", "contratto", "lettera", "sentenza", "perizia", "verbale", "circolare", "ricevuta", "preventivo", "altro".
- "subject": soggetto o intestatario principale in 2-4 parole. Es: "Studio Rossi", "Bianchi Mario", "Comune di Torino". Sanifica: niente caratteri speciali, solo lettere/numeri/spazi/trattini.
- "number": numero di documento se presente (es. fattura n. 458 → "458"). null se assente.

Esempio output:
{"date": "2024-03-15", "type": "fattura", "subject": "Edison Energia", "number": "458"}

Restituisci SOLO il JSON, niente commenti né markdown. TESTO:
"""


class RenameProcessor:
    def __init__(self):
        self.ollama = OllamaClient()
        # Use the same lightweight model as Smart Catalog for triage.
        # `catalog_model` is configured in models.json and is typically
        # `gemma4:e4b` (HIGH) or `gemma3:12b` (LOW).
        try:
            import json
            with open(Path(__file__).parent.parent / "backend_config" / "models.json", "r", encoding="utf-8") as f:
                cfg = json.load(f)
            self.smart_model = cfg.get("catalog_model", "gemma4:e4b")
            self.smart_ctx = cfg.get("catalog_model_ctx", 16384)
        except Exception:
            self.smart_model = "gemma4:e4b"
            self.smart_ctx = 16384

    # ──────────────────────────────────────────────────────────────────
    # PLAN BUILDING
    # ──────────────────────────────────────────────────────────────────
    async def build_rename_plan(
        self,
        file_paths: List[Path],
        mode: str,
        schema: Dict[str, Any],
        lang: str = "it",
    ) -> List[Dict[str, Any]]:
        """Build a rename plan without touching files. Returns a list of
        dicts {id, old, new, size_bytes, error?} in input order, with
        conflicts already resolved (appending _01, _02 to duplicates).
        """
        if not file_paths:
            return []

        preset = schema.get("preset", "")

        # Sort files for sequence-style presets so numbering matches user
        # expectation (chronological, by name, ...).
        if mode == "fast" and preset == "sequence":
            sort_by = schema.get("sort_by", "name")
            ordered = _sort_files(file_paths, sort_by)
        else:
            ordered = list(file_paths)

        # Index by original path for stable IDs in the output.
        original_index = {p: i for i, p in enumerate(file_paths)}

        new_names_by_path: Dict[Path, str] = {}
        errors_by_path: Dict[Path, str] = {}

        if mode == "fast":
            fn = _FAST_PRESETS.get(preset)
            if not fn:
                raise ValueError(f"Unknown fast preset: {preset!r}")
            for idx, p in enumerate(ordered):
                try:
                    stem = p.stem
                    ext = p.suffix
                    new = fn(stem, ext, schema, p, idx)
                    new_names_by_path[p] = _sanitize_filename(Path(new).stem) + Path(new).suffix
                except Exception as e:
                    errors_by_path[p] = f"compose_failed: {e}"

        elif mode == "smart":
            template = schema.get("template", "{date}_{type}_{subject}")
            fallback = schema.get("fallback", "numbered")  # "numbered" | "filename"
            for idx, p in enumerate(ordered):
                try:
                    metadata = await self._extract_smart_metadata(p, lang)
                    new = self._compose_smart_name(p, metadata, template, idx, fallback)
                    new_names_by_path[p] = _sanitize_filename(Path(new).stem) + Path(new).suffix
                except Exception as e:
                    errors_by_path[p] = f"smart_failed: {e}"
                    # Fall back to a numbered name so the item still gets a plan row.
                    new_names_by_path[p] = f"file_{idx+1:03d}{p.suffix.lower()}"
        else:
            raise ValueError(f"Unknown mode: {mode!r}")

        # Build plan in INPUT order (so the UI shows files in the order the
        # user dropped them, not the sorted order we used for numbering).
        plan: List[Dict[str, Any]] = []
        for p in file_paths:
            new = new_names_by_path.get(p, p.name)
            err = errors_by_path.get(p)
            plan.append({
                "id": f"rn_{original_index[p]}",
                "old": p.name,
                "new": new,
                "size_bytes": p.stat().st_size if p.exists() else 0,
                "error": err,
            })

        # Conflict resolution: ensure no two new names collide.
        return self._resolve_conflicts(plan)

    @staticmethod
    def _resolve_conflicts(plan: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """If two items map to the same new name (case-insensitive on Windows),
        append _01, _02 to all but the first."""
        seen: Dict[str, int] = {}
        for item in plan:
            new = item["new"]
            key = new.lower()
            if key in seen:
                seen[key] += 1
                stem, dot, ext = new.rpartition(".")
                if not dot:
                    stem, ext = new, ""
                else:
                    ext = "." + ext
                item["new"] = f"{stem}_{seen[key]:02d}{ext}"
            else:
                seen[key] = 0
        return plan

    # ──────────────────────────────────────────────────────────────────
    # SMART metadata extraction via LLM
    # ──────────────────────────────────────────────────────────────────
    async def _extract_smart_metadata(self, path: Path, lang: str) -> Dict[str, Any]:
        """Read first chunk of the file, ask the LLM for {date, type, subject, number}.
        Returns dict with normalized values (empty strings if missing).
        """
        text = _extract_text_for_smart(path)
        if not text or len(text.strip()) < 30:
            return {"date": "", "type": "altro", "subject": "", "number": ""}

        prompt = _SMART_PROMPT + text
        try:
            raw = await self.ollama.chat(
                model=self.smart_model,
                messages=[
                    {"role": "system", "content": "Sei un estrattore di metadati per nomi file. Restituisci SOLO JSON valido."},
                    {"role": "user", "content": prompt},
                ],
                num_ctx=self.smart_ctx,
                temperature=0.0,
            )
            # Strip optional markdown fences the model may add.
            cleaned = raw.strip()
            if cleaned.startswith("```"):
                cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
                cleaned = re.sub(r"\s*```$", "", cleaned)
            data = json.loads(cleaned)
            if not isinstance(data, dict):
                return {"date": "", "type": "altro", "subject": "", "number": ""}
            return {
                "date": (data.get("date") or "").strip(),
                "type": (data.get("type") or "altro").strip().lower(),
                "subject": (data.get("subject") or "").strip(),
                "number": (str(data.get("number")) if data.get("number") else "").strip(),
            }
        except Exception as e:
            logger.warning(f"Smart metadata extraction failed for {path.name}: {e}")
            return {"date": "", "type": "altro", "subject": "", "number": ""}

    @staticmethod
    def _compose_smart_name(
        path: Path,
        metadata: Dict[str, Any],
        template: str,
        idx: int,
        fallback: str,
    ) -> str:
        """Fill the template with metadata. If `date` and `subject` are both
        empty, fall back to a safer scheme (numbered or original filename).
        """
        ext = path.suffix.lower()
        date = metadata.get("date") or ""
        # If LLM didn't find a date, try EXIF or filesystem.
        if not date:
            dt = _resolve_date_for_file(path, "auto")
            if dt:
                date = dt.strftime("%Y-%m-%d")
        # If still no date AND no subject, this file has no usable metadata.
        subject = metadata.get("subject") or ""
        if not date and not subject:
            if fallback == "filename":
                return f"{path.stem}{ext}"
            return f"file_{idx+1:03d}{ext}"

        type_ = metadata.get("type") or "altro"
        number = metadata.get("number") or ""

        # Build the name from the template; empty values are skipped cleanly.
        parts = {
            "date": date,
            "type": type_,
            "subject": _sanitize_filename(subject, max_len=40),
            "number": number,
        }
        try:
            name = template.format(**parts)
        except KeyError:
            # Unknown placeholder in template → fall back to a safe default.
            name = f"{date}_{type_}_{parts['subject']}".strip("_")
        # Collapse double separators left by empty placeholders.
        name = re.sub(r"[_\-]{2,}", "_", name).strip("_-")
        return f"{name}{ext}"

    # ──────────────────────────────────────────────────────────────────
    # APPLY — copy files into a Renamed/<timestamp>/ subfolder.
    # ──────────────────────────────────────────────────────────────────
    @staticmethod
    async def apply_rename_plan(
        file_paths: List[Path],
        plan: List[Dict[str, Any]],
        output_root: Path,
        selected_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Apply the rename plan: copy each source file to
        `output_root/Renamed/<timestamp>/` with the new name. Write a JSON
        log alongside so future Undo can read it.
        Returns: {subfolder, applied, errors, log_filename}.
        """
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        target_root = output_root / "Renamed" / ts
        target_root.mkdir(parents=True, exist_ok=True)

        # Build a path lookup from the plan ID.
        old_paths_by_name = {p.name: p for p in file_paths}
        selected = set(selected_ids) if selected_ids is not None else None

        applied = 0
        errors: List[Dict[str, Any]] = []
        log_entries: List[Dict[str, Any]] = []

        for item in plan:
            if selected is not None and item["id"] not in selected:
                continue
            if item.get("error"):
                errors.append({"id": item["id"], "old": item["old"], "error": item["error"]})
                continue
            src = old_paths_by_name.get(item["old"])
            if src is None or not src.exists():
                errors.append({"id": item["id"], "old": item["old"], "error": "source_missing"})
                continue
            dst = target_root / item["new"]
            try:
                # Run blocking IO in a thread to avoid choking the event loop.
                await asyncio.to_thread(shutil.copy2, str(src), str(dst))
                applied += 1
                log_entries.append({"old": item["old"], "new": item["new"]})
            except Exception as e:
                errors.append({"id": item["id"], "old": item["old"], "error": f"copy_failed: {e}"})

        # Persist log for potential Undo.
        log_path = target_root / "rename_log.json"
        try:
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump({
                    "created_at": ts,
                    "source_count": len(file_paths),
                    "applied_count": applied,
                    "entries": log_entries,
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"Failed to write rename log: {e}")

        return {
            "subfolder": str(target_root.relative_to(output_root)).replace("\\", "/"),
            "applied": applied,
            "errors": errors,
            "log_filename": "rename_log.json",
        }
