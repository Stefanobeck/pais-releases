"""
Redline DOCX generator for Compare Mode.

Produces a static (non-track-changes) word-level diff between two text blobs
as a .docx file:
- Tokens present in F1 but missing in F2  -> red strikethrough
- Tokens added in F2                      -> green underline
- Unchanged tokens                        -> normal black

Uses python-docx (already in requirements) and difflib.SequenceMatcher on
whitespace-aware word tokens. The output is meant to be opened in Word/LibreOffice
as a deliverable — there is no Accept/Reject revision flow (deliberate choice:
the legal-grade XML markup of native track-changes is not supported by python-docx
and would need raw <w:ins>/<w:del> XML manipulation).
"""
from __future__ import annotations

import re
import difflib
from datetime import datetime
from pathlib import Path
from typing import Optional, Iterable

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH


# Visual palette: chosen for legibility on white background, color-blind-safe enough.
COLOR_DELETE = RGBColor(0xC0, 0x39, 0x2B)  # red
COLOR_INSERT = RGBColor(0x2E, 0x7D, 0x32)  # green
COLOR_HEADER = RGBColor(0x33, 0x33, 0x33)
COLOR_META = RGBColor(0x88, 0x88, 0x88)


# Localized strings used in the DOCX header / legend / fallback.
# Kept here as a small dict so the redline module is self-contained and does
# not need to load labels.json at runtime. Add a new lang by appending an entry.
_LABELS = {
    'it': {
        'title': 'Redline — Confronto Documenti',
        'f1_label': 'F1  ',
        'f2_label': 'F2  ',
        'generated_label': 'Generato  ',
        'legend_label': 'Legenda:  ',
        'removed': 'rimosso in F2',
        'added': 'aggiunto in F2',
        'unchanged': '   invariato',
        'no_content': 'Nessun contenuto da confrontare.',
    },
    'en': {
        'title': 'Redline — Document Compare',
        'f1_label': 'F1  ',
        'f2_label': 'F2  ',
        'generated_label': 'Generated  ',
        'legend_label': 'Legend:  ',
        'removed': 'removed in F2',
        'added': 'added in F2',
        'unchanged': '   unchanged',
        'no_content': 'No content to compare.',
    },
}


def _get_labels(lang: Optional[str]) -> dict:
    """Resolve the label dict for a given language, falling back to English."""
    if lang and lang in _LABELS:
        return _LABELS[lang]
    return _LABELS['en']

# Token regex: each match is either a whitespace run or a non-whitespace run.
# Preserving whitespace tokens means SequenceMatcher sees real word boundaries
# and we can re-emit the original spacing without separate accounting.
_TOKEN_RE = re.compile(r'\S+|\s+', re.UNICODE)


def _tokenize(text: str) -> list[str]:
    """Word + whitespace tokens preserving the original spacing."""
    return _TOKEN_RE.findall(text or '')


def _add_run(paragraph, text: str, *, color: Optional[RGBColor] = None,
             strike: bool = False, underline: bool = False, bold: bool = False,
             size_pt: Optional[float] = None) -> None:
    """Append a styled run to a paragraph. Whitespace is preserved as-is."""
    if not text:
        return
    run = paragraph.add_run(text)
    font = run.font
    if color is not None:
        font.color.rgb = color
    if strike:
        font.strike = True
    if underline:
        font.underline = True
    if bold:
        font.bold = True
    if size_pt is not None:
        font.size = Pt(size_pt)


def _emit_diff_runs(paragraph, tokens_a: list[str], tokens_b: list[str]) -> None:
    """Compute opcodes between the two token lists and emit styled runs."""
    matcher = difflib.SequenceMatcher(a=tokens_a, b=tokens_b, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            _add_run(paragraph, ''.join(tokens_a[i1:i2]))
        elif tag == 'delete':
            _add_run(paragraph, ''.join(tokens_a[i1:i2]),
                     color=COLOR_DELETE, strike=True)
        elif tag == 'insert':
            _add_run(paragraph, ''.join(tokens_b[j1:j2]),
                     color=COLOR_INSERT, underline=True)
        elif tag == 'replace':
            _add_run(paragraph, ''.join(tokens_a[i1:i2]),
                     color=COLOR_DELETE, strike=True)
            _add_run(paragraph, ''.join(tokens_b[j1:j2]),
                     color=COLOR_INSERT, underline=True)


def _split_into_blocks(text: str) -> list[str]:
    """Split text into paragraph-sized blocks on blank lines or single newlines.

    We diff per-block instead of one giant blob so the resulting DOCX has natural
    paragraph breaks (DOCX paragraphs map to <w:p> and a single mega-paragraph
    would be unreadable). Empty blocks are kept so vertical spacing is preserved.
    """
    if not text:
        return []
    # Normalise line endings, then split on newline. Empty lines become empty
    # blocks (which we render as empty paragraphs for visual breathing room).
    return text.replace('\r\n', '\n').replace('\r', '\n').split('\n')


def _align_blocks(blocks_a: list[str], blocks_b: list[str]) -> Iterable[tuple[str, str]]:
    """Pair up paragraph-blocks across the two documents using a line-level
    SequenceMatcher, then yield (block_a, block_b) tuples ready for word-level
    diff. This avoids the worst-case O(N*M) explosion of running word-level
    diff on the full concatenated text.

    Pairing strategy:
    - 'equal' opcodes: pair 1-to-1.
    - 'replace' opcodes: pair k-to-k (zip), trailing extras emit as pure
      delete/insert pairs against an empty counterpart.
    - 'delete' opcodes: pair each block_a with empty string (entire paragraph removed).
    - 'insert' opcodes: pair empty string with each block_b (entire paragraph added).
    """
    matcher = difflib.SequenceMatcher(a=blocks_a, b=blocks_b, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            for k in range(i2 - i1):
                yield (blocks_a[i1 + k], blocks_b[j1 + k])
        elif tag == 'replace':
            n_a = i2 - i1
            n_b = j2 - j1
            common = min(n_a, n_b)
            for k in range(common):
                yield (blocks_a[i1 + k], blocks_b[j1 + k])
            for k in range(common, n_a):
                yield (blocks_a[i1 + k], '')
            for k in range(common, n_b):
                yield ('', blocks_b[j1 + k])
        elif tag == 'delete':
            for k in range(i1, i2):
                yield (blocks_a[k], '')
        elif tag == 'insert':
            for k in range(j1, j2):
                yield ('', blocks_b[k])


def build_redline_docx(
    file_a_name: str,
    text_a: str,
    file_b_name: str,
    text_b: str,
    output_path: Path,
    studio: Optional[dict] = None,
    lang: Optional[str] = None,
) -> Path:
    """Render the word-level redline of (text_a -> text_b) to a .docx file.

    Args:
        file_a_name: Original (F1) filename, shown in the header.
        text_a: Plain text of F1.
        file_b_name: Revised (F2) filename, shown in the header.
        text_b: Plain text of F2.
        output_path: Destination .docx path. Parent dir is created if needed.
        studio: Reserved for future studio-branding header. Ignored for now —
                the export_manager DocxExporter already handles studio identity
                for the chat export, and the redline is a separate deliverable
                where minimal branding keeps the visual focus on the diff.
        lang: Language code ('it' or 'en'). Used to localize the title, legend
              and meta labels in the document header. Defaults to English when
              missing or unknown.

    Returns:
        The path that was written (== output_path).
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    L = _get_labels(lang)

    doc = Document()

    # Cover header
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    _add_run(title, L['title'], bold=True, size_pt=18, color=COLOR_HEADER)

    meta = doc.add_paragraph()
    _add_run(meta, L['f1_label'], bold=True, size_pt=10, color=COLOR_META)
    _add_run(meta, file_a_name + '\n', size_pt=10)
    _add_run(meta, L['f2_label'], bold=True, size_pt=10, color=COLOR_META)
    _add_run(meta, file_b_name + '\n', size_pt=10)
    _add_run(meta, L['generated_label'], bold=True, size_pt=10, color=COLOR_META)
    _add_run(meta, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), size_pt=10)

    legend = doc.add_paragraph()
    _add_run(legend, L['legend_label'], bold=True, size_pt=9, color=COLOR_META)
    _add_run(legend, L['removed'], color=COLOR_DELETE, strike=True, size_pt=9)
    _add_run(legend, '   ', size_pt=9)
    _add_run(legend, L['added'], color=COLOR_INSERT, underline=True, size_pt=9)
    _add_run(legend, L['unchanged'], size_pt=9, color=COLOR_META)

    doc.add_paragraph()  # spacer

    # Body — per-paragraph word-level diff
    blocks_a = _split_into_blocks(text_a)
    blocks_b = _split_into_blocks(text_b)

    if not blocks_a and not blocks_b:
        empty = doc.add_paragraph()
        _add_run(empty, L['no_content'], color=COLOR_META, size_pt=10)
    else:
        for block_a, block_b in _align_blocks(blocks_a, blocks_b):
            tokens_a = _tokenize(block_a)
            tokens_b = _tokenize(block_b)
            paragraph = doc.add_paragraph()
            if not tokens_a and not tokens_b:
                # Preserve blank lines for vertical rhythm.
                continue
            # Replaced-clause guard: when the aligner pairs two unrelated
            # paragraphs (same position, different content — e.g. a clause
            # swapped for another that happens to sit at the same spot), a
            # word-level diff scrambles them into an unreadable interleaving.
            # Below the similarity threshold we render the whole old paragraph
            # struck-through and the whole new one underlined — the clean
            # "removed + added" view a reviewer expects. Mirrors the
            # _BOTH_DEMOTE_THRESHOLD demotion used for the textual diff evidence.
            if tokens_a and tokens_b:
                similarity = difflib.SequenceMatcher(
                    None, tokens_a, tokens_b, autojunk=False
                ).ratio()
                if similarity < _BOTH_DEMOTE_THRESHOLD:
                    _add_run(paragraph, ''.join(tokens_a),
                             color=COLOR_DELETE, strike=True)
                    _add_run(paragraph, ''.join(tokens_b),
                             color=COLOR_INSERT, underline=True)
                    continue
            _emit_diff_runs(paragraph, tokens_a, tokens_b)

    doc.save(str(output_path))
    return output_path


# ─── Textual redline (LLM-friendly) ──────────────────────────────────────────
# Same paragraph alignment + word-level diff pipeline used for the visual DOCX
# redline, but serialized to plain text with explicit markers. Designed to be
# injected into an LLM system prompt as ground-truth diff evidence: the model
# sees exactly what the human sees, expressed in tokens that LLM tokenizers
# parse natively (no color, no styling, no PDF/DOCX extraction loss).

# Inline marker delimiters for atomic word-level changes inside [BOTH] blocks.
_INLINE_DEL_OPEN = "[-"
_INLINE_DEL_CLOSE = "-]"
_INLINE_INS_OPEN = "[+"
_INLINE_INS_CLOSE = "+]"


def _escape_marker_collisions(text: str) -> str:
    """Soften any literal occurrence of `[-` or `[+` in the source text so the
    LLM can not confuse it with an inline diff marker. We add a single space
    after the bracket — visually identical for the human reader, but no longer
    a valid marker prefix. Applied only to text emitted inside `equal` opcodes
    (i.e. unchanged content). Marker tokens we emit ourselves are obviously
    safe by construction.
    """
    if not text:
        return text
    return text.replace("[-", "[ -").replace("[+", "[ +")


def _emit_textual_diff_for_block(tokens_a: list[str], tokens_b: list[str]) -> tuple[str, bool]:
    """Compute opcodes between two token lists and serialize as text with
    inline `[-…-]` / `[+…+]` markers around changed runs.

    Returns (text, has_changes). `has_changes` is False when every opcode is
    `equal` — caller can use it to decide whether to wrap in [BOTH] silently
    or actually highlight the paragraph.
    """
    matcher = difflib.SequenceMatcher(a=tokens_a, b=tokens_b, autojunk=False)
    parts: list[str] = []
    has_changes = False
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            parts.append(_escape_marker_collisions(''.join(tokens_a[i1:i2])))
        elif tag == 'delete':
            parts.append(f"{_INLINE_DEL_OPEN}{''.join(tokens_a[i1:i2])}{_INLINE_DEL_CLOSE}")
            has_changes = True
        elif tag == 'insert':
            parts.append(f"{_INLINE_INS_OPEN}{''.join(tokens_b[j1:j2])}{_INLINE_INS_CLOSE}")
            has_changes = True
        elif tag == 'replace':
            parts.append(f"{_INLINE_DEL_OPEN}{''.join(tokens_a[i1:i2])}{_INLINE_DEL_CLOSE}")
            parts.append(f"{_INLINE_INS_OPEN}{''.join(tokens_b[j1:j2])}{_INLINE_INS_CLOSE}")
            has_changes = True
    return ''.join(parts), has_changes


# Similarity threshold for MOVED detection. A paragraph is considered "moved"
# when an [F1-ONLY] block and an [F2-ONLY] block share content above this
# ratio (SequenceMatcher on the raw paragraph text). 0.85 is empirically
# permissive enough to catch "Articolo 8 - Foro competente" ↔ "Articolo 9 -
# Foro competente" (only the article number changes) but strict enough to
# avoid false positives on paragraphs with similar boilerplate but different
# substance.
_MOVED_SIMILARITY_THRESHOLD = 0.85


# Below this ratio, two paragraphs that the line-level aligner happens to pair
# (e.g. because they share a common prefix like "Articolo 5 -") are NOT really
# the same paragraph modified — they're two distinct topics that just happen to
# live at the same position. We demote them from BOTH (which would render as
# Modified in the LLM output) to F1-ONLY + F2-ONLY (which renders as Removed +
# Added — the correct categorization for "Esclusiva" replaced by "Riservatezza").
_BOTH_DEMOTE_THRESHOLD = 0.40


def _detect_moved_pairs(
    typed_blocks: list[tuple[str, str]],
    threshold: float = _MOVED_SIMILARITY_THRESHOLD,
) -> list[tuple[int, int]]:
    """Greedy matching of F1-ONLY ↔ F2-ONLY paragraphs by content similarity.

    Iterates F1-ONLY blocks in order, picks the best-scoring un-matched F2-ONLY
    block above the threshold, and pairs them. Greedy is fine here because:
    - paragraphs are paragraph-sized (rarely > 1KB),
    - duplicates within a single document are uncommon,
    - the cost of a wrong pairing is just slightly less informative output.

    Returns a list of (f1_index, f2_index) pairs into `typed_blocks`.
    """
    f1_candidates = [(i, body) for i, (kind, body) in enumerate(typed_blocks) if kind == 'F1-ONLY']
    f2_candidates = [(i, body) for i, (kind, body) in enumerate(typed_blocks) if kind == 'F2-ONLY']
    if not f1_candidates or not f2_candidates:
        return []

    pairs: list[tuple[int, int]] = []
    used_f2: set[int] = set()
    for f1_idx, f1_body in f1_candidates:
        best_f2 = None
        best_ratio = 0.0
        for f2_idx, f2_body in f2_candidates:
            if f2_idx in used_f2:
                continue
            ratio = difflib.SequenceMatcher(None, f1_body, f2_body, autojunk=False).ratio()
            if ratio >= threshold and ratio > best_ratio:
                best_f2 = f2_idx
                best_ratio = ratio
        if best_f2 is not None:
            pairs.append((f1_idx, best_f2))
            used_f2.add(best_f2)
    return pairs


# Heading/anchor detection for the compact LLM evidence path. When unchanged
# paragraphs are collapsed (to keep the diff small enough for a small local
# model to reason over), heading-like lines are ALWAYS kept: they let the model
# attribute every change to the right article/section number. Dropping a
# "Articolo 12 — Garanzia" header would leave a change like "[-12-][+24+] mesi"
# un-citable.
_ANCHOR_RE = re.compile(
    r'^\s*(?:'
    r'art(?:icolo|\.)?\s*\d+'        # Articolo 12 / Art. 12 / Art 12
    r'|article\s*\d+'                # Article 12
    r'|allegato\b|annex\b|appendice\b'
    r'|premess|sezione\b|capo\b|titolo\b|clausola\s*\d+'
    r')',
    re.IGNORECASE,
)


def _is_anchor(text: str) -> bool:
    """True if a paragraph looks like a heading worth keeping as a citation
    anchor even when unchanged: an article/section header, or a short ALL-CAPS
    title line (e.g. the document title, "PREMESSO CHE", "ALLEGATO A — …")."""
    t = (text or '').strip()
    if not t:
        return False
    if _ANCHOR_RE.match(t):
        return True
    # Short ALL-CAPS heading heuristic (covers titles and section banners).
    if len(t) <= 90:
        letters = [c for c in t if c.isalpha()]
        if letters and sum(1 for c in letters if c.isupper()) / len(letters) >= 0.8:
            return True
    return False


def build_textual_redline(
    text_a: str,
    text_b: str,
    f1_label: str = "F1",
    f2_label: str = "F2",
    collapse_unchanged: bool = False,
) -> str:
    """Render a paragraph-grouped, word-level diff as plain text with markers.

    Output schema:
      [F1-ONLY] / [F2-ONLY]  → entire paragraph present only in one document
      [BOTH] with [-…-] / [+…+] inline markers for atomic word-level changes
      [MOVED]                → paragraph present in both, near-identical text,
                                different position. Detected deterministically
                                via SequenceMatcher.ratio() ≥ 0.85.

    The MOVED post-processing prevents two recurrent LLM failure modes:
    1. labelling moved paragraphs as Added (because they appear F2-ONLY in the
       paragraph alignment when their position changes),
    2. duplicating them in both Removed and Moved sections.

    When `collapse_unchanged` is True, runs of unchanged [BOTH] paragraphs are
    replaced by a compact `[UNCHANGED ×N]` placeholder, while heading-like
    anchors (see `_is_anchor`) and every actual change are kept verbatim. This
    is the LLM-evidence path: it keeps the prompt small (a small local model
    reasons better over signal than over the whole document) and — crucially —
    guarantees no real difference is ever dropped by the downstream size cap,
    because the unchanged bulk is gone before truncation is even considered.
    Default False preserves the full output (every paragraph emitted).

    Reuses the same `_split_into_blocks` / `_align_blocks` pipeline that
    backs the visual DOCX redline, so the model's view and the human's view
    stay in lock-step. `f1_label` / `f2_label` are reserved for future use
    (e.g. custom labels in a multi-doc context); current callers pass the
    defaults and the markers themselves are hard-coded to F1/F2.
    """
    # Reserved for future per-call customization. Currently unused — the
    # markers are hard-coded as `[F1-ONLY]` / `[F2-ONLY]` for stability:
    # the LLM prompt is calibrated against these exact strings.
    del f1_label, f2_label

    blocks_a = _split_into_blocks(text_a)
    blocks_b = _split_into_blocks(text_b)
    if not blocks_a and not blocks_b:
        return ""

    # Phase 1 — type each aligned pair as F1-ONLY / F2-ONLY / BOTH.
    # When the aligner pairs two paragraphs that happen to share only a
    # common prefix (e.g. "Articolo 5 - Esclusiva" vs "Articolo 5 - Riservatezza")
    # the body word-level similarity is low — we demote those to F1-ONLY +
    # F2-ONLY so the LLM treats them as Removed + Added, never as Modified.
    typed_blocks: list[tuple[str, str]] = []
    for block_a, block_b in _align_blocks(blocks_a, blocks_b):
        tokens_a = _tokenize(block_a)
        tokens_b = _tokenize(block_b)

        if not tokens_a and not tokens_b:
            continue
        if not tokens_a:
            typed_blocks.append(('F2-ONLY', _escape_marker_collisions(block_b)))
            continue
        if not tokens_b:
            typed_blocks.append(('F1-ONLY', _escape_marker_collisions(block_a)))
            continue

        # Both sides have content — measure word-level similarity to decide.
        similarity = difflib.SequenceMatcher(
            None, tokens_a, tokens_b, autojunk=False
        ).ratio()

        if similarity < _BOTH_DEMOTE_THRESHOLD:
            typed_blocks.append(('F1-ONLY', _escape_marker_collisions(block_a)))
            typed_blocks.append(('F2-ONLY', _escape_marker_collisions(block_b)))
            continue

        body, _has_changes = _emit_textual_diff_for_block(tokens_a, tokens_b)
        typed_blocks.append(('BOTH', body))

    # Phase 2 — detect MOVED pairs (F1-ONLY ↔ F2-ONLY with ratio ≥ threshold).
    moved_pairs = _detect_moved_pairs(typed_blocks)
    moved_f1_to_f2 = {f1: f2 for f1, f2 in moved_pairs}
    moved_f2_consumed = {f2 for _, f2 in moved_pairs}

    # Phase 3 — serialize, emitting [MOVED] in place of paired F1-ONLY/F2-ONLY.
    # With `collapse_unchanged`, unchanged [BOTH] filler is folded into a compact
    # `[UNCHANGED ×N]` marker; anchors and real changes are always kept verbatim.
    out: list[str] = []
    pending_unchanged = 0  # consecutive collapsed filler paragraphs awaiting flush

    def _flush_unchanged() -> None:
        nonlocal pending_unchanged
        if pending_unchanged:
            out.append(f"[UNCHANGED ×{pending_unchanged}]")
            pending_unchanged = 0

    for i, (kind, body) in enumerate(typed_blocks):
        if kind == 'F2-ONLY' and i in moved_f2_consumed:
            # Already absorbed into a MOVED block when its F1-ONLY peer was emitted.
            continue

        # An unchanged paragraph is a [BOTH] block with no inline change markers
        # (source collisions are escaped to `[ -` / `[ +`, so a genuine marker is
        # exactly `[-` / `[+`).
        if (
            collapse_unchanged
            and kind == 'BOTH'
            and '[-' not in body and '[+' not in body
            and not _is_anchor(body)
        ):
            pending_unchanged += 1
            continue

        if collapse_unchanged:
            _flush_unchanged()

        if kind == 'F1-ONLY' and i in moved_f1_to_f2:
            f2_idx = moved_f1_to_f2[i]
            f2_body = typed_blocks[f2_idx][1]
            out.append(
                f"[MOVED]\nF1: {body}\nF2: {f2_body}\n[/MOVED]"
            )
        elif kind == 'BOTH':
            out.append(f"[BOTH]\n{body}\n[/BOTH]")
        else:
            out.append(f"[{kind}]\n{body}\n[/{kind}]")

    if collapse_unchanged:
        _flush_unchanged()

    return "\n\n".join(out)
