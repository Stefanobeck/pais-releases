"""
Manipulate Module - API Routes per PAI Premium
Supporta:
- Upload Excel/CSV
- Analysis SQL streaming
- Smart Suggestions
- Export Excel
"""
import os
import uuid
import json
from typing import List, Optional, Dict
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Query, Form
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from pathlib import Path
import logging

from backend_config.settings import BASE_DIR
from backend_config.project_manager import project_manager
from backend_config.auth_pro import require_pro_or_trial
from services.manipulate_service import ManipulateService
from services.i18n_service import i18n

logger = logging.getLogger(__name__)

# Gate PRO-only: tutti gli endpoint MANIPULATE richiedono tier pro o
# free_trial. In free_residual → 402 UPGRADE_REQUIRED handled da frontend.
router = APIRouter(dependencies=[Depends(require_pro_or_trial)])

# Router PUBBLICO (no gate): endpoint di sola lettura che la pagina Impostazioni
# usa anche da free per mostrare/scaricare i modelli (così l'utente può
# prepararsi a PRO). NON deve esporre nessuna operazione di trasformazione.
public_router = APIRouter()

# Service instance (initialized lazily per project)
_manipulate_service = None


def get_manipulate_service():
    """Ottieni ManipulateService con path ChromaDB per progetto."""
    global _manipulate_service
    chroma_path = str(project_manager.get_path("db")) if project_manager.active_project_path else str(BASE_DIR / "chroma_db")
    if _manipulate_service is None or _manipulate_service._chroma_path != chroma_path:
        _manipulate_service = ManipulateService(persist_directory=chroma_path)
        _manipulate_service._chroma_path = chroma_path
    return _manipulate_service


# Request/Response Models
class ManipulateUploadResponse(BaseModel):
    filename: str
    status: str
    message: str
    ref: Optional[str] = None
    tables: Optional[List[str]] = None
    session_id: str


class UploadRequest(BaseModel):
    session_id: Optional[str] = None
    mode: str = "Export to Sheet"


class MemorizeRequest(BaseModel):
    session_id: Optional[str] = None
    mode: str = "Export to Sheet"
    lang: str = "it"


class AnalyzeRequest(BaseModel):
    query: str
    session_id: Optional[str] = None
    mode: str = "Export to Sheet"
    lang: str = "it"


class ChartsRequest(BaseModel):
    query: str
    session_id: Optional[str] = None
    chart_type: str = "Auto"
    lang: str = "it"


class StyleOptions(BaseModel):
    """Toggle 'cosa includere nello stile'. Header + formati numerici sono sempre on.
    Default allineati a DEFAULT_STYLE_OPTIONS in processors/styler.py."""
    conditional_formatting: bool = True
    sparkline_trend: bool = True
    data_validation: bool = False
    freeze_panes: bool = True
    autofilter: bool = True


class StyleRequest(BaseModel):
    session_id: Optional[str] = None
    excel_style: str = "Corporate Blue"
    lang: str = "it"
    # default_factory ⇒ ogni richiesta ha la sua istanza; client che omettono il
    # campo ottengono i default approvati (retrocompatibile).
    style_options: StyleOptions = Field(default_factory=StyleOptions)


class MergeSheetsRequest(BaseModel):
    session_id: Optional[str] = None
    lang: str = "it"


class SuggestionsRequest(BaseModel):
    session_id: Optional[str] = None
    mode: str = "Export to Sheet"
    level: str = "Easy"
    area: str = "General"
    lang: str = "it"


class FileListResponse(BaseModel):
    files: List[Dict]
    session_id: str


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None),
    mode: str = Form(default="Analyze"),
    lang: str = Form(default="it")
):
    """
    Upload file Excel/CSV per MANIPULATE.
    """
    try:
        session_id = session_id or str(uuid.uuid4())
        
        # Aggiorna lingua
        get_manipulate_service().set_language(lang)

        # Salva file - usa uploads del progetto
        upload_dir = project_manager.get_path("uploads") / "manipulate" if project_manager.active_project_path else BASE_DIR / "uploads" / "manipulate"
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_path = upload_dir / file.filename
        content = await file.read()
        with open(file_path, "wb") as buffer:
            buffer.write(content)

        # Determina tipo file
        ext = Path(file.filename).suffix.lower()
        allowed_exts = {'.xlsx', '.xls', '.csv'}

        if ext not in allowed_exts:
            raise HTTPException(
                status_code=400,
                detail=i18n.get('sidebar.unsupported_format_error', "Il modulo {module} non accetta il formato {ext}. Formati accettati: {allowed}")
                        .replace('{module}', 'MANIPULATE')
                        .replace('{ext}', ext)
                        .replace('{allowed}', 'XLSX, XLS, CSV')
            )

        # Upload con MANIPULATE service
        result = await get_manipulate_service().upload_file(
            file_path=str(file_path),
            filename=file.filename,
            session_id=session_id,
            mode=mode
        )
        
        return ManipulateUploadResponse(
            filename=file.filename,
            status=result['status'],
            message=result.get('message', ''),
            ref=result.get('ref'),
            tables=result.get('tables'),
            session_id=session_id
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/memorize")
async def memorize_files(request: MemorizeRequest):
    """
    Processa file in staging e li carica in DuckDB.
    """
    try:
        session_id = request.session_id or str(uuid.uuid4())
        
        # Aggiorna lingua
        get_manipulate_service().set_language(request.lang)

        result = await get_manipulate_service().memorize_files(
            session_id=session_id,
            mode=request.mode
        )

        return {
            "status": result['status'],
            "message": result.get('message', ''),
            "uploaded_count": result.get('uploaded_count', 0),
            "warnings": result.get('warnings', []),
            "session_id": session_id
        }

    except Exception as e:
        logger.error(f"Memorize error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze/stream")
async def analyze_stream(request: AnalyzeRequest):
    """
    Analisi SQL con streaming.
    """
    session_id = request.session_id or str(uuid.uuid4())
    
    # Aggiorna lingua
    get_manipulate_service().set_language(request.lang)

    async def generate():
        try:
            async for chunk in get_manipulate_service().analyze(
                query=request.query,
                session_id=session_id,
                mode=request.mode
            ):
                # chunk is Tuple[bool, str, List]
                # We yield the string message as 'chunk' for the frontend typewriter effect
                message_str = chunk[1] if isinstance(chunk, tuple) and len(chunk) > 1 else str(chunk)
                yield f"data: {json.dumps({'chunk': message_str})}\n\n"
            
            yield f"data: {json.dumps({'done': True, 'session_id': session_id})}\n\n"
            
        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


@router.post("/charts")
async def create_charts(request: ChartsRequest):
    """
    Generazione grafici (Excel + PNG).
    """
    session_id = request.session_id or str(uuid.uuid4())
    
    # Aggiorna lingua
    get_manipulate_service().set_language(request.lang)

    try:
        result = await get_manipulate_service().analyze_charts(
            query=request.query,
            session_id=session_id,
            chart_type=request.chart_type
        )
        
        return {
            "status": "success",
            "message": result,
            "session_id": session_id
        }
        
    except Exception as e:
        logger.error(f"Charts error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/style")
async def apply_style(request: StyleRequest):
    """
    Formattazione Excel professionale.
    """
    session_id = request.session_id or str(uuid.uuid4())

    # Aggiorna lingua
    get_manipulate_service().set_language(request.lang)

    try:
        result = await get_manipulate_service().analyze_style(
            session_id=session_id,
            excel_style=request.excel_style,
            style_options=request.style_options.model_dump()
        )

        return {
            "status": "success",
            "message": result,
            "session_id": session_id
        }

    except Exception as e:
        logger.error(f"Style error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/style_templates")
async def get_style_templates():
    """Template di stile disponibili (id + label + palette colori). Fonte unica:
    STYLE_TEMPLATES in processors/styler.py. Le card del frontend renderizzano da qui."""
    from processors.styler import STYLE_TEMPLATES
    return {"templates": [
        {"id": name, "label": name, **palette}
        for name, palette in STYLE_TEMPLATES.items()
    ]}


@router.post("/merge")
async def merge_sheets(request: MergeSheetsRequest):
    """
    Merge Sheets (4° sottomodulo Manipulate, re-introdotto 2026-05-19).
    Versione semplice: N file xlsx/csv caricati -> 1 xlsx output con
    un foglio per file sorgente (sheet name = filename sanitized).
    Min 2 file, max 5.
    """
    session_id = request.session_id or str(uuid.uuid4())
    get_manipulate_service().set_language(request.lang)
    try:
        result = await get_manipulate_service().merge_sheets(session_id=session_id)
        return {
            "status": "success",
            "message": result,
            "session_id": session_id,
        }
    except Exception as e:
        logger.error(f"Merge Sheets error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/suggestions")
async def get_suggestions(
    request: SuggestionsRequest
):
    """
    Ottiene suggerimenti contestuali categorizzati (Area/Level).
    """
    try:
        if not request.session_id:
            raise HTTPException(status_code=400, detail="session_id is required")

        suggestions = await get_manipulate_service().get_smart_suggestions(
            session_id=request.session_id,
            mode=request.mode,
            level=request.level,
            area=request.area,
            lang=request.lang
        )

        return {
            "status": "success",
            "suggestions": suggestions,
            "session_id": request.session_id
        }

    except Exception as e:
        logger.error(f"Suggestions error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/staged")
async def get_staged_files(session_id: str):
    """
    Ottieni file in staging.
    """
    files = get_manipulate_service().get_staged_files(session_id)
    return {
        "files": files,
        "session_id": session_id
    }


@router.delete("/staged/{filename}")
async def remove_staged_file(filename: str, session_id: str):
    """
    Rimuovi file da staging.
    """
    try:
        get_manipulate_service().remove_file(filename, session_id, from_staged=True)
        return {"status": "success", "message": f"File {filename} removed from staging"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/files", response_model=FileListResponse)
async def get_uploaded_files(session_id: str):
    """
    Ottieni lista file caricati con metadati colonne (Legacy alignment).
    """
    files = get_manipulate_service().get_uploaded_files(session_id)

    enriched_files = []
    for f in files:
        f_enriched = f.copy()
        f_enriched['columns'] = []
        for t_name in f.get('tables', []):
            if t_name in get_manipulate_service().data_processor.table_info:
                f_enriched['columns'].extend(get_manipulate_service().data_processor.table_info[t_name].get('columns', []))
        f_enriched['columns'] = list(dict.fromkeys(f_enriched['columns']))
        enriched_files.append(f_enriched)

    return FileListResponse(
        files=enriched_files,
        session_id=session_id
    )


@router.delete("/upload/{filename}")
async def remove_document(filename: str, session_id: str):
    """
    Remove a file from the session.
    """
    try:
        get_manipulate_service().remove_file(filename, session_id)
        return {"status": "success", "message": f"File {filename} removed"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class HistoryResponse(BaseModel):
    history: List[Dict]
    session_id: str
    documents: List[Dict] = []

@router.get("/history/{session_id}", response_model=HistoryResponse)
async def get_history(session_id: str):
    """Ottieni storia conversazione e file attivi."""
    # Garantisce il caricamento da disco se necessario
    history = get_manipulate_service()._get_or_create_session(session_id)

    files = get_manipulate_service().get_uploaded_files(session_id)
    logger.info(f"📋 [GET_HISTORY] Session: {session_id} | Files found: {len(files)}")

    enriched_files = []
    for f in files:
        f_enriched = f.copy()
        f_enriched['columns'] = []
        tables = f.get('tables', [])
        logger.info(f"📋 [GET_HISTORY] File: {f['name']} | Tables: {tables}")

        for t_name in tables:
            if t_name in get_manipulate_service().data_processor.table_info:
                cols = get_manipulate_service().data_processor.table_info[t_name].get('columns', [])
                f_enriched['columns'].extend(cols)
                logger.info(f"📋 [GET_HISTORY] Table {t_name} found! Cols: {len(cols)}")
            else:
                logger.warning(f"📋 [GET_HISTORY] Table {t_name} NOT FOUND in table_info!")
                
        f_enriched['columns'] = list(dict.fromkeys(f_enriched['columns']))
        enriched_files.append(f_enriched)
        
    return HistoryResponse(
        history=history,
        session_id=session_id,
        documents=enriched_files
    )

@router.delete("/history/{session_id}")
async def clear_history(session_id: str):
    """
    Clear session history.
    """
    try:
        get_manipulate_service().clear_session(session_id)
        return {"status": "success", "message": "History cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── Manipulate model swap (high/low profile) ──────────────────────────────
# In MANIPULATE l'utente sceglie tra modello "default" (qwen3-coder:30b, qualità
# massima ma 18 GB di VRAM) e "low profile" (qwen2.5-coder:7b, leggero su PC
# meno performanti). Il cambio mute *tutte* le chiavi qwen3-coder usate dal
# modulo: manipulate_model, engineering_model, graphics_model, style_model,
# smart_suggestion_model, smart_suggestion_model_analyze, planner_model.
# A differenza di INTERROGATE, il cambio NON è persistito tra riavvi (in-memory).

# Chiavi di models.json che il modulo MANIPULATE usa per i suoi LLM.
_MANIPULATE_MODEL_KEYS = (
    "manipulate_model", "engineering_model", "graphics_model", "style_model",
    "smart_suggestion_model", "smart_suggestion_model_analyze", "planner_model",
)


@router.get("/settings/model")
async def get_manipulate_model():
    """Restituisce il modello attivo per MANIPULATE (legge da settings runtime)."""
    from backend_config.settings import settings as _settings
    return {"model": _settings.MANIPULATE_MODEL}


@router.post("/settings/model")
async def set_manipulate_model(model: str):
    """Cambia il modello LLM di MANIPULATE a runtime.

    Aggiorna in cascata TUTTE le variabili di settings usate dai sottomoduli
    di MANIPULATE: MANIPULATE_MODEL, ENGINEERING_MODEL (Export to Sheet),
    GRAPHICS_MODEL (Add Charts), ANALYZE_MODEL (Add Style + suggestions
    fallback), SUGGESTION_MODEL. Aggiorna anche il dict self.models del
    manipulate_service (usato dai metodi che leggono via models.json keys).

    Risultato atteso: scegliendo qwen2.5-coder:7b nel picker, ANCHE i
    suggestions di Add Style passano a 7b (prima restavano su qwen3-coder:30b
    perché ANALYZE_MODEL era escluso dallo swap — bug noto, ora corretto).
    """
    from backend_config.settings import settings as _settings
    _settings.MANIPULATE_MODEL = model
    _settings.ENGINEERING_MODEL = model
    _settings.GRAPHICS_MODEL = model
    _settings.ANALYZE_MODEL = model      # usato da suggestions_service per "Add Style"
    _settings.SUGGESTION_MODEL = model
    svc = get_manipulate_service()
    if hasattr(svc, "models") and isinstance(svc.models, dict):
        for k in _MANIPULATE_MODEL_KEYS:
            svc.models[k] = model
    logger.info(f"[MANIPULATE] Model switched at runtime → {model}")
    return {"status": "success", "model": model}


@public_router.get("/models_catalog")
async def get_models_catalog():
    """Catalog dei modelli per MANIPULATE: canonical da profiles.json
    (qwen3-coder:30b → HIGH, qwen2.5-coder:7b → LOW) + custom utente.
    Solo gli installati sono selezionabili nel picker frontend.
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import get_manipulate_catalog
        return await get_manipulate_catalog(system_service)
    except Exception as e:
        logger.error(f"manipulate models_catalog failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class ManipulateCustomModelRequest(BaseModel):
    model_id: str


@router.post("/custom_model")
async def add_custom_model(req: ManipulateCustomModelRequest):
    """Add a user-installed Ollama model to the Manipulate picker.
    Must already be installed via /api/system/install (only registers it).
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import add_module_custom_model
        return await add_module_custom_model(system_service, "manipulate", req.model_id)
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"manipulate add_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/custom_model/{model_id:path}")
async def remove_custom_model(model_id: str):
    """Remove a custom model from the Manipulate picker. Does NOT uninstall the
    model from Ollama (use DELETE /api/system/model for that).
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import remove_module_custom_model
        return await remove_module_custom_model(system_service, "manipulate", model_id)
    except LookupError as le:
        raise HTTPException(status_code=404, detail=str(le))
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"manipulate remove_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
