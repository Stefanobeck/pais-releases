"""
Studio Identity Service - Logo upload/delete + lookup wrapper.

Logo storage: BASE_DIR/user_assets/studio_logo.<ext> (svuotato e ricreato a ogni
upload). Solo PNG/JPG/SVG, max 2MB. user_settings.json salva il path relativo
('user_assets/studio_logo.png') così il frontend può servirlo.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Tuple

from backend_config import settings

logger = logging.getLogger("PAIS.StudioIdentity")

ALLOWED_LOGO_EXTS = {"png", "jpg", "jpeg", "svg"}
ALLOWED_LOGO_MIMES = {"image/png", "image/jpeg", "image/svg+xml"}
LOGO_MAX_BYTES = 2 * 1024 * 1024  # 2MB

USER_ASSETS_DIRNAME = "user_assets"


def _user_assets_dir() -> Path:
    p = settings.BASE_DIR / USER_ASSETS_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_logo_full_path() -> Optional[Path]:
    """Return absolute path to current logo file, or None if missing."""
    from services import user_settings_service as uss
    s = uss.get_studio_identity()
    if not s:
        return None
    rel = s.get("logo_path")
    if not rel:
        return None
    p = settings.BASE_DIR / rel
    if not p.exists():
        return None
    return p


def save_logo(content: bytes, content_type: str, original_filename: str) -> str:
    """Validate + persist logo, update user_settings.json with relative path.
    Returns the relative path stored (e.g. 'user_assets/studio_logo.png').
    """
    if len(content) > LOGO_MAX_BYTES:
        raise ValueError(f"Logo too large: {len(content)} bytes (max {LOGO_MAX_BYTES})")
    ct = (content_type or "").lower().split(";")[0].strip()
    if ct not in ALLOWED_LOGO_MIMES:
        raise ValueError(f"Unsupported logo MIME '{ct}'. Allowed: {sorted(ALLOWED_LOGO_MIMES)}")

    # Determina estensione dal mime, fallback sul filename.
    ext_map = {"image/png": "png", "image/jpeg": "jpg", "image/svg+xml": "svg"}
    ext = ext_map.get(ct)
    if not ext:
        ext = (original_filename.rsplit(".", 1)[-1] or "").lower()
    if ext not in ALLOWED_LOGO_EXTS:
        raise ValueError(f"Unsupported logo extension '{ext}'")

    # Pulisci eventuali logo precedenti con altre estensioni (atomicità).
    assets = _user_assets_dir()
    for old in assets.glob("studio_logo.*"):
        try:
            old.unlink()
        except Exception:
            pass

    target = assets / f"studio_logo.{ext}"
    target.write_bytes(content)
    logger.info(f"Logo saved: {target} ({len(content)} bytes)")

    rel_path = f"{USER_ASSETS_DIRNAME}/studio_logo.{ext}"
    from services import user_settings_service as uss
    uss.set_studio_logo_path(rel_path)
    return rel_path


def delete_logo() -> bool:
    """Remove the current logo file and clear logo_path. Returns True if a file
    was actually deleted.
    """
    assets = _user_assets_dir()
    deleted = False
    for old in assets.glob("studio_logo.*"):
        try:
            old.unlink()
            deleted = True
        except Exception as e:
            logger.warning(f"failed to delete {old}: {e}")
    from services import user_settings_service as uss
    uss.set_studio_logo_path(None)
    return deleted
