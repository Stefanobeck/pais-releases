"""
Vision Processor - PAI Premium
Image-only visual analysis (JPG, PNG, WEBP).

Supporto VIDEO + AUDIO (Whisper) RIMOSSO il 2026-05-08. Il file è ora
focalizzato su:
- Resize non-distruttivo (vedi never_overwrite_original policy)
- Analisi singola immagine via qwen3-vl o gemma4 (modello selezionabile)
"""
import cv2
import os
import logging
import base64
from typing import Dict, Optional
import ollama
from pathlib import Path

from backend_config.settings import settings

# Logging Configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VisionProcessor:
    """
    Image-only Visual Analysis pipeline.
    - Resize non-distruttivo via OpenCV (max 1024px lato lungo, JPEG q85)
    - Analisi immagine con qwen3-vl o gemma4 (modello selezionabile runtime)
    - Output: descrizione testuale per indicizzazione RAG
    """

    def __init__(self, lang: str = "it"):
        self._client = None
        self.lang = lang
        self.prompts = self._load_prompts()

    @property
    def client(self):
        """Restituisce un client Ollama aggiornato con l'host corrente."""
        if self._client is None:
            logger.info(f"Initializing Vision Ollama Client on {settings.OLLAMA_HOST_URL}")
            self._client = ollama.AsyncClient(host=settings.OLLAMA_HOST_URL)
        return self._client

    def _load_prompts(self) -> Dict:
        """Carica prompt da configurazione."""
        prompts_path = Path(__file__).parent.parent / "backend_config" / "prompts_vision.json"
        try:
            import json
            with open(prompts_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get(self.lang, data.get('it', {}))
        except Exception as e:
            logger.error(f"Error loading vision prompts: {e}")
            return {
                "analysis": {
                    "image_prompt": "Describe this image in detail.",
                    "single_frame_description": "Analyze this frame with precision."
                }
            }

    def set_language(self, lang: str):
        self.lang = lang
        self.prompts = self._load_prompts()

    def _resize_image(self, image_path: str, max_size: int = 1024, quality: int = 85) -> Optional[bytes]:
        """
        Ridimensiona immagine a max_size px sul lato più lungo.
        Se già sotto la soglia, ritorna i bytes originali.
        Risparmio tipico: 15MB → 300KB con zero perdita per il modello.
        """
        try:
            with open(image_path, 'rb') as f:
                original_bytes = f.read()

            # Se sotto 500KB, skip resize (già ottimale)
            if len(original_bytes) < 500 * 1024:
                return original_bytes

            img = cv2.imread(image_path)
            if img is None:
                return original_bytes

            h, w = img.shape[:2]
            longest = max(h, w)

            # Skip se già sotto max_size
            if longest <= max_size:
                return original_bytes

            # Calcola nuove dimensioni
            scale = max_size / longest
            new_w = int(w * scale)
            new_h = int(h * scale)

            small = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)

            # Encode JPEG con qualità controllata
            _, encoded = cv2.imencode('.jpg', small, [cv2.IMWRITE_JPEG_QUALITY, quality])
            resized_bytes = encoded.tobytes()

            logger.info(f"🖼️ Image resized: {w}x{h} → {new_w}x{new_h} | {len(original_bytes)/1024:.0f}KB → {len(resized_bytes)/1024:.0f}KB")
            return resized_bytes

        except Exception as e:
            logger.warning(f"Resize failed, using original: {e}")
            try:
                with open(image_path, 'rb') as f:
                    return f.read()
            except:
                return None


    async def analyze_image(self, image_path: str, prompt: str = None) -> str:
        """
        Analyzes a single image and returns description.
        """
        if prompt is None:
            prompt = self.prompts.get('analysis', {}).get('image_prompt', 'Describe this image in detail.')
        
        try:
            with open(image_path, 'rb') as f:
                img_bytes = f.read()
            
            # num_ctx: usa il VISION_CTX dei settings (default 32768) invece di
            #   un valore hardcoded — coerente con la chat stream che ora usa
            #   lo stesso valore come max_ctx.
            # num_predict: cap output 8192 → previene thinking loop infiniti
            #   (specie su modelli vision più grandi che tendono a ragionare a lungo).
            # repeat_penalty / repeat_last_n: stessa formula della chat stream
            #   per scoraggiare loop di token ripetuti.
            # top_k 30 / top_p 0.85: leggermente più stretti del default Ollama
            #   (40 / 0.9) per ridurre allucinazioni nelle descrizioni iniziali
            #   che servono al RAG.
            res = await self.client.chat(
                model=settings.VISION_MODEL,
                messages=[{
                    'role': 'user',
                    'content': prompt,
                    'images': [img_bytes]
                }],
                options={
                    'temperature': 0.0,
                    'num_ctx': min(settings.VISION_CTX, 32768),
                    'num_predict': 8192,
                    'repeat_penalty': 1.15,
                    'repeat_last_n': 256,
                    'top_k': 30,
                    'top_p': 0.85,
                }
            )
            return res['message']['content']
        except Exception as e:
            logger.error(f"Image analysis error: {e}")
            return f"Error: {e}"

    async def analyze_image_base64(self, image_base64: str, prompt: str = None) -> str:
        """
        Analyzes image from base64 string.
        """
        if prompt is None:
            prompt = self.prompts.get('analysis', {}).get('image_prompt', 'Describe this image in detail.')
        
        try:
            img_bytes = base64.b64decode(image_base64)
            
            res = await self.client.chat(
                model=settings.VISION_MODEL,
                messages=[{
                    'role': 'user',
                    'content': prompt,
                    'images': [img_bytes]
                }],
                options={
                    'temperature': 0.0,
                    'num_ctx': 8192
                }
            )
            return res['message']['content']
        except Exception as e:
            logger.error(f"Image analysis error: {e}")
            return f"Error: {e}"

