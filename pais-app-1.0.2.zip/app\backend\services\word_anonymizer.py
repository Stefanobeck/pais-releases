
import logging
from docx import Document
from typing import Dict
import asyncio
from services.text_advanced_anonymizer import AdvancedTextAnonymizer

logger = logging.getLogger(__name__)

class WordAnonymizer:
    """Specialized anonymizer for .docx files that preserves layout and formatting."""
    
    def __init__(self, vault, language="it"):
        self.vault = vault
        self.language = language
        self.text_engine = AdvancedTextAnonymizer(vault, language=language)

    async def process(self, input_path: str, output_path: str):
        """Processes a DOCX file in-place, replacing text while keeping styles."""
        try:
            doc = Document(input_path)
            
            # 1. Anonimizzazione Paragrafi
            for para in doc.paragraphs:
                if para.text.strip():
                    para.text = await self.text_engine.process(para.text)

            # 2. Anonimizzazione Tabelle
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            # Nota: cell.text = ... resetta la formattazione interna della cella (es. grassetti singoli),
                            # ma mantiene lo stile della tabella e la struttura.
                            cell.text = await self.text_engine.process(cell.text)

            # 3. Anonimizzazione Header e Footer
            for section in doc.sections:
                # Header
                if section.header:
                    for para in section.header.paragraphs:
                        if para.text.strip():
                            para.text = await self.text_engine.process(para.text)
                # Footer
                if section.footer:
                    for para in section.footer.paragraphs:
                        if para.text.strip():
                            para.text = await self.text_engine.process(para.text)

            doc.save(output_path)
            logger.info(f"✅ Word file processed and saved to {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"❌ Error processing Word file: {e}")
            raise e
