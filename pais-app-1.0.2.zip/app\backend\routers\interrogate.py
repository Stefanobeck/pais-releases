"""
Interrogate Module - Chat API Routes per PAI Premium
Supporta:
- Chat streaming con RAG
- Upload documenti multipli
- Smart File Reference Detection
- Persistenza cronologia
- WebSocket per streaming real-time
- Smart Suggestions System
"""
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse, PlainTextResponse
from pydantic import BaseModel
from typing import List, Optional, Dict
import logging
import json
import time
import os
import shutil
import asyncio
import uuid
from pathlib import Path

from backend_config.settings import settings
from backend_config.project_manager import project_manager
from services.chat_service import ChatService
from services.suggestions_service import SuggestionsService
from services.export_manager import ExportManager, strip_thinking_tags

router = APIRouter()
logger = logging.getLogger(__name__)

# Upload limits
MAX_FILES       = 5
MAX_FILE_BYTES  = 20 * 1024 * 1024   # 20 MB
MAX_TOTAL_BYTES = 50 * 1024 * 1024   # 50 MB

# Service instances (initialized lazily per project)
_chat_service = None
_suggestions_service = None
_export_manager = None


def get_chat_service():
    """Ottieni ChatService con path ChromaDB per progetto."""
    global _chat_service
    chroma_path = str(project_manager.get_path("db")) if project_manager.active_project_path else None
    if _chat_service is None or _chat_service._chroma_path != chroma_path:
        _chat_service = ChatService(persist_directory=chroma_path)
        _chat_service._chroma_path = chroma_path
    return _chat_service


def get_suggestions_service_instance():
    global _suggestions_service
    if _suggestions_service is None:
        _suggestions_service = SuggestionsService()
    return _suggestions_service


def get_export_manager_instance():
    global _export_manager
    if _export_manager is None:
        _export_manager = ExportManager(str(settings.BASE_DIR / "exports"))
    return _export_manager

# Models for requests/responses
class ChatRequest(BaseModel):
    message: str
    session_id: str
    use_rag: bool = True

class StreamChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    use_rag: bool = True
    lang: str = "it"
    temperature: Optional[float] = None
    seed: Optional[int] = None

class ExportRequest(BaseModel):
    session_id: str
    format: str # txt, md, html, pdf, docx
    include_thinking: bool = False
    content: Optional[str] = None
    style: str = "plain"  # 'plain' (default) o 'studio' — 'studio' aggiunge header brandizzato a Word/PDF

class ExportTablesRequest(BaseModel):
    session_id: str
    content: Optional[str] = None

class ExportArtifactRequest(BaseModel):
    session_id: str
    type: str  # 'code' (estendibile in futuro: 'json', 'latex', 'csv', ...)
    content: Optional[str] = None

class ExportRedlineRequest(BaseModel):
    session_id: str
    open_after: bool = True
    lang: str = "it"

class ExportCompareTableRequest(BaseModel):
    session_id: str
    open_after: bool = True
    lang: str = "it"

class HistoryResponse(BaseModel):
    """Chat history response model."""
    messages: List[Dict]

@router.post("/chat")
async def chat_endpoint(request: ChatRequest):
    """
    Standard HTTP chat endpoint (non-streaming).
    Useful for quick tests or simple clients.
    """
    try:
        response_chunks = []
        async for chunk in get_chat_service().send_message(
            message=request.message,
            session_id=request.session_id,
            use_rag=request.use_rag
        ):
            response_chunks.append(chunk)
        
        return {
            "status": "success",
            "response": "".join(response_chunks),
            "session_id": request.session_id
        }
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/stream")
async def send_chat_message_stream(request: StreamChatRequest):
    """
    Send a message to the AI and get a streaming response.
    Returns SSE (Server-Sent Events) stream.
    """
    session_id = request.session_id or str(uuid.uuid4())
    logger.info(f"💬 Interrogate stream request: session_id={session_id}, message={request.message[:50]}...")

    # Aggiorna lingua
    get_chat_service().set_language(request.lang)

    async def generate():
        """Generator per SSE stream."""
        try:
            async for chunk in get_chat_service().send_message(
                message=request.message,
                session_id=session_id,
                use_rag=request.use_rag,
                temperature=request.temperature,
                seed=request.seed,
            ):
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"

            yield f"data: {json.dumps({'done': True, 'session_id': session_id})}\n\n"

        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None),
    lang: str = Form("it")
):
    """
    Upload a document for RAG in a specific session. Max 8 files.
    """
    try:
        session_id = session_id or str(uuid.uuid4())

        # I file tabellari (CSV/TSV/TAB) NON sono ammessi in Interrogate: i dati a
        # righe/colonne vanno analizzati nel modulo Manipulate (SQL), non chattati
        # come testo RAG. Guardia server-side (il frontend li filtra già a monte).
        _ext = Path(file.filename or "").suffix.lower()
        if _ext in {'.csv', '.tsv', '.tab'}:
            raise HTTPException(status_code=400, detail=f"UNSUPPORTED_TABULAR:{_ext}")

        existing_files = get_chat_service().get_uploaded_files(session_id)

        # Check max file count
        if len(existing_files) >= MAX_FILES:
            raise HTTPException(status_code=400, detail=f"LIMIT_TOO_MANY:{MAX_FILES}")

        # Check per-file size (read content to measure, then re-wrap)
        file_bytes = await file.read()
        file_size = len(file_bytes)
        if file_size > MAX_FILE_BYTES:
            size_mb = round(file_size / (1024 * 1024), 1)
            raise HTTPException(status_code=400, detail=f"LIMIT_FILE_SIZE:{file.filename}:{size_mb}")

        # Check total session size
        upload_dir = project_manager.get_path("uploads") / "interrogate" if project_manager.active_project_path else settings.BASE_DIR / "temp" / "uploads" / "interrogate"
        existing_total = 0
        if upload_dir.exists():
            for ef in existing_files:
                fp = upload_dir / ef['name']
                if fp.exists():
                    existing_total += fp.stat().st_size
        if existing_total + file_size > MAX_TOTAL_BYTES:
            total_mb = round((existing_total + file_size) / (1024 * 1024), 1)
            raise HTTPException(status_code=400, detail=f"LIMIT_TOTAL_SIZE:{total_mb}")

        # Create temp directory for upload - usa uploads del progetto
        upload_dir.mkdir(parents=True, exist_ok=True)

        file_path = upload_dir / file.filename
        with open(file_path, "wb") as buffer:
            buffer.write(file_bytes)

        # Process document
        get_chat_service().set_language(lang)

        # Caso speciale .pptx: estrai testo (con OCR su immagini embedded) e
        # registra il file come TXT generato dall'app — così l'utente vede
        # l'icona dell'occhio per ispezionare cosa l'AI ha realmente "letto".
        # Pattern identico ad auto_ocr_pdf per coerenza UX.
        ext = Path(file.filename).suffix.lower()
        if ext == '.pptx':
            try:
                doc_proc = get_chat_service().doc_processor
                extracted_text = await doc_proc._extract_pptx_text(str(file_path))
                if not extracted_text.strip():
                    raise HTTPException(status_code=400, detail="PPTX vuoto o non leggibile.")

                txt_filename = f"{Path(file.filename).stem}_PPTX.txt"
                txt_path = upload_dir / txt_filename
                with open(txt_path, "w", encoding="utf-8") as f:
                    f.write(extracted_text)

                # Cancella il PPTX originale: il testo è già nel TXT, non serve più
                try: file_path.unlink()
                except Exception: pass

                result = await get_chat_service().upload_file(
                    file_path=str(txt_path),
                    filename=txt_filename,
                    session_id=session_id,
                    is_generated=True,
                )
                if result.get('status') == 'success':
                    return result
                raise HTTPException(status_code=400, detail=result.get('message'))
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"PPTX processing error: {e}")
                # Cleanup in caso di fallimento
                try:
                    if file_path.exists(): file_path.unlink()
                except Exception: pass
                raise HTTPException(status_code=500, detail=f"PPTX processing failed: {e}")

        result = await get_chat_service().upload_file(
            file_path=str(file_path),
            filename=file.filename,
            session_id=session_id
        )

        if result.get('status') == 'success':
            # PDF con immagini embedded: segnaliamo al client che può ARRICCHIRE
            # con OCR (tabelle/figure che il testo nativo non cattura). Il testo
            # nativo è GIÀ indicizzato: l'arricchimento è opt-in lato UI.
            if (result.get('images_count') or 0) > 0 and Path(file.filename).suffix.lower() == '.pdf':
                result['images_pending'] = True
            return result
        else:
            # Se è un PDF scansionato, restituiamo 200 con status 'needs_ocr'
            if result.get('message') in ("ERROR_PDF_IMAGE_ONLY", "ERROR_DOCX_IMAGE_ONLY"):
                return {
                    "status": "needs_ocr",
                    "session_id": session_id,
                    "message": "Documento immagine rilevato"
                }
            # Embedding/processing fallito: rimuovi il file fisico dal disco
            # per evitare che l'auto-sync lo re-inserisca come "orfano"
            try:
                if file_path.exists():
                    file_path.unlink()
                    logger.info(f"🗑️ Removed failed upload file from disk: {file.filename}")
            except Exception as cleanup_err:
                logger.warning(f"Could not remove failed upload file: {cleanup_err}")
            raise HTTPException(status_code=400, detail=result.get('message'))
            
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/upload/auto-ocr")
async def auto_ocr_document(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None),
    lang: str = Form("it")
):
    """
    Automatic OCR for scanned PDFs in INTERROGATE.
    Converts scanned PDF to text and registers it.
    """
    try:
        session_id = session_id or str(uuid.uuid4())

        existing_files = get_chat_service().get_uploaded_files(session_id)

        # Check max file count
        if len(existing_files) >= MAX_FILES:
            raise HTTPException(status_code=400, detail=f"LIMIT_TOO_MANY:{MAX_FILES}")

        # Check per-file size
        file_bytes = await file.read()
        file_size = len(file_bytes)
        if file_size > MAX_FILE_BYTES:
            size_mb = round(file_size / (1024 * 1024), 1)
            raise HTTPException(status_code=400, detail=f"LIMIT_FILE_SIZE:{file.filename}:{size_mb}")

        from processors.ocr_processor import OCRImgPDFProcessor
        ocr_proc = OCRImgPDFProcessor()

        # Create temp directory for upload - usa uploads del progetto
        temp_dir = project_manager.get_path("uploads") / "interrogate" if project_manager.active_project_path else settings.BASE_DIR / "temp" / "ocr_uploads" / "interrogate"
        temp_dir.mkdir(parents=True, exist_ok=True)

        file_path = temp_dir / file.filename
        with open(file_path, "wb") as buffer:
            buffer.write(file_bytes)

        # 1. Run OCR conversion — PDF o DOCX con sole immagini
        file_ext = Path(file.filename).suffix.lower()
        if file_ext == '.docx':
            # Estrai immagini embedded da word/media/ e OCRa ciascuna
            import zipfile as _zipfile
            import tempfile as _tempfile
            ocr_parts = []
            supported_img_exts = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif', '.webp', '.emf', '.wmf'}
            with _zipfile.ZipFile(str(file_path)) as z:
                media_files = [n for n in z.namelist()
                               if n.startswith('word/media/') and Path(n).suffix.lower() in supported_img_exts]
            if not media_files:
                raise HTTPException(status_code=400, detail="DOCX non contiene immagini riconoscibili per OCR.")
            tmp_img_dir = Path(_tempfile.mkdtemp())
            try:
                with _zipfile.ZipFile(str(file_path)) as z:
                    for media_name in media_files:
                        img_path = tmp_img_dir / Path(media_name).name
                        img_path.write_bytes(z.read(media_name))
                        # EMF/WMF → converti in PNG con Pillow (Windows GDI) prima di OCR
                        if img_path.suffix.lower() in {'.emf', '.wmf'}:
                            try:
                                from PIL import Image as _PILImage
                                pil_img = _PILImage.open(str(img_path))
                                png_path = img_path.with_suffix('.png')
                                pil_img.save(str(png_path))
                                img_path = png_path
                            except Exception as emf_err:
                                logger.warning(f"EMF→PNG conversion failed for {media_name}: {emf_err}")
                                continue
                        img_ok, img_text = await ocr_proc.process_image(str(img_path))
                        if img_ok and img_text.strip():
                            ocr_parts.append(img_text.strip())
            finally:
                import shutil
                shutil.rmtree(tmp_img_dir, ignore_errors=True)
            if not ocr_parts:
                raise HTTPException(status_code=500, detail="OCR DOCX: nessun testo estratto dalle immagini.")
            full_text = "\n\n---\n\n".join(ocr_parts)
            success = True
        else:
            success, full_text = await ocr_proc.process_pdf(str(file_path))

        if not success:
            raise HTTPException(status_code=500, detail=f"OCR failed: {full_text}")

        # 2. Save extracted text to a .txt file in the project's uploads folder
        uploads_dir = project_manager.get_path("uploads") / "interrogate"
        uploads_dir.mkdir(parents=True, exist_ok=True)

        txt_filename = f"{Path(file.filename).stem}_OCR.txt"
        txt_path = uploads_dir / txt_filename

        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(full_text)

        # 3. Register the TXT file in Interrogate session
        get_chat_service().set_language(lang)
        result = await get_chat_service().upload_file(
            file_path=str(txt_path),
            filename=txt_filename,
            session_id=session_id,
            is_generated=True
        )
        
        # Clean up temp PDF
        if os.path.exists(file_path):
            os.remove(file_path)
            
        if result.get('status') == 'success':
            return {
                "status": "success",
                "message": "OCR completed and registered",
                "txt_file": txt_filename,
                "txt_path": str(txt_path),
                "text_length": len(full_text),
                "ref": result.get("ref"),
                "session_id": session_id,
                "is_generated": True
            }
        else:
            raise HTTPException(status_code=400, detail=result.get('message'))
            
    except Exception as e:
        logger.error(f"Auto-OCR error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/upload/enrich-ocr")
async def enrich_pdf_with_ocr(
    filename: str = Form(...),
    session_id: Optional[str] = Form(None),
    lang: str = Form("it"),
):
    """Arricchimento OCR opt-in di un PDF GIÀ caricato in INTERROGATE.

    Il testo nativo è già stato indicizzato all'upload; qui catturiamo SOLO le
    regioni immagine (tabelle/figure/formule) che pypdf non vede e le registriamo
    come file generato `{stem}_OCR_IMAGES.txt` (icona-occhio per ispezione).
    Risolve l'incoerenza con il tool UTILITY OCR IMG/PDF. Non PRO-gated.
    """
    try:
        session_id = session_id or str(uuid.uuid4())

        # Stesso upload_dir usato da /upload
        upload_dir = project_manager.get_path("uploads") / "interrogate" if project_manager.active_project_path else settings.BASE_DIR / "temp" / "uploads" / "interrogate"
        file_path = upload_dir / filename
        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"File non trovato: {filename}")
        if file_path.suffix.lower() != '.pdf':
            raise HTTPException(status_code=400, detail="L'arricchimento OCR immagini è supportato solo per i PDF.")

        from processors.ocr_processor import OCRImgPDFProcessor
        ocr_proc = OCRImgPDFProcessor()

        success, regions_text = await ocr_proc.extract_image_regions_only(str(file_path))
        if not success:
            raise HTTPException(status_code=500, detail=f"OCR immagini fallito: {regions_text}")

        # Nessuna regione immagine utile trovata: non creiamo file vuoti.
        if not regions_text.strip():
            return {
                "status": "success",
                "added": 0,
                "session_id": session_id,
                "message": "Nessuna tabella/immagine con contenuto OCR rilevata.",
            }

        uploads_dir = project_manager.get_path("uploads") / "interrogate"
        uploads_dir.mkdir(parents=True, exist_ok=True)
        txt_filename = f"{file_path.stem}_OCR_IMAGES.txt"
        txt_path = uploads_dir / txt_filename
        header = (
            f"[OCR IMMAGINI/TABELLE — {filename}]\n"
            "Contenuto estratto via OCR dalle regioni immagine del PDF "
            "(tabelle/figure non lette dal testo nativo).\n\n"
        )
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(header + regions_text)

        get_chat_service().set_language(lang)
        result = await get_chat_service().upload_file(
            file_path=str(txt_path),
            filename=txt_filename,
            session_id=session_id,
            is_generated=True,
        )
        if result.get('status') == 'success':
            return {
                "status": "success",
                "added": 1,
                "txt_file": txt_filename,
                "txt_path": str(txt_path),
                "text_length": len(regions_text),
                "ref": result.get("ref"),
                "session_id": session_id,
                "is_generated": True,
            }
        raise HTTPException(status_code=400, detail=result.get('message'))

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Enrich-OCR error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/upload/{filename}")
async def remove_document(filename: str, session_id: str):
    """
    Remove a document from session context.
    """
    try:
        result = get_chat_service().remove_file(filename, session_id)
        chat_message = result.get("chat_message", "") if isinstance(result, dict) else ""
        return {"status": "success", "message": f"Document {filename} removed", "chat_message": chat_message}
    except Exception as e:
        logger.error(f"Remove document error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/files")
async def list_files(session_id: str):
    """
    List uploaded files for a session.
    """
    try:
        files = get_chat_service().get_uploaded_files(session_id)
        return {"status": "success", "files": files}
    except Exception as e:
        logger.error(f"List files error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/files/open")
async def open_generated_file(session_id: str, filename: str):
    """Apre un file generato dall'app (PPTX→TXT, OCR PDF/DOCX, Grab Link)
    con l'app di default dell'OS (Notepad, Wordpad, ecc. su Windows;
    open su macOS; xdg-open su Linux).

    Sicurezza: solo file con `is_generated=True` nella sessione attiva
    sono apribili — niente traversal su disco arbitrario.
    """
    try:
        files = get_chat_service().get_uploaded_files(session_id)
        entry = next((f for f in files if f.get('name') == filename), None)
        if not entry:
            raise HTTPException(status_code=404, detail="File not found in session")
        if not entry.get('is_generated'):
            raise HTTPException(status_code=403, detail="File not openable")
        file_path = Path(entry.get('path', ''))
        if not file_path.exists() or not file_path.is_file():
            raise HTTPException(status_code=404, detail="File missing on disk")
        path_str = str(file_path.absolute())
        if os.name == 'nt':
            os.startfile(path_str)
        else:
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])
        return {"status": "success", "message": f"Opened {filename}"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Open generated file error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/files/view")
async def view_generated_file(session_id: str, filename: str):
    """
    Serve the content of an app-generated TXT (Grab Link, OCR PDF/DOCX) as plain text.
    Only files marked is_generated=True in the session can be served — protects against
    arbitrary disk reads via filename traversal.
    """
    try:
        files = get_chat_service().get_uploaded_files(session_id)
        entry = next((f for f in files if f.get('name') == filename), None)
        if not entry:
            raise HTTPException(status_code=404, detail="File not found in session")
        if not entry.get('is_generated'):
            raise HTTPException(status_code=403, detail="File not viewable")

        file_path = Path(entry.get('path', ''))
        if not file_path.exists() or not file_path.is_file():
            raise HTTPException(status_code=404, detail="File missing on disk")

        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        return PlainTextResponse(content)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"View generated file error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.websocket("/ws/{session_id}")
async def chat_websocket(websocket: WebSocket, session_id: str):
    """
    WebSocket for real-time streaming chat.
    """
    await websocket.accept()
    logger.info(f"Client connected to Interrogate WS: {session_id}")
    
    try:
        while True:
            data = await websocket.receive_text()
            try:
                request = json.loads(data)
                message = request.get('message', '')
                use_rag = request.get('use_rag', True)
            except:
                message = data
                use_rag = True
            
            # Send streaming response
            async for chunk in get_chat_service().send_message(
                message=message,
                session_id=session_id,
                use_rag=use_rag
            ):
                await websocket.send_text(chunk)
            
            # Send end marker
            await websocket.send_json({"type": "end", "session_id": session_id})
    
    except WebSocketDisconnect:
        logger.info(f"Client disconnected: {session_id}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except:
            pass

@router.get("/settings")
async def get_settings():
    """
    Get current settings (model, language, etc.).
    """
    return {
        "model": settings.CHAT_MODEL,
        "profile": settings.CHAT_PROFILE,
        "language": get_chat_service().lang,
        "ollama_host": settings.OLLAMA_HOST_URL
    }


class ProfilePromptItem(BaseModel):
    id: str
    system_prompt: str
    profile_focus: Optional[str] = None
    is_custom: bool = False


class ProfilePromptsResponse(BaseModel):
    lang: str
    profiles: List[ProfilePromptItem]


@router.get("/profiles/prompts", response_model=ProfilePromptsResponse)
async def get_profiles_prompts(lang: str = "it"):
    """
    Return the full system prompt of every profile, plus the matching profile_focus
    used by the AI Suggestions pipeline. Used by the frontend to render the
    hover-preview panel in the Style picker.

    NOTE: profiles are returned in English regardless of the `lang` query param —
    the chat service migrated to EN-only system prompts (see chat_service._build_messages).
    The `lang` param is kept for forward-compat with future custom profiles
    (which may be language-specific) and ends up in the response for the client.
    """
    data = get_chat_service()._load_prompts_for_lang('en')
    rag = data.get("rag", {})
    profiles = rag.get("profiles", {}) or {}
    focus_map = rag.get("interrogate_suggestions", {}).get("profile_focus", {}) or {}
    items = [
        ProfilePromptItem(
            id=pid,
            system_prompt=text,
            profile_focus=focus_map.get(pid),
            is_custom=False,
        )
        for pid, text in profiles.items()
    ]
    # Merge dei profili custom universali (storage utente, non per-progetto)
    try:
        from services.custom_profiles_service import custom_profiles_service
        for cp in custom_profiles_service.list_profiles():
            items.append(ProfilePromptItem(
                id=cp["id"],
                system_prompt=cp.get("system_prompt", ""),
                profile_focus=None,  # I custom non hanno profile_focus
                is_custom=True,
            ))
    except Exception as e:
        logger.warning(f"Failed to merge custom profiles into /profiles/prompts: {e}")
    return ProfilePromptsResponse(lang=lang, profiles=items)


# ─── Custom Profiles CRUD (universal storage) ─────────────────────────────

class CustomProfileIn(BaseModel):
    name: str
    system_prompt: str
    description: Optional[str] = ""
    icon: Optional[str] = "tune"


class CustomProfileOut(BaseModel):
    id: str
    name: str
    description: str = ""
    system_prompt: str
    icon: str
    created_at: str
    updated_at: str
    is_custom: bool = True


@router.get("/profiles/custom", response_model=List[CustomProfileOut])
async def list_custom_profiles():
    """Lista tutti i custom profiles dell'utente (storage universal)."""
    from services.custom_profiles_service import custom_profiles_service
    return custom_profiles_service.list_profiles()


@router.post("/profiles/custom", response_model=CustomProfileOut, status_code=201)
async def create_custom_profile(payload: CustomProfileIn):
    """Crea un nuovo custom profile. ID auto-generato come 'custom_<slug>'."""
    from services.custom_profiles_service import custom_profiles_service
    try:
        profile = custom_profiles_service.create(
            name=payload.name,
            system_prompt=payload.system_prompt,
            description=payload.description or "",
            icon=payload.icon or "tune",
        )
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    # Audit
    try:
        from services.audit_service import audit_logger
        audit_logger.log("system", "custom_profile_created",
                         profile_id=profile["id"], name=profile["name"])
    except Exception:
        pass
    return profile


@router.put("/profiles/custom/{profile_id}", response_model=CustomProfileOut)
async def update_custom_profile(profile_id: str, payload: CustomProfileIn):
    """Aggiorna un custom profile esistente."""
    from services.custom_profiles_service import custom_profiles_service
    try:
        profile = custom_profiles_service.update(
            profile_id=profile_id,
            name=payload.name,
            system_prompt=payload.system_prompt,
            description=payload.description or "",
            icon=payload.icon or "tune",
        )
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except LookupError:
        raise HTTPException(status_code=404, detail="Profilo non trovato")
    # Audit
    try:
        from services.audit_service import audit_logger
        audit_logger.log("system", "custom_profile_updated",
                         profile_id=profile["id"], name=profile["name"])
    except Exception:
        pass
    return profile


@router.delete("/profiles/custom/{profile_id}")
async def delete_custom_profile(profile_id: str):
    """Elimina un custom profile. Se era attivo, fa fallback al profilo 'default'."""
    from services.custom_profiles_service import custom_profiles_service
    try:
        deleted = custom_profiles_service.delete(profile_id)
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    if not deleted:
        raise HTTPException(status_code=404, detail="Profilo non trovato")
    # Se il profilo cancellato era attivo, reset al profilo di default
    reset_to = None
    if getattr(settings, 'CHAT_PROFILE', '') == profile_id:
        settings.CHAT_PROFILE = 'default'
        reset_to = 'default'
    # Audit
    try:
        from services.audit_service import audit_logger
        audit_logger.log("system", "custom_profile_deleted",
                         profile_id=profile_id, was_active=bool(reset_to))
    except Exception:
        pass
    return {"success": True, "deleted": profile_id, "reset_to": reset_to}

@router.post("/settings/model")
async def set_chat_model(model: str):
    """Switch the active chat model at runtime."""
    settings.CHAT_MODEL = model
    return {"status": "success", "model": model}


# ─── Models catalog (canonical + user custom) ──────────────────────────────
class CustomModelRequest(BaseModel):
    model_id: str


@router.get("/models_catalog")
async def get_models_catalog():
    """Return the list of models available for INTERROGATE: canonical (from
    profiles.json catalog) + user-installed custom Ollama models, with
    `installed`/`profile_tag`/`is_custom` flags. Single source of truth for
    the picker.
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import get_interrogate_catalog
        return await get_interrogate_catalog(system_service)
    except Exception as e:
        logger.error(f"models_catalog failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/custom_model")
async def add_custom_model(req: CustomModelRequest):
    """Add a user-installed Ollama model to the Interrogate picker.
    The model must already be installed via /api/system/install — this endpoint
    only registers it for visibility in the picker.
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import add_interrogate_custom_model
        return await add_interrogate_custom_model(system_service, req.model_id)
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"add_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/custom_model/{model_id:path}")
async def remove_custom_model(model_id: str):
    """Remove a custom model from the Interrogate picker. Does NOT uninstall
    the model from Ollama — use DELETE /api/system/model for that.
    """
    try:
        from services.system_service import system_service
        from services.catalog_service import remove_interrogate_custom_model
        return await remove_interrogate_custom_model(system_service, model_id)
    except LookupError as le:
        raise HTTPException(status_code=404, detail=str(le))
    except ValueError as ve:
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as e:
        logger.error(f"remove_custom_model failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/settings/profile")
async def set_chat_profile(profile: str, session_id: Optional[str] = None, clear_history: bool = False):
    """Switch the active system prompt profile at runtime.

    Se viene passato `session_id` con `clear_history=true`, svuota anche la
    cronologia di chat di quella sessione: necessario per evitare context
    contamination (il modello mima lo stile delle risposte precedenti
    nonostante il nuovo system prompt). I file caricati e l'indice ChromaDB
    vengono mantenuti.
    """
    settings.CHAT_PROFILE = profile
    cleared = False
    if session_id and clear_history:
        try:
            get_chat_service().clear_history(session_id)
            cleared = True
        except Exception as e:
            logger.warning(f"clear_history failed for session {session_id}: {e}")
    return {"status": "success", "profile": profile, "history_cleared": cleared}

@router.post("/settings/language")
async def set_language(language: str):
    """
    Set language for chat.
    """
    get_chat_service().set_language(language)
    get_suggestions_service_instance().set_language(language)
    return {"status": "success", "language": language}

# Smart Suggestions Routes
@router.get("/suggestions/categories")
async def get_suggestion_categories():
    """
    Get available suggestion categories and levels.
    """
    return {
        "categories": list(SuggestionsService.CATEGORIES.keys()),
        "levels": SuggestionsService.LEVELS
    }

@router.post("/suggestions/generate")
async def generate_suggestions(
    session_id: str,
    level: str = "Easy",
    category: str = "General"
):
    """
    Generate smart suggestions for a session.
    """
    try:
        # Ottieni contesto dalla sessione
        files = get_chat_service().get_uploaded_files(session_id)
        history = get_chat_service().get_history(session_id)
        
        # Costruisci contesto
        context_parts = []
        
        # File list
        if files:
            files_text = "\n".join([f['name'] for f in files])
            context_parts.append(f"UPLOADED FILES:\n{files_text}")
        
        # Last messages
        if history:
            recent = history[-6:]  # Ultimi 6 messaggi
            messages_text = "\n".join([f"{m['role']}: {m['content'][:200]}" for m in recent])
            context_parts.append(f"RECENT CONVERSATION:\n{messages_text}")
        
        context = "\n\n".join(context_parts) if context_parts else ""
        
        # Genera suggerimenti
        suggestions = await get_suggestions_service_instance().generate_suggestions(
            context=context,
            level=level,
            category=category
        )
        
        return {
            "status": "success",
            "suggestions": suggestions,
            "level": level,
            "category": category
        }
    
    except Exception as e:
        logger.error(f"Error generating suggestions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class ProfileSuggestionsRequest(BaseModel):
    profile_id: str = "default"
    profile_name: str = "General Assistant"
    documents: List[str] = []
    lang: str = "it"
    session_id: str = ""

@router.post("/suggestions/ai")
async def get_profile_suggestions(req: ProfileSuggestionsRequest):
    """
    Generate 4 context-aware suggestions based on active profile and actual document content.
    Uses a fast model (gemma4:e4b) to produce role-aware suggestions.
    """
    try:
        suggestions = await get_chat_service().generate_suggestions(
            profile_id=req.profile_id,
            profile_name=req.profile_name,
            documents=req.documents,
            lang=req.lang,
            session_id=req.session_id
        )
        return {"status": "success", "suggestions": suggestions}
    except Exception as e:
        logger.error(f"Error in profile suggestions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history/{session_id}", response_model=HistoryResponse)
async def get_chat_history(session_id: str):
    """
    Get chat history for a session.
    """
    history = get_chat_service().get_history(session_id)
    
    return HistoryResponse(
        messages=history,
    )

@router.delete("/history/{session_id}")
async def clear_chat_history(session_id: str):
    """
    Clear chat history for a session.
    """
    try:
        get_chat_service().clear_session(session_id)
        return {"status": "success", "message": "History cleared"}
    except Exception as e:
        logger.error(f"Clear history error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Export Routes
@router.post("/export")
async def export_chat(request: ExportRequest):
    """
    Export specific chat message content to specified format and open it.
    """
    try:
        from backend_config.project_manager import project_manager

        # Determina il contenuto da esportare
        if request.content:
            export_content = request.content
        else:
            # Fallback alla storia completa se il contenuto non è fornito
            history = get_chat_service().get_history(request.session_id)
            if not history:
                raise HTTPException(status_code=404, detail="No history found for session")

            export_content = f"# PAI Chat Export\n\nSession: {request.session_id}\n\n---\n\n"
            for msg in history:
                role = "AI" if msg['role'] == 'assistant' else "UTENTE"
                content = msg['content']
                if not request.include_thinking:
                    content = strip_thinking_tags(content)
                export_content += f"## {role}\n\n{content}\n\n"

        # Configura l'ExportManager con la cartella output del progetto attivo
        project_output_dir = project_manager.get_path("output")
        export_mgr = get_export_manager_instance()
        export_mgr.output_dir = str(project_output_dir)
        for exp in export_mgr.exporters.values():
            exp.output_dir = project_output_dir

        # Esporta con nome file parlante
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"chat_export_{timestamp}.{request.format}"

        # Studio identity opzionale: passata solo se style="studio" e configurata.
        # Inietta i toggle header/footer dalle export options.
        studio_payload = None
        if (request.style or "plain").lower() == "studio":
            try:
                from services import user_settings_service as uss
                # Identity + opzioni export (header on/off, template colore,
                # posizione logo). Footer rimosso dal prodotto.
                studio_payload = uss.get_studio_payload()
            except Exception as e:
                logger.warning(f"Studio identity lookup failed: {e}")

        success, result, warning = await export_mgr.export_content(
            content=export_content,
            format_type=request.format,
            filename=filename,
            studio=studio_payload,
        )

        if success:
            path_str = str(Path(result).absolute())
            if os.name == 'nt':
                os.startfile(path_str)
            else:
                import subprocess
                opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
                subprocess.call([opener, path_str])

            # Nome reale del file prodotto (può differire dal richiesto in caso di
            # fallback onesto, es. PDF→DOCX se Chromium manca).
            resp = {
                "status": "success",
                "message": f"Export completato: {os.path.basename(result)}",
                "filepath": result,
            }
            if warning:
                resp["status"] = "success_fallback"
                resp["warning"] = warning
            return resp
        else:
            raise HTTPException(status_code=500, detail=result)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/export/tables")
async def export_tables(request: ExportTablesRequest):
    """
    Extract tables from provided content or chat and export to Excel, then open it.
    """
    try:
        from backend_config.project_manager import project_manager

        project_output_dir = project_manager.get_path("output")
        export_mgr = get_export_manager_instance()
        export_mgr.output_dir = str(project_output_dir)

        markdown_text = ""
        if request.content:
            markdown_text = request.content
        else:
            history = get_chat_service().get_history(request.session_id)
            for msg in history:
                if msg['role'] == 'assistant':
                    markdown_text += msg['content'] + "\n\n"

        success, result = await export_mgr.export_tables_to_excel(markdown_text)

        if success:
            path_str = str(Path(result).absolute())
            if os.name == 'nt':
                os.startfile(path_str)
            else:
                import subprocess
                opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
                subprocess.call([opener, path_str])

            return {
                "status": "success",
                "message": "Tabelle esportate in Excel",
                "filepath": result
            }
        else:
            raise HTTPException(status_code=400, detail=result)

    except Exception as e:
        logger.error(f"Table export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Estensioni "script/eseguibili": su Windows os.startfile() le ESEGUIREBBE
# (associazione di file) invece di aprirle. Per questi file riveliamo solo la
# posizione in Explorer (file evidenziato), senza mai lanciarli.
_REVEAL_EXTS = {
    '.py', '.pyw', '.js', '.mjs', '.cjs', '.ts', '.sh', '.bash', '.zsh',
    '.ps1', '.bat', '.cmd', '.rb', '.pl', '.php', '.r', '.lua', '.vbs',
    '.jar', '.exe', '.com', '.scr', '.msi',
}


def _open_or_reveal(path_str: str) -> None:
    """Apre il file con l'app di default; ma per gli script/eseguibili (che
    su Windows verrebbero ESEGUITI da os.startfile) ne rivela soltanto la
    posizione nel file manager, senza eseguirli."""
    import subprocess
    ext = os.path.splitext(path_str)[1].lower()
    is_script = ext in _REVEAL_EXTS
    try:
        if os.name == 'nt':
            if is_script:
                # /select, evidenzia il file in Explorer senza eseguirlo.
                subprocess.Popen(['explorer', '/select,', path_str])
            else:
                os.startfile(path_str)
        else:
            target = os.path.dirname(path_str) if is_script else path_str
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, target])
    except Exception as e:
        logger.warning(f"open/reveal failed for {path_str}: {e}")


@router.post("/export/artifact")
async def export_artifact(request: ExportArtifactRequest):
    """Export generico di un "artefatto" estratto dal messaggio: a seconda di
    `type` estrae e salva il contenuto, poi apre il file. Estendibile: oggi
    supporta 'code' (blocchi di codice fenced → file singolo o .zip)."""
    try:
        from backend_config.project_manager import project_manager

        project_output_dir = project_manager.get_path("output")
        export_mgr = get_export_manager_instance()
        export_mgr.output_dir = str(project_output_dir)

        markdown_text = request.content or ""
        if not markdown_text:
            history = get_chat_service().get_history(request.session_id)
            for msg in history:
                if msg['role'] == 'assistant':
                    markdown_text += msg['content'] + "\n\n"

        atype = (request.type or '').lower()
        if atype == 'code':
            success, result = await export_mgr.export_code_blocks(markdown_text)
        elif atype == 'json':
            success, result = await export_mgr.export_json_blocks(markdown_text)
        elif atype in ('tables_csv', 'csv'):
            success, result = await export_mgr.export_tables_to_csv(markdown_text)
        elif atype == 'latex':
            success, result = await export_mgr.export_latex(markdown_text)
        elif atype == 'latex_png':
            success, result = await export_mgr.export_latex_png(markdown_text)
        elif atype == 'code_highlight':
            success, result = await export_mgr.export_code_highlight(markdown_text)
        elif atype == 'mermaid':
            success, result = await export_mgr.export_mermaid(markdown_text)
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported artifact type: {request.type}")

        if success:
            path_str = str(Path(result).absolute())
            # NB: per gli snippet di codice (.py/.js/.sh…) NON usiamo os.startfile
            # (li eseguirebbe): _open_or_reveal li mostra in Explorer.
            _open_or_reveal(path_str)

            return {
                "status": "success",
                "message": f"Artifact '{atype}' exported",
                "filepath": result
            }
        else:
            raise HTTPException(status_code=400, detail=result)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Artifact export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/export/redline-docx")
async def export_redline_docx(request: ExportRedlineRequest):
    """
    Generate a word-level redline DOCX between the 2 documents in the session
    (Compare Mode deliverable). Output: red strikethrough for tokens removed
    in F2, green underline for tokens added in F2, normal text otherwise.

    Validations:
    - Active profile must be `document_compare` (Compare Mode active).
    - Session must contain exactly 2 documents.
    """
    try:
        from backend_config.project_manager import project_manager
        from services.redline_docx import build_redline_docx
        from backend_config.auth_pro import require_pro_or_trial

        # PRO gate — Compare Mode (and its deliverables) is a PRO feature.
        require_pro_or_trial()  # raises 402 if not pro/trial

        # Profile gate — feature is Compare-Mode-only by design.
        active_profile = getattr(settings, 'CHAT_PROFILE', 'default')
        if active_profile != 'document_compare':
            raise HTTPException(
                status_code=409,
                detail="Redline export is only available in Compare Mode."
            )

        chat = get_chat_service()
        files = chat.uploaded_files.get(request.session_id, [])
        if len(files) != 2:
            raise HTTPException(
                status_code=400,
                detail=f"Redline export requires exactly 2 documents. Currently {len(files)} loaded."
            )

        docs = chat.get_session_documents_text(request.session_id)
        if len(docs) != 2 or not all(d[0] for d in docs):
            raise HTTPException(
                status_code=500,
                detail="Could not retrieve plain text for one or both documents."
            )
        (name_a, text_a), (name_b, text_b) = docs[0], docs[1]
        if not text_a or not text_b:
            raise HTTPException(
                status_code=500,
                detail="One or both documents have no extractable text in the index."
            )

        project_output_dir = Path(project_manager.get_path("output"))
        project_output_dir.mkdir(parents=True, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        out_path = project_output_dir / f"redline_{timestamp}.docx"

        build_redline_docx(
            file_a_name=name_a,
            text_a=text_a,
            file_b_name=name_b,
            text_b=text_b,
            output_path=out_path,
            lang=request.lang,
        )

        if request.open_after:
            path_str = str(out_path.absolute())
            try:
                if os.name == 'nt':
                    os.startfile(path_str)
                else:
                    import subprocess
                    opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
                    subprocess.call([opener, path_str])
            except Exception as e:
                logger.warning(f"Could not auto-open redline DOCX: {e}")

        return {
            "status": "success",
            "message": f"Redline export completato: {out_path.name}",
            "filepath": str(out_path),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Redline export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/export/compare-table")
async def export_compare_table(request: ExportCompareTableRequest):
    """
    Generate a DETERMINISTIC comparison workbook (.xlsx) between the 2 documents
    in the session — no LLM. 4 sheets: Valori modificati / Aggiunte / Rimozioni /
    Spostamenti, with the exact article number for each change. Companion to the
    redline DOCX; same Compare-Mode gating.
    """
    try:
        from backend_config.project_manager import project_manager
        from services.compare_table_builder import build_compare_records, export_compare_xlsx
        from backend_config.auth_pro import require_pro_or_trial

        # PRO gate — Compare Mode (and its deliverables) is a PRO feature.
        require_pro_or_trial()  # raises 402 if not pro/trial

        active_profile = getattr(settings, 'CHAT_PROFILE', 'default')
        if active_profile != 'document_compare':
            raise HTTPException(
                status_code=409,
                detail="Compare table export is only available in Compare Mode."
            )

        chat = get_chat_service()
        files = chat.uploaded_files.get(request.session_id, [])
        if len(files) != 2:
            raise HTTPException(
                status_code=400,
                detail=f"Compare table export requires exactly 2 documents. Currently {len(files)} loaded."
            )

        docs = chat.get_session_documents_text(request.session_id)
        if len(docs) != 2 or not all(d[0] for d in docs):
            raise HTTPException(
                status_code=500,
                detail="Could not retrieve plain text for one or both documents."
            )
        (name_a, text_a), (name_b, text_b) = docs[0], docs[1]
        if not text_a or not text_b:
            raise HTTPException(
                status_code=500,
                detail="One or both documents have no extractable text."
            )

        records = build_compare_records(text_a, text_b)

        project_output_dir = Path(project_manager.get_path("output"))
        project_output_dir.mkdir(parents=True, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        out_path = project_output_dir / f"compare_table_{timestamp}.xlsx"

        export_compare_xlsx(records, out_path)

        if request.open_after:
            path_str = str(out_path.absolute())
            try:
                if os.name == 'nt':
                    os.startfile(path_str)
                else:
                    import subprocess
                    opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
                    subprocess.call([opener, path_str])
            except Exception as e:
                logger.warning(f"Could not auto-open compare table: {e}")

        return {
            "status": "success",
            "message": f"Tabella confronto completata: {out_path.name}",
            "filepath": str(out_path),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Compare table export error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/prompt-library")
async def get_prompt_library(lang: str = "it"):
    """
    Get prompt library for INTERROGATE, categorized by area.
    Loads from language-specific JSON files.
    """
    try:
        config_dir = Path(__file__).parent.parent / "backend_config"
        lib_path = config_dir / f"prompts_library_{lang}.json"

        # Fallback a italiano se la lingua richiesta non esiste
        if not lib_path.exists():
            lib_path = config_dir / "prompts_library_it.json"

        with open(lib_path, 'r', encoding='utf-8') as f:
            library = json.load(f)

        return {
            "status": "success",
            "library": library,
            "lang": lang
        }
    except Exception as e:
        logger.error(f"Prompt library error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class GrabLinkFetchRequest(BaseModel):
    url: str

class GrabLinkAttachRequest(BaseModel):
    url: str
    content: str
    filename: str
    session_id: str
    lang: str = "it"


# Web Search rimosso: l'"interrogate web search" è stato dismesso (DDG/SearXNG/Wikipedia/Brave).
# Il flusso supportato è solo manuale: l'utente incolla URL nella modale Grab Link e il
# backend li scarica via /grab-link/fetch (decideono i siti decisi DALL'UTENTE, non da un motore).


@router.post("/grab-link/fetch")
async def grab_link_fetch(req: GrabLinkFetchRequest):
    """
    Fetch a URL and extract its text using a 4-level extraction pipeline:
      1. trafilatura (best article/blog extraction)
      2. readability-lxml (Mozilla Readability algorithm)
      3. BeautifulSoup smart content detection (main/article/div heuristics)
      4. BeautifulSoup full body strip (last resort)

    HTTP fetch uses a rotating UA strategy: Chrome first, Firefox on 403 retry.
    """
    import re as _re
    import asyncio as _asyncio

    url = req.url.strip()

    if not _re.match(r'^https?://', url, _re.IGNORECASE):
        raise HTTPException(status_code=400, detail="INVALID_URL")

    # --- UA profiles ---
    UA_CHROME = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
    UA_FIREFOX = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) "
        "Gecko/20100101 Firefox/125.0"
    )
    UA_GOOGLEBOT = (
        "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
    )

    def _make_headers(ua: str) -> dict:
        # Referer = Google → alcuni siti paywall (Corriere, NYT) servono
        # preview articolo a chi arriva da Google search invece di redirect
        # alla homepage. Trick noto e legittimo (è ciò che fa il browser reale
        # cliccando un risultato di ricerca).
        return {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "cross-site",
            "Sec-Fetch-User": "?1",
            "Cache-Control": "max-age=0",
            "DNT": "1",
            "Referer": "https://www.google.com/",
        }

    async def _fetch_html(ua: str) -> tuple[int, str, str]:
        """Fetch URL. Returns (status_code, html, final_url_after_redirects)."""
        import httpx
        async with httpx.AsyncClient(
            follow_redirects=True,
            timeout=httpx.Timeout(20.0),
            headers=_make_headers(ua),
            http2=False,
        ) as client:
            r = await client.get(url)
            return r.status_code, r.text, str(r.url)

    def _is_homepage_redirect(original: str, final: str) -> bool:
        """Returns True se siamo stati redirectati a una homepage di sito.

        Casi tipici: articolo vecchio scaduto, paywall fail, anti-bot generic
        landing. Tipicamente l'URL originale ha path lunghetto (>1 segmento) e
        quello finale è vuoto / `/` / `/home`.
        """
        from urllib.parse import urlparse as _up
        op = _up(original).path.strip("/")
        fp = _up(final).path.strip("/")
        # Originale aveva un path "vero" (almeno 8 char, escluso "home" / "index")
        if len(op) < 8 or op.lower() in ("home", "index", "index.html"):
            return False
        # Finale è vuoto, root, o landing page generica
        return fp == "" or fp.lower() in ("home", "index", "index.html")

    def _looks_like_homepage_content(text: str) -> bool:
        """Euristica: se il contenuto estratto sembra una homepage (lista di
        articoli card, non un singolo articolo).

        Segnali:
        - molte righe corte ad alta densità di parole capitalizzate (titoli card)
        - presenza ripetuta di pattern data tipo "12 marzo 2026" / "March 12"
        - assenza di paragrafi "veri" (>200 char continui senza newline)
        """
        import re as _re
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        if len(lines) < 10:
            return False  # poco testo, non è una home
        # Conta paragrafi lunghi (proxy per "vero contenuto articolo")
        long_paragraphs = sum(1 for l in lines if len(l) > 200)
        if long_paragraphs >= 3:
            return False  # ha contenuto sostanzioso, accetta
        # Pattern data IT/EN comuni nelle card di home
        date_pat = _re.compile(
            r'\b(\d{1,2}\s+(gen|feb|mar|apr|mag|giu|lug|ago|set|ott|nov|dic|'
            r'jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-zà-ù]*\s+\d{4}|'
            r'\d{1,2}/\d{1,2}/\d{2,4})\b',
            _re.I,
        )
        date_count = sum(1 for l in lines if date_pat.search(l))
        # Titoli card: righe corte (15-100 char), iniziano con maiuscola, pochi spazi
        card_title_count = sum(
            1 for l in lines
            if 15 <= len(l) <= 100 and l[0].isupper() and l.count(" ") <= 12
        )
        # Sentenza: se troviamo molte date + tanti titoli card + nessun paragrafo
        # lungo, è quasi certamente una home.
        return date_count >= 4 and card_title_count >= 8 and long_paragraphs == 0

    # --- Extraction helpers ---
    # Soglia minima di accettazione: se l'estrazione rende meno di questo, prova il tier successivo.
    # 100 era troppo basso → quasi qualsiasi pagina sporca passava il filtro.
    MIN_ACCEPT_CHARS = 400

    def _extract_trafilatura(html: str) -> str | None:
        try:
            import trafilatura
            # Pass 1: PRECISION-first — modalità "solo l'articolo", scarta header/menu/footer.
            # È il modo corretto per estrarre contenuto pulito da pagine HTML standard.
            result = trafilatura.extract(
                html,
                include_tables=True,
                include_links=False,
                include_images=False,
                include_comments=False,
                no_fallback=False,
                favor_precision=True,
                deduplicate=True,
            )
            if result and len(result.strip()) >= MIN_ACCEPT_CHARS:
                return result.strip()
            # Pass 2: RECALL — articoli brevi o pagine con markup non standard.
            # Più permissivo: può includere blocchi periferici, ma meglio che niente.
            result2 = trafilatura.extract(
                html,
                include_tables=True,
                include_links=False,
                include_images=False,
                include_comments=False,
                no_fallback=False,
                favor_recall=True,
                deduplicate=True,
            )
            if result2 and len(result2.strip()) >= MIN_ACCEPT_CHARS:
                return result2.strip()
            # Pass 3: ultima chance, accetta anche risultati corti (>= 100)
            for r in (result, result2):
                if r and len(r.strip()) >= 100:
                    return r.strip()
        except Exception as e:
            logger.debug(f"trafilatura extraction failed: {e}")
        return None

    def _extract_readability(html: str) -> str | None:
        try:
            from readability import Document
            doc = Document(html)
            summary_html = doc.summary()
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(summary_html, "html.parser")
            text = soup.get_text(separator="\n", strip=True)
            if text and len(text.strip()) > 100:
                return text.strip()
        except Exception as e:
            logger.debug(f"readability extraction failed: {e}")
        return None

    def _strip_structural_noise(soup) -> None:
        """
        Rimuove in-place tutti gli elementi non-contenuto:
        tag strutturali, ARIA roles, attributi/ID/class che indicano chrome del sito.
        Usato sia da BS4 smart che da BS4 full-body.
        """
        # Tag strutturali e funzionali
        for tag in soup(["script", "style", "noscript", "iframe", "svg",
                         "nav", "footer", "header", "aside", "form",
                         "button", "figure", "menu", "dialog", "template"]):
            tag.decompose()
        # ARIA landmark roles per il chrome del sito
        for role in ("banner", "navigation", "contentinfo",
                     "complementary", "search", "dialog", "alertdialog"):
            for tag in soup.find_all(attrs={"role": role}):
                tag.decompose()
        # Hidden/cookie banners
        for tag in soup.find_all(attrs={"aria-hidden": "true"}):
            tag.decompose()
        # ID + class denylist (case-insensitive, parziali)
        noise_pattern = _re.compile(
            r'(menu|nav|sidebar|footer|header|cookie|consent|gdpr|'
            r'banner|popup|modal|overlay|toast|toolbar|skip-link|'
            r'advertisement|ad-(?:slot|container|wrap|unit)|adsbygoogle|'
            r'widget|breadcrumb|social|share|subscribe|newsletter|'
            r'comment|disqus|related-posts|recommended|trending|'
            r'site-header|site-footer|global-header|global-footer|'
            r'top-bar|bottom-bar|masthead)',
            _re.I
        )
        for tag in soup.find_all(True, class_=noise_pattern):
            tag.decompose()
        for tag in soup.find_all(True, id=noise_pattern):
            tag.decompose()

    def _link_density(tag) -> float:
        """Frazione di testo dentro tag <a>: i menu/sidebar hanno density alta (~1.0),
        gli articoli hanno density bassa (<0.2)."""
        try:
            total = len(tag.get_text(strip=True)) or 1
            link_text = sum(len(a.get_text(strip=True)) for a in tag.find_all("a"))
            return link_text / total
        except Exception:
            return 1.0

    def _extract_bs4_smart(html: str) -> str | None:
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "lxml" if _lxml_available() else "html.parser")

            _strip_structural_noise(soup)

            # Priority content selectors (ordered by specificity)
            CONTENT_SELECTORS = [
                "article",
                "main",
                '[role="main"]',
                ".entry-content",
                ".post-content",
                ".article-content",
                ".article-body",
                ".content-body",
                ".page-content",
                ".single-content",
                "#content",
                "#main-content",
                "#post-content",
                ".td-post-content",   # TagDiv theme
                ".et_pb_post_content", # Divi
                ".elementor-widget-theme-post-content",
            ]
            for sel in CONTENT_SELECTORS:
                tag = soup.select_one(sel)
                if tag:
                    text = tag.get_text(separator="\n", strip=True)
                    if len(text) > 200:
                        return text

            # Fallback: scegli il blocco con più testo MA bassa link-density.
            # Un menu/sidebar pieno di link viene scartato anche se è il più grosso.
            candidates = soup.find_all(["div", "section", "main", "article"])
            scored = []
            for c in candidates:
                txt_len = len(c.get_text(strip=True))
                if txt_len < 200:
                    continue
                density = _link_density(c)
                if density > 0.5:
                    continue  # quasi sicuro è una nav/sidebar
                # score = lunghezza testo penalizzata dalla link-density
                score = txt_len * (1.0 - density)
                scored.append((score, c))
            if scored:
                scored.sort(key=lambda x: x[0], reverse=True)
                best = scored[0][1]
                text = best.get_text(separator="\n", strip=True)
                if len(text) > 200:
                    return text
        except Exception as e:
            logger.debug(f"bs4 smart extraction failed: {e}")
        return None

    def _extract_bs4_full(html: str) -> str | None:
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "lxml" if _lxml_available() else "html.parser")
            # Anche il fallback finale strippa il chrome del sito — meglio meno testo pulito
            # che molto testo sporco.
            _strip_structural_noise(soup)
            # Prendi <body> se c'è, altrimenti l'intero soup
            root = soup.body if soup.body else soup
            text = root.get_text(separator="\n", strip=True)
            # Collapse blank lines
            lines = [l for l in text.splitlines() if l.strip()]
            joined = "\n".join(lines)
            # Floor a 300 char: meno = solitamente solo `<title>` o stub anti-scrape.
            # Senza questo floor il testo "Titolo Pagina - Brand.it" (70 char) veniva
            # accettato come content, risultato inutile per il RAG.
            if len(joined) < 300:
                return None
            return joined
        except Exception as e:
            logger.debug(f"bs4 full extraction failed: {e}")
        return None

    def _lxml_available() -> bool:
        try:
            import lxml  # noqa
            return True
        except ImportError:
            return False

    def _clean_text(text: str) -> str:
        """Collapse excessive blank lines and strip leading/trailing whitespace."""
        import re
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    # ---- Main fetch + extraction flow ----
    try:
        import httpx

        # Attempt 1: Chrome UA
        status, html, final_url = await _fetch_html(UA_CHROME)

        # Attempt 2: on 403, retry with Firefox
        if status == 403:
            logger.info(f"Grab link: 403 with Chrome UA, retrying with Firefox UA for {url}")
            await _asyncio.sleep(0.8)
            status, html, final_url = await _fetch_html(UA_FIREFOX)

        # Attempt 3: on still 403, try Googlebot (some sites allow it)
        if status == 403:
            logger.info(f"Grab link: 403 with Firefox UA, retrying with Googlebot UA for {url}")
            await _asyncio.sleep(0.5)
            status, html, final_url = await _fetch_html(UA_GOOGLEBOT)

        if status == 404:
            raise HTTPException(status_code=422, detail="NOT_FOUND")
        if status == 403:
            raise HTTPException(status_code=422, detail="FORBIDDEN")
        if status >= 400:
            raise HTTPException(status_code=422, detail=f"HTTP_ERROR:{status}")

        if not html or len(html.strip()) < 100:
            raise HTTPException(status_code=422, detail="EMPTY_CONTENT")

        # GUARDIA REDIRECT: l'articolo richiesto è stato silenziosamente
        # redirezionato alla homepage del sito. Non vogliamo allegare la home
        # come se fosse l'articolo — l'utente vedrebbe contenuti random.
        if _is_homepage_redirect(url, final_url):
            logger.info(f"Grab link: detected redirect to homepage ({url} → {final_url})")
            raise HTTPException(
                status_code=422,
                detail="REDIRECTED_TO_HOMEPAGE: l'articolo non è disponibile (probabilmente scaduto o paywall). Il sito ha redirezionato alla homepage.",
            )

        # Extraction pipeline — log esplicito di quale tier ha prodotto il risultato
        # (utile per diagnosticare estrazioni sporche su URL specifici)
        extracted = None
        tier_used = None
        for name, fn in (
            ("trafilatura", _extract_trafilatura),
            ("readability", _extract_readability),
            ("bs4_smart",  _extract_bs4_smart),
            ("bs4_full",   _extract_bs4_full),
        ):
            extracted = fn(html)
            if extracted:
                tier_used = name
                break

        # Threshold: 300 char minimi. Il vecchio limite (50) accettava pagine
        # con solo `<title>` o stub anti-bot — inutili per il RAG.
        # 300 char ≈ 50 parole, sotto cui non c'è quasi mai contenuto reale.
        if not extracted or len(extracted.strip()) < 300:
            raise HTTPException(status_code=422, detail="EMPTY_CONTENT")

        # GUARDIA HOMEPAGE-LIKE: euristica sul contenuto estratto. Se sembra
        # un feed di card-articoli (molti titoli + date, niente paragrafi
        # lunghi), il link richiesto si è risolto nella home / SPA shell.
        if _looks_like_homepage_content(extracted):
            logger.info(
                f"Grab link: extracted content looks like homepage feed (no real article body) for {url}"
            )
            raise HTTPException(
                status_code=422,
                detail="HOMEPAGE_CONTENT_DETECTED: la pagina sembra una homepage/lista articoli, non un singolo articolo. "
                "Il sito potrebbe usare JavaScript per caricare il contenuto, oppure l'articolo è dietro paywall.",
            )

        extracted = _clean_text(extracted)
        logger.info(
            f"[GRAB-LINK] tier={tier_used} chars={len(extracted)} url={url}"
        )

        # Build safe filename
        from urllib.parse import urlparse as _urlparse
        parsed = _urlparse(url)
        domain = parsed.netloc.replace("www.", "").replace(".", "_")
        path_slug = parsed.path.strip("/").replace("/", "_")[:40]
        filename = f"{domain}_{path_slug}.txt" if path_slug else f"{domain}.txt"
        filename = _re.sub(r'[^\w\-_\.]', '_', filename)

        return {
            "status": "success",
            "url": url,
            "filename": filename,
            "content": extracted,
            "char_count": len(extracted),
            "word_count": len(extracted.split()),
        }

    except HTTPException:
        raise
    except httpx.ConnectError:
        raise HTTPException(status_code=422, detail="CONNECTION_ERROR")
    except httpx.TimeoutException:
        raise HTTPException(status_code=422, detail="TIMEOUT")
    except Exception as e:
        logger.error(f"Grab link fetch error for {url}: {e}")
        raise HTTPException(status_code=422, detail=f"FETCH_ERROR:{str(e)[:80]}")


@router.post("/grab-link/attach")
async def grab_link_attach(req: GrabLinkAttachRequest):
    """
    Save scraped content as a .txt file and ingest it into the INTERROGATE session.
    """
    try:
        uploads_dir = (
            project_manager.get_path("uploads") / "interrogate"
            if project_manager.active_project_path
            else settings.BASE_DIR / "temp" / "uploads" / "interrogate"
        )
        uploads_dir.mkdir(parents=True, exist_ok=True)

        # Check max file count
        existing_files = get_chat_service().get_uploaded_files(req.session_id)
        if len(existing_files) >= MAX_FILES:
            raise HTTPException(status_code=400, detail=f"LIMIT_TOO_MANY:{MAX_FILES}")

        txt_path = uploads_dir / req.filename
        with open(txt_path, "w", encoding="utf-8") as f:
            # Add source header so the model knows the origin
            f.write(f"SOURCE URL: {req.url}\n{'='*60}\n\n{req.content}")

        get_chat_service().set_language(req.lang)
        result = await get_chat_service().upload_file(
            file_path=str(txt_path),
            filename=req.filename,
            session_id=req.session_id,
            is_generated=True
        )

        if result.get("status") == "success":
            return {
                "status": "success",
                "filename": req.filename,
                "ref": result.get("ref"),
                "session_id": req.session_id,
                "chat_message": result.get("chat_message", ""),
                "is_generated": True
            }
        else:
            if txt_path.exists():
                txt_path.unlink()
            raise HTTPException(status_code=400, detail=result.get("message", "INGEST_ERROR"))

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Grab link attach error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/debug/logs")
async def get_debug_logs(lines: int = 150):
    """
    Returns the last N lines from the system log file for the in-app debug panel.
    """
    try:
        log_file = Path(__file__).parent.parent / "pais_system.log"
        if not log_file.exists():
            return {"logs": [], "total_lines": 0}
        with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
            all_lines = f.readlines()
        tail = [l.rstrip('\n') for l in all_lines[-lines:]]
        return {"logs": tail, "total_lines": len(all_lines)}
    except Exception as e:
        logger.error(f"Debug logs error: {e}")
        return {"logs": [f"Error reading logs: {e}"], "total_lines": 0}
