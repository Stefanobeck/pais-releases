"""Format Converter — multi-format conversion utility.

Supporta:
  - Documenti: DOCX → PDF (mammoth + Playwright), PDF → DOCX (pypdf, testo flow)
  - Fogli: XLSX ↔ CSV (pandas)
  - Immagini: JPG ↔ PNG ↔ WEBP ↔ BMP ↔ TIFF ↔ GIF (Pillow)

Tutto local-first, zero API. NO HEIC (codec patentato MPEG-LA), NO audio
(richiederebbe ffmpeg bundle) — rinviati a v2 con scelte di licenza
specifiche.

Dipendenze:
  - mammoth (BSD-2): DOCX→HTML
  - playwright (Apache 2.0): HTML→PDF, già installato per chat export
  - pypdf (BSD): PDF→testo
  - python-docx (MIT): scrittura DOCX
  - pandas, openpyxl (BSD/MIT): xlsx↔csv
  - Pillow (HPND): immagini

Output: tutti i file in `output/CONVERT/<filename>.<new_ext>`.
"""
import logging
import re
import datetime
from io import BytesIO
from pathlib import Path
from typing import List, Tuple, Optional

logger = logging.getLogger(__name__)

# Mappa estensione → categoria (per dispatch e validazione UI)
DOC_EXTS = {".docx", ".pdf"}
SHEET_EXTS = {".xlsx", ".xls", ".csv"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff", ".tif", ".gif"}
ALL_SUPPORTED_EXTS = DOC_EXTS | SHEET_EXTS | IMAGE_EXTS

# Coppie source→target ammesse (frontend filtra via questa stessa logica
# duplicata in TS — qui è la source of truth lato server)
ALLOWED_CONVERSIONS = {
    ".docx": [".pdf"],
    ".pdf": [".docx"],
    ".xlsx": [".csv"],
    ".xls":  [".csv"],
    ".csv":  [".xlsx"],
    # Immagini: tutte le combinazioni reciproche eccetto self
    ".jpg":  [".png", ".webp", ".bmp", ".tiff", ".gif"],
    ".jpeg": [".png", ".webp", ".bmp", ".tiff", ".gif"],
    ".png":  [".jpg", ".webp", ".bmp", ".tiff", ".gif"],
    ".webp": [".jpg", ".png", ".bmp", ".tiff", ".gif"],
    ".bmp":  [".jpg", ".png", ".webp", ".tiff", ".gif"],
    ".tiff": [".jpg", ".png", ".webp", ".bmp", ".gif"],
    ".tif":  [".jpg", ".png", ".webp", ".bmp", ".gif"],
    ".gif":  [".jpg", ".png", ".webp", ".bmp", ".tiff"],
}


class FormatConverter:
    """Multi-format converter dispatcher.

    Chiama il metodo giusto in base alla coppia (source_ext, target_ext).
    Solleva ValueError per coppie non supportate.
    """

    @staticmethod
    def _safe_stem(name: str) -> str:
        """Sanitize stem per filesystem Windows-compatible."""
        return re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', Path(name).stem)[:80].rstrip('. ').strip() or "converted"

    @staticmethod
    def _next_unique(out_dir: Path, base_name: str, ext: str) -> Path:
        """Genera path univoco aggiungendo _02, _03 in caso di collisione."""
        candidate = out_dir / f"{base_name}{ext}"
        n = 2
        while candidate.exists():
            candidate = out_dir / f"{base_name}_{n:02d}{ext}"
            n += 1
        return candidate

    async def convert(
        self,
        input_path: Path,
        output_root: Path,
        target_ext: str,
        lang: str = "it",
    ) -> Tuple[str, str, Optional[str]]:
        """Dispatch principale.

        Returns: (output_filename, output_subfolder, warning_or_none)
        """
        source_ext = input_path.suffix.lower()
        target_ext = target_ext.lower()
        if not target_ext.startswith("."):
            target_ext = "." + target_ext

        if source_ext not in ALLOWED_CONVERSIONS:
            raise ValueError(f"Unsupported source format: {source_ext}")
        if target_ext not in ALLOWED_CONVERSIONS[source_ext]:
            raise ValueError(f"Cannot convert {source_ext} → {target_ext}")

        out_dir = output_root / "CONVERT"
        out_dir.mkdir(parents=True, exist_ok=True)
        base = self._safe_stem(input_path.name)

        # ─── Documenti ────────────────────────────────────────────────
        if source_ext == ".docx" and target_ext == ".pdf":
            out_path = self._next_unique(out_dir, base, ".pdf")
            await self._docx_to_pdf(input_path, out_path)
            return out_path.name, "CONVERT", None

        if source_ext == ".pdf" and target_ext == ".docx":
            out_path = self._next_unique(out_dir, base, ".docx")
            warning = self._pdf_to_docx(input_path, out_path)
            return out_path.name, "CONVERT", warning

        # ─── Fogli di calcolo ─────────────────────────────────────────
        if source_ext in {".xlsx", ".xls"} and target_ext == ".csv":
            out_path = self._next_unique(out_dir, base, ".csv")
            self._xlsx_to_csv(input_path, out_path)
            return out_path.name, "CONVERT", None

        if source_ext == ".csv" and target_ext == ".xlsx":
            out_path = self._next_unique(out_dir, base, ".xlsx")
            self._csv_to_xlsx(input_path, out_path)
            return out_path.name, "CONVERT", None

        # ─── Immagini ─────────────────────────────────────────────────
        if source_ext in IMAGE_EXTS and target_ext in IMAGE_EXTS:
            out_path = self._next_unique(out_dir, base, target_ext)
            self._convert_image(input_path, out_path, target_ext)
            return out_path.name, "CONVERT", None

        # Non dovrebbe accadere per la guard sopra, ma defensive
        raise ValueError(f"Conversion {source_ext} → {target_ext} not implemented")

    # ─────────────────────────────────────────────────────────────────
    # Document conversions
    # ─────────────────────────────────────────────────────────────────

    async def _docx_to_pdf(self, input_path: Path, output_path: Path) -> None:
        """DOCX → PDF via mammoth (DOCX→HTML) + Playwright (HTML→PDF).

        Stesso stack della chat export. Fedeltà ~90% per documenti
        d'ufficio standard (lettere, contratti, fatture). Layout
        complessi (multi-colonna, header/footer custom) hanno fedeltà
        parziale — è un limite noto di mammoth.
        """
        import mammoth
        from playwright.async_api import async_playwright

        # 1. DOCX → HTML
        with open(input_path, "rb") as f:
            mammoth_result = mammoth.convert_to_html(f)
        html_body = mammoth_result.value
        # Embed in un HTML completo con stile basico per stampa A4
        html_full = f"""<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<title>{input_path.stem}</title>
<style>
  @page {{ size: A4; margin: 2cm; }}
  body {{ font-family: 'Calibri', 'Segoe UI', sans-serif; font-size: 11pt; line-height: 1.4; color: #222; }}
  h1, h2, h3, h4, h5, h6 {{ color: #111; margin-top: 1.2em; margin-bottom: 0.4em; }}
  h1 {{ font-size: 18pt; }}
  h2 {{ font-size: 15pt; }}
  h3 {{ font-size: 13pt; }}
  p {{ margin: 0.3em 0; }}
  table {{ border-collapse: collapse; width: 100%; margin: 0.6em 0; }}
  table td, table th {{ border: 1px solid #999; padding: 4px 8px; }}
  table th {{ background: #f0f0f0; font-weight: bold; }}
  img {{ max-width: 100%; height: auto; }}
  ul, ol {{ margin: 0.4em 0; padding-left: 1.6em; }}
</style>
</head>
<body>
{html_body}
</body>
</html>"""

        # 2. HTML → PDF via Playwright Chromium
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.set_content(html_full, wait_until="networkidle")
            await page.pdf(
                path=str(output_path),
                format="A4",
                margin={"top": "2cm", "bottom": "2cm", "left": "2cm", "right": "2cm"},
                print_background=True,
            )
            await browser.close()

        # Audit
        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="format_converter.docx_to_pdf",
                output_filename=output_path.name,
                success=True,
                **{f"input_{k}": v for k, v in file_metadata(input_path).items()},
            )
        except Exception:
            pass

    def _pdf_to_docx(self, input_path: Path, output_path: Path) -> str:
        """PDF → DOCX via pypdf (estrazione testo) + python-docx.

        Output: testo flow piatto senza layout originale. È un limite
        intrinseco del formato PDF (non ha semantica strutturata) e
        della scelta di non dipendere da PyMuPDF (AGPL/commercial).
        Per layout complessi conviene usare il modulo OCR Layout.

        Returns: warning message ("text_only_extraction").
        """
        import pypdf
        from docx import Document
        from docx.shared import Pt

        reader = pypdf.PdfReader(str(input_path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:
                raise ValueError("PDF is password-protected")

        doc = Document()
        style = doc.styles["Normal"]
        style.font.name = "Calibri"
        style.font.size = Pt(11)

        # Heading con metadati origine — segnala chiaramente che è un'estrazione
        title = doc.add_paragraph()
        run = title.add_run(f"Estratto da: {input_path.name}")
        run.bold = True
        run.font.size = Pt(9)
        run.font.color.rgb = None  # default scuro

        for page_num, page in enumerate(reader.pages, start=1):
            try:
                text = page.extract_text() or ""
            except Exception as e:
                logger.warning(f"pdf_to_docx: extract_text failed on page {page_num}: {e}")
                text = ""
            if not text.strip():
                continue
            # Page heading
            ph = doc.add_paragraph()
            ph_run = ph.add_run(f"— Pagina {page_num} —")
            ph_run.italic = True
            ph_run.font.size = Pt(9)
            # Body: paragrafi separati da blank line
            for block in text.split("\n\n"):
                clean = block.strip()
                if clean:
                    doc.add_paragraph(clean)

        doc.save(str(output_path))

        try:
            from services.audit_service import audit_logger, file_metadata
            audit_logger.log(
                "utility", "file_processed",
                processor="format_converter.pdf_to_docx",
                output_filename=output_path.name,
                input_pages=len(reader.pages),
                success=True,
                **{f"input_{k}": v for k, v in file_metadata(input_path).items()},
            )
        except Exception:
            pass

        return "text_only_extraction"

    # ─────────────────────────────────────────────────────────────────
    # Spreadsheet conversions
    # ─────────────────────────────────────────────────────────────────

    def _xlsx_to_csv(self, input_path: Path, output_path: Path) -> None:
        """XLSX → CSV (primo foglio).

        Multi-sheet: solo il primo foglio viene convertito (simmetrico al
        comportamento di tutti i tool simili — Excel UI lo richiede esplicito).
        """
        import pandas as pd
        df = pd.read_excel(input_path, dtype=str, keep_default_na=False, engine="openpyxl")
        df.to_csv(output_path, index=False, encoding="utf-8")

    def _csv_to_xlsx(self, input_path: Path, output_path: Path) -> None:
        """CSV → XLSX. Auto-detect encoding (utf-8 → latin-1 fallback)."""
        import pandas as pd
        try:
            df = pd.read_csv(input_path, dtype=str, keep_default_na=False, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(input_path, dtype=str, keep_default_na=False, encoding="latin-1")
        df.to_excel(output_path, index=False, engine="openpyxl")

    # ─────────────────────────────────────────────────────────────────
    # Image conversions
    # ─────────────────────────────────────────────────────────────────

    def _convert_image(self, input_path: Path, output_path: Path, target_ext: str) -> None:
        """JPG/PNG/WEBP/BMP/TIFF/GIF interconversione via Pillow.

        - Alpha → flatten su bianco quando target è JPG (no alpha)
        - GIF→GIF: copia primo frame se animato (semplificazione)
        """
        from PIL import Image

        with Image.open(input_path) as img:
            # Mappa estensione → format Pillow
            fmt_map = {
                ".jpg": "JPEG", ".jpeg": "JPEG",
                ".png": "PNG",
                ".webp": "WEBP",
                ".bmp": "BMP",
                ".tiff": "TIFF", ".tif": "TIFF",
                ".gif": "GIF",
            }
            target_fmt = fmt_map[target_ext]

            # Flatten alpha se target non supporta trasparenza
            no_alpha_targets = {"JPEG", "BMP"}
            if target_fmt in no_alpha_targets:
                if img.mode in ("RGBA", "LA"):
                    bg = Image.new("RGB", img.size, (255, 255, 255))
                    bg.paste(img, mask=img.split()[-1])
                    img = bg
                elif img.mode == "P":
                    img = img.convert("RGB")
                elif img.mode != "RGB":
                    img = img.convert("RGB")
            # Modalità target che richiedono RGB esplicito
            elif target_fmt == "WEBP" and img.mode == "P":
                img = img.convert("RGBA")

            save_kwargs = {}
            if target_fmt == "JPEG":
                save_kwargs.update(quality=90, optimize=True)
            elif target_fmt == "WEBP":
                save_kwargs.update(quality=90, method=6)
            elif target_fmt == "PNG":
                save_kwargs.update(optimize=True)

            img.save(output_path, format=target_fmt, **save_kwargs)
