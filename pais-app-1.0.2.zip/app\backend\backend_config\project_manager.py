import os
import re
import json
import time
from pathlib import Path
from datetime import datetime
import shutil
from typing import List, Dict, Optional, Tuple


# Lunghezza massima del nome progetto (il nome diventa parte del path cartella).
_PROJECT_NAME_MAX_LEN = 60


def _safe_display_name(name: str) -> str:
    """Nome 'leggibile' da mostrare in UI (config["name"]): rimuove i caratteri
    non ammessi, normalizza gli spazi multipli, taglia a _PROJECT_NAME_MAX_LEN.
    Ammessi: lettere (anche accentate), cifre, spazi, '-' e '_'. Fallback 'default'."""
    cleaned = re.sub(r'[^\w\s\-]', '', name or '', flags=re.UNICODE)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned[:_PROJECT_NAME_MAX_LEN].strip() or "default"


def _safe_folder_component(name: str) -> str:
    """Componente <name> del folder `project_<name>_<timestamp>`.

    Difesa anti path-traversal e anti caratteri vietati dal filesystem
    (/ \\ : * ? " < > | . e separatori di percorso): tiene solo \\w (lettere/
    cifre/underscore unicode), spazi e '-', poi converte gli spazi in '_' e
    ripulisce i bordi. Allineato al filtro live del frontend
    (Header.tsx → sanitizeProjectName). Fallback 'default' se vuoto."""
    cleaned = re.sub(r'[^\w\s\-]', '', name or '', flags=re.UNICODE)
    cleaned = re.sub(r'\s+', '_', cleaned.strip())
    cleaned = cleaned.strip('_-')[:_PROJECT_NAME_MAX_LEN].strip('_-')
    return cleaned or "default"


def _rmtree_with_retry(path: Path, max_attempts: int = 4) -> Tuple[bool, Optional[Exception], int]:
    """shutil.rmtree con backoff esponenziale per file lock Windows.

    Su Windows, quando l'utente chiude PAIS e rilancia subito il .bat, il processo
    precedente può ancora tenere file handle su file persistenti (in particolare
    `data_level0.bin` di ChromaDB / file LMDB). Il rilascio richiede ~1-2 secondi.

    Sleep cumulato nei retry: 0.3 + 0.5 + 1.0 = 1.8s max. Se dopo 4 tentativi il
    lock persiste, il caller decide se è errore o warning (per ChromaDB è warning:
    al peggio sopravvivono embedding della sessione precedente, ChromaDB tollera).

    Ritorna (success, last_exception, attempts_used).
    """
    if not path.exists():
        return True, None, 0
    delays = [0.3, 0.5, 1.0]
    last_err: Optional[Exception] = None
    for attempt in range(max_attempts):
        try:
            shutil.rmtree(path)
            return True, None, attempt + 1
        except (OSError, PermissionError) as e:
            last_err = e
            if attempt < max_attempts - 1:
                time.sleep(delays[min(attempt, len(delays) - 1)])
    return False, last_err, max_attempts


class ProjectManager:
    """
    Gestisce la creazione, il caricamento e la gestione dei percorsi dei progetti.
    È implementato come singleton per mantenere uno stato globale del progetto attivo.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(ProjectManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.USER_DOCUMENTS = Path(os.path.expanduser("~/Documents"))
        self.BASE_DIR = self.USER_DOCUMENTS / "PAI_Files"

        # MIGRATION logic: if old folder exists and new one doesn't, rename it
        old_dir = self.USER_DOCUMENTS / "AziendaGPT_Files"
        if old_dir.exists() and not (self.USER_DOCUMENTS / "PAI_Files").exists():
            try:
                import shutil
                # shutil.move è più robusto di rename su Windows
                shutil.move(str(old_dir), str(self.USER_DOCUMENTS / "PAI_Files"))
                print(f"📦 MIGRATION: Successfully moved AziendaGPT_Files to PAI_Files")
            except Exception as e:
                print(f"⚠️ MIGRATION WARNING: Could not move folder ({e}).")
                print(f"💡 Tip: Close any folder or file inside 'AziendaGPT_Files' and restart.")
                # Se fallisce, usiamo la vecchia cartella come BASE_DIR per non perdere dati
                self.BASE_DIR = old_dir

        self.PROJECTS_ROOT_DIR = self.BASE_DIR
        self.active_project_path = None
        self.active_project_name = "Nessun Progetto"

        os.makedirs(self.PROJECTS_ROOT_DIR, exist_ok=True)

        self._initialized = True

        # Processa eliminazioni pending (progetti marcati al riavvio precedente)
        self.process_pending_deletes()
        print("ProjectManager initialized.")

        # LOGICA SANDBOX: Avvio su progetto Default con inizializzazione NON distruttiva
        default_name = "000_DEFAULT_WORKSPACE"
        self.initialize_default(default_name)

    def initialize_default(self, name: str):
        """
        Inizializza il progetto Default in modo NON distruttivo.
        
        Strategia:
        - Se la cartella NON esiste: crea struttura completa
        - Se la cartella ESISTE: pulisce SOLO DB, sessioni e uploads temporanei
        - NON TOCCA MAI output/ (i file generati restano intatti)
        - Non usa strategie distruttive (no move aside, no trash)
        """
        import shutil
        import os
        
        project_folder_name = f"project_{name}"
        project_path = self.PROJECTS_ROOT_DIR / project_folder_name
        
        if not project_path.exists():
            # PRIMO AVVI: Crea struttura completa da zero
            print(f"📁 Primo avvio: creazione progetto {name}...")
            os.makedirs(project_path / "uploads" / "interrogate", exist_ok=True)
            os.makedirs(project_path / "uploads" / "manipulate", exist_ok=True)
            os.makedirs(project_path / "uploads" / "vision", exist_ok=True)
            os.makedirs(project_path / "uploads" / "anonimyze", exist_ok=True)
            os.makedirs(project_path / "chroma_db_v2", exist_ok=True)
            os.makedirs(project_path / "output", exist_ok=True)
            os.makedirs(project_path / "temp", exist_ok=True)
            os.makedirs(project_path / "sql_db", exist_ok=True)
            
            # Crea cartelle per sessioni temporanee
            os.makedirs(project_path / "temp" / "chat_sessions", exist_ok=True)
            os.makedirs(project_path / "temp" / "manipulate_sessions", exist_ok=True)
            os.makedirs(project_path / "temp" / "vision_sessions", exist_ok=True)
            
            # Configurazione fissa per Default
            config = {"name": "DEFAULT WORKSPACE", "short_id": "DFT", "created_at": "SYSTEM"}
            with open(project_path / "project_config.json", 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)
            
            print(f"✅ Project {name} created successfully")
        else:
            # AVVI SUCCESSIVI: Pulizia selettiva NON distruttiva
            print(f"🧹 Subsequent boot: selective workspace cleanup...")

            # 1️⃣ Pulizia ChromaDB (Vector DB) — retry per file lock di Windows
            # quando l'utente riavvia velocemente (vedi _rmtree_with_retry).
            chroma_path = project_path / "chroma_db_v2"
            ok, err, attempts = _rmtree_with_retry(chroma_path)
            if ok and attempts == 1:
                print("✅ ChromaDB cleaned")
            elif ok:
                print(f"✅ ChromaDB cleaned (attempt {attempts}/4 — file lock released)")
            else:
                print(
                    f"⚠️ ChromaDB partial cleanup after {attempts} attempts: {err}. "
                    "Effect: embeddings from previous session may persist. "
                    "Functional but inconsistent — wait 2-3s between close and reopen to avoid it."
                )
            os.makedirs(chroma_path, exist_ok=True)

            # 2️⃣ Pulizia SQL DB (DuckDB)
            sql_path = project_path / "sql_db"
            if sql_path.exists():
                try:
                    # Cancella solo i file .db, non la cartella
                    for db_file in sql_path.glob("*.db"):
                        db_file.unlink()
                    print("✅ SQL DB cleaned")
                except Exception as e:
                    print(f"⚠️ SQL DB cleanup error: {e}")
            os.makedirs(sql_path, exist_ok=True)

            # 3️⃣ Pulizia sessioni temporanee
            temp_path = project_path / "temp"
            if temp_path.exists():
                try:
                    # Cancella chat_sessions
                    chat_sessions_path = temp_path / "chat_sessions"
                    if chat_sessions_path.exists():
                        shutil.rmtree(chat_sessions_path)
                    os.makedirs(chat_sessions_path, exist_ok=True)

                    # Cancella manipulate_sessions
                    manipulate_sessions_path = temp_path / "manipulate_sessions"
                    if manipulate_sessions_path.exists():
                        shutil.rmtree(manipulate_sessions_path)
                    os.makedirs(manipulate_sessions_path, exist_ok=True)

                    # Cancella vision_sessions
                    vision_sessions_path = temp_path / "vision_sessions"
                    if vision_sessions_path.exists():
                        shutil.rmtree(vision_sessions_path)
                    os.makedirs(vision_sessions_path, exist_ok=True)

                    print("✅ Temporary sessions cleaned")
                except Exception as e:
                    print(f"⚠️ Session cleanup error: {e}")

            # 3️⃣bis Pulizia cartella sessions/ persistente (dentro il progetto)
            sessions_path = project_path / "sessions"
            if sessions_path.exists():
                try:
                    shutil.rmtree(sessions_path)
                    print("✅ Persistent sessions (chat/manipulate) cleaned")
                except Exception as e:
                    print(f"⚠️ Persistent session cleanup error: {e}")
            os.makedirs(sessions_path, exist_ok=True)
            
            # 4️⃣ Pulizia uploads temporanei
            uploads_path = project_path / "uploads"
            if uploads_path.exists():
                try:
                    shutil.rmtree(uploads_path)
                    print("✅ Temporary uploads cleaned")
                except Exception as e:
                    print(f"⚠️ Uploads cleanup error: {e}")
            os.makedirs(uploads_path / "interrogate", exist_ok=True)
            os.makedirs(uploads_path / "manipulate", exist_ok=True)
            os.makedirs(uploads_path / "vision", exist_ok=True)
            os.makedirs(uploads_path / "anonimyze", exist_ok=True)

            # 5️⃣ VERIFICA output/ (NON TOCCARE!)
            output_path = project_path / "output"
            if output_path.exists():
                # Conta i file presenti per logging
                file_count = sum(1 for _ in output_path.rglob('*') if _.is_file())
                print(f"✅ Output/ preserved: {file_count} files intact")
            else:
                os.makedirs(output_path, exist_ok=True)
                print("✅ Output/ created (new)")

            # 6️⃣ Verifica config
            config_path = project_path / "project_config.json"
            if not config_path.exists():
                config = {"name": "DEFAULT WORKSPACE", "short_id": "DFT", "created_at": "SYSTEM"}
                with open(config_path, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                print("✅ Config created")
            else:
                print("✅ Existing config verified")
        
        self.set_active_project(project_folder_name)
        return project_folder_name

    def wipe_and_create_default(self, name: str):
        """DEPRECATED: Usare initialize_default invece.
        Questo metodo è mantenuto solo per backward compatibility ma NON dovrebbe essere usato."""
        import warnings
        warnings.warn("wipe_and_create_default è deprecato, usare initialize_default", DeprecationWarning)
        return self.initialize_default(name)

    def save_current_as(self, new_name: str):
        """Clona il progetto attivo (tipicamente il Default) in un nuovo progetto definitivo."""
        if not new_name: return False, "Nome non valido"

        # Sanitizzazione difensiva (vedi create_project): il nome diventa path.
        display_name = _safe_display_name(new_name)
        folder_component = _safe_folder_component(new_name)

        import shutil
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        new_folder_name = f"project_{folder_component}_{timestamp}"
        new_path = self.PROJECTS_ROOT_DIR / new_folder_name

        try:
            # 1. Recupera il vecchio short_id prima della copia
            old_short_id = self.get_short_id() or "DFT"

            # 2. Copia fisica dell'intera cartella
            shutil.copytree(self.active_project_path, new_path)

            # 3. Genera nuovo short_id e aggiorna config del nuovo progetto
            import random, string
            new_short_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=3))
            config = {"name": display_name, "short_id": new_short_id, "created_at": timestamp}
            with open(new_path / "project_config.json", 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)

            # 4. Rinomina i file JSON di sessione che contengono il vecchio short_id
            # Questo garantisce che i servizi di chat/vision/manipulate riconoscano le sessioni clonate
            sessions_dir = new_path / "sessions"
            if sessions_dir.exists() and sessions_dir.is_dir():
                for file_path in sessions_dir.iterdir():
                    if file_path.is_file() and file_path.suffix == '.json':
                        old_filename = file_path.name
                        if old_short_id in old_filename:
                            new_filename = old_filename.replace(old_short_id, new_short_id)
                            try:
                                file_path.rename(sessions_dir / new_filename)
                            except Exception as e:
                                print(f"Errore rinomina file di sessione {old_filename}: {e}")

            # 4-bis. Riscrivi i path assoluti DENTRO i JSON di sessione.
            # Bug pre-fix: chat_state_<sid>.json contiene `files: [{path: "C:\\...\\<old>\\uploads\\..."}]`.
            # Dopo la copia il file fisico vive nel nuovo progetto, ma il path puntava al vecchio.
            # get_uploaded_files() (chat_service.py:1267) fa pruning sui path che non esistono → la
            # sidebar "documenti attivi" si svuotava anche se i file erano stati copiati correttamente.
            old_path_str = str(self.active_project_path)
            new_path_str = str(new_path)
            if sessions_dir.exists() and sessions_dir.is_dir():
                for file_path in sessions_dir.iterdir():
                    if not (file_path.is_file() and file_path.suffix == '.json'):
                        continue
                    try:
                        data = json.loads(file_path.read_text(encoding='utf-8'))
                    except Exception as e:
                        print(f"Errore lettura {file_path.name} per rewrite path: {e}")
                        continue

                    def _walk(node):
                        if isinstance(node, str):
                            # Replace sia old_path_str che la sua versione con forward-slash
                            # (alcuni service normalizzano a "/"), e gestisci anche short_id residuo.
                            replaced = node.replace(old_path_str, new_path_str)
                            replaced = replaced.replace(
                                old_path_str.replace('\\', '/'),
                                new_path_str.replace('\\', '/')
                            )
                            return replaced
                        if isinstance(node, list):
                            return [_walk(x) for x in node]
                        if isinstance(node, dict):
                            return {k: _walk(v) for k, v in node.items()}
                        return node

                    new_data = _walk(data)
                    if new_data != data:
                        try:
                            file_path.write_text(
                                json.dumps(new_data, indent=2, ensure_ascii=False),
                                encoding='utf-8'
                            )
                        except Exception as e:
                            print(f"Errore scrittura {file_path.name} dopo rewrite path: {e}")

            # 5. Attiva automaticamente il nuovo progetto
            self.set_active_project(new_folder_name)

            return True, {
                "folder": new_folder_name,
                "short_id": new_short_id,
                "name": display_name
            }
        except Exception as e:
            return False, str(e)

    def get_projects(self):
        """Elenca tutti i progetti esistenti (cartelle che iniziano con 'project_')."""
        return [p.name for p in self.PROJECTS_ROOT_DIR.iterdir() if p.is_dir() and p.name.startswith("project_")]

    def create_project(self, name: str):
        """Crea una nuova struttura di cartelle per un progetto."""
        # Sanitizzazione difensiva: il frontend già filtra l'input, ma il nome
        # finisce in un path su disco → non fidarsi mai del client.
        display_name = _safe_display_name(name)
        folder_component = _safe_folder_component(name)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        project_folder_name = f"project_{folder_component}_{timestamp}"
        project_path = self.PROJECTS_ROOT_DIR / project_folder_name

        # Creazione delle sottocartelle
        os.makedirs(project_path / "uploads" / "interrogate", exist_ok=True)
        os.makedirs(project_path / "uploads" / "manipulate", exist_ok=True)
        os.makedirs(project_path / "uploads" / "vision", exist_ok=True)
        os.makedirs(project_path / "uploads" / "anonimyze", exist_ok=True)
        os.makedirs(project_path / "chroma_db_v2", exist_ok=True)
        os.makedirs(project_path / "output", exist_ok=True)
        os.makedirs(project_path / "temp", exist_ok=True)
        os.makedirs(project_path / "sql_db", exist_ok=True)

        # Genera ID breve unico
        import random, string
        short_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=3))

        config = {"name": display_name, "short_id": short_id, "created_at": timestamp}
        with open(project_path / "project_config.json", 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)

        print(f"Project '{display_name}' ({short_id}) created at: {project_path}")
        self.set_active_project(project_folder_name)
        return project_folder_name

    def list_projects(self) -> List[Dict]:
        """Restituisce lista di dict con info sui progetti esistenti.

        Include `last_opened` (ISO 8601) quando presente in `project_config.json`
        — aggiornato a ogni `set_active_project`. Lista ordinata per last_opened
        desc; progetti mai ancora aperti vanno in fondo (sort fallback su folder).
        """
        projects = []
        if not self.PROJECTS_ROOT_DIR.exists(): return []

        for p in self.PROJECTS_ROOT_DIR.iterdir():
            if p.is_dir() and p.name.startswith("project_"):
                config_path = p / "project_config.json"
                name = p.name.replace('project_', '').split('_')[0]
                short_id = "DFT"
                last_opened: Optional[str] = None
                created_at: Optional[str] = None
                if config_path.exists():
                    try:
                        with open(config_path, 'r', encoding='utf-8') as f:
                            cfg = json.load(f)
                            name = cfg.get("name", name)
                            short_id = cfg.get("short_id", "DFT")
                            last_opened = cfg.get("last_opened")
                            created_at = cfg.get("created_at")
                    except: pass
                projects.append({
                    "folder": p.name,
                    "name": name,
                    "short_id": short_id,
                    "last_opened": last_opened,
                    "created_at": created_at,
                })
        # Ordina per last_opened desc; None va in fondo
        return sorted(
            projects,
            key=lambda x: (x.get("last_opened") or "", x.get("folder", "")),
            reverse=True,
        )

    def get_short_id(self) -> str:
        """Restituisce lo short_id del progetto attivo."""
        if not self.active_project_path: return "???"
        config_path = self.active_project_path / "project_config.json"
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    return json.load(f).get("short_id", "DFT")
            except: pass
        return self.active_project_name[:3].upper()

    def set_active_project(self, project_folder_name: str):
        """Imposta il progetto attivo e salva la preferenza.

        Aggiorna anche `last_opened` (ISO 8601) in `project_config.json` per
        permettere alla UI di mostrare "ultima apertura" e ordinare i progetti
        per recency. Errore di scrittura non blocca: il progetto si apre
        comunque, last_opened resta al valore precedente.
        """
        path = self.PROJECTS_ROOT_DIR / project_folder_name
        if not path.is_dir():
            raise ValueError(f"Progetto '{project_folder_name}' non trovato")

        self.active_project_path = path
        self.active_project_name = project_folder_name
        self._save_last_project_preference(project_folder_name)

        # Aggiorna last_opened nel project_config.json (best-effort, errori non fatali)
        try:
            config_path = path / "project_config.json"
            cfg = {}
            if config_path.exists():
                with open(config_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
            cfg["last_opened"] = datetime.now().isoformat(timespec="seconds")
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"⚠️ Non sono riuscito ad aggiornare last_opened per {project_folder_name}: {e}")

        print(f"Progetto attivo impostato su: {self.active_project_name}")

    def delete_project(self, project_folder_name: str) -> bool:
        """Elimina fisicamente la cartella del progetto con strategia aggressiva per Windows."""
        path = self.PROJECTS_ROOT_DIR / project_folder_name
        if path.is_dir():
            import shutil, gc, time

            # Se il progetto da eliminare è quello attivo, switcha prima sul default
            if project_folder_name == self.active_project_name:
                print(f"Switching to default project before deleting {project_folder_name}...")
                self.set_active_project('project_000_DEFAULT_WORKSPACE')
                time.sleep(0.3)

            # Rilascio risorse: forza garbage collection
            gc.collect()
            time.sleep(0.5)

            # Strategia Windows: Prova a rinominare prima di cancellare
            temp_path = path.parent / f"to_delete_{int(time.time())}_{project_folder_name}"
            try:
                os.rename(path, temp_path)
                target_path = temp_path
            except:
                target_path = path

            max_retries = 4
            for attempt in range(max_retries):
                try:
                    shutil.rmtree(target_path)
                    print(f"Progetto eliminato: {project_folder_name}")
                    return True
                except Exception as e:
                    if attempt < max_retries - 1:
                        gc.collect()
                        time.sleep(1.5)
                    else:
                        # FALLIMENTO: Segna per eliminazione al prossimo avvio
                        print(f"ERRORE ELIMINAZIONE: {project_folder_name} - {e}")
                        self._mark_for_delete_on_restart(project_folder_name)
                        return False
        return False

    def _mark_for_delete_on_restart(self, project_folder_name: str):
        """Segna un progetto per l'eliminazione al prossimo avvio (se i file sono bloccati)."""
        pending_path = self.BASE_DIR / "pending_deletes.json"
        try:
            pending = []
            if pending_path.exists():
                with open(pending_path, 'r') as f:
                    pending = json.load(f)
            if project_folder_name not in pending:
                pending.append(project_folder_name)
                with open(pending_path, 'w') as f:
                    json.dump(pending, f)
                print(f"Progetto '{project_folder_name}' marcato per eliminazione al prossimo avvio.")
        except Exception as e:
            print(f"Errore marking per delete on restart: {e}")

    def process_pending_deletes(self):
        """Elimina i progetti marcati al prossimo avvio (prima di caricare qualsiasi cosa)."""
        pending_path = self.BASE_DIR / "pending_deletes.json"
        if not pending_path.exists():
            return

        try:
            with open(pending_path, 'r') as f:
                pending = json.load(f)

            deleted = []
            for project_folder_name in pending:
                path = self.PROJECTS_ROOT_DIR / project_folder_name
                if path.exists():
                    # Prova a eliminare ora (all'avvio i lock non ci sono ancora)
                    try:
                        import shutil, time
                        time.sleep(0.5)  # Attendi che tutto sia inizializzato
                        shutil.rmtree(path)
                        print(f"Eliminato progetto pending: {project_folder_name}")
                        deleted.append(project_folder_name)
                    except Exception as e:
                        print(f"Non posso eliminare {project_folder_name}: {e}")
                else:
                    deleted.append(project_folder_name)  # Già eliminato

            # Aggiorna lista pending
            remaining = [p for p in pending if p not in deleted]
            if remaining:
                with open(pending_path, 'w') as f:
                    json.dump(remaining, f)
            else:
                pending_path.unlink()  # Rimuovi file se vuoto
        except Exception as e:
            print(f"Errore process_pending_deletes: {e}")

    def delete_all_projects(self) -> int:
        """Elimina tutti i progetti tranne il workspace default E quello
        attualmente in uso. Ritorna il numero di progetti eliminati.

        ATTENZIONE: snapshottiamo `active_before` PRIMA di switchare sul
        default per rilasciare i lock, altrimenti il `current` perderebbe
        identità (è il default, non quello originale dell'utente) e
        l'iter di delete cancellerebbe il progetto che l'utente sta usando.
        """
        active_before = self.active_project_name
        is_active_default = active_before == 'project_000_DEFAULT_WORKSPACE'

        # Switcha sul default per rilasciare lock su ChromaDB/DuckDB del
        # progetto attivo (necessario su Windows altrimenti delete fallisce).
        if not is_active_default:
            print("Switching to default project before bulk delete (will preserve {} too)...".format(active_before))
            self.set_active_project('project_000_DEFAULT_WORKSPACE')
            import time
            time.sleep(0.3)

        import gc, time
        gc.collect()
        time.sleep(0.5)

        projects = self.get_projects()
        count = 0
        for p in projects:
            # Salta DEFAULT e progetto attivo PRE-switch.
            if p == 'project_000_DEFAULT_WORKSPACE':
                continue
            if p == active_before:
                continue
            if self.delete_project(p):
                count += 1

        # Se l'utente era su un progetto custom, ripristinalo come attivo.
        if not is_active_default:
            if (self.PROJECTS_ROOT_DIR / active_before).is_dir():
                self.set_active_project(active_before)
            else:
                # Il progetto pre-attivo è sparito (fallita la preservazione):
                # resta sul default per coerenza.
                print(f"⚠ Pre-active project {active_before} no longer exists, staying on default")

        return count

    def get_preferences(self) -> Dict:
        """Carica le preferenze globali dell'utente (lingua, ultimo progetto)."""
        prefs_path = self.BASE_DIR / "user_preferences.json"
        # Supporto legacy per last_project.json
        old_path = self.BASE_DIR / "last_project.json"

        # Auto-Discovery della lingua di sistema
        default_lang = "en"
        try:
            import locale
            sys_loc = locale.getdefaultlocale()[0]
            if sys_loc:
                sys_lang = sys_loc[:2].lower()
                if sys_lang in ['it', 'en']:
                    default_lang = sys_lang
        except Exception:
            pass

        if not prefs_path.exists() and old_path.exists():
            try:
                with open(old_path, 'r') as f:
                    data = json.load(f)
                    return {"lang": default_lang, "last_active_project": data.get("last_active_project")}
            except: pass

        if prefs_path.exists():
            try:
                with open(prefs_path, 'r') as f:
                    data = json.load(f)
                    if "lang" not in data:
                        data["lang"] = default_lang
                    return data
            except: pass

        return {"lang": default_lang, "setup_finished": False}

    def save_language_preference(self, lang: str):
        """Salva la lingua scelta dall'utente nelle preferenze globali."""
        try:
            prefs = self.get_preferences()
            prefs["lang"] = lang
            with open(self.BASE_DIR / "user_preferences.json", 'w') as f:
                json.dump(prefs, f, indent=4)
            print(f"Preferred language saved: {lang}")
        except Exception as e:
            print(f"Language save error: {e}")

    def set_setup_finished(self, finished: bool = True):
        """Salva lo stato del completamento del setup iniziale."""
        try:
            prefs = self.get_preferences()
            prefs["setup_finished"] = finished
            with open(self.BASE_DIR / "user_preferences.json", 'w') as f:
                json.dump(prefs, f, indent=4)
        except Exception as e:
            print(f"Errore salvataggio stato setup: {e}")

    def is_setup_finished(self) -> bool:
        """Verifica se il setup iniziale è stato completato in precedenza."""
        return self.get_preferences().get("setup_finished", False)

    def load_last_project(self):
        """Carica l'ultimo progetto utilizzato o ne crea uno di default."""
        prefs = self.get_preferences()
        last_project = prefs.get("last_active_project")
        if last_project and (self.PROJECTS_ROOT_DIR / last_project).is_dir():
            self.set_active_project(last_project)
            return

        # Se non c'è un progetto precedente valido, ne crea uno di default
        print("Nessun progetto precedente trovato o valido. Creazione di un progetto di default.")
        self.create_project("default_session")

    def _save_last_project_preference(self, project_folder_name: str):
        """Salva il nome del progetto attivo in un file json."""
        try:
            prefs = self.get_preferences()
            prefs["last_active_project"] = project_folder_name
            with open(self.BASE_DIR / "user_preferences.json", 'w') as f:
                json.dump(prefs, f, indent=4)
        except Exception as e:
            print(f"Impossibile salvare le preferenze: {e}")

    def get_path(self, key: str) -> Path:
        """Restituisce il percorso di una sottocartella specifica del progetto attivo."""
        if not self.active_project_path:
            raise ValueError("Nessun progetto attivo. Impossibile ottenere il percorso.")

        path_map = {"uploads": "uploads", "db": "chroma_db_v2", "output": "output", "temp": "temp", "sql_db": "sql_db", "root": "", "batch": "batch", "batch_attachments": "batch/attachments"}
        subfolder = path_map.get(key)
        if subfolder is None: raise ValueError(f"Chiave percorso non valida: '{key}'")
        return self.active_project_path / subfolder

    def get_sql_db_path(self) -> Path:
        """Restituisce il percorso del file database DuckDB del progetto attivo."""
        return self.get_path("sql_db") / "business_data.db"

# Istanza globale unica
project_manager = ProjectManager()
