"""
I18N Service - Gestione traduzioni multilingua per PAI Premium
Carica e fornisce label UI da file JSON.
Supporto lingue: IT, EN, ES, FR, DE
"""
import json
import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

class I18NService:
    """
    Servizio per gestione traduzioni UI.
    Singleton per mantenere stato globale della lingua corrente.
    """
    _instance = None
    _labels: Dict = {}
    _current_lang: str = "it"
    _loaded: bool = False

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(I18NService, cls).__new__(cls)
        return cls._instance

    def __init__(self, labels_path: Optional[Path] = None):
        if self._loaded:
            return
        
        if labels_path is None:
            # Path corretto: backend_config/labels.json
            labels_path = Path(__file__).parent.parent / "backend_config" / "labels.json"
        
        self.labels_path = labels_path
        self.load_labels()
        self._loaded = True

    def load_labels(self):
        """Carica le label dal file JSON."""
        try:
            with open(self.labels_path, 'r', encoding='utf-8') as f:
                self._labels = json.load(f)
            
            # Imposta lingua di default SOLO se non è stata già impostata manualmente
            if not self._loaded:
                self._current_lang = self._initial_lang()
            
            logger.info(f"✅ I18N: Loaded translations for {len(self._labels)} languages (Current: {self._current_lang})")
        except Exception as e:
            logger.error(f"❌ I18N: Labels loading failed: {e}")
            # Fallback minimo
            self._labels = {
                "it": {"sidebar": {"system_ready": "Sistema Pronto"}},
                "en": {"sidebar": {"system_ready": "System Ready"}}
            }
            self._current_lang = "it"

    def _initial_lang(self) -> str:
        """Lingua di partenza al boot del backend:
          1. scelta dell'utente persistita in ~/.pais/config.json (priorità);
          2. altrimenti lingua del sistema operativo.
        Così la lingua scelta nell'app viene ricordata tra un riavvio e l'altro."""
        try:
            from backend_config.settings import get_persisted_language
            persisted = get_persisted_language()
            if persisted and persisted in self._labels:
                return persisted
        except Exception:
            pass
        return self._detect_system_lang()

    def _detect_system_lang(self) -> str:
        """Rileva lingua del sistema operativo."""
        try:
            import locale
            sys_locale = locale.getdefaultlocale()[0]
            if sys_locale:
                sys_lang = sys_locale[:2].lower()
                if sys_lang in self._labels:
                    return sys_lang
        except:
            pass
        
        # Fallback a italiano
        return "it"

    def get_current_lang(self) -> str:
        """Ottiene lingua corrente."""
        return self._current_lang

    def set_language(self, lang: str) -> bool:
        """
        Imposta lingua corrente e ricarica le label dal disco.
        """
        # Ricarica sempre dal disco per riflettere modifiche al file JSON
        self.load_labels()
        
        if lang in self._labels:
            self._current_lang = lang
            # Persiste la scelta così sopravvive al riavvio (splash + UI).
            try:
                from backend_config.settings import set_persisted_language
                set_persisted_language(lang)
            except Exception:
                pass
            logger.info(f"🌐 I18N: Language set: {lang}")
            return True

        logger.warning(f"⚠️ I18N: Language '{lang}' not available, using 'it'")
        self._current_lang = "it"
        return False

    def get(self, key: str, *args, **kwargs) -> str:
        """
        Ottiene label per chiave.
        Supporta argomenti extra per evitare crash se vengono passati parametri di lingua legacy.
        """
        default = kwargs.get('default')
        if not default and len(args) > 0:
            default = args[0]
            
        labels = self._labels.get(self._current_lang, {})
        
        # Naviga chiavi annidate
        parts = key.split('.')
        value = labels
        for part in parts:
            if isinstance(value, dict):
                value = value.get(part)
            else:
                value = None
                break
        
        if value is None:
            # Prova fallback in italiano
            if self._current_lang != 'it':
                it_labels = self._labels.get('it', {})
                value = it_labels
                for part in parts:
                    if isinstance(value, dict):
                        value = value.get(part)
                    else:
                        value = None
                        break
            
            # Se ancora None, usa default
            if value is None:
                return default if default else key
        
        return str(value)

    def get_all_labels(self) -> Dict:
        """Ottiene tutte le label per la lingua corrente."""
        return self._labels.get(self._current_lang, {})

    def get_available_languages(self) -> list:
        """Ottiene lista lingue disponibili."""
        return list(self._labels.keys())


# Istanza globale singleton
i18n = I18NService()
