"""
USER LIBRARY router — libreria prompt personale dell'utente.

L'utente sceglie una cartella (selettore nativo via pywebview bridge,
services/auth_service.PywebviewBridge.select_folder) contenente file .txt:
ogni file = un prompt → nome del file (senza estensione) = titolo, contenuto
del file = testo del prompt.

Il path della cartella è persistito in ~/.pais/user_library.json. Lo scan
avviene a OGNI GET, così aggiungere/modificare file si riflette subito senza
riavviare l'app. La libreria è UNICA e CONDIVISA fra INTERROGATE e VISION
("USER LIBRARY" generica).

Robustezza: se la cartella non esiste più (spostata, cancellata, chiavetta USB
rimossa) l'endpoint NON va in errore — ritorna `missing=true` e lista vuota,
così i prompt built-in continuano a funzionare e l'utente può ricollegarla.
"""
import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()
logger = logging.getLogger("PAIS.UserLibrary")

# Limiti di sicurezza per non bloccare l'app su cartelle enormi / file giganti.
_MAX_FILES = 300
_MAX_FILE_BYTES = 1_000_000  # 1 MB per prompt
_MAX_TITLE_LEN = 120


def _settings_path() -> Path:
    """~/.pais/user_library.json (stesso pattern del token, vedi auth_service)."""
    home = os.environ.get("USERPROFILE") or str(Path.home())
    return Path(home) / ".pais" / "user_library.json"


def _load_folder() -> Optional[str]:
    p = _settings_path()
    try:
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            return data.get("folder") or None
    except Exception as e:
        logger.warning(f"user_library settings read failed: {e}")
    return None


def _save_folder(folder: Optional[str]) -> None:
    p = _settings_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps({"folder": folder}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception as e:
        logger.error(f"user_library settings write failed: {e}")


def _read_text_file(path: Path) -> str:
    """Legge un .txt tollerando le codifiche più comuni su Windows (BOM, ANSI)."""
    try:
        if path.stat().st_size > _MAX_FILE_BYTES:
            return ""
    except OSError:
        return ""
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return path.read_text(encoding=enc).strip()
        except (UnicodeDecodeError, OSError):
            continue
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def _scan_folder(folder: Path) -> List[Dict[str, str]]:
    """Top-level (non ricorsivo): ogni *.txt non vuoto diventa un prompt."""
    prompts: List[Dict[str, str]] = []
    try:
        files = sorted(
            (f for f in folder.iterdir() if f.is_file() and f.suffix.lower() == ".txt"),
            key=lambda f: f.name.lower(),
        )
    except OSError as e:
        logger.warning(f"user_library scan failed for {folder}: {e}")
        return prompts
    for f in files[:_MAX_FILES]:
        text = _read_text_file(f)
        if not text:
            continue
        title = (f.stem.strip() or f.name)[:_MAX_TITLE_LEN]
        prompts.append({"title": title, "text": text})
    return prompts


def _empty(configured: bool = False, folder: Optional[str] = None,
           folder_name: Optional[str] = None, missing: bool = False) -> dict:
    return {
        "configured": configured,
        "folder": folder,
        "folder_name": folder_name,
        "missing": missing,
        "prompts": [],
        "count": 0,
    }


def _build_response() -> dict:
    folder = _load_folder()
    if not folder:
        return _empty()
    fp = Path(folder)
    if not fp.exists() or not fp.is_dir():
        # Cartella sparita: NON è un errore — l'utente la ricollegherà.
        return _empty(configured=True, folder=folder, folder_name=fp.name, missing=True)
    prompts = _scan_folder(fp)
    return {
        "configured": True,
        "folder": folder,
        "folder_name": fp.name,
        "missing": False,
        "prompts": prompts,
        "count": len(prompts),
    }


class SetFolderRequest(BaseModel):
    folder: str


@router.get("/prompts")
async def get_user_library():
    """Stato corrente + prompt scansionati. Mai 500 per cartella mancante."""
    return _build_response()


@router.post("/folder")
async def set_user_library_folder(req: SetFolderRequest):
    """Imposta (e persiste) la cartella USER LIBRARY, poi ritorna i prompt."""
    folder = (req.folder or "").strip()
    if folder:
        fp = Path(folder)
        if fp.exists() and fp.is_dir():
            _save_folder(str(fp))
        else:
            # Path non valido: non persistere ma non andare in errore.
            return _empty(configured=True, folder=folder, folder_name=fp.name, missing=True)
    return _build_response()


@router.delete("/folder")
async def clear_user_library_folder():
    """Scollega la cartella USER LIBRARY (i prompt built-in restano)."""
    _save_folder(None)
    return _empty()
