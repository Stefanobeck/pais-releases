"""
OCR Img/PDF Conversion Processor per PAI Premium
Converts images and PDF pages to text using vision OCR model.
Conformità Commerciale: Usa pypdfium2 (Apache 2.0) e python-docx (MIT).
"""

import os
import asyncio
import logging
import re
import time
from pathlib import Path
from typing import Callable, Optional, Tuple, List

logger = logging.getLogger(__name__)

from backend_config.settings import settings

# Estensioni supportate
SUPPORTED_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tiff', '.tif', '.gif'}
SUPPORTED_FORMATS = SUPPORTED_IMAGE_EXTS | {'.pdf'}

# Prompt OCR ottimizzato (Standard Professionale GLM-OCR)
OCR_SYSTEM_PROMPT = """You are a professional OCR assistant.
Your task is to transcribe the provided image into high-quality Markdown.
Preserve all structural elements: tables, headers, lists, and LaTeX formulas.
Output raw Markdown only. No preamble, no code blocks.
"""

# Prompt OCR ottimizzato per Qwen-VL (Vision Global)
QWEN_OCR_PROMPT = """You are an advanced AI vision assistant.
Extract all text, tables, and structured data from this image.
Output the result in high-quality Markdown format.
Maintain the visual hierarchy and structure of the document.
Output raw Markdown only. No preamble, no code blocks.
"""

class OCRImgPDFProcessor:
    """
    Processa immagini e PDF pagina per pagina, trascrivendo il testo con OCR model.
    """

    def __init__(self):
        from .layout_processor import LayoutProcessor
        self._client = None
        self.layout_processor = LayoutProcessor()

    @property
    def client(self):
        """Restituisce un client Ollama aggiornato con l'host corrente."""
        import ollama
        from backend_config.settings import settings
        current_host = settings.OLLAMA_HOST_URL
        
        # Inizializza o aggiorna il client se l'host è cambiato
        if self._client is None:
            logger.info(f"Initializing OCR Ollama Client on {current_host}")
            self._client = ollama.AsyncClient(host=current_host)
        return self._client

    @staticmethod
    def get_output_dir() -> Path:
        """Restituisce la cartella OCR_CONVERSION nella cartella output del progetto."""
        from backend_config.project_manager import project_manager
        output_dir = project_manager.get_path("output") / "OCR_CONVERSION"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def _clean_hallucinations(self, text: str) -> str:
        """Rimuove cicli di allucinazioni comuni generati da modelli vision su regioni vuote."""
        if not text:
            return ""
            
        # Filtro per le ripetizioni "Possible text:"
        lines = text.split('\n')
        cleaned_lines = []
        possible_text_count = 0
        
        for line in lines:
            line_stripped = line.strip()
            if "Possible text:" in line_stripped:
                possible_text_count += 1
                if possible_text_count > 1:
                    continue 
            else:
                possible_text_count = 0
            cleaned_lines.append(line)
            
        result = "\n".join(cleaned_lines).strip()
        
        # Pulizia blocchi markdown vuoti o residui tecnici
        result = result.replace("```markdown", "").replace("```", "").strip()
        
        if result.lower() == "possible text:" or not result:
            return ""
            
        return result

    async def _preprocess_image(self, image_path: str) -> str:
        """Ridimensiona e ottimizza l'immagine per migliorare la precisione OCR."""
        try:
            from PIL import Image, ImageOps, ImageFilter
            img = Image.open(image_path)
            
            # Converte in RGB se necessario
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            
            # Ridimensionamento intelligente: lato lungo max 1536px per bilanciare precisione e VRAM
            max_size = 1536
            ratio = max_size / max(img.size)
            if ratio < 1.0:
                new_size = (int(img.size[0] * ratio), int(img.size[1] * ratio))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
            
            # Miglioramento contrasto e nitidezza
            img = img.filter(ImageFilter.SHARPEN)
            
            prep_path = image_path.replace(".png", "_prep.png").replace(".jpg", "_prep.jpg")
            img.save(prep_path, "PNG", quality=95)
            return prep_path
        except Exception as e:
            logger.error(f"Image preprocessing failed: {e}")
            return image_path

    async def _ocr_single_image(self, image_path: str, model: str = "glm-ocr:latest") -> str:
        """Chiama OCR model su una singola immagine usando Layout Analysis se GLM-OCR."""
        processed_path = image_path
        try:
            logger.info(f"🔍 [OCR] Starting image processing ({model}): {Path(image_path).name}")
            processed_path = await self._preprocess_image(image_path)
            
            # Strategia 1: GLM-OCR (Layout Aware)
            if "glm-ocr" in model.lower():
                logger.info(f"🧠 [LAYOUT] Analisi del layout ONNX per {Path(processed_path).name}...")
                regions = self.layout_processor.segment_layout(processed_path)
                logger.info(f"📊 [LAYOUT] Trovate {len(regions)} regioni.")
                
                if regions and len(regions) > 0:
                    all_parts = []
                    for i, region in enumerate(regions):
                        x1, y1, x2, y2 = region['bbox']
                        if (x2 - x1) < 10 or (y2 - y1) < 10: continue

                        part_text = await self._ocr_region(processed_path, region['bbox'], region['label'], model)
                        if part_text:
                            all_parts.append(part_text)
                    
                    full_text = "\n\n".join(all_parts)
                    if full_text.strip():
                        return full_text

            # Strategia 2: Qwen-VL o Fallback (Full Image)
            logger.info(f"🚀 [OCR] Chiamata a {model} (Full Image Mode)")
            with open(processed_path, "rb") as f:
                img_bytes = f.read()

            prompt = QWEN_OCR_PROMPT if "qwen" in model.lower() else f"Text Recognition: \n{OCR_SYSTEM_PROMPT}"
            
            response = await self.client.generate(
                model=model,
                prompt=prompt,
                images=[img_bytes],
                options={
                    "temperature": 0.0,
                    "num_ctx": 8192, # 8K per stabilità VRAM
                    "num_predict": 4096,
                    "seed": 42
                }
            )
            
            raw_text = response.get("response", "").strip()
            text = self._clean_hallucinations(raw_text)
            logger.info(f"✅ [OCR] Estrazione completata ({len(text)} caratteri).")
            return text if text else "[No text detected on this page]"
            
        except Exception as e:
            logger.error(f"❌ [OCR] Errore critico: {e}")
            return f"[OCR Error on this page: {e}]"
        finally:
            if processed_path != image_path:
                try: os.remove(processed_path)
                except: pass

    async def _ocr_single_image_stream(self, image_path: str, model: str = "glm-ocr:latest"):
        """Chiama OCR model in streaming."""
        processed_path = image_path
        try:
            logger.info(f"🔍 [STREAM] Starting streaming OCR ({model}) for {Path(image_path).name}")
            processed_path = await self._preprocess_image(image_path)
            
            # Strategia 1: GLM-OCR (Layout Aware)
            if "glm-ocr" in model.lower():
                logger.info(f"🧠 [LAYOUT] Analisi del layout ONNX (Stream Mode)...")
                regions = self.layout_processor.segment_layout(processed_path)
                
                if regions and len(regions) > 0:
                    for i, region in enumerate(regions):
                        x1, y1, x2, y2 = region['bbox']
                        if (x2 - x1) < 10 or (y2 - y1) < 10: continue
                        text = await self._ocr_region(processed_path, region['bbox'], region['label'], model)
                        if text:
                            yield text + "\n\n"
                    return

            # Strategia 2: Qwen-VL o Fallback (Full Image)
            with open(processed_path, "rb") as f:
                img_bytes = f.read()

            prompt = QWEN_OCR_PROMPT if "qwen" in model.lower() else f"Text Recognition: \n{OCR_SYSTEM_PROMPT}"

            async for chunk in await self.client.generate(
                model=model,
                prompt=prompt,
                images=[img_bytes],
                stream=True,
                options={"temperature": 0.0, "num_ctx": 8192, "seed": 42}
            ):
                content = chunk.get("response", "")
                if content:
                    yield content
                    
        except Exception as e:
            logger.error(f"❌ [STREAM] Errore: {e}")
            yield f"\n\n[OCR Error: {e}]\n\n"
        finally:
            if processed_path != image_path:
                try: os.remove(processed_path)
                except: pass

    async def _ocr_region(self, image_path: str, bbox: List[int], label: str, model: str) -> str:
        """Processa una singola regione estratta dal LayoutProcessor."""
        try:
            from PIL import Image
            img = Image.open(image_path)
            # bbox è [x1, y1, x2, y2]
            region = img.crop((bbox[0], bbox[1], bbox[2], bbox[3]))
            region_path = image_path.replace(".png", f"_reg_{label}.png")
            region.save(region_path)
            
            with open(region_path, "rb") as f:
                img_bytes = f.read()

            # Intento basato sulla label del layout (Standard GLM-OCR + Semantic Hint)
            if label == "title":
                intent = "Text Recognition: Output as Markdown Level 1 Header (# Title)"
            elif label == "heading":
                intent = "Text Recognition: Output as Markdown Level 2 Header (## Header)"
            elif label == "table":
                intent = "Table Recognition: "
            elif label == "figure":
                # Forziamo Text Recognition anche per le figure per catturare il testo interno
                intent = "Text Recognition: Extract all text from this image. "
            else:
                intent = "Text Recognition: "
            
            logger.info(f"📤 [OCR] Invio regione '{label}' a {model} (Intent: {intent})")
            
            response = await self.client.generate(
                model=model,
                prompt=f"{intent}\n\n{OCR_SYSTEM_PROMPT}",
                images=[img_bytes],
                options={
                    "temperature": 0.0,
                    "num_ctx": 8192, # 8K per stabilità VRAM
                    "num_predict": 4096,
                    "seed": 42
                }
            )
            
            if os.path.exists(region_path):
                os.remove(region_path)
                
            raw_text = response.get("response", "").strip()
            return self._clean_hallucinations(raw_text)
        except Exception as e:
            logger.error(f"❌ [REGION] Errore OCR regione {label}: {e}")
            return ""

    async def process_image_stream(self, image_path: str, model: str = "glm-ocr:latest"):
        """Processa una singola immagine usando la pipeline OCR streaming."""
        async for chunk in self._ocr_single_image_stream(image_path, model):
            yield chunk

    async def process_pdf_stream(self, pdf_path: str, model: str = "glm-ocr:latest"):
        """Processa un PDF pagina per pagina in modalità streaming usando pypdfium2 (Apache 2.0)."""
        try:
            import pypdfium2 as pdfium
        except ImportError:
            yield "Error: pypdfium2 is not installed."
            return

        from backend_config.settings import settings
        temp_dir = settings.BASE_DIR / "temp" / "ocr_conversion"
        temp_dir.mkdir(parents=True, exist_ok=True)

        try:
            pdf = pdfium.PdfDocument(pdf_path)
            total_pages = len(pdf)

            for page_num in range(total_pages):
                page_label = f"Page {page_num + 1}/{total_pages}"
                yield f"\n\n**--- {page_label} ---**\n\n"

                page = pdf[page_num]
                # Rendering ad alta qualità (72 * 4 = 288 DPI)
                bitmap = page.render(scale=4.0)
                pil_image = bitmap.to_pil()
                
                temp_img_path = str(temp_dir / f"ocr_page_stream_{page_num + 1}.png")
                pil_image.save(temp_img_path)

                async for chunk in self._ocr_single_image_stream(temp_img_path, model):
                    yield chunk

                try: os.remove(temp_img_path)
                except: pass

            pdf.close()
        except Exception as e:
            logger.error(f"PDF OCR Stream error: {e}")
            yield f"\n\n[Error during PDF processing: {e}]\n\n"

    async def process_image(
        self,
        image_path: str,
        progress_callback: Optional[Callable[[str], None]] = None,
        model: str = "glm-ocr:latest"
    ) -> Tuple[bool, str]:
        """
        Processa una singola immagine.
        """
        name = Path(image_path).name
        if progress_callback:
            progress_callback(f"Analyzing image: {name}...")
        text = await self._ocr_single_image(image_path, model)
        return True, text

    async def process_pdf(
        self,
        pdf_path: str,
        progress_callback: Optional[Callable[[str], None]] = None,
        model: str = "glm-ocr:latest"
    ) -> Tuple[bool, str]:
        """
        Processa un PDF pagina per pagina usando pypdfium2.
        """
        try:
            import pypdfium2 as pdfium
        except ImportError:
            return False, "Error: pypdfium2 is not installed."

        from backend_config.settings import settings
        temp_dir = settings.BASE_DIR / "temp" / "ocr_conversion"
        temp_dir.mkdir(parents=True, exist_ok=True)

        try:
            pdf = pdfium.PdfDocument(pdf_path)
            total_pages = len(pdf)
            all_text_parts = []

            for page_num in range(total_pages):
                page_label = f"Page {page_num + 1}/{total_pages}"
                if progress_callback:
                    progress_callback(f"Analyzing {page_label}...")

                page = pdf[page_num]
                bitmap = page.render(scale=4.0)
                pil_image = bitmap.to_pil()
                
                temp_img_path = str(temp_dir / f"ocr_page_{page_num + 1}.png")
                pil_image.save(temp_img_path)

                page_text = await self._ocr_single_image(temp_img_path, model)
                try: os.remove(temp_img_path)
                except: pass

                all_text_parts.append(f"**--- {page_label} ---**\n\n{page_text}")

            pdf.close()
            full_text = "\n\n".join(all_text_parts)
            return True, full_text

        except Exception as e:
            logger.error(f"PDF OCR error: {e}")
            return False, f"Error during PDF processing: {e}"

    async def extract_image_regions_only(
        self,
        pdf_path: str,
        model: str = "glm-ocr:latest",
        progress_callback: Optional[Callable[[str], None]] = None,
    ) -> Tuple[bool, str]:
        """OCR delle SOLE regioni immagine (tabelle, figure, formule) di un PDF.

        Pensato per ARRICCHIRE l'ingest di INTERROGATE: il testo nativo è già
        estratto da pypdf, qui catturiamo solo ciò che pypdf NON vede (tabelle
        come immagine, testo dentro le figure) SENZA ri-OCRare le regioni di
        testo → niente duplicazione del testo nativo. Riusa segment_layout +
        _ocr_region, stessa rasterizzazione di process_pdf (pypdfium2, 288 DPI).

        Ritorna (True, testo) coi soli blocchi immagine (marker [PAGE:N], coerente
        con ingest_file), oppure (True, "") se non c'è nulla di utile.
        (False, msg) solo su errore hard (es. pypdfium2 mancante).
        """
        try:
            import pypdfium2 as pdfium
        except ImportError:
            return False, "Error: pypdfium2 is not installed."

        # Solo regioni NON testuali: testo/title/heading sono già coperti da pypdf.
        OCR_LABELS = {"table", "figure", "equation"}

        from backend_config.settings import settings
        temp_dir = settings.BASE_DIR / "temp" / "ocr_conversion"
        temp_dir.mkdir(parents=True, exist_ok=True)

        pdf = None
        page_blocks = []
        try:
            pdf = pdfium.PdfDocument(pdf_path)
            total_pages = len(pdf)

            for page_num in range(total_pages):
                if progress_callback:
                    progress_callback(f"Analyzing images on page {page_num + 1}/{total_pages}...")

                page = pdf[page_num]
                bitmap = page.render(scale=4.0)  # 288 DPI, come process_pdf
                pil_image = bitmap.to_pil()
                temp_img_path = str(temp_dir / f"enrich_page_{page_num + 1}.png")
                pil_image.save(temp_img_path)

                processed_path = temp_img_path
                try:
                    # Preprocess + layout sulla STESSA immagine usata per il crop,
                    # così le bbox combaciano (come fa _ocr_single_image).
                    processed_path = await self._preprocess_image(temp_img_path)
                    regions = self.layout_processor.segment_layout(processed_path)
                    region_parts = []
                    for region in (regions or []):
                        if region.get("label") not in OCR_LABELS:
                            continue
                        x1, y1, x2, y2 = region["bbox"]
                        if (x2 - x1) < 10 or (y2 - y1) < 10:
                            continue
                        part = await self._ocr_region(processed_path, region["bbox"], region["label"], model)
                        if part and part.strip():
                            region_parts.append(part.strip())
                    if region_parts:
                        page_blocks.append(
                            f"\n[PAGE:{page_num + 1}] [IMMAGINI/TABELLE OCR]\n" + "\n\n".join(region_parts)
                        )
                finally:
                    for p in {temp_img_path, processed_path}:
                        try:
                            if os.path.exists(p):
                                os.remove(p)
                        except Exception:
                            pass

            return True, "\n".join(page_blocks).strip()
        except Exception as e:
            logger.error(f"PDF image-region OCR error: {e}")
            return False, f"Error during image-region OCR: {e}"
        finally:
            if pdf is not None:
                try:
                    pdf.close()
                except Exception:
                    pass

    async def ocr_pdf_to_text(self, pdf_path: str) -> Tuple[bool, str]:
        """Wrapper semplice per OCR PDF."""
        return await self.process_pdf(pdf_path)

    def _clean_text_for_xml(self, text: str) -> str:
        """Rimuove caratteri non compatibili con XML/DOCX."""
        import re
        return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)

    def save_as_txt(self, text: str, base_name: str) -> str:
        """Salva il testo in formato .txt."""
        import time
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_dir = self.get_output_dir()
        output_path = output_dir / f"{base_name}_{timestamp}.txt"
        
        clean_text = self._clean_text_for_xml(text)
        
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(clean_text)
        return str(output_path)

    def save_as_docx(self, text: str, base_name: str) -> str:
        """
        Salva il testo in formato .docx usando python-docx (MIT) con parser Markdown e HTML Table support.
        Legalità Commerciale: Rimpiazza Pandoc (GPL).
        """
        import time
        from docx import Document
        from docx.shared import Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from bs4 import BeautifulSoup
        
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_dir = self.get_output_dir()
        output_path = output_dir / f"{base_name}_{timestamp}.docx"
        
        def add_formatted_text(p, text_content):
            """Aggiunge testo al paragrafo gestendo il grassetto **text**."""
            parts = re.split(r'(\*\*.*?\*\*)', text_content)
            for part in parts:
                if part.startswith('**') and part.endswith('**'):
                    run = p.add_run(part[2:-2])
                    run.bold = True
                else:
                    p.add_run(part)

        try:
            doc = Document()
            doc.core_properties.title = base_name
            
            clean_text = self._clean_hallucinations(text)
            
            # --- GESTIONE TABELLE HTML (GLM-OCR SPECIAL) ---
            # Se il testo contiene <table>, usiamo BeautifulSoup per isolarle e convertirle
            if "<table" in clean_text.lower():
                soup = BeautifulSoup(clean_text, 'html.parser')
                
                # Iteriamo su tutti gli elementi (testo e tabelle)
                for element in soup.contents:
                    if element.name == 'table':
                        # Estrazione righe
                        rows = element.find_all('tr')
                        if not rows: continue
                        
                        # Calcolo colonne (gestendo colspan)
                        max_cols = 0
                        for row in rows:
                            cols_in_row = 0
                            for cell in row.find_all(['td', 'th']):
                                cols_in_row += int(cell.get('colspan', 1))
                            max_cols = max(max_cols, cols_in_row)
                        
                        if max_cols == 0: continue
                        
                        word_table = doc.add_table(rows=len(rows), cols=max_cols)
                        word_table.style = 'Table Grid'
                        
                        for r_idx, row in enumerate(rows):
                            word_row = word_table.rows[r_idx]
                            current_col = 0
                            for cell in row.find_all(['td', 'th']):
                                # Gestione Colspan (molto basica)
                                if current_col < max_cols:
                                    w_cell = word_row.cells[current_col]
                                    text_val = cell.get_text().strip()
                                    p = w_cell.paragraphs[0]
                                    add_formatted_text(p, text_val)
                                    if cell.name == 'th' or r_idx == 0:
                                        for run in p.runs: run.bold = True
                                    current_col += int(cell.get('colspan', 1))
                    
                    elif isinstance(element, str) or element.name not in ['table']:
                        # Testo normale o altri tag non gestiti
                        txt = element.get_text() if hasattr(element, 'get_text') else str(element)
                        lines = txt.split('\n')
                        for line in lines:
                            stripped = line.strip()
                            if not stripped:
                                doc.add_paragraph("")
                                continue
                            if stripped.startswith('# '):
                                doc.add_heading(stripped[2:], level=1)
                            elif stripped.startswith('## '):
                                doc.add_heading(stripped[3:], level=2)
                            elif stripped.startswith('### '):
                                doc.add_heading(stripped[4:], level=3)
                            elif stripped.startswith('- ') or stripped.startswith('* '):
                                p = doc.add_paragraph(style='List Bullet')
                                add_formatted_text(p, stripped[2:])
                            else:
                                p = doc.add_paragraph()
                                add_formatted_text(p, stripped)
                
                doc.save(str(output_path))
                return str(output_path)

            # --- FALLBACK: PARSER MARKDOWN STANDARD (Se non c'è HTML) ---
            lines = clean_text.split('\n')
            i = 0
            while i < len(lines):
                line = lines[i]
                stripped = line.strip()
                
                if "**--- Page" in stripped and "---**" in stripped:
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    run = p.add_run(stripped.replace("**", "").replace("---", "").strip())
                    run.bold = True
                    run.font.size = Pt(12)
                    run.font.color.rgb = RGBColor(0, 102, 204)
                    i += 1
                    continue

                if stripped.startswith('|') and '|' in stripped[1:]:
                    table_buffer = []
                    while i < len(lines) and lines[i].strip().startswith('|'):
                        table_buffer.append(lines[i].strip())
                        i += 1
                    
                    if table_buffer:
                        table_data = []
                        for row_str in table_buffer:
                            if re.match(r'^\s*\|?[\s-]*:?-+[:\s-]*\|', row_str): continue
                            cells = [c.strip() for c in row_str.split('|') if c.strip() or row_str.count('|') > 1]
                            if row_str.startswith('|'): cells = cells[1:]
                            if row_str.endswith('|'): cells = cells[:-1]
                            if cells: table_data.append(cells)
                        
                        if table_data:
                            word_table = doc.add_table(rows=len(table_data), cols=max(len(r) for r in table_data))
                            word_table.style = 'Table Grid'
                            for r_idx, row_cells in enumerate(table_data):
                                for c_idx, cell_text in enumerate(row_cells):
                                    if c_idx < len(word_table.columns):
                                        p = word_table.cell(r_idx, c_idx).paragraphs[0]
                                        add_formatted_text(p, cell_text)
                                        if r_idx == 0:
                                            for run in p.runs: run.bold = True
                        continue
                
                if stripped.startswith('# '):
                    doc.add_heading(stripped[2:], level=1)
                elif stripped.startswith('## '):
                    doc.add_heading(stripped[3:], level=2)
                elif stripped.startswith('### '):
                    doc.add_heading(stripped[4:], level=3)
                elif stripped.startswith('- ') or stripped.startswith('* '):
                    p = doc.add_paragraph(style='List Bullet')
                    add_formatted_text(p, stripped[2:])
                elif not stripped:
                    doc.add_paragraph("")
                else:
                    p = doc.add_paragraph()
                    add_formatted_text(p, stripped)
                i += 1
            
            doc.save(str(output_path))
            return str(output_path)
            
        except Exception as e:
            logger.error(f"Errore export DOCX MIT: {e}")
            return self.save_as_txt(text, base_name)
