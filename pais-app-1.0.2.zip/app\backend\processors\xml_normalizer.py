"""
Universal XML → text normalizer for RAG ingestion.

Replaces the per-schema XML parsers (HL7/C-CDA, FatturaPA, Akoma Ntoso,
generic flattening) with a single walker that converts ANY XML tree into a
hierarchical Markdown-ish text representation. The general document chunker
then ingests this text as if it were a PDF/DOCX/MD — no XML-specific
chunking logic needed downstream.

A small set of domain-specific "prologue extractors" prepend a deterministic
summary header for known namespaces (HL7 = patient demographics, FatturaPA =
invoice header). This guarantees that key facts (patient name, invoice number)
land in the FIRST chunk emitted to ChromaDB, where retrieval is most likely
to find them for generic queries like "summary" or "what is this file about".

Design notes
- We strip XML namespace prefixes for readability — the renderer cares about
  local names only.
- HL7-style date attributes (`19541218171138`, `20260307`) are auto-formatted
  to ISO `1954-12-18` / `2026-03-07` so the LLM sees normal dates.
- We skip pure-structural noise nodes (`templateId`, `xsi:*`, `xmlns:*`).
- Walker depth is capped at 12 to defend against pathological documents.
- Output uses Markdown headers for the first 3 levels and indented bullets
  for deeper levels — keeps top-level structure readable in chunks.
"""
from __future__ import annotations

import re
import logging
from typing import Optional

import defusedxml.ElementTree as ET

logger = logging.getLogger(__name__)

_MAX_DEPTH = 12
_HEADER_DEPTH = 3  # Levels 0..2 → Markdown headers; level 3+ → indented bullets.

# HL7-style timestamps: 8 to 14 digits (date, datetime, datetime+timezone).
_HL7_TIMESTAMP_RE = re.compile(r'^\d{8,14}$')

# HTML/HL7 narrative anchor references used to link narrative ↔ structured
# entries (e.g. `#conditions-desc-10`, `#medications-code-1`). These are
# pure cross-reference plumbing — they leak into LLM output as bogus IDs
# without adding clinical information.
_ANCHOR_REF_RE = re.compile(r'^#[\w-]+$')

# Attributes that often carry HL7 timestamps and should be pretty-printed.
_DATE_LIKE_ATTRS = {'value', 'birthTime', 'effectiveTime', 'time', 'low', 'high'}

# Attributes that are XML schema boilerplate and add noise without information.
_NOISE_ATTR_PREFIXES = ('xmlns', 'xsi:')
_NOISE_ATTRS = {'schemaLocation', 'xmlns'}

# Elements that are pure structural identifiers — skip them entirely.
_SKIP_TAGS = {'templateId'}


def _local_tag(node) -> str:
    """Return the tag without its XML namespace prefix."""
    if '}' in node.tag:
        return node.tag.split('}', 1)[1]
    return node.tag


def _format_hl7_date(value: str) -> str:
    """`19541218171138` → `1954-12-18`. Pass-through if not an HL7 timestamp."""
    if not value:
        return value
    v = value.strip()
    if _HL7_TIMESTAMP_RE.match(v):
        return f"{v[:4]}-{v[4:6]}-{v[6:8]}"
    return v


def _is_noise_attr(key: str) -> bool:
    """ElementTree expands namespaced attributes to Clark notation
    `{namespace-uri}localname`. We strip the URI part to compare against
    our noise list. Attributes from the XML Schema Instance namespace
    (`xsi:schemaLocation`, `xsi:type`, ...) are always noise.
    """
    if '}' in key:
        ns, local = key.split('}', 1)
        ns = ns.lstrip('{')
        if 'XMLSchema-instance' in ns or 'XMLSchema' in ns:
            return True
    else:
        local = key
    if local in _NOISE_ATTRS:
        return True
    return any(local.startswith(p) for p in _NOISE_ATTR_PREFIXES) or local.startswith('xsi')


def _format_attrs(attrs: dict) -> str:
    """Render attributes as `key=value | key=value`, hiding XML noise."""
    parts = []
    for k, v in attrs.items():
        if _is_noise_attr(k) or not v:
            continue
        local_k = k.split('}', 1)[1] if '}' in k else k
        val = v
        # Skip HTML/HL7 anchor references — `#conditions-desc-10` etc are
        # narrative↔entry cross-links, not clinical data.
        if _ANCHOR_REF_RE.match(val):
            continue
        # Skip the `ID="..."` attribute when its value looks like an anchor
        # target (Synthea-style C-CDA narrative tables tag every <td> with
        # `ID="conditions-desc-N"`).
        if local_k == 'ID' and '-' in val:
            continue
        if local_k in _DATE_LIKE_ATTRS and _HL7_TIMESTAMP_RE.match(val):
            val = _format_hl7_date(val)
        parts.append(f"{local_k}={val}")
    return ' | '.join(parts)


def _walk(node, lines: list, depth: int = 0) -> None:
    """Render `node` into `lines`. Recurses into children up to _MAX_DEPTH."""
    if depth > _MAX_DEPTH:
        return

    tag = _local_tag(node)
    if tag in _SKIP_TAGS:
        return

    attrs_str = _format_attrs(dict(node.attrib))
    text = (node.text or '').strip()
    children = list(node)

    # Leaf with text content → inline.
    if text and not children:
        if depth < _HEADER_DEPTH:
            hashes = '#' * (depth + 1)
            head = f"\n{hashes} {tag}"
            if attrs_str:
                head += f" ({attrs_str})"
            lines.append(head)
            lines.append(text)
        else:
            indent = '  ' * (depth - _HEADER_DEPTH)
            label = f"{tag}: {text}"
            if attrs_str:
                label += f" — {attrs_str}"
            lines.append(f"{indent}- {label}")
        return

    # Branch node (with or without inline text).
    if depth < _HEADER_DEPTH:
        hashes = '#' * (depth + 1)
        head = f"\n{hashes} {tag}"
        if attrs_str:
            head += f" ({attrs_str})"
        lines.append(head)
        if text:
            lines.append(text)
    else:
        indent = '  ' * (depth - _HEADER_DEPTH)
        line = f"{indent}- {tag}"
        if attrs_str:
            line += f" — {attrs_str}"
        if text:
            line += f" : {text}"
        lines.append(line)

    for child in children:
        _walk(child, lines, depth + 1)


def xml_to_markdown(root) -> str:
    """Walk the entire tree and return a Markdown-ish text rendering.

    Caller-friendly: pass an ElementTree root. Returns empty string on error
    so the document_processor can fall back gracefully.
    """
    try:
        lines: list = []
        _walk(root, lines, depth=0)
        return '\n'.join(lines).strip()
    except Exception as e:
        logger.warning(f"xml_to_markdown failed: {e}")
        return ''


# ─── Domain prologue extractors ───────────────────────────────────────────────
# These produce a small (≈500 char) deterministic summary at the top of the
# normalized text. Goal: the first chunk emitted to ChromaDB contains the
# document's core identity (patient name, invoice number, ...) so retrieval
# for generic queries always surfaces it.


def _hl7_text(root, ns: dict, xpath: str) -> str:
    el = root.find(xpath, ns)
    if el is None:
        return ''
    return (el.text or '').strip() if el.text else ''


def extract_hl7_prologue(root, ns_uri: str = 'urn:hl7-org:v3') -> str:
    """Deterministic header for HL7/C-CDA documents."""
    ns = {'hl7': ns_uri}
    lines = ["# DOCUMENT SUMMARY (auto-generated)"]
    added_any = False

    title = _hl7_text(root, ns, 'hl7:title')
    if title:
        lines.append(f"- Document title: {title}")
        added_any = True

    eff = root.find('hl7:effectiveTime', ns)
    if eff is not None and eff.get('value'):
        lines.append(f"- Document date: {_format_hl7_date(eff.get('value'))}")
        added_any = True

    patient_role = root.find('.//hl7:recordTarget/hl7:patientRole', ns)
    if patient_role is not None:
        patient = patient_role.find('hl7:patient', ns)
        if patient is not None:
            name = patient.find('hl7:name', ns)
            if name is not None:
                givens = [g.text.strip() for g in name.findall('hl7:given', ns) if g.text]
                families = [f.text.strip() for f in name.findall('hl7:family', ns) if f.text]
                full = ' '.join(givens + families).strip()
                if full:
                    lines.append(f"- Patient name: {full}")
                    added_any = True

            gender = patient.find('hl7:administrativeGenderCode', ns)
            if gender is not None:
                code = gender.get('code') or ''
                pretty = {'M': 'Male', 'F': 'Female'}.get(code, gender.get('displayName') or code)
                if pretty:
                    lines.append(f"- Sex: {pretty}")
                    added_any = True

            birth = patient.find('hl7:birthTime', ns)
            if birth is not None and birth.get('value'):
                lines.append(f"- Date of birth: {_format_hl7_date(birth.get('value'))}")
                added_any = True

        # Address.
        addr = patient_role.find('hl7:addr', ns)
        if addr is not None:
            parts = []
            for tag in ('streetAddressLine', 'city', 'state', 'postalCode', 'country'):
                for el in addr.findall(f'hl7:{tag}', ns):
                    if el.text and el.text.strip():
                        parts.append(el.text.strip())
            if parts:
                lines.append(f"- Address: {', '.join(parts)}")
                added_any = True

    # Custodian organization.
    cust_name = root.find(
        './/hl7:custodian/hl7:assignedCustodian/hl7:representedCustodianOrganization/hl7:name',
        ns,
    )
    if cust_name is not None and cust_name.text:
        lines.append(f"- Custodian: {cust_name.text.strip()}")
        added_any = True

    if not added_any:
        return ''
    return '\n'.join(lines) + '\n\n---\n\n'


def extract_fatturapa_prologue(root) -> str:
    """Deterministic header for FatturaPA invoices.

    FatturaPA uses no real XML namespace on inner elements (the root has
    `p:FatturaElettronica` but children are unprefixed), so we can use raw
    XPath without a namespace map.
    """
    lines = ["# DOCUMENT SUMMARY (auto-generated)"]
    added_any = False

    def t(xpath: str) -> str:
        el = root.find(xpath)
        return (el.text or '').strip() if el is not None and el.text else ''

    numero = t('.//Numero')
    if numero:
        lines.append(f"- Numero fattura: {numero}")
        added_any = True
    data = t('.//Data')
    if data:
        lines.append(f"- Data: {data}")
        added_any = True
    tipo = t('.//TipoDocumento')
    if tipo:
        lines.append(f"- Tipo documento: {tipo}")
        added_any = True
    divisa = t('.//Divisa')
    if divisa:
        lines.append(f"- Divisa: {divisa}")
        added_any = True

    cliente = t('.//CessionarioCommittente//Anagrafica//Denominazione')
    if not cliente:
        cliente = (
            t('.//CessionarioCommittente//Anagrafica//Nome')
            + ' '
            + t('.//CessionarioCommittente//Anagrafica//Cognome')
        ).strip()
    if cliente:
        lines.append(f"- Cliente: {cliente}")
        added_any = True

    fornitore = t('.//CedentePrestatore//Anagrafica//Denominazione')
    if fornitore:
        lines.append(f"- Fornitore: {fornitore}")
        added_any = True

    importo = t('.//ImportoTotaleDocumento')
    if importo:
        lines.append(f"- Importo totale: {importo}")
        added_any = True

    if not added_any:
        return ''
    return '\n'.join(lines) + '\n\n---\n\n'


def _detect_namespace(root) -> str:
    """Return the namespace URI of the root element, or empty string."""
    if '}' in root.tag:
        return root.tag.split('}', 1)[0].lstrip('{')
    return ''


def build_xml_text_for_rag(file_path: str) -> str:
    """Main entry point — produce text suitable for the general chunker.

    Pipeline:
    1. Parse the file (defusedxml = safe against XXE).
    2. Detect the root namespace.
    3. Generate a domain prologue if the namespace is known (HL7, FatturaPA).
    4. Render the full tree via the universal walker.
    5. Concatenate: prologue + walker output.

    Returns the empty string on parse failure — the caller is expected to
    fall back to raw text read.
    """
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
    except Exception as e:
        logger.warning(f"build_xml_text_for_rag parse failed for {file_path}: {e}")
        return ''

    ns_uri = _detect_namespace(root)

    prologue = ''
    try:
        if ns_uri == 'urn:hl7-org:v3':
            prologue = extract_hl7_prologue(root, ns_uri)
        elif 'ivaservizi.agenziaentrate.gov.it' in ns_uri or 'FatturaElettronica' in _local_tag(root):
            prologue = extract_fatturapa_prologue(root)
    except Exception as e:
        logger.warning(f"prologue extraction failed (ns={ns_uri}): {e}")

    body = xml_to_markdown(root)
    return prologue + body
