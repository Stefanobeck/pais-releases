"""
Batch Executor for PAIS.

Reads the per-project queue (BatchQueueService) and executes each pending
item sequentially, dispatching to the appropriate module service. Each item
is fully self-contained — model, profile, direct-mode, files are all taken
from the item's snapshot. The user's *current* settings are NEVER read here.

Sequential execution by design:
- Ollama on consumer hardware is single-tenant; parallel inference would
  thrash GPU/CPU.
- File system is the only shared resource — sequential = no contention.
- The user runs batches at night and wants to read results in the morning;
  total throughput is not the bottleneck.

Per-item flow (Interrogate):
1. Mark item `running`.
2. Create a unique temp session id.
3. Ingest each snapshot file into the temp session (re-embedding in ChromaDB).
4. Call `chat_service.send_message` with all the `force_*` overrides from
   the item snapshot. Collect the full stream into a single string.
5. Strip <think> blocks (we want only the clean answer in the DOCX).
6. Export the answer as DOCX into the batch output folder.
7. Clear the temp session (removes chunks + physical files).
8. Mark item `completed` (and cleanup the snapshot folder), or `failed`
   (and keep the snapshot for debugging).

Per-item flow (Vision / Manipulate):
- Vision and Manipulate Charts/Style are stubbed for now — they mark the
  item as failed with a clear "not yet wired" message. They will be wired
  in a follow-up patch once the basic Interrogate path is validated in UI.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional

from services.batch_queue_service import (
    BatchQueueService,
    STATUS_COMPLETED,
    STATUS_FAILED,
    STATUS_PENDING,
    STATUS_RUNNING,
    get_batch_queue_service,
)

logger = logging.getLogger(__name__)


def _strip_thinking(text: str) -> str:
    """Remove <think>...</think> blocks from the model output. Some models
    emit chain-of-thought; we don't want it in the final DOCX deliverable.
    """
    if not text:
        return ""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()


def _slugify_for_filename(text: str, max_len: int = 60) -> str:
    """Make a string safe for use as a filename fragment."""
    if not text:
        return "untitled"
    s = re.sub(r"\s+", "_", text.strip())
    s = re.sub(r"[^A-Za-z0-9_\-.]+", "", s)
    return s[:max_len] or "untitled"


class BatchExecutor:
    """Singleton-per-process executor.

    Lifecycle states:
    - `idle`: no execution in progress, ready to start.
    - `running`: actively processing items.
    - `stopping`: stop requested, finishing the current item then stopping.

    The `progress` dict is read by the `/api/batch/status` endpoint for
    UI polling.
    """

    def __init__(self):
        self.state: str = "idle"
        self.progress: Dict[str, Any] = {
            "current_item_id": None,
            "current_index": 0,
            "total": 0,
            "completed": 0,
            "failed": 0,
            "execution_folder": None,
            "started_at": None,
        }
        self._task: Optional[asyncio.Task] = None
        self._stop_requested: bool = False

    def is_running(self) -> bool:
        return self.state == "running" or self.state == "stopping"

    def request_stop(self) -> None:
        if self.is_running():
            self._stop_requested = True
            self.state = "stopping"
            logger.info("BatchExecutor: stop requested")

    def get_status(self) -> Dict[str, Any]:
        return {"state": self.state, **self.progress}

    async def start(self) -> Dict[str, Any]:
        """Kick off a new execution run if none is in progress.

        Returns a dict {started: bool, reason: str|None}. The actual work
        runs in the background — callers poll `get_status()` for progress.
        """
        if self.is_running():
            return {"started": False, "reason": "Already running"}
        queue = get_batch_queue_service()
        pending = queue.list_pending()
        if not pending:
            return {"started": False, "reason": "No pending items"}

        # Fresh state for this run.
        self._stop_requested = False
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        from backend_config.project_manager import project_manager
        output_root = project_manager.get_path("output")
        execution_folder = output_root / f"BATCH_{ts}"
        execution_folder.mkdir(parents=True, exist_ok=True)

        self.state = "running"
        self.progress = {
            "current_item_id": None,
            "current_index": 0,
            "total": len(pending),
            "completed": 0,
            "failed": 0,
            "execution_folder": str(execution_folder),
            "started_at": datetime.now().isoformat(),
        }

        # Background task — caller returns immediately.
        self._task = asyncio.create_task(self._run(pending, execution_folder))
        return {"started": True, "total": len(pending), "folder": str(execution_folder)}

    async def _run(self, items: List[Dict[str, Any]], execution_folder: Path) -> None:
        """Main loop. Process items sequentially, never blocks the API."""
        queue = get_batch_queue_service()
        execution_id = uuid.uuid4().hex[:8]
        execution_start = datetime.now()
        try:
            for idx, item in enumerate(items, start=1):
                if self._stop_requested:
                    logger.info(f"BatchExecutor: stopping at item {idx}/{len(items)}")
                    break

                self.progress["current_item_id"] = item["id"]
                self.progress["current_index"] = idx

                queue.update_item(
                    item["id"],
                    status=STATUS_RUNNING,
                    started_at=datetime.now().isoformat(),
                )

                ok, error, output_path = await self._execute_one(item, idx, execution_folder)

                if ok:
                    queue.update_item(
                        item["id"],
                        status=STATUS_COMPLETED,
                        completed_at=datetime.now().isoformat(),
                        result={
                            "output_file": str(output_path) if output_path else None,
                            "execution_folder": str(execution_folder),
                        },
                        error=None,
                    )
                    queue.cleanup_snapshot(item["id"])
                    self.progress["completed"] += 1
                else:
                    queue.update_item(
                        item["id"],
                        status=STATUS_FAILED,
                        completed_at=datetime.now().isoformat(),
                        result={"execution_folder": str(execution_folder)},
                        error=error or "Unknown error",
                    )
                    self.progress["failed"] += 1

            # Execution record.
            queue.add_execution({
                "execution_id": execution_id,
                "started_at": execution_start.isoformat(),
                "completed_at": datetime.now().isoformat(),
                "execution_folder": str(execution_folder),
                "total_items": len(items),
                "completed": self.progress["completed"],
                "failed": self.progress["failed"],
                "stopped_early": self._stop_requested,
            })
        except Exception as e:
            logger.error(f"BatchExecutor: fatal error in run loop: {e}", exc_info=True)
        finally:
            self.state = "idle"
            self._stop_requested = False
            self.progress["current_item_id"] = None
            logger.info(
                f"BatchExecutor: run finished — "
                f"completed={self.progress['completed']} failed={self.progress['failed']}"
            )

    async def _execute_one(
        self,
        item: Dict[str, Any],
        item_index: int,
        execution_folder: Path,
    ) -> tuple:
        """Dispatch a single item to the right module. Returns (ok, error, output_path)."""
        module = item.get("module", "")
        try:
            if module == "interrogate":
                return await self._execute_interrogate(item, item_index, execution_folder)
            elif module == "vision":
                return await self._execute_vision(item, item_index, execution_folder)
            elif module == "manipulate_sheet":
                return await self._execute_manipulate_sheet(item, item_index, execution_folder)
            return False, f"Unknown module '{module}'", None
        except Exception as e:
            logger.error(f"BatchExecutor: item {item['id']} crashed: {e}", exc_info=True)
            return False, str(e), None

    async def _execute_interrogate(
        self,
        item: Dict[str, Any],
        item_index: int,
        execution_folder: Path,
    ) -> tuple:
        """Run an Interrogate batch item end-to-end.

        Returns (ok, error_or_None, output_path_or_None).
        """
        from backend_config.project_manager import project_manager
        from routers.interrogate import get_chat_service
        from services.export_manager import ExportManager
        from backend_config import settings

        snap = item.get("snapshot", {}) or {}
        prompt = item.get("prompt", "") or ""
        if not prompt.strip():
            return False, "Empty prompt", None

        files_rel: List[str] = snap.get("files", []) or []
        force_model = snap.get("model") or None
        force_profile = snap.get("profile") or None
        force_direct_mode = snap.get("direct_mode")  # may be None / True / False
        export_style = (snap.get("export_style") or "plain").lower()
        snapshot_folder_rel = item.get("snapshot_folder")
        snapshot_folder = project_manager.active_project_path / snapshot_folder_rel if snapshot_folder_rel else None

        chat = get_chat_service()
        # Unique temp session so this batch item is fully isolated from
        # any UI sessions and from sibling batch items.
        temp_session = f"batch-{item['id']}"

        # 1) Ingest snapshot files into the temp session.
        ingested = 0
        if snapshot_folder and snapshot_folder.exists():
            for fname in files_rel:
                fpath = snapshot_folder / fname
                if not fpath.exists():
                    logger.warning(f"Batch {item['id']}: snapshot file missing {fname}")
                    continue
                try:
                    result = await chat.upload_file(str(fpath), fname, temp_session)
                    if result.get("status") == "success":
                        ingested += 1
                    else:
                        logger.warning(f"Batch {item['id']}: upload_file failed for {fname}: {result}")
                except Exception as e:
                    logger.warning(f"Batch {item['id']}: upload_file exception for {fname}: {e}")

        # 2) Run inference, collecting the full stream.
        full_response_parts: List[str] = []
        try:
            async for chunk in chat.send_message(
                message=prompt,
                session_id=temp_session,
                use_rag=True,
                force_model=force_model,
                force_profile=force_profile,
                force_direct_mode=force_direct_mode,
            ):
                full_response_parts.append(chunk)
        except Exception as e:
            # Best-effort cleanup before bailing out.
            try:
                chat.clear_session(temp_session)
            except Exception:
                pass
            return False, f"Inference failed: {e}", None

        full_response = "".join(full_response_parts)
        clean_response = _strip_thinking(full_response)
        if not clean_response.strip():
            try:
                chat.clear_session(temp_session)
            except Exception:
                pass
            return False, "Model returned an empty response", None

        # 3) The DOCX must be print-ready: only the model's clean answer,
        # no header, no metadata. Batch context (module, model, profile,
        # files, timestamp) goes into a sibling `.metadata.txt` file so
        # the user can audit the deliverable without polluting it.
        document_body = clean_response

        # 4) Export as DOCX. Filename embeds the per-item completion timestamp
        # so each DOCX is identifiable even when moved out of its execution folder.
        filename_slug = _slugify_for_filename(prompt, max_len=40)
        item_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.docx"
        output_path = execution_folder / output_filename
        export_mgr = ExportManager(str(execution_folder))
        # ExportManager writes into export_mgr.output_dir; make sure each
        # exporter targets our execution folder, not the global one.
        for exp in export_mgr.exporters.values():
            exp.output_dir = execution_folder

        # Studio branding: when the snapshot requests style="studio", look up
        # the studio identity + header/footer toggles at *execution time* and
        # pass them to the DocxExporter. Same pattern as /api/interrogate/export.
        # Read at execution time, not at queue time, so the user can refine
        # studio data (logo path, address) up to the moment the batch runs.
        studio_payload = None
        if export_style == "studio":
            try:
                from services import user_settings_service as uss
                studio_payload = uss.get_studio_payload()
            except Exception as e:
                logger.warning(f"Batch {item['id']}: studio identity lookup failed: {e}")

        success, result_or_err, _warning = await export_mgr.export_content(
            content=document_body,
            format_type="docx",
            filename=output_filename,
            studio=studio_payload,
        )

        # 4b) Sibling metadata sidecar — same basename + `.metadata.txt`. The
        # user can ignore it if they only want the deliverable; auditors get
        # the full reproducibility info (model, profile, snapshot files).
        try:
            metadata_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.metadata.txt"
            metadata_path = execution_folder / metadata_filename
            metadata_lines = [
                "BATCH ITEM METADATA",
                "===================",
                f"Item index           : {item_index:02d}",
                f"Batch ID             : {item.get('id', '?')}",
                f"Module               : {item.get('module', '?').upper()}",
                f"Model                : {force_model or '(default)'}",
                f"Profile              : {force_profile or '(default)'}",
                f"Direct Mode          : {'ON' if force_direct_mode else 'OFF' if force_direct_mode is False else '(default)'}",
                f"Export style         : {export_style}{' (studio identity applied)' if export_style == 'studio' and studio_payload else ''}",
                f"Prompt               : {prompt}",
                f"Attached files       : {', '.join(files_rel) if files_rel else '(none)'}",
                f"Files ingested in RAG: {ingested}",
                f"Queued at            : {item.get('created_at', '?')}",
                f"Started at           : {item.get('started_at', '?')}",
                f"Completed at         : {datetime.now().isoformat()}",
                f"Output document      : {output_filename}",
                "",
                "Notes",
                "-----",
                "This file accompanies the DOCX deliverable. The DOCX contains",
                "ONLY the model's print-ready answer (Direct Mode rules apply when",
                "ON). All execution context lives here, in this sidecar.",
            ]
            metadata_path.write_text("\n".join(metadata_lines), encoding="utf-8")
        except Exception as e:
            # Sidecar is best-effort: a failure here must not fail the item.
            logger.warning(f"Batch {item['id']}: metadata sidecar write failed: {e}")

        # 5) Always cleanup temp session — frees ChromaDB chunks and physical files.
        try:
            chat.clear_session(temp_session)
        except Exception as e:
            logger.warning(f"Batch {item['id']}: clear_session failed: {e}")

        if not success:
            return False, f"DOCX export failed: {result_or_err}", None
        return True, None, output_path

    async def _execute_vision(
        self,
        item: Dict[str, Any],
        item_index: int,
        execution_folder: Path,
    ) -> tuple:
        """Run a Vision batch item end-to-end.

        Same pattern as Interrogate: copy snapshot images into a temp Vision
        session, call vision.send_message, export the answer as DOCX.
        Differences: vision.upload_image (not upload_file), force_model
        override goes to send_message, no Compare/Direct mode here.

        Returns (ok, error_or_None, output_path_or_None).
        """
        from backend_config.project_manager import project_manager
        from routers.vision import get_vision_service
        from services.export_manager import ExportManager

        vision = get_vision_service()

        snap = item.get("snapshot", {}) or {}
        prompt = item.get("prompt", "") or ""
        if not prompt.strip():
            return False, "Empty prompt", None

        files_rel: List[str] = snap.get("files", []) or []
        force_model = snap.get("model") or snap.get("vision_model") or None
        export_style = (snap.get("export_style") or "plain").lower()
        snapshot_folder_rel = item.get("snapshot_folder")
        snapshot_folder = project_manager.active_project_path / snapshot_folder_rel if snapshot_folder_rel else None

        temp_session = f"batch-{item['id']}"

        # 1) Ingest snapshot images into the temp Vision session.
        ingested = 0
        if snapshot_folder and snapshot_folder.exists():
            for fname in files_rel:
                fpath = snapshot_folder / fname
                if not fpath.exists():
                    logger.warning(f"Batch {item['id']}: snapshot image missing {fname}")
                    continue
                try:
                    result = await vision.upload_image(str(fpath), fname, temp_session)
                    if result.get("status") == "success":
                        ingested += 1
                    else:
                        logger.warning(f"Batch {item['id']}: vision upload_image failed for {fname}: {result}")
                except Exception as e:
                    logger.warning(f"Batch {item['id']}: vision upload_image exception for {fname}: {e}")

        # 2) Run inference, collect full stream.
        full_response_parts: List[str] = []
        try:
            async for chunk in vision.send_message(
                message=prompt,
                session_id=temp_session,
                use_rag=True,
                force_model=force_model,
            ):
                full_response_parts.append(chunk)
        except Exception as e:
            try:
                vision.clear_session(temp_session)
            except Exception:
                pass
            return False, f"Vision inference failed: {e}", None

        full_response = "".join(full_response_parts)
        clean_response = _strip_thinking(full_response)
        if not clean_response.strip():
            try:
                vision.clear_session(temp_session)
            except Exception:
                pass
            return False, "Vision model returned an empty response", None

        # 3) Export DOCX (clean) + sidecar metadata.
        filename_slug = _slugify_for_filename(prompt, max_len=40)
        item_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.docx"
        output_path = execution_folder / output_filename
        export_mgr = ExportManager(str(execution_folder))
        for exp in export_mgr.exporters.values():
            exp.output_dir = execution_folder

        studio_payload = None
        if export_style == "studio":
            try:
                from services import user_settings_service as uss
                studio_payload = uss.get_studio_payload()
            except Exception as e:
                logger.warning(f"Batch {item['id']}: studio identity lookup failed: {e}")

        success, result_or_err, _warning = await export_mgr.export_content(
            content=clean_response,
            format_type="docx",
            filename=output_filename,
            studio=studio_payload,
        )

        # 4) Sidecar metadata.
        try:
            metadata_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.metadata.txt"
            metadata_path = execution_folder / metadata_filename
            metadata_lines = [
                "BATCH ITEM METADATA",
                "===================",
                f"Item index           : {item_index:02d}",
                f"Batch ID             : {item.get('id', '?')}",
                f"Module               : VISION",
                f"Model                : {force_model or '(default)'}",
                f"Export style         : {export_style}{' (studio identity applied)' if export_style == 'studio' and studio_payload else ''}",
                f"Prompt               : {prompt}",
                f"Attached files       : {', '.join(files_rel) if files_rel else '(none)'}",
                f"Images ingested      : {ingested}",
                f"Queued at            : {item.get('created_at', '?')}",
                f"Started at           : {item.get('started_at', '?')}",
                f"Completed at         : {datetime.now().isoformat()}",
                f"Output document      : {output_filename}",
            ]
            metadata_path.write_text("\n".join(metadata_lines), encoding="utf-8")
        except Exception as e:
            logger.warning(f"Batch {item['id']}: vision metadata sidecar write failed: {e}")

        # 5) Cleanup vision session — frees ChromaDB chunks + history.
        try:
            vision.clear_session(temp_session)
        except Exception as e:
            logger.warning(f"Batch {item['id']}: vision clear_session failed: {e}")

        if not success:
            return False, f"DOCX export failed: {result_or_err}", None
        return True, None, output_path

    async def _execute_manipulate_sheet(
        self,
        item: Dict[str, Any],
        item_index: int,
        execution_folder: Path,
    ) -> tuple:
        """Run a Manipulate Export-to-Sheet batch item end-to-end.

        The user's prompt drives a SQL transformation over the attached
        Excel/CSV files (max 2). Output is an Excel produced by manipulate's
        styler.tool_create_report at `<BASE_DIR>/exports/transformed_data_*.xlsx`.
        We move it into the batch execution folder so the outputs of one
        nightly run are co-located.

        We touch only the public manipulate_service API (upload_file,
        memorize_files, analyze) — no internal changes.
        """
        import re
        import shutil
        from backend_config.project_manager import project_manager
        from routers.manipulate import get_manipulate_service

        manipulate = get_manipulate_service()

        snap = item.get("snapshot", {}) or {}
        prompt = item.get("prompt", "") or ""
        if not prompt.strip():
            return False, "Empty prompt", None

        files_rel: List[str] = snap.get("files", []) or []
        if not files_rel:
            return False, "No file attached for Manipulate Sheet", None

        snapshot_folder_rel = item.get("snapshot_folder")
        snapshot_folder = project_manager.active_project_path / snapshot_folder_rel if snapshot_folder_rel else None
        if not snapshot_folder or not snapshot_folder.exists():
            return False, "Snapshot folder missing", None

        temp_session = f"batch-{item['id']}"

        # 1) Upload + stage each snapshot file in the manipulate temp session.
        #    upload_file copies the file into the project's manipulate uploads dir
        #    AND registers it as "staged" — memorize_files then loads them into DuckDB.
        staged_count = 0
        for fname in files_rel:
            fpath = snapshot_folder / fname
            if not fpath.exists():
                logger.warning(f"Batch {item['id']}: snapshot file missing {fname}")
                continue
            try:
                up = await manipulate.upload_file(
                    str(fpath), fname, temp_session, mode="Export to Sheet"
                )
                if up.get("status") != "error":
                    staged_count += 1
                else:
                    logger.warning(f"Batch {item['id']}: manipulate upload_file failed for {fname}: {up}")
            except Exception as e:
                logger.warning(f"Batch {item['id']}: manipulate upload_file exception for {fname}: {e}")

        if staged_count == 0:
            return False, "No file could be staged into Manipulate", None

        # 2) Memorize: loads staged files into DuckDB so analyze() can query them.
        try:
            mem_result = await manipulate.memorize_files(temp_session, mode="Export to Sheet")
            if not mem_result or mem_result.get("status") == "error":
                return False, f"Memorize failed: {mem_result}", None
        except Exception as e:
            return False, f"Memorize exception: {e}", None

        # 3) Run analyze() — AsyncGenerator yielding (success, message, files_list)
        #    tuples. We capture every chunk and look at the last successful one
        #    to extract the generated Excel path.
        last_msg = ""
        last_files: List[str] = []
        last_success = False
        try:
            async for chunk in manipulate.analyze(
                query=prompt,
                session_id=temp_session,
                mode="Export to Sheet",
            ):
                if isinstance(chunk, tuple) and len(chunk) >= 3:
                    success, message, files = chunk
                    last_success = bool(success) or last_success
                    if message:
                        last_msg = message
                    if files:
                        last_files = list(files)
        except Exception as e:
            try:
                manipulate.clear_session(temp_session)
            except Exception:
                pass
            return False, f"Manipulate analyze failed: {e}", None

        # 4) Locate the generated Excel.
        # The styler.tool_create_report writes to `<project>/output/<filename>`
        # (see processors/styler.py:41), but analyze() returns the path as
        # `<BASE_DIR>/exports/<filename>` (legacy — that location is not actually
        # used). We probe in order: project/output (real), the path analyze
        # returned (fallback), BASE_DIR/exports (legacy). Filename is extracted
        # either from last_files[0] or from the `<!-- FILE:xxx -->` marker.
        from backend_config import settings as app_settings
        candidates: List[Path] = []
        fname_only: Optional[str] = None
        if last_files:
            try:
                fname_only = Path(last_files[0]).name
            except Exception:
                pass
        if not fname_only:
            m = re.search(r"<!--\s*FILE:([^\s]+?)\s*-->", last_msg)
            if m:
                fname_only = m.group(1).strip()
        if fname_only:
            try:
                candidates.append(project_manager.get_path("output") / fname_only)
            except Exception:
                pass
            candidates.append(Path(app_settings.BASE_DIR) / "exports" / fname_only)
        if last_files:
            candidates.append(Path(last_files[0]))

        generated_path: Optional[Path] = next((c for c in candidates if c.exists()), None)

        if generated_path is None or not generated_path.exists():
            try:
                manipulate.clear_session(temp_session)
            except Exception:
                pass
            err = "Manipulate did not produce an Excel file"
            if last_msg:
                err += f" — last message: {last_msg[:300]}"
            return False, err, None

        # 5) Move the Excel into the batch execution folder.
        filename_slug = _slugify_for_filename(prompt, max_len=40)
        item_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.xlsx"
        output_path = execution_folder / output_filename
        try:
            shutil.move(str(generated_path), str(output_path))
        except Exception as e:
            try:
                manipulate.clear_session(temp_session)
            except Exception:
                pass
            return False, f"Could not move Excel to batch folder: {e}", None

        # 6) Sidecar metadata.
        try:
            metadata_filename = f"{item_index:02d}_{item_ts}_{filename_slug}.metadata.txt"
            metadata_path = execution_folder / metadata_filename
            metadata_lines = [
                "BATCH ITEM METADATA",
                "===================",
                f"Item index           : {item_index:02d}",
                f"Batch ID             : {item.get('id', '?')}",
                f"Module               : MANIPULATE — Export to Sheet",
                f"Model                : (manipulate default — qwen3-coder)",
                f"Prompt               : {prompt}",
                f"Attached files       : {', '.join(files_rel) if files_rel else '(none)'}",
                f"Files staged in DB   : {staged_count}",
                f"Queued at            : {item.get('created_at', '?')}",
                f"Started at           : {item.get('started_at', '?')}",
                f"Completed at         : {datetime.now().isoformat()}",
                f"Output document      : {output_filename}",
            ]
            metadata_path.write_text("\n".join(metadata_lines), encoding="utf-8")
        except Exception as e:
            logger.warning(f"Batch {item['id']}: manipulate metadata sidecar write failed: {e}")

        # 7) Cleanup manipulate session — releases DuckDB tables + memory.
        try:
            manipulate.clear_session(temp_session)
        except Exception as e:
            logger.warning(f"Batch {item['id']}: manipulate clear_session failed: {e}")

        return True, None, output_path


# ─── Singleton ─────────────────────────────────────────────────────────────────

_executor: Optional[BatchExecutor] = None


def get_batch_executor() -> BatchExecutor:
    global _executor
    if _executor is None:
        _executor = BatchExecutor()
    return _executor
