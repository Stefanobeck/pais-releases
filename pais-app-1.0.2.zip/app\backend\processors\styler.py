"""
Manipulate Styler - Formattazione Excel Avanzata per PAI Premium
Supporta:
- Template stile Originali (Corporate Blue, Modern Tech, Financial Times)
- Doppio motore: XlsxWriter (Grafica Pro) + OpenPyXL (Preservazione Grafici)
- Sparklines, Data Validation, Formule di Totale, Formattazione Condizionale
- Nuclear Cell Rewrite per integrità numerica
"""
import os
import re
import time
import logging
import pandas as pd
import numpy as np
import openpyxl
from typing import List, Dict, Any, Optional
from openpyxl.styles import PatternFill, Font, Side, Border, Alignment
from openpyxl.utils import get_column_letter as get_col_letter_pyxl

from backend_config.project_manager import project_manager

logger = logging.getLogger(__name__)


# --- PALETTE TEMPLATE (fonte unica per i due motori) ---------------------------
# Ogni template = 4 colori (hex CON '#', convenzione xlsxwriter). Il path openpyxl
# usa _strip_hash() per ottenere il formato 'FFFFFF'. head_fg normalizzato a hex
# (#ffffff) cosi' lo stesso dict serve entrambi i motori senza casi speciali.
STYLE_TEMPLATES: Dict[str, Dict[str, str]] = {
    "Corporate Blue":   {"head_bg": "#1f4e78", "head_fg": "#ffffff", "bar_color": "#3b82f6", "accent_color": "#ff9999"},
    "Modern Tech":      {"head_bg": "#2d2d2d", "head_fg": "#00ff88", "bar_color": "#00ff88", "accent_color": "#eafff5"},
    "Financial Times":  {"head_bg": "#fff1e5", "head_fg": "#333333", "bar_color": "#b30000", "accent_color": "#e20000"},
    "Slate Minimal":    {"head_bg": "#334155", "head_fg": "#ffffff", "bar_color": "#64748b", "accent_color": "#cbd5e1"},
    "Emerald Fresh":    {"head_bg": "#065f46", "head_fg": "#ffffff", "bar_color": "#10b981", "accent_color": "#d1fae5"},
    "Royal Purple":     {"head_bg": "#4c1d95", "head_fg": "#ffffff", "bar_color": "#8b5cf6", "accent_color": "#ede9fe"},
    "Sunset Warm":      {"head_bg": "#7c2d12", "head_fg": "#fff7ed", "bar_color": "#f97316", "accent_color": "#ffedd5"},
    "Monochrome Print": {"head_bg": "#111827", "head_fg": "#ffffff", "bar_color": "#6b7280", "accent_color": "#e5e7eb"},
}
DEFAULT_STYLE = "Corporate Blue"

# Default dei toggle "cosa includere nello stile" (allineati a StyleOptions nel router).
DEFAULT_STYLE_OPTIONS: Dict[str, bool] = {
    "conditional_formatting": True,
    "sparkline_trend": True,
    "data_validation": False,
    "freeze_panes": True,
    "autofilter": True,
}


def get_palette(excel_style: str) -> Dict[str, str]:
    """Palette del template; fallback a Corporate Blue per nomi sconosciuti."""
    return STYLE_TEMPLATES.get(excel_style, STYLE_TEMPLATES[DEFAULT_STYLE])


def _strip_hash(color: str) -> str:
    """'#1F4E78' -> '1F4E78' (formato richiesto da openpyxl PatternFill/Font)."""
    return color.lstrip('#').upper()


class ManipulateStyler:
    """
    Gestisce la stilizzazione professionale dei file Excel (Perfect Logic Port).
    """

    def __init__(self):
        self.detected_currency = "€"

    async def tool_create_report(
        self, 
        sheets_data: Dict[str, Any], 
        filename: str = "Analysis_Report.xlsx", 
        styling: str = "pro",
        excel_style: str = "Corporate Blue",
        style_options: Optional[dict] = None
    ) -> str:
        """Genera un file Excel multi-foglio con formattazione professionale."""
        output_dir = project_manager.get_path("output")
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / filename
        
        logger.info(f"[TOOL CALL] create_report | file: {filename} | style: {excel_style}")
        
        # Crea Writer con XlsxWriter per feature grafiche avanzate
        writer = pd.ExcelWriter(str(output_path), engine='xlsxwriter')
        
        for sheet_name, content in sheets_data.items():
            if not isinstance(content, pd.DataFrame):
                continue
                
            df = content
            safe_sheet = sheet_name[:31]
            
            # Scrittura base
            df.to_excel(writer, sheet_name=safe_sheet, index=False)
            
            # Applicazione Stile Pro (Porting esatto NiceGUI)
            if styling == 'pro':
                try:
                    self._apply_pro_formatting(
                        writer.book,
                        writer.sheets[safe_sheet],
                        df,
                        safe_sheet,
                        excel_style=excel_style,
                        style_options=style_options
                    )
                except Exception as e:
                    logger.error(f"Error styling sheet {safe_sheet}: {e}")
            
        writer.close()
        return str(output_path)

    def _apply_pro_formatting(self, workbook, worksheet, df, sheet_name, excel_style="Corporate Blue", style_options: Optional[dict] = None):
        """Applica formattazione Premium (Porting millimetrico NiceGUI).
        style_options: toggle 'cosa includere' (vedi DEFAULT_STYLE_OPTIONS).
        Header e formati numerici sono SEMPRE applicati (non toggleabili)."""
        currency_symbol = self.detected_currency
        rows, cols = df.shape
        if rows == 0: return
        opts = {**DEFAULT_STYLE_OPTIONS, **(style_options or {})}

        # --- COLORI TEMPLATE (fonte unica: STYLE_TEMPLATES, fallback Corporate Blue) ---
        pal = get_palette(excel_style)
        head_bg, head_fg = pal["head_bg"], pal["head_fg"]
        bar_color, accent_color = pal["bar_color"], pal["accent_color"]

        # --- FORMATI ---
        header_fmt = workbook.add_format({
            'bold': True, 'font_name': 'Segoe UI', 'font_size': 11,
            'bg_color': head_bg, 'font_color': head_fg,
            'border': 1, 'align': 'center', 'valign': 'vcenter'
        })
        
        fmt_currency = workbook.add_format({'num_format': f'#,##0.00 "{currency_symbol}"', 'border': 1, 'valign': 'vcenter', 'font_name': 'Segoe UI', 'font_size': 10})
        fmt_percent = workbook.add_format({'num_format': '0.00%', 'border': 1, 'valign': 'vcenter', 'font_name': 'Segoe UI', 'font_size': 10})
        fmt_date = workbook.add_format({'num_format': 'dd/mm/yyyy', 'border': 1, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Segoe UI', 'font_size': 10})
        fmt_num = workbook.add_format({'num_format': '#,##0.00', 'border': 1, 'valign': 'vcenter', 'font_name': 'Segoe UI', 'font_size': 10})
        fmt_text = workbook.add_format({'border': 1, 'valign': 'vcenter', 'font_name': 'Segoe UI', 'font_size': 10})

        # 1. SCRIVI HEADER
        for col_num, col_name in enumerate(df.columns):
            worksheet.write(0, col_num, col_name, header_fmt)

        # 2. RILEVAMENTO SEMANTICO E APPLICAZIONE FORMATI
        numeric_cols = []
        for col_num, col_name in enumerate(df.columns):
            col_name_l = str(col_name).lower()
            target_fmt = fmt_text
            
            is_curr = any(x in col_name_l for x in ['prezzo', 'costo', 'margine', 'vendite', 'totale', 'fatturato', 'importo', 'price', 'cost', 'revenue', 'total', 'amount'])
            is_perc = any(x in col_name_l for x in ['%', 'percent', 'quota', 'share', 'tasso', 'rate', 'ratio'])
            is_date = any(x in col_name_l for x in ['data', 'date', 'updated', 'timestamp'])

            if is_curr: 
                target_fmt = fmt_currency
                numeric_cols.append(col_num)
            elif is_perc: 
                target_fmt = fmt_percent
                numeric_cols.append(col_num)
            elif pd.api.types.is_numeric_dtype(df[col_name]): 
                target_fmt = fmt_num
                numeric_cols.append(col_num)
            
            if pd.api.types.is_datetime64_any_dtype(df[col_name]) or is_date: 
                target_fmt = fmt_date

            # Applica formato colonna
            worksheet.set_column(col_num, col_num, 15, target_fmt)

            # NUCLEAR OPTION: Riscrive forzatamente i numeri per Excel
            if col_num in numeric_cols:
                for r in range(rows):
                    val = df.iloc[r, col_num]
                    if pd.notna(val):
                        try: worksheet.write_number(r + 1, col_num, float(val), target_fmt)
                        except: pass

        # 3. CONDIZIONALE (Barre, Scale, Icone) — toggle conditional_formatting
        if opts["conditional_formatting"]:
            for col_num, col_name in enumerate(df.columns):
                col_name_l = str(col_name).lower()
                if rows > 1:
                    if any(x in col_name_l for x in ['prezzo', 'costo', 'vendite', 'total', 'revenue']):
                        worksheet.conditional_format(1, col_num, rows, col_num, {'type': 'data_bar', 'bar_color': bar_color, 'bar_solid': False})
                    elif any(x in col_name_l for x in ['%', 'percent', 'quota', 'share']):
                        worksheet.conditional_format(1, col_num, rows, col_num, {'type': '2_color_scale', 'min_color': accent_color, 'max_color': "#99ff99"})
                    elif any(x in col_name_l for x in ['status', 'kpi', 'trend']):
                        worksheet.conditional_format(1, col_num, rows, col_num, {'type': 'icon_set', 'icon_style': '3_traffic_lights'})

        # 4. AUTO-SPARK LINES — toggle sparkline_trend
        spark_added = False
        if opts["sparkline_trend"] and len(numeric_cols) >= 3:
            spark_added = True
            def col_to_letter(n):
                string = ""
                while n >= 0:
                    n, remainder = divmod(n, 26)
                    string = chr(65 + remainder) + string
                    n -= 1
                return string

            spark_col = cols
            worksheet.write(0, spark_col, "Trend", header_fmt)
            worksheet.set_column(spark_col, spark_col, 12)
            for row_num in range(1, rows + 1):
                start_cell = f"{col_to_letter(numeric_cols[0])}{row_num+1}"
                end_cell = f"{col_to_letter(numeric_cols[-1])}{row_num+1}"
                worksheet.add_sparkline(row_num, spark_col, {
                    'range': f"'{sheet_name}'!{start_cell}:{end_cell}",
                    'type': 'line', 'style': 18
                })

        # 5. DATA VALIDATION (Drop-downs automatici) — toggle data_validation
        if opts["data_validation"]:
            for col_num, col_name in enumerate(df.columns):
                if rows > 1 and df[col_name].dtype == 'object':
                    try:
                        u_vals = df[col_name].dropna().unique().tolist()
                        if 0 < len(u_vals) < 20:
                            worksheet.data_validation(1, col_num, rows, col_num, {
                                'validate': 'list', 'source': [str(x) for x in u_vals]
                            })
                    except: pass

        # 6. FINISH UI
        if opts["freeze_panes"]:
            worksheet.freeze_panes(1, 1)

        # AUTOFILTER (nuovo) — toggle autofilter. Copre header + dati; include la
        # colonna "Trend" solo se la sparkline e' stata effettivamente aggiunta.
        if opts["autofilter"]:
            last_col = cols if spark_added else cols - 1
            if last_col >= 0:
                worksheet.autofilter(0, 0, rows, last_col)

        for i, col in enumerate(df.columns):
            max_len = max(df[col].astype(str).map(len).max() if len(df)>0 else 0, len(str(col))) + 3
            worksheet.set_column(i, i, min(max_len, 50))

        logger.info(f"✅ Full Premium formatting applied to {sheet_name}")

    # --- MOTOR OPENPYXL (PRESERVAZIONE) ---

    def _has_charts(self, file_path: str) -> bool:
        """Controlla se un file Excel contiene grafici usando openpyxl."""
        if not os.path.exists(file_path): return False
        try:
            wb = openpyxl.load_workbook(file_path, read_only=False, data_only=True)
            for sheet in wb.worksheets:
                if len(getattr(sheet, '_charts', [])) > 0: return True
                if hasattr(sheet, '_drawings') and sheet._drawings: return True
            return False
        except: return False

    async def apply_style_with_preservation(self, original_path: str, output_name: str, df: pd.DataFrame, excel_style: str = "Corporate Blue"):
        """Applica lo stile SENZA distruggere grafici esistenti (Usa OpenPyXL)."""
        output_dir = project_manager.get_path("output")
        output_path = output_dir / output_name
        import shutil
        shutil.copyfile(original_path, str(output_path))
        
        try:
            wb = openpyxl.load_workbook(str(output_path))
            
            pal = get_palette(excel_style)
            head_bg, head_fg = _strip_hash(pal["head_bg"]), _strip_hash(pal["head_fg"])

            header_fill = PatternFill(start_color=head_bg, end_color=head_bg, fill_type='solid')
            header_font = Font(name='Segoe UI', size=11, bold=True, color=head_fg)
            border = Border(top=Side(style="thin"), left=Side(style="thin"), right=Side(style="thin"), bottom=Side(style="thin"))

            for ws in wb.worksheets:
                # Sincronizza Dati
                for c_idx, col_name in enumerate(df.columns, 1):
                    ws.cell(row=1, column=c_idx, value=col_name)
                for r_idx, row in enumerate(df.values, 2):
                    for c_idx, value in enumerate(row, 1):
                        ws.cell(row=r_idx, column=c_idx, value="" if pd.isna(value) else value)

                # Stile Header
                for cell in ws[1]:
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.border = border
                    cell.alignment = Alignment(horizontal='center', vertical='center')

            wb.save(str(output_path))
            logger.info(f"✅ Style preserved and applied to {output_name}")
            return str(output_path)
        except Exception as e:
            logger.error(f"OpenPyXL Error: {e}")
            raise
