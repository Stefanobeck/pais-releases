"""
update_service — Auto-update "Opzione 1": manifest remoto + download del nuovo
setup.exe (con verifica sha256) + lancio dell'installer (upgrade in-place Inno).

Tutto GRACEFUL: se il manifest è assente/irraggiungibile/malformato la feature è
dormiente — nessun banner, nessun crash. L'URL del manifest arriva da env
`PAIS_UPDATE_MANIFEST_URL` (l'hosting di manifest + setup.exe è esterno al codice).

Manifest atteso (JSON):
    {
      "version": "1.0.2",
      "url": "https://.../PAIS_Setup_1.0.2.exe",
      "sha256": "<hex sha256 del setup.exe>",
      "notes": "Changelog breve"
    }
"""
from __future__ import annotations

import hashlib
import logging
import os
import tempfile
import urllib.parse
from pathlib import Path

from backend_config import settings

logger = logging.getLogger("PAIS.Update")

_MANIFEST_TIMEOUT = 8.0

# Host pinning: l'update scarica ed ESEGUE un .exe → accettiamo SOLO URL HTTPS
# verso GitHub (manifest su raw.githubusercontent.com; binario su github.com →
# redirect a *.githubusercontent.com). Difesa in profondità: anche se la env
# PAIS_UPDATE_MANIFEST_URL venisse manomessa non si scarica da host arbitrari.
_ALLOWED_UPDATE_HOSTS = {
    "github.com",
    "raw.githubusercontent.com",
    "objects.githubusercontent.com",
    "release-assets.githubusercontent.com",
    "codeload.github.com",
}


def _is_trusted_url(url: str) -> bool:
    """True solo se URL HTTPS verso un host GitHub fidato."""
    try:
        u = urllib.parse.urlparse(url)
    except Exception:
        return False
    if u.scheme != "https":
        return False
    host = (u.hostname or "").lower()
    return host in _ALLOWED_UPDATE_HOSTS or host.endswith(".githubusercontent.com")


def _manifest_url() -> str:
    return os.environ.get("PAIS_UPDATE_MANIFEST_URL", "").strip()


def _runtime_version() -> str:
    """Versione del 'runtime' (python-embed + deps + ollama + chromium). Bumpata
    a mano in backend/RUNTIME_VERSION quando cambiano: serve a decidere se un
    update può essere app-only (stesso runtime) o richiede il full installer."""
    try:
        p = Path(__file__).resolve().parents[1] / "RUNTIME_VERSION"
        if p.is_file():
            return p.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return ""


def _packaged_dirs():
    """(app_dir, dist_root, start_bat) se siamo nell'app IMPACCHETTATA
    (dist-portable con start.bat), altrimenti None (dev / non applicabile).
    update_service.py vive in <dist_root>/app/backend/services/."""
    try:
        backend_dir = Path(__file__).resolve().parents[1]   # .../app/backend
        app_dir = backend_dir.parent                          # .../app
        dist_root = app_dir.parent                            # .../dist-portable
        start_bat = dist_root / "start.bat"
        if app_dir.name == "app" and start_bat.is_file():
            return app_dir, dist_root, start_bat
    except Exception:
        pass
    return None


def _parse_version(v: str):
    """Versione → oggetto comparabile. Usa packaging.version se disponibile,
    altrimenti fallback a tuple di interi (es. '1.0.10' → (1,0,10))."""
    v = (v or "").strip().lstrip("vV")
    try:
        from packaging.version import Version
        return Version(v)
    except Exception:
        parts = []
        for chunk in v.split("."):
            digits = "".join(ch for ch in chunk if ch.isdigit())
            parts.append(int(digits) if digits else 0)
        return tuple(parts) if parts else (0,)


def _is_newer(latest: str, current: str) -> bool:
    try:
        return _parse_version(latest) > _parse_version(current)
    except Exception:
        return False


def check_for_update() -> dict:
    """Controlla il manifest remoto e confronta con APP_VERSION.
    Graceful: ogni errore → {update_available: False, reason: ...}."""
    current = settings.APP_VERSION
    url = _manifest_url()
    if not url:
        return {"update_available": False, "current": current, "reason": "no_manifest_url"}
    if not _is_trusted_url(url):
        logger.warning("Manifest URL non attendibile (richiesto HTTPS verso GitHub) — update disabilitato.")
        return {"update_available": False, "current": current, "reason": "untrusted_manifest_url"}
    try:
        import httpx
        r = httpx.get(url, timeout=_MANIFEST_TIMEOUT, follow_redirects=True)
        r.raise_for_status()
        data = r.json()
        latest = str(data.get("version", "")).strip()
        dl_url = str(data.get("url", "")).strip()
        sha256 = str(data.get("sha256", "")).strip().lower()
        notes = str(data.get("notes", "")).strip()
        # Update incrementale "app-only" (campi opzionali nel manifest).
        app_url = str(data.get("app_url", "")).strip()
        app_sha = str(data.get("app_sha256", "")).strip().lower()
        manifest_rt = str(data.get("runtime", "")).strip()
        if not latest or not dl_url:
            return {"update_available": False, "current": current, "reason": "manifest_incomplete"}
        if not _is_trusted_url(dl_url):
            return {"update_available": False, "current": current, "reason": "untrusted_download_url"}
        if len(sha256) != 64 or any(c not in "0123456789abcdef" for c in sha256):
            return {"update_available": False, "current": current, "reason": "missing_sha256"}
        available = _is_newer(latest, current)
        # App-only se: runtime combacia, app_url fidato + sha valido, app impacchettata.
        app_ok = (
            available and bool(app_url) and _is_trusted_url(app_url)
            and len(app_sha) == 64 and all(c in "0123456789abcdef" for c in app_sha)
            and bool(manifest_rt) and manifest_rt == _runtime_version()
            and _packaged_dirs() is not None
        )
        kind = "app" if app_ok else "full"
        return {
            "update_available": available,
            "current": current,
            "latest": latest,
            "kind": kind if available else "",
            "url": dl_url if available else "",
            "sha256": sha256 if available else "",
            "app_url": app_url if app_ok else "",
            "app_sha256": app_sha if app_ok else "",
            "notes": notes if available else "",
        }
    except Exception as e:
        logger.info(f"Update check failed (feature dormiente): {e}")
        return {"update_available": False, "current": current, "reason": "unreachable"}


async def download_update(url: str, sha256: str = ""):
    """Async-gen: scarica il setup.exe nel temp dir con progress NDJSON e verifica
    sha256 a fine. Yield {status:downloading, completed, total} ... poi
    {status:success, path} oppure {status:error, message}."""
    if not url:
        yield {"status": "error", "message": "URL update mancante"}
        return
    if not _is_trusted_url(url):
        yield {"status": "error", "message": "URL non attendibile: l'update accetta solo HTTPS verso GitHub."}
        return
    if len(sha256) != 64:
        yield {"status": "error", "message": "sha256 mancante o non valido: download rifiutato (fail-closed)."}
        return
    try:
        import httpx
        fname = (url.split("/")[-1] or "PAIS_Setup_update.exe").split("?")[0]
        if not fname.lower().endswith((".exe", ".zip")):
            fname += ".exe"
        dest = Path(tempfile.gettempdir()) / fname
        hasher = hashlib.sha256()
        dl_timeout = httpx.Timeout(connect=10.0, read=600.0, write=30.0, pool=10.0)
        async with httpx.AsyncClient(timeout=dl_timeout, follow_redirects=True) as client:
            async with client.stream("GET", url) as resp:
                resp.raise_for_status()
                total = int(resp.headers.get("content-length", 0) or 0)
                completed = 0
                with open(dest, "wb") as f:
                    async for chunk in resp.aiter_bytes(chunk_size=1024 * 256):
                        f.write(chunk)
                        hasher.update(chunk)
                        completed += len(chunk)
                        yield {"status": "downloading", "completed": completed, "total": total}
        # Verifica integrità (se il manifest fornisce lo sha256).
        if sha256:
            digest = hasher.hexdigest().lower()
            if digest != sha256.lower():
                try:
                    dest.unlink()
                except Exception:
                    pass
                yield {"status": "error", "message": "Verifica integrità fallita: sha256 non corrisponde."}
                return
        yield {"status": "success", "message": "Download completato", "path": str(dest)}
    except Exception as e:
        logger.error(f"Update download failed: {e}")
        yield {"status": "error", "message": str(e)}


def launch_installer(path: str) -> dict:
    """Lancia il setup.exe scaricato (upgrade in-place). L'app dovrebbe poi
    chiudersi così l'installer non trova file lockati — il coordinamento di
    chiusura è gestito dal frontend dopo questa chiamata."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Installer non trovato: {path}")
    if os.name == "nt":
        os.startfile(str(p))  # nosec B606 - file scaricato e verificato sha256
    else:
        import subprocess
        subprocess.Popen([str(p)])
    logger.info(f"Update installer launched: {p}")
    return {"status": "launched", "path": str(p)}


def apply_app_update(zip_path: str) -> dict:
    """Update incrementale 'app-only': a PAIS chiuso, un helper sovrascrive la
    cartella `app\\` con lo zip (gia' scaricato e verificato sha256, contiene solo
    il layer codice) e rilancia. Ritorna subito; il frontend chiude poi l'app.

    Sicuro per design: lo zip e' integro (sha256 ok), l'estrazione e' di pochi MB
    e tocca SOLO i file codice (bin/ ollama+chromium e models/ restano intatti
    perche' non sono nello zip)."""
    dirs = _packaged_dirs()
    if dirs is None:
        raise RuntimeError("App-update disponibile solo nell'app installata (non in dev).")
    if os.name != "nt":
        raise RuntimeError("App-update supportato solo su Windows.")
    _app_dir, dist_root, start_bat = dirs
    zp = Path(zip_path)
    if not zp.is_file():
        raise FileNotFoundError(f"Pacchetto update non trovato: {zip_path}")

    # Helper .bat: attende la chiusura di PAIS (per liberare i lock), estrae lo
    # zip su dist_root (lo zip contiene `app\...` → sovrascrive app\) e rilancia.
    helper = Path(tempfile.gettempdir()) / "pais_apply_update.bat"
    helper.write_text(
        "@echo off\r\n"
        'set "ZIP=%~1"\r\n'
        'set "DEST=%~2"\r\n'
        'set "RELAUNCH=%~3"\r\n'
        'set "PID=%~4"\r\n'
        "set /a tries=0\r\n"
        ":wait\r\n"
        'tasklist /FI "PID eq %PID%" 2>nul | find "%PID%" >nul\r\n'
        "if errorlevel 1 goto apply\r\n"
        "set /a tries+=1\r\n"
        "if %tries% geq 30 goto apply\r\n"
        "timeout /t 1 /nobreak >nul\r\n"
        "goto wait\r\n"
        ":apply\r\n"
        "timeout /t 1 /nobreak >nul\r\n"
        'powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path \'%ZIP%\' -DestinationPath \'%DEST%\' -Force"\r\n'
        'start "" "%RELAUNCH%"\r\n'
        'del "%ZIP%" >nul 2>&1\r\n'
        'del "%~f0" >nul 2>&1\r\n',
        encoding="utf-8",
    )
    import subprocess
    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200
    subprocess.Popen(
        ["cmd", "/c", str(helper), str(zp), str(dist_root), str(start_bat), str(os.getpid())],
        creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
        close_fds=True,
    )
    logger.info(f"App-update helper avviato (zip={zp.name} → {dist_root})")
    return {"status": "applying", "path": str(zp)}
