"""
Batch Queue Service for PAIS.

Manages a per-project queue of "Add to Batch" items. Each item is fully
self-contained: at the moment the user clicks "Add to Batch" we snapshot
the relevant settings (model, profile, direct/compare mode, ...) AND copy
the attached files into a dedicated folder. This guarantees the batch
executes correctly hours/days later, even if the user has since deleted
files, switched profiles, or uninstalled models.

Storage layout (per active project):

    <project>/batch/
    ├── queue.json                      # the queue + execution history
    └── attachments/
        ├── <batch_id_1>/
        │   ├── file_a.pdf              # physical snapshot of session files
        │   └── file_b.pdf
        ├── <batch_id_2>/
        │   └── image.png
        └── ...

Each `<batch_id>` snapshot folder lives until either:
- the item is removed before execution → folder deleted immediately,
- the item executes successfully → folder deleted after success,
- the item fails during execution → folder kept for manual debugging.
"""
from __future__ import annotations

import json
import logging
import shutil
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Hard cap on queue size — safety guard against accidental accumulation.
MAX_QUEUE_ITEMS = 100

# Supported modules. The executor will dispatch each item to the matching
# service based on this string. Manipulate Add Charts / Add Style are
# intentionally excluded (interactive single-shot artifacts that don't
# benefit from queueing); Manipulate Export to Sheet IS supported because
# each request produces a different SQL transformation worth scheduling.
VALID_MODULES = {"interrogate", "vision", "manipulate_sheet"}

# Item statuses.
STATUS_PENDING = "pending"
STATUS_RUNNING = "running"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
STATUS_CANCELLED = "cancelled"


def _new_batch_id() -> str:
    """Time-sortable id: batch-YYYYMMDD-HHMMSS-<8char>."""
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"batch-{ts}-{uuid.uuid4().hex[:8]}"


class BatchQueueService:
    """File-based queue. One instance per process; reads/writes queue.json on demand.

    Concurrency: we don't expect parallel `add_item`/`remove_item` from the
    desktop UI (single user, single foreground action), so we use a coarse
    file-rewrite-on-each-mutation strategy. The executor reads via
    `list_pending` once at execution start and then operates on its own copy
    of the queue snapshot — mutations made by the UI while a batch is running
    apply only to items that have not yet been picked up.
    """

    def __init__(self, project_path: Path):
        if project_path is None:
            raise ValueError("project_path is required")
        self.project_path = Path(project_path)
        self.batch_root = self.project_path / "batch"
        self.attachments_root = self.batch_root / "attachments"
        self.queue_file = self.batch_root / "queue.json"
        self.batch_root.mkdir(parents=True, exist_ok=True)
        self.attachments_root.mkdir(parents=True, exist_ok=True)

    # ─── Low-level read/write ──────────────────────────────────────────────────

    def _read(self) -> Dict[str, Any]:
        if not self.queue_file.exists():
            return {"items": [], "executions": []}
        try:
            with open(self.queue_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return {"items": [], "executions": []}
            data.setdefault("items", [])
            data.setdefault("executions", [])
            return data
        except Exception as e:
            logger.error(f"BatchQueue read failed: {e} — returning empty queue")
            return {"items": [], "executions": []}

    def _write(self, data: Dict[str, Any]) -> None:
        try:
            with open(self.queue_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"BatchQueue write failed: {e}")
            raise

    # ─── Public API ────────────────────────────────────────────────────────────

    def add_item(
        self,
        module: str,
        prompt: str,
        snapshot: Dict[str, Any],
        source_files: List[Path],
    ) -> Dict[str, Any]:
        """Add a new item to the queue.

        Args:
            module: one of VALID_MODULES.
            prompt: user prompt (empty string allowed for Manipulate Style which
                    has no free-text input).
            snapshot: dict of settings frozen at add time (model, profile,
                      direct_mode, compare_mode, vision_model, excel_style,
                      chart_type, ...). Only fields relevant to the module
                      should be set — extras are stored as-is.
            source_files: absolute paths to files in the session that must be
                          snapshot-copied into the batch's attachments folder.
                          May be empty (e.g. Manipulate Style with no upload).

        Returns the created item dict.
        Raises ValueError on invalid input or queue overflow.
        """
        if module not in VALID_MODULES:
            raise ValueError(f"Unknown module '{module}'. Allowed: {sorted(VALID_MODULES)}")

        data = self._read()
        pending = [it for it in data["items"] if it.get("status") == STATUS_PENDING]
        if len(pending) >= MAX_QUEUE_ITEMS:
            raise ValueError(
                f"Queue full ({MAX_QUEUE_ITEMS} pending items). "
                "Execute or remove existing items before adding more."
            )

        batch_id = _new_batch_id()
        snapshot_folder = self.attachments_root / batch_id
        snapshot_folder.mkdir(parents=True, exist_ok=True)

        snapshot_files: List[str] = []
        total_bytes = 0
        try:
            for src in source_files:
                src = Path(src)
                if not src.exists() or not src.is_file():
                    logger.warning(f"BatchQueue add_item: source file missing, skipping: {src}")
                    continue
                dest = snapshot_folder / src.name
                # If a file with the same name was already copied, append a
                # numeric suffix to avoid silent overwrite.
                if dest.exists():
                    stem, suffix = dest.stem, dest.suffix
                    i = 1
                    while (snapshot_folder / f"{stem}__{i}{suffix}").exists():
                        i += 1
                    dest = snapshot_folder / f"{stem}__{i}{suffix}"
                shutil.copy2(src, dest)
                snapshot_files.append(dest.name)
                total_bytes += dest.stat().st_size
        except Exception as e:
            # Roll back partial snapshot.
            shutil.rmtree(snapshot_folder, ignore_errors=True)
            raise RuntimeError(f"Failed to snapshot files for batch item: {e}") from e

        item = {
            "id": batch_id,
            "module": module,
            "status": STATUS_PENDING,
            "created_at": datetime.now().isoformat(),
            "prompt": prompt or "",
            "snapshot": {
                **snapshot,
                "files": snapshot_files,
                "files_total_bytes": total_bytes,
            },
            "snapshot_folder": str(snapshot_folder.relative_to(self.project_path)),
            "started_at": None,
            "completed_at": None,
            "result": None,
            "error": None,
        }
        data["items"].append(item)
        self._write(data)
        logger.info(f"BatchQueue: added {batch_id} ({module}, {len(snapshot_files)} files, {total_bytes} bytes)")
        return item

    def list_items(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return queue items, optionally filtered by status."""
        data = self._read()
        items = data["items"]
        if status:
            items = [it for it in items if it.get("status") == status]
        return items

    def list_pending(self) -> List[Dict[str, Any]]:
        return self.list_items(status=STATUS_PENDING)

    def list_executions(self) -> List[Dict[str, Any]]:
        return self._read()["executions"]

    def get_item(self, batch_id: str) -> Optional[Dict[str, Any]]:
        for it in self._read()["items"]:
            if it["id"] == batch_id:
                return it
        return None

    def remove_item(self, batch_id: str) -> bool:
        """Remove an item from the queue. Only allowed if `pending` or `failed`/`completed`/`cancelled`.

        For pending items we also delete the snapshot folder.
        Returns True if the item was found and removed, False otherwise.
        """
        data = self._read()
        idx = next((i for i, it in enumerate(data["items"]) if it["id"] == batch_id), None)
        if idx is None:
            return False
        item = data["items"][idx]
        if item.get("status") == STATUS_RUNNING:
            logger.warning(f"BatchQueue: refusing to remove running item {batch_id}")
            return False
        # Best-effort cleanup of snapshot folder.
        snapshot_rel = item.get("snapshot_folder")
        if snapshot_rel:
            snap_path = self.project_path / snapshot_rel
            if snap_path.exists():
                try:
                    shutil.rmtree(snap_path, ignore_errors=True)
                except Exception as e:
                    logger.warning(f"BatchQueue: snapshot cleanup failed for {batch_id}: {e}")
        del data["items"][idx]
        self._write(data)
        logger.info(f"BatchQueue: removed {batch_id}")
        return True

    def update_item(self, batch_id: str, **fields) -> Optional[Dict[str, Any]]:
        """Patch fields on an existing item. Used by the executor to track
        status transitions (pending → running → completed/failed)."""
        data = self._read()
        for it in data["items"]:
            if it["id"] == batch_id:
                it.update(fields)
                self._write(data)
                return it
        return None

    def add_execution(self, execution: Dict[str, Any]) -> None:
        """Record a completed execution (folder, counts, timestamps)."""
        data = self._read()
        data["executions"].append(execution)
        self._write(data)

    def cleanup_snapshot(self, batch_id: str) -> None:
        """Delete the attachments folder of `batch_id`. Used after a successful
        execution. Failures are logged but never raised — cleanup is best-effort.
        """
        item = self.get_item(batch_id)
        if not item:
            return
        snapshot_rel = item.get("snapshot_folder")
        if not snapshot_rel:
            return
        snap_path = self.project_path / snapshot_rel
        if snap_path.exists():
            try:
                shutil.rmtree(snap_path, ignore_errors=True)
                logger.info(f"BatchQueue: cleaned snapshot {batch_id}")
            except Exception as e:
                logger.warning(f"BatchQueue: snapshot cleanup failed for {batch_id}: {e}")

    def recover_orphans(self) -> int:
        """Recover from a crashed executor: any item left in `running` state
        at process start is marked failed with a clear error. Called at startup.

        Returns the number of items recovered.
        """
        data = self._read()
        recovered = 0
        for it in data["items"]:
            if it.get("status") == STATUS_RUNNING:
                it["status"] = STATUS_FAILED
                it["error"] = "Execution interrupted (process restart)"
                it["completed_at"] = datetime.now().isoformat()
                recovered += 1
        if recovered:
            self._write(data)
            logger.warning(f"BatchQueue: recovered {recovered} orphaned running item(s) on startup")
        return recovered


# ─── Singleton factory ─────────────────────────────────────────────────────────

_instance: Optional[BatchQueueService] = None
_instance_project_path: Optional[Path] = None


def get_batch_queue_service() -> BatchQueueService:
    """Return a singleton bound to the currently active project. If the active
    project changes, we rebind to the new path automatically.
    """
    global _instance, _instance_project_path
    from backend_config.project_manager import project_manager
    if not project_manager.active_project_path:
        raise RuntimeError("No active project — cannot use batch queue.")
    current = project_manager.active_project_path
    if _instance is None or _instance_project_path != current:
        _instance = BatchQueueService(current)
        _instance_project_path = current
        _instance.recover_orphans()
    return _instance
