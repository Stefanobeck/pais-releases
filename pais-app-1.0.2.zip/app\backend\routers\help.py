"""
Help & Support Module - Backend Router for PAIS
"""
import logging
import webbrowser
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from backend_config import settings

router = APIRouter()
logger = logging.getLogger("PAIS.Help")

class OpenHelpRequest(BaseModel):
    module: str = "intro"
    lang: str = "it"

@router.post("/open")
async def open_help_in_browser(req: OpenHelpRequest):
    """Opens the HTML manual via the internal HTTP server to guarantee anchor stability."""
    try:
        # Determine language subfolder
        lang_folder = req.lang.lower() if req.lang.lower() in ["it", "en"] else "it"
        
        # We now use the HTTP URL because browsers handle fragments (#) better via HTTP than file://
        base_url = f"http://127.0.0.1:{settings.PORT}/help"
        file_url = f"{base_url}/{lang_folder}/index.html"
        
        anchor = req.module.lower()
        if anchor and anchor != "intro":
            file_url += f"#{anchor}"

        logger.info(f"🌐 Opening Knowledge Center via HTTP ({lang_folder.upper()}): {file_url}")
        webbrowser.open(file_url)
        
        return {"success": True, "url": file_url}
    except Exception as e:
        logger.error(f"Internal error opening browser: {e}")
        raise HTTPException(status_code=500, detail="Internal server error while opening documentation.")
