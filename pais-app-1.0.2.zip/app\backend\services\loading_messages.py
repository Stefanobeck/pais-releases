"""
Loading Messages Service - Messaggi ironici per animazioni di attesa
Carica e fornisce messaggi random da JSON config multilingua.
"""
import os
import json
import random
from typing import List, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class LoadingMessagesService:
    """
    Servizio per messaggi di attesa ironici e localizzati.
    """
    
    _messages: dict = {}
    _loaded: bool = False
    
    @classmethod
    def load(cls, config_path: Optional[Path] = None):
        """
        Carica messaggi da file JSON.
        
        Args:
            config_path: Percorso file JSON (opzionale, default: backend_config/waiting_messages.json)
        """
        if config_path is None:
            config_path = Path(__file__).parent / "waiting_messages.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                cls._messages = json.load(f)
            cls._loaded = True
            logger.info(f"✅ Loading messages loaded from {config_path}")
        except Exception as e:
            logger.error(f"❌ Error loading waiting messages: {e}")
            # Fallback messages
            cls._messages = {
                "it": ["Elaborazione in corso..."],
                "en": ["Processing..."],
                "es": ["Procesando..."],
                "fr": ["Traitement en cours..."],
                "de": ["Verarbeitung läuft..."]
            }
            cls._loaded = True
    
    @classmethod
    def get_random(cls, lang: str = 'it') -> str:
        """
        Ottiene messaggio random per lingua.
        
        Args:
            lang: Codice lingua (it, en, es, fr, de)
            
        Returns:
            Messaggio ironico random
        """
        if not cls._loaded:
            cls.load()
        
        msgs: List[str] = cls._messages.get(lang, cls._messages.get('it', ["Loading..."]))
        return random.choice(msgs)
    
    @classmethod
    def get_all(cls, lang: str = 'it') -> List[str]:
        """
        Ottiene tutti i messaggi per una lingua.
        
        Args:
            lang: Codice lingua
            
        Returns:
            Lista di tutti i messaggi
        """
        if not cls._loaded:
            cls.load()

        return cls._messages.get(lang, cls._messages.get('it', ["Loading..."]))
