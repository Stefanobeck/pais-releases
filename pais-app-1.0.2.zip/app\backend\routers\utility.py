from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, BackgroundTasks, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
# Gate PRO per i tool a pagamento (Transcribe / Mail Merge / PDF Redact).
# Tutti gli altri endpoint di /utility restano FREE.
from backend_config.auth_pro import require_pro_or_trial
import os
import json
import shutil
import uuid
import logging
from pathlib import Path
from typing import List, Optional

from backend_config.settings import settings
from backend_config.project_manager import project_manager
from processors.ocr_processor import OCRImgPDFProcessor, SUPPORTED_IMAGE_EXTS
from processors.translation_processor import TranslationProcessor
from processors.office_utility_processor import OfficeUtilityProcessor
from processors.format_converter import FormatConverter, ALLOWED_CONVERSIONS
from processors.qr_generator import generate_qr
from processors.rename_processor import RenameProcessor
from backend_config.project_manager import project_manager
# Importa la factory function di chat_service dal router interrogate
from routers.interrogate import get_chat_service
import datetime
import shutil

router = APIRouter()
logger = logging.getLogger(__name__)

# Inizializza i processori
ocr_processor = OCRImgPDFProcessor()
trans_processor = TranslationProcessor()
office_processor = OfficeUtilityProcessor()
format_converter = FormatConverter()
rename_processor = RenameProcessor()

@router.post("/catalog")
async def generate_catalog(
    files: List[UploadFile] = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    deep_mode: str = Form("false")
):
    """Genera un file Excel con l'indice dei documenti caricati."""
    try:
        # Conversione esplicita della stringa in booleano
        is_deep = deep_mode.lower() == "true"
        
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        saved_paths = []
        for file in files:
            file_path = temp_dir / file.filename
            # Crea le sottocartelle se il filename contiene dei percorsi (es: folder/file.txt)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            saved_paths.append(file_path)
            
        output_filename = f"Smart_Catalog_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        output_path = project_manager.get_path("output") / output_filename
        
        await office_processor.generate_smart_catalog(saved_paths, output_path, lang, is_deep)
        
        return {"success": True, "filename": output_filename}
    except Exception as e:
        logger.error(f"Catalog error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/sanitize")
async def sanitize_metadata(
    file: UploadFile = File(...),
    session_id: str = Form(...)
):
    """Rimuove metadati da un file."""
    try:
        temp_dir = project_manager.get_path("uploads")
        file_path = temp_dir / file.filename
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        output_filename = f"Sanitized_{file.filename}"
        sanitize_out_dir = project_manager.get_path("output") / "SANITIZER"
        sanitize_out_dir.mkdir(parents=True, exist_ok=True)
        output_path = sanitize_out_dir / output_filename
        
        success, removed_meta = await office_processor.sanitize_file(file_path, output_path)
        
        if success:
            return {"success": True, "filename": output_filename, "removed_meta": removed_meta}
        else:
            raise HTTPException(status_code=400, detail="Sanitization failed for this file type.")
    except Exception as e:
        logger.error(f"Sanitize error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/split")
async def split_pdf(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    mode: str = Form("per_page"),
    pages_per_chunk: int = Form(1),
    ranges_spec: Optional[str] = Form(None),
    num_parts: int = Form(2),
    target_size_mb: float = Form(10.0),
):
    """Divide un PDF in più documenti.

    Modalità supportate:
      - 'per_page'  : una pagina per file (default)
      - 'chunks'    : ogni `pages_per_chunk` pagine un file
      - 'ranges'    : range custom da `ranges_spec` (es. "1-3,5,8-10")
      - 'parts'     : divide in `num_parts` file uguali
      - 'size'      : chunks ottimizzati per dimensione massima `target_size_mb` MB
                      (utile per allegati email)
    Risposta: {success, subfolder, filenames}
      `subfolder` è il nome cartella creata in output/, contenente tutti i file generati.
    """
    try:
        temp_dir = project_manager.get_path("uploads")
        file_path = temp_dir / file.filename
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        output_root = project_manager.get_path("output")

        subfolder, filenames = await office_processor.smart_split_pdf(
            file_path, output_root, lang,
            mode=mode,
            pages_per_chunk=pages_per_chunk,
            ranges_spec=ranges_spec,
            num_parts=num_parts,
            target_size_mb=target_size_mb,
        )

        return {"success": True, "subfolder": subfolder, "filenames": filenames}
    except ValueError as ve:
        logger.warning(f"Split validation error: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"Split error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────────────────────────────────
# PDF Toolkit (merge / compress) + Mail Merge (DOCX template + CSV/XLSX)
# ─────────────────────────────────────────────────────────────────────────

# In-memory cache per il pattern two-phase del Mail Merge.
# token UUID → (template_path, data_path, created_at). TTL 30 min.
_mail_merge_cache: dict = {}
_MAIL_MERGE_TTL = datetime.timedelta(minutes=30)


def _mail_merge_cache_sweep():
    """Rimuove voci scadute e elimina i file temporanei associati.
    Chiamata ad ogni call della route per evitare leak in `uploads/`.
    """
    now = datetime.datetime.now()
    expired = [tk for tk, (_, _, ts) in _mail_merge_cache.items() if now - ts > _MAIL_MERGE_TTL]
    for tk in expired:
        tpl_p, data_p, _ = _mail_merge_cache.pop(tk, (None, None, None))
        for p in (tpl_p, data_p):
            try:
                if p and Path(p).exists():
                    Path(p).unlink()
            except Exception:
                pass


@router.post("/pdf-merge")
async def pdf_merge(
    files: List[UploadFile] = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    output_name: Optional[str] = Form(None),
):
    """Unisce N PDF in un singolo file.

    L'ordine di drop nel client = ordine di unione (FastAPI preserva l'ordine
    dei multipart upload). File corrotti/protetti vengono saltati e segnalati
    in `skipped`.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)

        saved_paths: List[Path] = []
        for f in files:
            # uniquify per evitare collisioni se l'utente droppa due file con lo stesso nome
            unique_name = f"merge_{uuid.uuid4().hex[:8]}_{f.filename}"
            file_path = temp_dir / unique_name
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(f.file, buffer)
            saved_paths.append(file_path)

        output_root = project_manager.get_path("output")
        filename, page_count, skipped = await office_processor.pdf_merge(
            saved_paths, output_root, output_name, lang,
        )

        # Cleanup uploads
        for p in saved_paths:
            try: p.unlink()
            except Exception: pass

        return {
            "success": True,
            "filename": filename,
            "page_count": page_count,
            "skipped": skipped,
        }
    except ValueError as ve:
        logger.warning(f"pdf_merge validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_merge error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pdf-compress")
async def pdf_compress(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    quality: str = Form("medium"),
):
    """Comprime un PDF ricomprimendo le immagini al DPI target del preset.

    Preset: low (72dpi), medium (110dpi), high (150dpi).
    Se l'output è ≥98% dell'input, restituisce una copia originale e
    `warning='no_gain'` (mai consegnare un file più grande dell'input).
    """
    if quality not in ("low", "medium", "high"):
        raise HTTPException(status_code=400, detail=f"Invalid quality preset: {quality}")
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / f"compress_{uuid.uuid4().hex[:8]}_{file.filename}"
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        output_root = project_manager.get_path("output")
        filename, original, compressed, no_gain = await office_processor.pdf_compress(
            file_path, output_root, quality, lang,
        )

        try: file_path.unlink()
        except Exception: pass

        ratio = (compressed / original) if original > 0 else 1.0
        gain_pct = max(0.0, (1.0 - ratio) * 100.0)
        resp = {
            "success": True,
            "filename": filename,
            "original_size_bytes": original,
            "compressed_size_bytes": compressed,
            "ratio": round(ratio, 4),
            "gain_pct": round(gain_pct, 2),
        }
        if no_gain:
            resp["warning"] = "no_gain"
        return resp
    except ValueError as ve:
        logger.warning(f"pdf_compress validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_compress error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pdf-rotate")
async def pdf_rotate(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    angle: int = Form(90),
    pages_spec: Optional[str] = Form(None),
):
    """Ruota pagine di un PDF (90/180/270°). pages_spec opzionale (es. "1-3,5,8-10")."""
    if angle not in (90, 180, 270):
        raise HTTPException(status_code=400, detail=f"angle must be 90/180/270")
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / f"rotate_{uuid.uuid4().hex[:8]}_{file.filename}"
        with open(file_path, "wb") as buf:
            shutil.copyfileobj(file.file, buf)
        output_root = project_manager.get_path("output")
        filename, rotated = await office_processor.pdf_rotate(
            file_path, output_root, angle, pages_spec, lang,
        )
        try: file_path.unlink()
        except Exception: pass
        return {"success": True, "filename": filename, "rotated_pages": rotated}
    except ValueError as ve:
        logger.warning(f"pdf_rotate validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_rotate error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pdf-watermark")
async def pdf_watermark(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    text: str = Form(...),
    position: str = Form("center"),
    opacity: float = Form(0.2),
    color: str = Form("red"),
):
    """Aggiunge un watermark testuale a tutte le pagine di un PDF.

    position: 'center' (diagonale -45°) | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'
    color: 'red' | 'gray' | 'black'
    opacity: 0.05-0.5
    """
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / f"watermark_{uuid.uuid4().hex[:8]}_{file.filename}"
        with open(file_path, "wb") as buf:
            shutil.copyfileobj(file.file, buf)
        output_root = project_manager.get_path("output")
        filename, pages = await office_processor.pdf_watermark(
            file_path, output_root, text, position, opacity, color, lang,
        )
        try: file_path.unlink()
        except Exception: pass
        return {"success": True, "filename": filename, "pages": pages}
    except ValueError as ve:
        logger.warning(f"pdf_watermark validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_watermark error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pdf-redact", dependencies=[Depends(require_pro_or_trial)])
async def pdf_redact(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
):
    """Modalità "rapida" 1-click (legacy): applica pecette su TUTTE le entità
    rilevate. NOTA: overlay-only.
    """
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / f"redact_{uuid.uuid4().hex[:8]}_{file.filename}"
        with open(file_path, "wb") as buf:
            shutil.copyfileobj(file.file, buf)
        output_root = project_manager.get_path("output")
        result = await office_processor.pdf_redact(file_path, output_root, lang=lang)
        try: file_path.unlink()
        except Exception: pass
        return {"success": True, **result}
    except ValueError as ve:
        logger.warning(f"pdf_redact validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_redact error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ─── PDF Redact: workflow controllato Analyze → Review → Apply ──────────────
# L'utente carica il PDF (analyze), riceve la lista delle entità con preview
# (raggruppate per tipo+testo + contesto). Sceglie quali coprire e clicca Apply.
# Server-side: PDF + analisi JSON cachati in `temp/redact_jobs/<job_id>` con
# auto-cleanup dopo l'apply (o timeout 1h).

REDACT_JOB_TIMEOUT_SECONDS = 3600  # 1h


def _redact_jobs_dir() -> "Path":
    from pathlib import Path
    p = project_manager.get_path("temp") / "redact_jobs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _cleanup_stale_redact_jobs() -> None:
    """Rimuove job orfani (PDF + JSON) più vecchi del timeout."""
    import time
    try:
        dir_ = _redact_jobs_dir()
        cutoff = time.time() - REDACT_JOB_TIMEOUT_SECONDS
        for p in dir_.iterdir():
            try:
                if p.stat().st_mtime < cutoff:
                    p.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


@router.post("/pdf-redact/analyze", dependencies=[Depends(require_pro_or_trial)])
async def pdf_redact_analyze(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
):
    """Step 1: rileva le entità PII. NON modifica il file. Salva PDF + analisi
    JSON in cache server-side con un job_id che il client riusa per /apply.
    Returns: { job_id, entities, pages, pages_with_text, pages_without_text, warning }.
    """
    try:
        _cleanup_stale_redact_jobs()
        jobs_dir = _redact_jobs_dir()
        job_id = uuid.uuid4().hex[:16]
        ext = (file.filename or "input.pdf").rsplit(".", 1)[-1].lower() or "pdf"
        if ext != "pdf":
            raise HTTPException(status_code=400, detail="Only PDF files are accepted")
        pdf_path = jobs_dir / f"{job_id}.pdf"
        with open(pdf_path, "wb") as buf:
            shutil.copyfileobj(file.file, buf)

        analysis = await office_processor.pdf_redact_analyze(pdf_path, lang=lang)

        # Persistiamo l'analisi accanto al PDF.
        json_path = jobs_dir / f"{job_id}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "lang": lang,
                "original_filename": file.filename,
                "analysis": analysis,
            }, f)

        return {
            "success": True,
            "job_id": job_id,
            "entities": analysis.get("entities", []),
            "pages": analysis.get("pages", 0),
            "pages_with_text": analysis.get("pages_with_text", 0),
            "pages_without_text": analysis.get("pages_without_text", 0),
            "warning": analysis.get("warning"),
        }
    except HTTPException:
        raise
    except ValueError as ve:
        logger.warning(f"pdf_redact_analyze validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_redact_analyze error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class PdfRedactApplyRequest(BaseModel):
    job_id: str
    selected_entity_ids: List[str]


@router.post("/pdf-redact/apply", dependencies=[Depends(require_pro_or_trial)])
async def pdf_redact_apply(req: PdfRedactApplyRequest):
    """Step 2: applica le pecette solo alle entità selezionate dall'utente nello
    step di review. Cleanup del job (PDF + JSON) dopo apply.
    Returns: { filename, pages, entities_count, by_type }.
    """
    try:
        jobs_dir = _redact_jobs_dir()
        pdf_path = jobs_dir / f"{req.job_id}.pdf"
        json_path = jobs_dir / f"{req.job_id}.json"
        if not pdf_path.exists() or not json_path.exists():
            raise HTTPException(status_code=404, detail="Job not found or expired. Re-run Analyze.")

        with open(json_path, "r", encoding="utf-8") as f:
            cached = json.load(f)
        analysis = cached.get("analysis") or {}

        output_root = project_manager.get_path("output")
        result = await office_processor.pdf_redact_apply_selected(
            input_path=pdf_path,
            output_root=output_root,
            analysis=analysis,
            selected_entity_ids=req.selected_entity_ids,
        )

        # Cleanup job tmp.
        try: pdf_path.unlink()
        except Exception: pass
        try: json_path.unlink()
        except Exception: pass

        return {"success": True, **result}
    except HTTPException:
        raise
    except ValueError as ve:
        logger.warning(f"pdf_redact_apply validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_redact_apply error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/pdf-redact/job/{job_id}", dependencies=[Depends(require_pro_or_trial)])
async def pdf_redact_cancel_job(job_id: str):
    """Cancella un job di analyze (cleanup tmp). Usato dal frontend se l'utente
    abbandona la review senza applicare.
    """
    try:
        jobs_dir = _redact_jobs_dir()
        for ext in ("pdf", "json"):
            p = jobs_dir / f"{job_id}.{ext}"
            try:
                p.unlink(missing_ok=True)
            except Exception:
                pass
        return {"success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/images-to-pdf")
async def images_to_pdf(
    files: List[UploadFile] = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    output_name: Optional[str] = Form(None),
):
    """Combina N immagini in un singolo PDF (1 immagine per pagina). Ordine = ordine drop."""
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        saved: List[Path] = []
        for f in files:
            unique = temp_dir / f"img2pdf_{uuid.uuid4().hex[:8]}_{f.filename}"
            with open(unique, "wb") as buf:
                shutil.copyfileobj(f.file, buf)
            saved.append(unique)
        output_root = project_manager.get_path("output")
        filename, pages, skipped = await office_processor.images_to_pdf(
            saved, output_root, output_name, lang,
        )
        for p in saved:
            try: p.unlink()
            except Exception: pass
        return {"success": True, "filename": filename, "pages": pages, "skipped": skipped}
    except ValueError as ve:
        logger.warning(f"images_to_pdf validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"images_to_pdf error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pdf-to-images")
async def pdf_to_images(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    image_format: str = Form("png"),
    dpi: int = Form(150),
):
    """Esporta ogni pagina del PDF come immagine separata in una subfolder dedicata."""
    try:
        temp_dir = project_manager.get_path("uploads")
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / f"pdf2img_{uuid.uuid4().hex[:8]}_{file.filename}"
        with open(file_path, "wb") as buf:
            shutil.copyfileobj(file.file, buf)
        output_root = project_manager.get_path("output")
        subfolder, filenames = await office_processor.pdf_to_images(
            file_path, output_root, image_format, dpi, lang,
        )
        try: file_path.unlink()
        except Exception: pass
        return {"success": True, "subfolder": subfolder, "filenames": filenames}
    except ValueError as ve:
        logger.warning(f"pdf_to_images validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"pdf_to_images error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/qr/generate")
async def qr_generate(
    qr_type: str = Form(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    size: int = Form(1024),
    # URL
    url: Optional[str] = Form(None),
    # vCard
    first_name: Optional[str] = Form(None),
    last_name: Optional[str] = Form(None),
    organization: Optional[str] = Form(None),
    title: Optional[str] = Form(None),
    phone: Optional[str] = Form(None),
    email: Optional[str] = Form(None),
    website: Optional[str] = Form(None),
    address: Optional[str] = Form(None),
    # WiFi
    ssid: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    security: Optional[str] = Form("WPA"),
    hidden: Optional[bool] = Form(False),
):
    """Genera un QR code PNG: URL, vCard biglietto da visita, o WiFi guest.

    `qr_type`: 'url' | 'vcard' | 'wifi'
    """
    if qr_type not in ("url", "vcard", "wifi"):
        raise HTTPException(status_code=400, detail=f"Unknown QR type: {qr_type}")
    if size < 256 or size > 4096:
        raise HTTPException(status_code=400, detail="size must be between 256 and 4096")
    try:
        payload_data = {
            "url": url or "",
            "first_name": first_name or "",
            "last_name": last_name or "",
            "organization": organization or "",
            "title": title or "",
            "phone": phone or "",
            "email": email or "",
            "website": website or "",
            "address": address or "",
            "ssid": ssid or "",
            "password": password or "",
            "security": security or "WPA",
            "hidden": bool(hidden),
        }
        output_root = project_manager.get_path("output")
        filename, subfolder = generate_qr(qr_type, payload_data, output_root, size=size)
        return {"success": True, "filename": filename, "subfolder": subfolder}
    except ValueError as ve:
        logger.warning(f"qr_generate validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"qr_generate error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/mail-merge/open-examples-folder", dependencies=[Depends(require_pro_or_trial)])
async def open_mail_merge_examples_folder():
    """Apre la cartella dei file di esempio per Mail Merge nell'Esplora Risorse
    dell'OS. L'utente fa drag-and-drop dei file da lì verso le drop zone della UI.

    Cerca prima `frontend/dist/examples/` (produzione, dopo `npm run build`),
    poi `frontend/public/examples/` (dev). Entrambe contengono gli stessi
    4 file generati da `scripts/generate_mail_merge_examples.py`.
    """
    backend_dir = Path(__file__).parent.parent
    candidates = [
        backend_dir.parent / "frontend" / "dist" / "examples",
        backend_dir.parent / "frontend" / "public" / "examples",
    ]
    folder = next((c for c in candidates if c.exists() and c.is_dir()), None)
    if folder is None:
        raise HTTPException(
            status_code=404,
            detail="Examples folder not found. Run scripts/generate_mail_merge_examples.py.",
        )
    try:
        path_str = str(folder.absolute())
        if os.name == 'nt':
            os.startfile(path_str)
        else:
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])
        return {"success": True, "folder": path_str}
    except Exception as e:
        logger.error(f"open_mail_merge_examples_folder error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/mail-merge", dependencies=[Depends(require_pro_or_trial)])
async def mail_merge(
    action: str = Form(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    template: Optional[UploadFile] = File(None),
    data: Optional[UploadFile] = File(None),
    merge_token: Optional[str] = Form(None),
    filename_pattern: Optional[str] = Form(None),
):
    """Mail Merge two-phase.

    Phase `inspect`:
      Riceve `template` (DOCX) + `data` (CSV/XLSX), li salva in cache
      keyed by UUID, restituisce placeholders + columns + match analysis.
    Phase `generate`:
      Riceve `merge_token` (dalla phase inspect) + `filename_pattern`,
      genera N file DOCX e cancella la cache associata.
    """
    _mail_merge_cache_sweep()

    if action == "inspect":
        if not template or not data:
            raise HTTPException(status_code=400, detail="template + data required for inspect")
        tpl_ext = Path(template.filename).suffix.lower()
        if tpl_ext != ".docx":
            raise HTTPException(status_code=400, detail="Template must be .docx")
        data_ext = Path(data.filename).suffix.lower()
        if data_ext not in (".csv", ".xlsx", ".xls"):
            raise HTTPException(status_code=400, detail="Data must be .csv or .xlsx")

        try:
            temp_dir = project_manager.get_path("uploads")
            temp_dir.mkdir(parents=True, exist_ok=True)
            token = uuid.uuid4().hex
            tpl_path = temp_dir / f"mm_{token}_template{tpl_ext}"
            data_path = temp_dir / f"mm_{token}_data{data_ext}"
            with open(tpl_path, "wb") as f:
                shutil.copyfileobj(template.file, f)
            with open(data_path, "wb") as f:
                shutil.copyfileobj(data.file, f)

            inspect = await office_processor.mail_merge_inspect(tpl_path, data_path, lang)
            _mail_merge_cache[token] = (tpl_path, data_path, datetime.datetime.now())

            return {"success": True, "merge_token": token, **inspect}
        except ValueError as ve:
            logger.warning(f"mail_merge inspect validation: {ve}")
            raise HTTPException(status_code=400, detail=str(ve))
        except Exception as e:
            logger.error(f"mail_merge inspect error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    elif action == "generate":
        if not merge_token or not filename_pattern:
            raise HTTPException(status_code=400, detail="merge_token + filename_pattern required for generate")
        cached = _mail_merge_cache.get(merge_token)
        if not cached:
            raise HTTPException(status_code=400, detail="Invalid or expired merge_token — re-run inspect")
        tpl_path, data_path, _created_at = cached
        try:
            output_root = project_manager.get_path("output")
            subfolder, generated, skipped = await office_processor.mail_merge_generate(
                tpl_path, data_path, output_root, filename_pattern, lang,
            )
            # Cleanup cache + temp files
            _mail_merge_cache.pop(merge_token, None)
            for p in (tpl_path, data_path):
                try: Path(p).unlink()
                except Exception: pass
            return {
                "success": True,
                "subfolder": subfolder,
                "filenames": generated,
                "skipped": skipped,
            }
        except ValueError as ve:
            logger.warning(f"mail_merge generate validation: {ve}")
            raise HTTPException(status_code=400, detail=str(ve))
        except Exception as e:
            logger.error(f"mail_merge generate error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    else:
        raise HTTPException(status_code=400, detail=f"Unknown action: {action}")


# ─────────────────────────────────────────────────────────────────────────
# RENAMER — two-phase: build plan (no IO), then apply on user confirmation
# ─────────────────────────────────────────────────────────────────────────
RENAME_JOB_TIMEOUT_SECONDS = 3600  # 1h


def _rename_jobs_dir() -> Path:
    p = project_manager.get_path("temp") / "rename_jobs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _cleanup_stale_rename_jobs() -> None:
    import time
    try:
        d = _rename_jobs_dir()
        cutoff = time.time() - RENAME_JOB_TIMEOUT_SECONDS
        for p in d.iterdir():
            try:
                if p.stat().st_mtime < cutoff:
                    if p.is_dir():
                        shutil.rmtree(p, ignore_errors=True)
                    else:
                        p.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


@router.post("/file-renamer/plan")
async def rename_plan(
    files: List[UploadFile] = File(...),
    session_id: str = Form(...),
    mode: str = Form("fast"),
    rename_schema: str = Form(..., alias="schema"),
    lang: str = Form("it"),
):
    """Step 1: build a rename plan without modifying anything.

    Uploads stay in a temp job dir keyed by plan_id; the client passes
    plan_id back to /file-renamer/apply when the user confirms.

    NOTE: the form field is named `schema` for client compatibility, but
    bound to `rename_schema` server-side because `schema` is a reserved
    attribute on Pydantic BaseModel (UserWarning otherwise).
    """
    logger.info(f"📁 rename/plan called: files={len(files)} mode={mode} schema_len={len(rename_schema)}")
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    if mode not in ("fast", "smart"):
        raise HTTPException(status_code=400, detail=f"Invalid mode: {mode}")
    try:
        schema_dict = json.loads(rename_schema)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid schema JSON: {e}")

    try:
        _cleanup_stale_rename_jobs()
        plan_id = uuid.uuid4().hex[:16]
        job_dir = _rename_jobs_dir() / plan_id
        job_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"📁 rename/plan: created job_dir={job_dir}")

        saved_paths: List[Path] = []
        for f in files:
            dst = job_dir / Path(f.filename).name
            with open(dst, "wb") as buf:
                shutil.copyfileobj(f.file, buf)
            saved_paths.append(dst)

        plan = await rename_processor.build_rename_plan(
            file_paths=saved_paths,
            mode=mode,
            schema=schema_dict,
            lang=lang,
        )

        # Persist plan for /apply step.
        with open(job_dir / "plan.json", "w", encoding="utf-8") as f:
            json.dump({
                "plan_id": plan_id,
                "mode": mode,
                "schema": schema_dict,
                "lang": lang,
                "items": plan,
            }, f, ensure_ascii=False)

        return {"success": True, "plan_id": plan_id, "items": plan}
    except ValueError as ve:
        logger.warning(f"rename_plan validation: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"rename_plan error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


class RenameApplyRequest(BaseModel):
    plan_id: str
    selected_ids: Optional[List[str]] = None


@router.post("/file-renamer/apply")
async def rename_apply(req: RenameApplyRequest):
    """Step 2: copy files to output/Renamed/<timestamp>/ with new names.
    Writes a JSON log alongside the renamed files so a future Undo can
    restore the original names. Cleans up the job dir afterwards.
    """
    try:
        job_dir = _rename_jobs_dir() / req.plan_id
        plan_path = job_dir / "plan.json"
        if not plan_path.exists():
            raise HTTPException(status_code=404, detail="Plan not found or expired. Re-run Plan step.")
        with open(plan_path, "r", encoding="utf-8") as f:
            cached = json.load(f)

        # Resolve actual file paths in the job dir.
        items: List[dict] = cached.get("items", [])
        file_paths = [job_dir / it["old"] for it in items]
        file_paths = [p for p in file_paths if p.exists()]

        output_root = project_manager.get_path("output")
        result = await rename_processor.apply_rename_plan(
            file_paths=file_paths,
            plan=items,
            output_root=output_root,
            selected_ids=req.selected_ids,
        )

        # Cleanup job dir now that copies are in output/.
        try:
            shutil.rmtree(job_dir, ignore_errors=True)
        except Exception:
            pass

        return {"success": True, **result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"rename_apply error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/file-renamer/job/{plan_id}")
async def rename_cancel_job(plan_id: str):
    """Cleanup if the user abandons the renamer before applying."""
    try:
        job_dir = _rename_jobs_dir() / plan_id
        if job_dir.exists():
            shutil.rmtree(job_dir, ignore_errors=True)
        return {"success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/convert/allowed-conversions")
async def get_allowed_conversions():
    """Restituisce la mappa source_ext → [target_ext...] per il CONVERT tool.
    Frontend la usa per popolare il dropdown del formato di destinazione
    in base all'estensione del file droppato (single source of truth).
    """
    return ALLOWED_CONVERSIONS


@router.post("/convert")
async def convert_files(
    files: List[UploadFile] = File(...),
    target_formats: List[str] = Form(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
):
    """Converte N file. Ogni file ha il suo target_format (array parallelo).

    Esempio:
      files = [a.docx, b.png, c.csv]
      target_formats = ["pdf", "jpg", "xlsx"]

    Output: lista di {filename, source, target, warning?, error?} per file.
    Errori per file singolo NON fanno fallire tutto il batch — il file
    incriminato finisce in `errored` con la motivazione.
    """
    if len(files) == 0:
        raise HTTPException(status_code=400, detail="No files uploaded")
    if len(files) != len(target_formats):
        raise HTTPException(
            status_code=400,
            detail=f"files/target_formats length mismatch: {len(files)} vs {len(target_formats)}",
        )

    temp_dir = project_manager.get_path("uploads")
    temp_dir.mkdir(parents=True, exist_ok=True)
    output_root = project_manager.get_path("output")

    converted: List[dict] = []
    errored: List[dict] = []

    for f, target in zip(files, target_formats):
        unique_in = temp_dir / f"convert_{uuid.uuid4().hex[:8]}_{f.filename}"
        try:
            with open(unique_in, "wb") as buf:
                shutil.copyfileobj(f.file, buf)
            out_filename, out_subfolder, warning = await format_converter.convert(
                unique_in, output_root, target, lang,
            )
            converted.append({
                "source_filename": f.filename,
                "filename": out_filename,
                "subfolder": out_subfolder,
                "target": target,
                **({"warning": warning} if warning else {}),
            })
        except ValueError as ve:
            logger.warning(f"convert validation [{f.filename}]: {ve}")
            errored.append({"source_filename": f.filename, "error": str(ve)})
        except Exception as e:
            logger.error(f"convert error [{f.filename}]: {e}")
            errored.append({"source_filename": f.filename, "error": str(e)})
        finally:
            try: unique_in.unlink()
            except Exception: pass

    return {
        "success": len(converted) > 0,
        "converted": converted,
        "errored": errored,
    }


@router.get("/languages")
async def get_languages():
    """Elenco lingue supportate per traduzione."""
    return trans_processor.get_supported_languages()

@router.post("/ocr")
async def process_ocr(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it"),
    export_format: str = Form("txt")
):
    """
    Endpoint per l'OCR di immagini e PDF (Esclusivo GLM-OCR con Layout Analysis).
    """
    try:
        # Usa la cartella uploads del progetto (non una temp condivisa)
        temp_upload_dir = project_manager.get_path("uploads") if project_manager.active_project_path else settings.BASE_DIR / "temp" / "utility_uploads"
        temp_upload_dir.mkdir(parents=True, exist_ok=True)
        
        file_ext = Path(file.filename).suffix.lower()
        unique_filename = f"{uuid.uuid4()}{file_ext}"
        file_path = temp_upload_dir / unique_filename
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        # Processamento basato sull'estensione - Forza GLM-OCR
        success = False
        result_text = ""
        target_model = "glm-ocr:latest"
        
        if file_ext == '.pdf':
            success, result_text = await ocr_processor.process_pdf(str(file_path), model=target_model)
        elif file_ext in ['.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tiff', '.tif']:
            success, result_text = await ocr_processor.process_image(str(file_path), model=target_model)
        else:
            if os.path.exists(file_path): os.remove(file_path)
            raise HTTPException(status_code=400, detail=f"Formato file {file_ext} non supportato per OCR.")
            
        # Pulizia file temporaneo
        if os.path.exists(file_path):
            os.remove(file_path)
            
        if not success:
            raise HTTPException(status_code=500, detail=result_text)
            
        # Salvataggio risultati nel formato richiesto
        base_name = Path(file.filename).stem
        if export_format.lower() == 'docx':
            export_path = ocr_processor.save_as_docx(result_text, base_name)
        else:
            export_path = ocr_processor.save_as_txt(result_text, base_name)
        
        # Restituisce il testo estratto e il riferimento al file generato
        return {
            "success": True,
            "text": result_text,
            "filename": file.filename,
            "export_txt": os.path.basename(export_path) # Il nome campo rimane export_txt per compatibilità frontend, ma punta al file corretto
        }
        
    except Exception as e:
        logger.error(f"Error in OCR endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/ocr/stream")
async def process_ocr_stream(
    file: UploadFile = File(...),
    session_id: str = Form(...),
    lang: str = Form("it")
):
    """
    Endpoint per l'OCR streaming di immagini e PDF (Esclusivo GLM-OCR).
    """
    try:
        temp_upload_dir = project_manager.get_path("uploads") if project_manager.active_project_path else settings.BASE_DIR / "temp" / "utility_uploads"
        temp_upload_dir.mkdir(parents=True, exist_ok=True)
        
        file_ext = Path(file.filename).suffix.lower()
        unique_filename = f"stream_{uuid.uuid4()}{file_ext}"
        file_path = temp_upload_dir / unique_filename
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        target_model = "glm-ocr:latest"
        
        async def stream_generator():
            try:
                if file_ext == '.pdf':
                    async for chunk in ocr_processor.process_pdf_stream(str(file_path), model=target_model):
                        yield chunk
                elif file_ext in SUPPORTED_IMAGE_EXTS:
                    async for chunk in ocr_processor.process_image_stream(str(file_path), model=target_model):
                        yield chunk
                else:
                    yield f"Error: Unsupported format {file_ext}"
            finally:
                # Pulizia file temporaneo dopo lo streaming
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                    except:
                        pass

        return StreamingResponse(stream_generator(), media_type="text/plain")
        
    except Exception as e:
        logger.error(f"Error in OCR stream endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/export")
async def export_ocr_result(
    text: str = Form(...),
    filename: str = Form(...),
    format: str = Form("docx") # docx o txt
):
    """
    Esporta il risultato dell'OCR in formato DOCX o TXT.
    """
    try:
        base_name = Path(filename).stem
        if format == "docx":
            output_path = ocr_processor.save_as_docx(text, base_name)
        else:
            output_path = ocr_processor.save_as_txt(text, base_name)
            
        return {
            "success": True,
            "export_file": os.path.basename(output_path),
            "full_path": str(output_path)
        }
    except Exception as e:
        logger.error(f"Error in Export endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/open-file/{filename}")
async def open_ocr_file(filename: str):
    """
    Apre fisicamente un file generato dall'OCR nella cartella OCR_CONVERSION.
    """
    try:
        from backend_config.project_manager import project_manager
        output_dir = project_manager.get_path("output") / "OCR_CONVERSION"
        file_path = output_dir / filename
        
        if not file_path.exists():
            file_path = project_manager.get_path("output") / filename
            if not file_path.exists():
                raise HTTPException(status_code=404, detail=f"File {filename} non trovato")
            
        path_str = str(file_path.absolute())
        
        if os.name == 'nt': # Windows
            os.startfile(path_str)
        else: # macOS/Linux
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])
            
        return {"success": True, "message": f"File {filename} aperto"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error opening OCR file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/send-to-interrogate")
async def send_to_interrogate(
    filename: str = Form(...),
):
    """
    Copia e indicizza un file OCR nel modulo INTERROGATE.
    """
    try:
        from backend_config.project_manager import project_manager
        
        # 1. Recupera il session_id del progetto (short_id)
        session_id = project_manager.get_short_id()
        if not session_id:
            raise HTTPException(status_code=400, detail="Nessun progetto attivo trovato")

        # 2. Percorso sorgente (OCR_CONVERSION)
        output_dir = project_manager.get_path("output") / "OCR_CONVERSION"
        file_path = output_dir / filename
        
        if not file_path.exists():
            file_path = project_manager.get_path("output") / filename
            if not file_path.exists():
                raise HTTPException(status_code=404, detail=f"File {filename} non trovato")
        
        # 3. Directory di destinazione: uploads del progetto
        dest_dir = project_manager.get_path("uploads")
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        dest_path = dest_dir / filename
        shutil.copy2(file_path, dest_path)
        
        # 4. REGISTRAZIONE REALE IN INTERROGATE (RAG + SESSION)
        # Usiamo il metodo upload_file del chat_service per indicizzarlo realmente
        result = await get_chat_service().upload_file(
            file_path=str(dest_path),
            filename=filename,
            session_id=session_id
        )
        
        if result.get('status') != 'success':
            raise Exception(f"Errore indicizzazione RAG: {result.get('message')}")

        logger.info(f"✅ File {filename} indicizzato in INTERROGATE (Session: {session_id})")
        
        return {
            "success": True, 
            "message": f"File '{filename}' pronto in INTERROGATE.",
            "filename": filename
        }
    except Exception as e:
        logger.error(f"Error sending file to Interrogate: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/translate/text")
async def translate_text(
    text: str = Form(...),
    source_lang: str = Form(...),
    source_code: str = Form(...),
    target_lang: str = Form(...),
    target_code: str = Form(...),
    format: str = Form("docx")
):
    """Traduzione di testo puro con salvataggio automatico."""
    try:
        translated = await trans_processor.translate_text(
            text, source_lang, source_code, target_lang, target_code
        )
        # Salva automaticamente
        if format == "docx":
            output_path = trans_processor.save_as_docx(translated, "Instant_Translation", target_lang)
        else:
            output_path = trans_processor.save_as_txt(translated, "Instant_Translation", target_lang)
            
        return {
            "success": True, 
            "translated": translated, 
            "export_file": os.path.basename(output_path)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/translate/file")
async def translate_file(
    request: Request,
    file: UploadFile = File(...),
    source_lang: str = Form(...),
    source_code: str = Form(...),
    target_lang: str = Form(...),
    target_code: str = Form(...),
    session_id: Optional[str] = Form(None),
    format: str = Form("docx")
):
    """Traduzione di un documento con salvataggio automatico.

    Supporta cancellazione cooperativa: se il client (browser) chiude la fetch
    via AbortController, il loop dei chunk rileva la disconnessione e termina
    entro 1 chunk al massimo invece di continuare a saturare Ollama.
    """
    try:
        temp_dir = settings.BASE_DIR / "temp" / "trans_uploads"
        temp_dir.mkdir(parents=True, exist_ok=True)

        file_path = temp_dir / file.filename
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Callback per cooperative cancellation: passato al chunk loop.
        async def _stop_check() -> bool:
            return await request.is_disconnected()

        success, result = await trans_processor.translate_document(
            str(file_path), source_lang, source_code, target_lang, target_code,
            stop_check=_stop_check
        )

        if os.path.exists(file_path):
            os.remove(file_path)

        if not success:
            if result == "ABORTED_BY_CLIENT":
                # Client ha chiuso la fetch; non sollevare 500 (la fetch è già morta).
                # Codice 499 = "Client Closed Request" (convenzione nginx).
                raise HTTPException(status_code=499, detail="Client closed request")
            raise HTTPException(status_code=500, detail=result)
            
        # Salva automaticamente
        base_name = Path(file.filename).stem
        ext = Path(file.filename).suffix.lower()
        
        if ext == '.srt':
            output_path = trans_processor.save_as_srt(result, base_name, target_lang)
        elif format == "docx":
            output_path = trans_processor.save_as_docx(result, base_name, target_lang)
        else:
            output_path = trans_processor.save_as_txt(result, base_name, target_lang)
            
        return {
            "success": True,
            "translated": result,
            "filename": file.filename,
            "export_file": os.path.basename(output_path)
        }
    except Exception as e:
        logger.error(f"Error in translate file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/translate/open-file/{filename}")
async def open_trans_file(filename: str):
    """
    Apre fisicamente un file di traduzione nella cartella TRANSLATION.
    """
    try:
        from backend_config.project_manager import project_manager
        output_dir = project_manager.get_path("output") / "TRANSLATION"
        file_path = output_dir / filename
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"File {filename} non trovato")
            
        path_str = str(file_path.absolute())
        
        if os.name == 'nt':
            os.startfile(path_str)
        else: # macOS/Linux
            import subprocess
            opener = "open" if os.uname().sysname == "Darwin" else "xdg-open"
            subprocess.call([opener, path_str])
            
        return {"success": True, "message": f"File {filename} aperto"}
    except Exception as e:
        logger.error(f"Error opening translation file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

