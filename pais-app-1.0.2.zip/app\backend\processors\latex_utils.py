"""
LaTeX utilities for export.
Copied from NiceGUI modules/common/latex_utils.py
Used by export_manager for Pandoc DOCX conversion.
"""
import re
import binascii


def normalize_latex_for_pandoc(text: str) -> str:
    """
    Pandoc supports various formats, but for DOCX dollars are most stable.
    Ensures no stray backslashes confuse Pandoc.
    """
    if not text:
        return text

    # 0. Cleanup: Remove markdown code blocks wrapping LaTeX
    # Otherwise Pandoc treats them as literal text (CodeBlock)
    cleaned = re.sub(r'```latex\s*(\\\[[\s\S]*?\\\]|[\s\S]*?)\s*```', r'\1', text)
    cleaned = re.sub(r'```\s*(\\\[[\s\S]*?\\\])\s*```', r'\1', cleaned)

    # 1. Normalize IA delimiters (\\[ \\]) to classic dollars ($$ $$)
    normalized = re.sub(r'\\+\[\s*([\s\S]*?)\s*\\+\]', r'$$\1$$', cleaned)
    normalized = re.sub(r'\\+\(\s*([\s\S]*?)\s*\\+\)', r'$\1$', normalized)

    # 2. PANDOC REQUIREMENT for DOCX: $$ blocks MUST have blank line above and below.
    # Also force formula to line-break after $$ for max compatibility.
    normalized = re.sub(r'\s*\$\$(.*?)\$\$\s*', r'\n\n$$\n\1\n$$\n\n', normalized, flags=re.DOTALL)

    # Clean up triple+ newlines
    normalized = re.sub(r'\n{3,}', r'\n\n', normalized)

    return normalized.strip()
