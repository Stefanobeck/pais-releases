"""
Custom AI Profiles Service — CRUD su profili custom dell'utente.

Storage UNIVERSALE (non per progetto): `<BASE_DIR>/user_data/custom_profiles.json`.
I profili custom sono condivisi tra tutti i progetti dell'utente.

ID generato server-side come `custom_<slug-name>` per garantire zero collisione
con i built-in (nessun built-in inizia con 'custom_').
"""

import json
import logging
import os
import re
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ─── Costanti di validazione ─────────────────────────────────────────────
NAME_MAX = 60
DESCRIPTION_MAX = 200
PROMPT_MIN = 100
PROMPT_MAX = 10000
ID_PREFIX = "custom_"
ID_RE = re.compile(r"^custom_[a-z0-9_]{1,40}$")

# Whitelist icone Material Symbols accettabili. Altri valori → fallback "tune".
ALLOWED_ICONS = {
    "tune", "bolt", "balance", "gavel", "summarize", "bar_chart", "verified_user",
    "transform", "table_convert", "campaign", "movie", "history_edu", "school",
    "menu_book", "auto_awesome", "psychology", "smart_toy", "lightbulb",
    "engineering", "medical_information", "biotech", "code",
}


def _slugify(name: str) -> str:
    """Converte un nome in slug filesystem-safe (a-z, 0-9, _)."""
    s = name.lower().strip()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s[:40] or "profile"


class CustomProfilesService:
    """Singleton CRUD per profili AI personalizzati dell'utente."""

    _instance: Optional["CustomProfilesService"] = None
    _instance_lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._init()
        return cls._instance

    def _init(self):
        self._write_lock = threading.Lock()

    def _get_path(self) -> Path:
        """Path del custom_profiles.json (universal, fuori da qualsiasi progetto)."""
        from backend_config.settings import settings
        user_data = Path(settings.BASE_DIR) / "user_data"
        user_data.mkdir(parents=True, exist_ok=True)
        return user_data / "custom_profiles.json"

    def _read_raw(self) -> Dict[str, Any]:
        """Legge il file. Ritorna struttura vuota se non esiste o corrotto."""
        path = self._get_path()
        if not path.exists():
            return {"version": 1, "profiles": []}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or "profiles" not in data:
                logger.warning(f"custom_profiles.json malformato; ricreo struttura vuota")
                return {"version": 1, "profiles": []}
            return data
        except json.JSONDecodeError as e:
            logger.error(f"custom_profiles.json corrotto ({e}); fallback a struttura vuota")
            return {"version": 1, "profiles": []}
        except Exception as e:
            logger.error(f"Errore lettura custom_profiles.json: {e}")
            return {"version": 1, "profiles": []}

    def _write_atomic(self, data: Dict[str, Any]) -> None:
        """Scrittura atomica via tmp + os.replace per evitare corruzione."""
        path = self._get_path()
        with self._write_lock:
            tmp_fd, tmp_name = tempfile.mkstemp(
                suffix=".json", prefix=".custom_profiles.", dir=str(path.parent)
            )
            try:
                with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write("\n")
                os.replace(tmp_name, path)
            except Exception:
                try:
                    os.remove(tmp_name)
                except Exception:
                    pass
                raise

    # ─── Validation helpers ───────────────────────────────────────────────

    @staticmethod
    def _validate_inputs(name: str, system_prompt: str, description: str = "", icon: str = "tune") -> Dict[str, Any]:
        """Sanitizza e valida. Solleva ValueError con messaggio user-facing su errore."""
        # Name
        n = (name or "").strip()
        if not n:
            raise ValueError("Il nome del profilo è obbligatorio.")
        if len(n) > NAME_MAX:
            raise ValueError(f"Il nome supera i {NAME_MAX} caratteri.")
        # No control chars
        if any(ord(c) < 32 for c in n):
            raise ValueError("Il nome contiene caratteri non validi.")

        # Description
        d = (description or "").strip()
        if len(d) > DESCRIPTION_MAX:
            raise ValueError(f"La descrizione supera i {DESCRIPTION_MAX} caratteri.")

        # System prompt
        sp = (system_prompt or "").strip()
        if len(sp) < PROMPT_MIN:
            raise ValueError(f"Il system prompt è troppo corto (minimo {PROMPT_MIN} caratteri).")
        if len(sp) > PROMPT_MAX:
            raise ValueError(f"Il system prompt supera i {PROMPT_MAX} caratteri.")

        # Icon
        ic = (icon or "tune").strip()
        if ic not in ALLOWED_ICONS:
            ic = "tune"

        return {"name": n, "description": d, "system_prompt": sp, "icon": ic}

    # ─── Public API ───────────────────────────────────────────────────────

    def list_profiles(self) -> List[Dict[str, Any]]:
        """Ritorna tutti i custom profiles con flag is_custom=True."""
        data = self._read_raw()
        out = []
        for p in data.get("profiles", []):
            out.append({**p, "is_custom": True})
        return out

    def get_profile(self, profile_id: str) -> Optional[Dict[str, Any]]:
        """Lookup per ID. Ritorna None se non trovato."""
        if not profile_id or not profile_id.startswith(ID_PREFIX):
            return None
        for p in self._read_raw().get("profiles", []):
            if p.get("id") == profile_id:
                return {**p, "is_custom": True}
        return None

    def _make_unique_id(self, base_slug: str, existing_ids: set) -> str:
        """Genera ID con suffix incrementale se collide."""
        candidate = f"{ID_PREFIX}{base_slug}"
        if candidate not in existing_ids:
            return candidate
        for i in range(2, 1000):
            cand = f"{ID_PREFIX}{base_slug}_{i}"
            if cand not in existing_ids:
                return cand
        # fallback: timestamp
        return f"{ID_PREFIX}{base_slug}_{int(datetime.now().timestamp())}"

    def create(self, name: str, system_prompt: str, description: str = "", icon: str = "tune") -> Dict[str, Any]:
        """Crea un nuovo profilo. Ritorna il profilo completo (con id assegnato)."""
        validated = self._validate_inputs(name, system_prompt, description, icon)
        data = self._read_raw()
        existing_ids = {p.get("id") for p in data.get("profiles", [])}

        slug = _slugify(validated["name"])
        new_id = self._make_unique_id(slug, existing_ids)
        now = datetime.now(timezone.utc).isoformat()

        profile = {
            "id": new_id,
            "name": validated["name"],
            "description": validated["description"],
            "system_prompt": validated["system_prompt"],
            "icon": validated["icon"],
            "created_at": now,
            "updated_at": now,
        }
        data["profiles"].append(profile)
        self._write_atomic(data)
        logger.info(f"✅ Custom profile created: {new_id}")
        return {**profile, "is_custom": True}

    def update(self, profile_id: str, name: str, system_prompt: str, description: str = "", icon: str = "tune") -> Dict[str, Any]:
        """Aggiorna un profilo esistente. Solleva ValueError(404) se non esiste."""
        if not ID_RE.match(profile_id):
            raise ValueError(f"ID profilo non valido: {profile_id}")
        validated = self._validate_inputs(name, system_prompt, description, icon)

        data = self._read_raw()
        for p in data.get("profiles", []):
            if p.get("id") == profile_id:
                p["name"] = validated["name"]
                p["description"] = validated["description"]
                p["system_prompt"] = validated["system_prompt"]
                p["icon"] = validated["icon"]
                p["updated_at"] = datetime.now(timezone.utc).isoformat()
                self._write_atomic(data)
                logger.info(f"✅ Custom profile updated: {profile_id}")
                return {**p, "is_custom": True}
        raise LookupError(f"Profilo non trovato: {profile_id}")

    def delete(self, profile_id: str) -> bool:
        """Elimina un profilo. Ritorna True se cancellato, False se non esisteva."""
        if not ID_RE.match(profile_id):
            raise ValueError(f"ID profilo non valido: {profile_id}")
        data = self._read_raw()
        before = len(data.get("profiles", []))
        data["profiles"] = [p for p in data.get("profiles", []) if p.get("id") != profile_id]
        after = len(data["profiles"])
        if after == before:
            return False
        self._write_atomic(data)
        logger.info(f"🗑️ Custom profile deleted: {profile_id}")
        return True


# Singleton globale
custom_profiles_service = CustomProfilesService()
