"""
DuckDB technical knowledge base — seeds the per-project `tech_rag` ChromaDB
with concise, example-rich snippets so the SQL generator gets the right
DuckDB-specific guidance via retrieval (the prompt template already injects
the result of `tech_rag.get_context(query, limit=3)`).

Why this exists: qwen3-coder is trained heavily on PostgreSQL / MySQL /
BigQuery / Snowflake; on DuckDB it leaks dialect (date_sub, DATEADD, IIF,
date_part on table-names, etc.). The regression suite (404/420 nominal, but
60% strictly-correct on a semantic sample of 25) showed that most SQL retries
hit date-function dialect bugs. This KB is the second layer of defense after
the explicit cheatsheet in the system prompt.

Seeded under stable `source` ids (`duckdb_kb_<topic>__v<N>`); re-running the
seeder upgrades them in place. Version bump (`KB_VERSION`) invalidates the
cached entries automatically.
"""
from __future__ import annotations

import logging
from typing import List, Tuple

logger = logging.getLogger("PAIS.DuckdbKB")


# Bump this when documents change so existing per-project ChromaDB caches
# get refreshed automatically on the next ManipulateService boot.
KB_VERSION = 1
KB_MARKER_SOURCE = f"duckdb_kb_marker__v{KB_VERSION}"


# Each entry is (topic, body). `topic` is a stable identifier used as ChromaDB
# `source` field — letting us delete-then-reingest cleanly on version bumps.
DOCUMENTS: List[Tuple[str, str]] = [
    (
        "date_functions",
        """DuckDB DATE & TIMESTAMP — definitive reference.

Use ONLY these forms:
- Current date / time:        CURRENT_DATE         CURRENT_TIMESTAMP        now()
- Extract a date part:        EXTRACT(year FROM table.col)      EXTRACT(month FROM table.col)      EXTRACT(quarter FROM table.col)      EXTRACT(week FROM table.col)      EXTRACT(dayofweek FROM table.col)
- Days between two dates:     date_diff('day', start_col, end_col)         -- returns BIGINT
- Months between two dates:   date_diff('month', start_col, end_col)
- Add N days:                 col + INTERVAL N DAY                          -- N is an integer literal, NOT a quoted string
- Subtract N days:            col - INTERVAL N DAY
- Add N months:               col + INTERVAL N MONTH
- Truncate to month:          date_trunc('month', col)                      -- returns a TIMESTAMP at the first day of the month
- Truncate to quarter:        date_trunc('quarter', col)
- Format a date:              strftime(col, '%Y-%m')                        -- e.g. '2026-05'
- Cast text → date:           CAST(col AS DATE)
- First/last day of month:    date_trunc('month', col)                      and date_trunc('month', col) + INTERVAL 1 MONTH - INTERVAL 1 DAY

NEVER use these — they are MySQL / T-SQL / BigQuery and WILL FAIL in DuckDB:
- date_sub(d, INTERVAL n day)         → use:   d - INTERVAL n DAY
- date_add(d, INTERVAL n day)         → use:   d + INTERVAL n DAY
- DATEADD(day, n, d) / DATEDIFF(...)  → use:   d + INTERVAL n DAY  /  date_diff('day', a, b)
- date_part('year', col)              → use:   EXTRACT(year FROM col)
- STR_TO_DATE(...) / TO_DATE(...)     → use:   CAST(col AS DATE)
- IIF(cond, a, b)                     → use:   CASE WHEN cond THEN a ELSE b END

CRITICAL: when passing a column to ANY date function you MUST reference the column
explicitly. Passing only the table is invalid syntax — DuckDB will say
"date_part(STRING_LITERAL, STRUCT(...))" or similar.
   WRONG:   EXTRACT(year FROM employees)
   RIGHT:   EXTRACT(year FROM employees.Data_Assunzione)
""",
    ),
    (
        "percentage_columns",
        """DuckDB — handling percentage columns.

Smart Cleaning of input files stores every column whose name contains
'Perc', 'Percentage', 'Rate', '%' in DECIMAL form (0.0 to 1.0). For example,
a 15% discount lives in the column as 0.15, never 15.

Consequences in SQL:
- DO NOT divide by 100 again when using these columns.
- Multiply by (1 - Sconto_Perc), NOT (1 - Sconto_Perc/100).
- When the user wants the result formatted "as a %", multiply by 100.0 in the
  SELECT, but the raw column stays decimal.

Example — net revenue with discount:
   SELECT
     Prezzo_Listino * Quantita * (1 - Sconto_Perc) AS Ricavo_Netto
   FROM vendite_2026

Example — average discount expressed as percent:
   SELECT AVG(Sconto_Perc) * 100.0 AS Sconto_Medio_Pct
   FROM vendite_2026
""",
    ),
    (
        "grouping_dimensions",
        """DuckDB — GROUP BY semantics & the "per X" rule.

If the user's request contains a dimensioning phrase:
- "per X" / "by X" / "for each X" / "per ogni X" / "a livello di X" / "split by X"
then X MUST appear in the SELECT clause AND in GROUP BY. Never collapse to a
single global value when a dimension is requested.

WRONG (over-aggregation — collapses dimension):
   -- Prompt: "Calcola la variazione percentuale media per Mese"
   SELECT AVG(Variazione_Perc) FROM budget_2026;            -- returns one row

RIGHT:
   SELECT Mese, AVG(Variazione_Perc) AS media
   FROM budget_2026
   GROUP BY Mese
   ORDER BY Mese;

When grouping by a derived dimension (e.g. month from a date), repeat the
expression in GROUP BY (or use the alias since DuckDB allows it):
   SELECT date_trunc('month', Data_Ordine) AS mese, SUM(Quantita)
   FROM vendite_2026
   GROUP BY mese
   ORDER BY mese;

Multi-dimensional rollup: list every non-aggregated column in GROUP BY.
   SELECT Agente, Regione, SUM(Prezzo_Listino * Quantita) AS Revenue
   FROM vendite_2026
   GROUP BY Agente, Regione;
""",
    ),
    (
        "division_and_nullif",
        """DuckDB — safe division, integer promotion, NULLIF.

Two pitfalls to avoid:
1. Division by zero throws / returns NULL inconsistently. Always wrap the
   denominator in NULLIF(..., 0):
       SUM(revenue) * 1.0 / NULLIF(SUM(cost), 0)
2. Integer / integer = integer (truncates). Multiply the numerator by 1.0 or
   cast to DOUBLE to get a real ratio:
       COUNT(returns) * 1.0 / NULLIF(COUNT(*), 0)               -- gives 0.07
       COUNT(returns) / NULLIF(COUNT(*), 0)                      -- gives 0  (wrong)

Type rules: use 'DOUBLE' for floats, NEVER 'FLOAT64' (BigQuery-only). When the
final value should be a percentage, multiply by 100.0 in the SELECT:
   SUM(returns) * 100.0 / NULLIF(SUM(orders), 0) AS return_rate_pct
""",
    ),
    (
        "window_functions",
        """DuckDB — window functions for MoM / running totals / ranking.

Window functions go in SELECT, NEVER inside an aggregate. The pattern below
fails in DuckDB ("aggregate function calls cannot contain window function calls"):
   SUM(COUNT(*) OVER (PARTITION BY ...))               -- WRONG

Correct: use a CTE to compute the windowed value first, then aggregate.
   WITH monthly AS (
     SELECT date_trunc('month', Data_Ordine) AS mese, SUM(Prezzo_Listino * Quantita) AS rev
     FROM vendite_2026 GROUP BY mese
   )
   SELECT mese, rev, LAG(rev) OVER (ORDER BY mese) AS prev_rev,
          (rev - LAG(rev) OVER (ORDER BY mese)) * 100.0 /
            NULLIF(LAG(rev) OVER (ORDER BY mese), 0) AS mom_pct
   FROM monthly
   ORDER BY mese;

MoM growth rule: LAG/LEAD ONLY over a date/month dimension. NEVER apply LAG
between unrelated categorical rows (e.g. between 'Completato' and 'Annullato')
— the result would be meaningless.

Ranking: ROW_NUMBER() OVER (PARTITION BY x ORDER BY y DESC) — use to pick
top-N per group. Top-5 by revenue per region:
   SELECT * FROM (
     SELECT Regione, Agente, SUM(Prezzo_Listino*Quantita) AS rev,
            ROW_NUMBER() OVER (PARTITION BY Regione ORDER BY SUM(Prezzo_Listino*Quantita) DESC) AS rk
     FROM vendite_2026 GROUP BY Regione, Agente
   ) WHERE rk <= 5;
""",
    ),
    (
        "pareto_and_cumulative",
        """DuckDB — Pareto 80/20 and cumulative analyses.

A Pareto "who generates 80% of X" is NOT a flat list of values. It needs a
sorted cumulative percentage and a filter.

   WITH ranked AS (
     SELECT Agente, SUM(Prezzo_Listino * Quantita) AS rev
     FROM vendite_2026 GROUP BY Agente
   ),
   cum AS (
     SELECT Agente, rev,
            SUM(rev) OVER (ORDER BY rev DESC) AS cum_rev,
            SUM(rev) OVER ()                  AS tot_rev
     FROM ranked
   )
   SELECT Agente, rev, cum_rev * 100.0 / NULLIF(tot_rev, 0) AS cum_pct
   FROM cum
   WHERE cum_rev * 1.0 / NULLIF(tot_rev, 0) <= 0.80
   ORDER BY rev DESC;

A "Pareto" output that doesn't include a cumulative percent is WRONG —
re-read the request and include cum_pct.
""",
    ),
]


def topic_source_id(topic: str) -> str:
    """Stable per-topic source name used in ChromaDB (so we can find & delete)."""
    return f"duckdb_kb_{topic}__v{KB_VERSION}"


async def is_seeded(tech_rag) -> bool:
    """True if this project's tech_rag already contains the current KB version."""
    try:
        results = tech_rag.collection.get(where={"source": KB_MARKER_SOURCE}, include=[])
        return bool(results and results.get("ids"))
    except Exception as e:
        logger.warning(f"is_seeded check failed: {e}")
        return False


def _delete_old_versions(tech_rag) -> int:
    """Remove every duckdb_kb_* entry whose version differs from KB_VERSION.

    Idempotent. Safe to call when nothing's there.
    """
    removed = 0
    try:
        # ChromaDB doesn't support LIKE filters; fetch everything once and
        # client-filter. The collection is tiny so this is fine.
        all_meta = tech_rag.collection.get(include=["metadatas"])
        ids = all_meta.get("ids") or []
        metas = all_meta.get("metadatas") or []
        to_remove = [
            ids[i] for i, m in enumerate(metas)
            if isinstance(m, dict)
            and isinstance(m.get("source"), str)
            and m["source"].startswith("duckdb_kb_")
            and not m["source"].endswith(f"__v{KB_VERSION}")
        ]
        if to_remove:
            tech_rag.collection.delete(ids=to_remove)
            removed = len(to_remove)
    except Exception as e:
        logger.warning(f"old-version cleanup failed: {e}")
    return removed


async def seed(tech_rag, force: bool = False) -> dict:
    """Seed (or reseed) the DuckDB knowledge base into `tech_rag`.

    Returns a small summary dict: {seeded, skipped, removed_old, version}.
    """
    if not force and await is_seeded(tech_rag):
        return {"seeded": 0, "skipped": len(DOCUMENTS), "removed_old": 0, "version": KB_VERSION}

    removed_old = _delete_old_versions(tech_rag)

    seeded = 0
    for topic, body in DOCUMENTS:
        source_id = topic_source_id(topic)
        try:
            # If a same-version copy already exists, drop it first so re-ingest
            # doesn't grow the collection on repeated calls.
            existing = tech_rag.collection.get(where={"source": source_id}, include=[])
            if existing and existing.get("ids"):
                tech_rag.collection.delete(ids=existing["ids"])
        except Exception as e:
            logger.warning(f"pre-delete {source_id} failed: {e}")
        ok, msg = await tech_rag.ingest_text(body, source_name=source_id)
        if ok:
            seeded += 1
        else:
            logger.warning(f"ingest {source_id} failed: {msg}")

    # Drop a tiny marker so is_seeded() short-circuits next time.
    try:
        await tech_rag.ingest_text(
            f"DuckDB tech KB marker. Version {KB_VERSION}. Do not edit.",
            source_name=KB_MARKER_SOURCE,
        )
    except Exception as e:
        logger.warning(f"marker ingest failed: {e}")

    logger.info(f"DuckDB tech KB seeded: {seeded}/{len(DOCUMENTS)} docs, removed {removed_old} stale.")
    return {"seeded": seeded, "skipped": 0, "removed_old": removed_old, "version": KB_VERSION}
