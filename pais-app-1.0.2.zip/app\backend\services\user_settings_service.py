"""
User Settings Service - Centralized read/write for user_settings.json.

Storage: {BASE_DIR}/user_settings.json. Schema (only fields owned by this service;
existing keys like tos_accepted / telegram are managed by SystemService and left
untouched by this wrapper):

    {
      "system_profile": { "mode": "auto" | "manual", "value": "HIGH" | "LOW" | null },
      "interrogate_custom_models": ["llama3:8b", ...]
    }

mode="auto" → value is ignored, runtime profile derives from hardware detection.
mode="manual" → value is authoritative.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import List, Optional

from backend_config import settings

logger = logging.getLogger("PAIS.UserSettings")

VALID_PROFILES = ("HIGH", "LOW")
VALID_MODES = ("auto", "manual")


def _settings_path() -> Path:
    return settings.BASE_DIR / "user_settings.json"


def _read_all() -> dict:
    p = _settings_path()
    if not p.exists():
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        logger.error(f"user_settings.json read failed: {e}")
        return {}


def _write_all(data: dict) -> bool:
    p = _settings_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"user_settings.json write failed: {e}")
        return False


# ─── System profile (HIGH/LOW) ──────────────────────────────────────────────

def get_system_profile() -> dict:
    """Return {mode, value}. Defaults to {'auto', None}."""
    data = _read_all()
    sp = data.get("system_profile") or {}
    mode = sp.get("mode") if sp.get("mode") in VALID_MODES else "auto"
    value = sp.get("value") if sp.get("value") in VALID_PROFILES else None
    return {"mode": mode, "value": value}


def set_system_profile(mode: str, value: Optional[str] = None) -> bool:
    """Persist a new profile selection. Validates mode/value."""
    if mode not in VALID_MODES:
        raise ValueError(f"Invalid mode: {mode}. Must be one of {VALID_MODES}")
    if mode == "manual":
        if value not in VALID_PROFILES:
            raise ValueError(f"Manual mode requires value in {VALID_PROFILES}")
    data = _read_all()
    data["system_profile"] = {
        "mode": mode,
        "value": value if mode == "manual" else None,
    }
    return _write_all(data)


def get_active_profile_id(recommended: Optional[str] = None) -> str:
    """Resolve the currently active profile id (HIGH or LOW).

    - mode=manual → returns the persisted value
    - mode=auto   → returns `recommended` if provided and valid, else "HIGH" fallback
    """
    sp = get_system_profile()
    if sp["mode"] == "manual" and sp["value"] in VALID_PROFILES:
        return sp["value"]
    if recommended in VALID_PROFILES:
        return recommended
    return "HIGH"  # fallback safe default


# ─── Enabled modules (utente sceglie quali moduli attivare dalla pagina AI Setup) ──
# I 5 moduli core dell'app. UTILITY include i suoi tool individuali (gestiti
# separatamente via UTILITY_TOOL_DEPS sul frontend).
VALID_ENABLED_MODULES = ("interrogate", "vision", "manipulate", "anonimyze", "utility")


def get_enabled_modules() -> List[str]:
    """Return the list of modules the user has chosen to enable.

    Default: TUTTI i 5 moduli (decisione product 2026-05-28). Se l'utente entra
    in un modulo senza i suoi modelli installati, l'overlay "scarica i modelli"
    lo guida al Setup. Meglio mostrare tutto aperto che tutto grigio:
    discovery del valore prima, frizione dopo. La chiave del fix e' che ora
    il fresh install non parte con [] (lista vuota = utente vede tutto disabled),
    ma con tutti i moduli abilitati.

    Se l'utente ha esplicitamente disabilitato qualcosa via UI, viene rispettato
    (la chiave 'enabled_modules' nel file di settings esiste come lista vuota
    o ridotta, e questo branch e' bypassato).
    """
    data = _read_all()
    # Se la chiave esiste (anche come [] esplicito), rispetta la scelta utente.
    if "enabled_modules" in data:
        raw = data.get("enabled_modules") or []
        if not isinstance(raw, list):
            return list(VALID_ENABLED_MODULES)
        return [m for m in raw if isinstance(m, str) and m in VALID_ENABLED_MODULES]
    # Default fresh install: tutti i 5 moduli abilitati.
    return list(VALID_ENABLED_MODULES)


def set_enabled_modules(modules: List[str]) -> List[str]:
    """Persist the list of enabled modules. Whitelist-filtered + deduped.
    Returns the persisted list (cosi' il chiamante puo' echo back la verita').
    """
    if not isinstance(modules, list):
        raise ValueError("modules must be a list")
    # Whitelist + dedup mantenendo ordine
    seen: set = set()
    clean: List[str] = []
    for m in modules:
        if isinstance(m, str) and m in VALID_ENABLED_MODULES and m not in seen:
            clean.append(m)
            seen.add(m)
    data = _read_all()
    data["enabled_modules"] = clean
    _write_all(data)
    return clean


# Mappa modulo → modelli minimi richiesti per considerarlo "abilitabile".
# Usata solo dalla migrazione one-shot al primo avvio post-upgrade.
# Utility è omessa: troppo eterogenea (per-tool), preferiamo che l'utente la
# attivi esplicitamente.
_MODULE_MIN_REQUIREMENTS = {
    "interrogate": ["gemma4:e4b"],
    "vision": ["gemma4:e4b"],
    "manipulate": ["qwen3-coder:30b", "qwen2.5-coder:7b"],
    "anonimyze": ["onnx-community/multilang-pii-ner-ONNX", "xx_ent_wiki_sm"],
}

# Moduli per cui basta UNO dei requisiti (alternative), non tutti.
# Manipulate: i due coder sono alternative (HIGH RAM / LOW RAM) → ne basta uno.
_MODULE_ANY_OF = {"manipulate"}


def _model_matches(req: str, installed_names: List[str]) -> bool:
    """Loose match req vs installed (gestisce 'name' vs 'name:tag')."""
    for inst in installed_names:
        if not inst:
            continue
        if req == inst or inst.startswith(req + ":") or (":" not in req and inst.startswith(req)):
            return True
    return False


def auto_detect_and_persist_enabled_modules(installed_names: List[str]) -> List[str]:
    """Migrazione one-shot: se enabled_modules e' vuoto e l'utente ha gia' modelli
    installati (es. upgrade da versione precedente a questa feature), popola la
    lista auto-derivata dai requisiti minimi. Idempotente: se enabled_modules
    e' gia' popolato, non tocca niente.

    Chiamato dal GET /api/system/enabled_modules per evitare la confusione
    "perche' il mio modulo e' bloccato anche se ho gia' i modelli installati?".
    """
    current = get_enabled_modules()
    if current:
        # Lista gia' popolata — nessuna migrazione necessaria.
        return current
    if not installed_names:
        # Nessun modello installato → niente da migrare, utente sceglie da zero.
        return []
    auto: List[str] = []
    for module, reqs in _MODULE_MIN_REQUIREMENTS.items():
        match_fn = any if module in _MODULE_ANY_OF else all
        if match_fn(_model_matches(r, installed_names) for r in reqs):
            auto.append(module)
    if auto:
        logger.info(
            f"Migration: auto-enabling modules {auto} based on installed models"
        )
        return set_enabled_modules(auto)
    return []


# ─── Per-module custom models (user-installed Ollama models added to picker) ──

VALID_MODULES = ("interrogate", "vision", "manipulate")


def _custom_models_key(module: str) -> str:
    if module not in VALID_MODULES:
        raise ValueError(f"Invalid module '{module}'. Must be one of {VALID_MODULES}")
    return f"{module}_custom_models"


def get_custom_models(module: str) -> List[str]:
    key = _custom_models_key(module)
    data = _read_all()
    raw = data.get(key) or []
    if not isinstance(raw, list):
        return []
    return [m for m in raw if isinstance(m, str) and m.strip()]


def add_custom_model(module: str, model_id: str) -> bool:
    key = _custom_models_key(module)
    model_id = (model_id or "").strip()
    if not model_id:
        raise ValueError("model_id is required")
    data = _read_all()
    current = data.get(key) or []
    if not isinstance(current, list):
        current = []
    if model_id in current:
        return True  # idempotent
    current.append(model_id)
    data[key] = current
    return _write_all(data)


def remove_custom_model(module: str, model_id: str) -> bool:
    key = _custom_models_key(module)
    model_id = (model_id or "").strip()
    if not model_id:
        return False
    data = _read_all()
    current = data.get(key) or []
    if not isinstance(current, list) or model_id not in current:
        return False
    current.remove(model_id)
    data[key] = current
    return _write_all(data)


# ─── Custom models native context_length (AUTO-detect via Ollama /api/show) ──
# Storage in user_settings.json:
#   "custom_models_ctx": { "llama3:8b": 8192, "qwen2.5:14b": 32768, ... }
#
# Senza questa cache, Ollama tronca silenziosamente le request che superano
# il context_length nativo del modello (es. PAIS chiede num_ctx=131072 a un
# modello che ne supporta 8192 → risposta degradata, nessun warning).
# Il valore viene scritto al momento dell'add custom model dal catalog_service
# tramite ollama_client.get_model_context_length() e letto da ollama_client
# come tetto per il dynamic ctx budget.

def get_custom_models_ctx() -> dict:
    """Return {model_id: native_ctx} for all custom models with detected ctx."""
    data = _read_all()
    raw = data.get("custom_models_ctx") or {}
    if not isinstance(raw, dict):
        return {}
    out: dict = {}
    for k, v in raw.items():
        if isinstance(k, str) and isinstance(v, (int, float)) and v > 0:
            out[k] = int(v)
    return out


def set_custom_model_ctx(model_id: str, ctx: int) -> bool:
    model_id = (model_id or "").strip()
    if not model_id or not isinstance(ctx, int) or ctx <= 0:
        return False
    data = _read_all()
    current = data.get("custom_models_ctx") or {}
    if not isinstance(current, dict):
        current = {}
    current[model_id] = int(ctx)
    data["custom_models_ctx"] = current
    return _write_all(data)


def remove_custom_model_ctx(model_id: str) -> bool:
    model_id = (model_id or "").strip()
    if not model_id:
        return False
    data = _read_all()
    current = data.get("custom_models_ctx") or {}
    if not isinstance(current, dict) or model_id not in current:
        return False
    del current[model_id]
    data["custom_models_ctx"] = current
    return _write_all(data)


# ─── Backward-compat wrappers (kept so existing imports don't break) ──────────

def get_interrogate_custom_models() -> List[str]:
    return get_custom_models("interrogate")


def add_interrogate_custom_model(model_id: str) -> bool:
    return add_custom_model("interrogate", model_id)


def remove_interrogate_custom_model(model_id: str) -> bool:
    return remove_custom_model("interrogate", model_id)


# ─── Studio identity (header per export Word/PDF) ────────────────────────────

STUDIO_FIELDS = ("name", "address", "vat", "phone", "email", "website", "logo_path")


def get_studio_identity() -> Optional[dict]:
    """Return the studio identity block, or None if not configured.
    The block is None ONLY when never set (or all fields empty).
    """
    data = _read_all()
    s = data.get("studio_identity")
    if not isinstance(s, dict):
        return None
    cleaned = {k: (s.get(k) or "").strip() if isinstance(s.get(k), str) else None for k in STUDIO_FIELDS}
    if not any(cleaned.get(k) for k in ("name", "address", "vat", "phone", "email")):
        # Nessun campo significativo → consideriamo non configurato.
        return None
    return cleaned


def set_studio_identity(payload: dict) -> dict:
    """Persist the studio identity. Only known fields are accepted; empty strings
    are treated as None (campo non valorizzato). Returns the saved block.
    """
    if not isinstance(payload, dict):
        raise ValueError("Studio identity payload must be a dict")
    data = _read_all()
    current = data.get("studio_identity") or {}
    if not isinstance(current, dict):
        current = {}
    for k in STUDIO_FIELDS:
        if k in payload:
            v = payload.get(k)
            if v is None:
                current.pop(k, None)
            elif isinstance(v, str):
                v = v.strip()
                if v:
                    current[k] = v
                else:
                    current.pop(k, None)
            else:
                raise ValueError(f"Field '{k}' must be a string or None")
    data["studio_identity"] = current
    _write_all(data)
    return current


def set_studio_logo_path(logo_path: Optional[str]) -> dict:
    """Update only the logo_path (called dopo upload o delete del file)."""
    data = _read_all()
    current = data.get("studio_identity") or {}
    if not isinstance(current, dict):
        current = {}
    if logo_path:
        current["logo_path"] = logo_path
    else:
        current.pop("logo_path", None)
    data["studio_identity"] = current
    _write_all(data)
    return current


# ─── Studio export options (header/footer toggle) ─────────────────────────────

# Schemi colore disponibili per l'header studio (accent applicato a bordo +
# nome studio). 'blue' = look storico. Tenuti in sync col frontend.
STUDIO_HEADER_TEMPLATES = ("blue", "anthracite", "green", "bordeaux")
STUDIO_LOGO_POSITIONS = ("left", "center", "right")

# NB: il footer studio (disclaimer + hash) è stato RIMOSSO dal prodotto: gli
# export brandizzati mostrano solo l'header. `include_footer` non esiste più.
DEFAULT_STUDIO_EXPORT_OPTIONS = {
    "include_header": True,
    "header_template": "blue",
    "logo_position": "left",
}


def get_studio_export_options() -> dict:
    """Return {include_header, header_template, logo_position}. Default: header
    ON, template 'blue', logo a sinistra. Il footer non è più un'opzione."""
    data = _read_all()
    o = data.get("studio_export_options")
    if not isinstance(o, dict):
        return dict(DEFAULT_STUDIO_EXPORT_OPTIONS)
    tmpl = o.get("header_template", "blue")
    pos = o.get("logo_position", "left")
    return {
        "include_header": bool(o.get("include_header", True)),
        "header_template": tmpl if tmpl in STUDIO_HEADER_TEMPLATES else "blue",
        "logo_position": pos if pos in STUDIO_LOGO_POSITIONS else "left",
    }


def set_studio_export_options(include_header: bool, header_template: str = "blue",
                              logo_position: str = "left") -> dict:
    data = _read_all()
    data["studio_export_options"] = {
        "include_header": bool(include_header),
        "header_template": header_template if header_template in STUDIO_HEADER_TEMPLATES else "blue",
        "logo_position": logo_position if logo_position in STUDIO_LOGO_POSITIONS else "left",
    }
    _write_all(data)
    return data["studio_export_options"]


def get_studio_payload() -> Optional[dict]:
    """Studio identity arricchita con le opzioni export, pronta per gli
    exporter (chiavi `_show_header`, `_template`, `_logo_position`). Il footer è
    rimosso dal prodotto, quindi non viene mai impostato. Ritorna None se
    nessuna identity è configurata OPPURE se il tier non è pro/trial —
    il branding Studio è una funzione PRO a tempo (come Bot, Manipulate, ...):
    un utente free_residual ottiene export senza header brandizzato."""
    if not is_pro_or_trial():
        return None
    studio = get_studio_identity()
    if studio is None:
        return None
    opts = get_studio_export_options()
    studio["_show_header"] = bool(opts.get("include_header", True))
    studio["_template"] = opts.get("header_template", "blue")
    studio["_logo_position"] = opts.get("logo_position", "left")
    return studio


# ─── Interrogate Direct Mode (system prompt injection) ────────────────────────

def get_interrogate_direct_mode() -> bool:
    """Default: True. Quando ON, chat_service inietta l'istruzione DIRECT OUTPUT
    MODE nel system prompt per produrre risposte print-ready senza preamboli.
    """
    data = _read_all()
    v = data.get("interrogate_direct_mode")
    if v is None:
        return True
    return bool(v)


def set_interrogate_direct_mode(enabled: bool) -> bool:
    data = _read_all()
    data["interrogate_direct_mode"] = bool(enabled)
    _write_all(data)
    return bool(enabled)


# ─── Interrogate Compare Mode (document diff) ─────────────────────────────────

def get_interrogate_compare_mode() -> bool:
    """Default: False. Quando ON, l'upload Interrogate accetta max 2 file e il
    profilo AI è auto-switchato a 'document_compare' (4 sezioni Added/Removed/
    Modified/Moved con citazioni A vs B).
    """
    data = _read_all()
    return bool(data.get("interrogate_compare_mode", False))


def set_interrogate_compare_mode(enabled: bool) -> bool:
    data = _read_all()
    data["interrogate_compare_mode"] = bool(enabled)
    _write_all(data)
    return bool(enabled)


# ─── Account / License (dummy, Lemon Squeezy-compatible payload shape) ───────

# Solo "pro" è persistito davvero come tier. free_trial / free_residual
# sono stati DERIVATI runtime da first_install_at (vedi compute_effective_tier).
# "free" è mantenuto per backward-compat con vecchi user_settings.json.
VALID_TIERS = ("free", "pro")


def get_account() -> dict:
    """Return {tier, license_key, activated_at, expires_at, instance_id,
    customer_email}. Defaults when never activated: tier='free',
    everything else None.

    Schema is intentionally aligned with Lemon Squeezy's `licenses/activate`
    response so the frontend can stay unchanged when the dummy validation is
    swapped for the real provider call.

    `instance_id` is the LS activation instance — populated only when a key
    has been activated via real Lemon Squeezy (vs dummy "PRO" key). Used
    later for validate/deactivate calls against the same activation.
    """
    data = _read_all()
    a = data.get("account") or {}
    tier = a.get("tier") if a.get("tier") in VALID_TIERS else "free"
    return {
        "tier": tier,
        "license_key": a.get("license_key"),
        "activated_at": a.get("activated_at"),
        "expires_at": a.get("expires_at"),
        "instance_id": a.get("instance_id"),
        "customer_email": a.get("customer_email"),
    }


def set_account(
    tier: str,
    license_key: Optional[str],
    expires_at: Optional[str] = None,
    instance_id: Optional[str] = None,
    customer_email: Optional[str] = None,
) -> dict:
    """Persist the account block. `activated_at` is set to the current UTC time.

    Extra Lemon Squeezy fields (`instance_id`, `customer_email`) are
    optional — they stay None for dummy "PRO" activations and are only
    populated when the real Lemon Squeezy service activates a key.
    """
    if tier not in VALID_TIERS:
        raise ValueError(f"Invalid tier: {tier}. Must be one of {VALID_TIERS}")
    from datetime import datetime, timezone
    block = {
        "tier": tier,
        "license_key": license_key,
        "activated_at": datetime.now(timezone.utc).isoformat(),
        "expires_at": expires_at,
        "instance_id": instance_id,
        "customer_email": customer_email,
    }
    data = _read_all()
    data["account"] = block
    _write_all(data)


# ─── Lemon Squeezy webhook idempotency ───────────────────────────────────────

_MAX_WEBHOOK_EVENT_IDS = 200  # rolling window — older IDs are dropped


def webhook_event_already_processed(event_id: str) -> bool:
    """Idempotency check: returns True if this webhook event has already
    been seen. LS guarantees event_id uniqueness, so we use it as a
    deduplication key — protects against retry storms or duplicate
    deliveries from the LS side."""
    if not event_id:
        return False
    data = _read_all()
    seen = data.get("ls_webhook_event_ids") or []
    if not isinstance(seen, list):
        return False
    return event_id in seen


def mark_webhook_event_processed(event_id: str) -> None:
    """Record an event_id as processed. Keeps only the last
    `_MAX_WEBHOOK_EVENT_IDS` IDs to bound user_settings.json size.
    No-op when event_id is empty."""
    if not event_id:
        return
    data = _read_all()
    seen = data.get("ls_webhook_event_ids") or []
    if not isinstance(seen, list):
        seen = []
    if event_id in seen:
        return  # nothing to do
    seen.append(event_id)
    # Roll the window
    if len(seen) > _MAX_WEBHOOK_EVENT_IDS:
        seen = seen[-_MAX_WEBHOOK_EVENT_IDS:]
    data["ls_webhook_event_ids"] = seen
    _write_all(data)


def compute_effective_tier() -> dict:
    """Calcola il tier effettivo runtime combinando:
      - tier persistito (free / pro) + expires_at → PRO se valido
      - first_install_at da identity_service → FREE_TRIAL se entro durata trial
      - altrimenti → FREE_RESIDUAL

    NON scrive nulla: pura computazione su lettura.
    Ritorna:
      {
        "effective_tier": "free_trial" | "free_residual" | "pro",
        "first_install_at": ISO_string,
        "trial_seconds_total": int (durata trial configurata),
        "trial_seconds_left": int (>=0; 0 se fuori trial),
        "pro_seconds_left": int | None (None se non pro),
        "pro_expires_at": ISO_string | None,
      }
    """
    from datetime import datetime, timezone
    from services.identity_service import get_first_install_at, get_trial_seconds

    account = get_account()
    now = datetime.now(timezone.utc)
    trial_total = get_trial_seconds()
    first_install_iso = get_first_install_at()

    # Parse first_install_at robustamente
    try:
        first_install_dt = datetime.fromisoformat(first_install_iso)
        if first_install_dt.tzinfo is None:
            first_install_dt = first_install_dt.replace(tzinfo=timezone.utc)
    except Exception:
        first_install_dt = now  # fallback: trattalo come install adesso

    age_seconds = (now - first_install_dt).total_seconds()
    trial_seconds_left = max(0, int(trial_total - age_seconds))

    # PRO attivo?
    pro_seconds_left: Optional[int] = None
    pro_expires_at: Optional[str] = None
    is_pro_active = False
    if account.get("tier") == "pro" and account.get("expires_at"):
        try:
            expires_dt = datetime.fromisoformat(account["expires_at"])
            if expires_dt.tzinfo is None:
                expires_dt = expires_dt.replace(tzinfo=timezone.utc)
            delta = (expires_dt - now).total_seconds()
            if delta > 0:
                is_pro_active = True
                pro_seconds_left = int(delta)
                pro_expires_at = account["expires_at"]
        except Exception:
            pass

    if is_pro_active:
        effective = "pro"
    elif trial_seconds_left > 0:
        effective = "free_trial"
    else:
        effective = "free_residual"

    return {
        "effective_tier": effective,
        "first_install_at": first_install_iso,
        "trial_seconds_total": trial_total,
        "trial_seconds_left": trial_seconds_left,
        "pro_seconds_left": pro_seconds_left,
        "pro_expires_at": pro_expires_at,
    }


def is_pro_or_trial() -> bool:
    """Helper booleano per il backend gate sui moduli PRO-only."""
    eff = compute_effective_tier()
    return eff["effective_tier"] in ("pro", "free_trial")
    return block
