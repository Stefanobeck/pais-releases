"""Spot test for Tier 4 #5 (schema pre-validation) and #7 (implicit filter
disclosure). 10 prompts: 5 that failed in Tier 3 + 5 new for coverage.
Verifies: schema-mismatch warning fires; implicit-filter disclosure appears
in user message; previously-correct cases are not regressed.
"""
from __future__ import annotations
import asyncio, json, logging, re, shutil, sys, time, uuid
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "test_runs" / "manipulate_20260512_full" / "_spot_test_tier4.json"
INPUTS_DIR = ROOT / "test_runs" / "manipulate_20260512_full" / "inputs"
OUT_DIR = ROOT / "test_runs" / "manipulate_20260513_tier4_spot"
OUT_DIR.mkdir(parents=True, exist_ok=True)


class CaptureHandler(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.INFO)
        self.entries = []
    def emit(self, record):
        try:
            m = record.getMessage()
        except Exception:
            return
        if any(k in m for k in (
            "Schema mismatch detected", "Implicit filters disclosed",
            "Pareto completion failed", "Correlation validity failed",
            "Correlation intent missing", "Dialect Check failed",
            "SQL Execution failed", "Soft Validation failed",
        )):
            self.entries.append(m[:300])


async def main():
    prompts = json.load(SOURCE.open(encoding="utf-8"))
    print(f"Loaded {len(prompts)} prompts\n", flush=True)

    from services.manipulate_service import ManipulateService
    svc = ManipulateService()
    print(f"model: {svc.models.get('manipulate_model', 'unknown')}\n", flush=True)

    by_file = {}
    for p in prompts:
        by_file.setdefault(p["file"], []).append(p)

    results = []
    for file_name, entries in by_file.items():
        input_path = INPUTS_DIR / file_name
        if not input_path.exists():
            print(f"INPUT MISSING: {input_path}", flush=True); continue
        session_id = f"tier4-{uuid.uuid4().hex[:6]}"
        print(f"\n=== {file_name} (session {session_id}) ===", flush=True)
        up = await svc.upload_file(str(input_path), file_name, session_id, mode="Export to Sheet")
        if up.get("status") not in ("staged", "success"):
            print(f"upload failed: {up}", flush=True); continue
        mem = await svc.memorize_files(session_id, mode="Export to Sheet")
        if mem.get("status") != "success":
            print(f"memorize failed: {mem}", flush=True); continue

        for p in entries:
            print(f"\n[{p['area']} / {p['level']}] src={p['source']}#{p['src_idx']}", flush=True)
            print(f"  prompt: {p['prompt'][:140]!r}", flush=True)
            cap = CaptureHandler()
            svc_logger = logging.getLogger("services.manipulate_service")
            svc_logger.addHandler(cap)
            t0 = time.time()
            produced = None
            final_msg = ""
            try:
                async for ok, msg, files in svc.analyze(query=p['prompt'], session_id=session_id, mode="Export to Sheet"):
                    final_msg = msg
                    if files:
                        produced = files[0]
            except Exception as e:
                print(f"  EXC: {e}", flush=True)
            finally:
                svc_logger.removeHandler(cap)
            dt = time.time() - t0
            ok = produced is not None
            print(f"  → {'OK ' if ok else 'FAIL'} ({dt:.1f}s)", flush=True)
            schema_warn = any("Schema mismatch" in e for e in cap.entries)
            filter_disc = any("Implicit filters disclosed" in e for e in cap.entries)
            print(f"  schema-mismatch-warn: {schema_warn}  |  implicit-filter-discl: {filter_disc}", flush=True)
            if cap.entries:
                for e in cap.entries:
                    print(f"     {e[:200]}", flush=True)
            # Check if final msg contains the disclosure
            msg_has_disclosure = "Filtri impliciti applicati" in final_msg
            print(f"  final-msg-has-disclosure: {msg_has_disclosure}", flush=True)
            if ok and produced:
                safe = re.sub(r"[^\w\-]+", "_", f"{p['source']}_{p['src_idx']}").strip("_")
                target = OUT_DIR / f"{safe}.xlsx"
                for src in [Path(produced), *(Path.home() / "Documents" / "PAI_Files").rglob(Path(produced).name)]:
                    if src.exists():
                        try:
                            shutil.copy2(src, target)
                            break
                        except Exception:
                            pass
            results.append({
                "source": p["source"], "src_idx": p["src_idx"],
                "file": p["file"], "area": p["area"], "level": p["level"],
                "prompt": p["prompt"], "ok": ok, "duration_s": round(dt, 2),
                "schema_warn": schema_warn, "filter_disclosed": filter_disc,
                "final_msg_has_disclosure": msg_has_disclosure,
                "log_entries": cap.entries[:10],
            })
        try:
            svc.clear_session(session_id)
        except Exception:
            pass

    (OUT_DIR / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    n_ok = sum(1 for r in results if r["ok"])
    n_warn = sum(1 for r in results if r["schema_warn"])
    n_filt = sum(1 for r in results if r["final_msg_has_disclosure"])
    print(f"\n{'='*80}", flush=True)
    print(f"SUMMARY: {n_ok}/{len(results)} OK  |  {n_warn} schema-warnings fired  |  {n_filt} filter-disclosures shown", flush=True)
    print("="*80, flush=True)


if __name__ == "__main__":
    asyncio.run(main())
