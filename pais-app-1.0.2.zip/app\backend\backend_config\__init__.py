# Backend Config package
from .settings import settings

__all__ = ["settings"]
