"""
BGE Reranker Service - Cross-encoder reranking per RAG
Usa bbjson/bge-reranker-base via Ollama per valutare la rilevanza di ogni chunk.
Pipeline: Top 12 → Rerank → Top 8
"""
import asyncio
import logging
from typing import List, Dict, Optional
from ollama import AsyncClient

logger = logging.getLogger(__name__)


class BGEReranker:
    """
    Reranker basato su BGE (BAAI General Embedding) reranker.
    Il modello bbjson/bge-reranker-base restituisce un punteggio di rilevanza
    per ogni coppia query-document.
    """

    def __init__(self, model: str = "bbjson/bge-reranker-base:latest", host: str | None = None):
        # host obbligatorio: deve essere passato esplicitamente dal caller per
        # garantire che il reranker parli all'Ollama isolato di PAIS (porta 11435)
        # e non finisca per sbaglio su un Ollama di sistema (11434). Il default
        # storico era "http://127.0.0.1:11434" e poteva creare confusione.
        if not host:
            raise ValueError(
                "BGEReranker richiede un host esplicito (es. settings.OLLAMA_HOST_URL). "
                "Il default 11434 è stato rimosso per evitare interferenze con Ollama di sistema."
            )
        self.model = model
        self.client = AsyncClient(host=host)
        self._model_available = True  # disabilitato automaticamente al primo 404

    async def rerank(
        self,
        query: str,
        documents: List[Dict],
        top_k: int = 8,
        batch_size: int = 5
    ) -> List[Dict]:
        """
        Rerank documenti rispetto alla query usando BGE reranker.

        Args:
            query: Domanda utente
            documents: Lista di {"text": str, "score": float, "metadata": dict}
            top_k: Quanti risultati tenere dopo reranking
            batch_size: Quanti documenti processare in parallelo

        Returns:
            Documenti ordinati per rilevanza decrescente
        """
        if not documents:
            return []

        # Se ci sono pochi documenti, skip reranking
        if len(documents) <= top_k:
            return documents

        # Se il modello non è disponibile, restituisce i doc già ordinati da RRF
        if not self._model_available:
            return documents[:top_k]

        logger.info(f"🔄 BGE Reranking: {len(documents)} docs → top {top_k}")

        # Processa in batch per efficienza
        scored_docs = []
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            tasks = [self._score_document(query, doc) for doc in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for doc, result in zip(batch, results):
                if isinstance(result, Exception):
                    logger.warning(f"BGE rerank failed for doc: {result}")
                    doc['rerank_score'] = 0.0
                else:
                    doc['rerank_score'] = float(result)
                scored_docs.append(doc)

        # Ordina per rerank score decrescente
        scored_docs.sort(key=lambda d: d.get('rerank_score', 0), reverse=True)

        # Tieni solo top_k
        final = scored_docs[:top_k]
        scores = [f"{d.get('rerank_score', 0):.3f}" for d in final]
        logger.info(f"🔄 Rerank complete: {scores}")
        return final

    async def _score_document(self, query: str, doc: Dict) -> float:
        """
        Score rilevanza di un documento rispetto alla query usando BGE reranker.
        
        BGE reranker si aspetta un prompt nel formato:
        "query: <query>\ndocument: <document>"
        e restituisce un punteggio numerico.
        
        Returns: 0.0 - 1.0 (probabilità di rilevanza)
        """
        text = doc.get('text', '')[:2000]  # Trunca per efficienza (BGE gestisce ~512-8192 token)

        # Formato BGE reranker
        prompt = f"query: {query}\ndocument: {text}"

        try:
            response = await self.client.generate(
                model=self.model,
                prompt=prompt,
                options={"temperature": 0.0, "num_predict": 10, "top_p": 1.0}
            )
            score_text = response.get('response', '').strip()

            # Estrai il punteggio numerico
            import re
            # BGE può restituire: "0.85", "score: 0.85", "0.85\n", etc.
            match = re.search(r'(\d+\.?\d*)', score_text)
            if match:
                score = float(match.group(1))
                # Normalizza a 0-1
                return min(1.0, max(0.0, score))
            return 0.0

        except Exception as e:
            logger.warning(f"BGE score generation failed: {e}")
            # Marca il modello come non disponibile al primo 404 per evitare spam di errori
            if '404' in str(e) or 'not found' in str(e).lower():
                self._model_available = False
                logger.warning(f"BGE reranker model '{self.model}' not found — reranking disabled. Install it to enable.")
            return 0.0
