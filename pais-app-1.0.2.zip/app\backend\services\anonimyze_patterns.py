"""Single source of truth for Anonimyze regex patterns.

Until 2026-05, the IT (and DE/FR/UK/US/EN) patterns lived in TWO separate
places — one inside `anonimyze_service.py` (used by the tabular pipeline:
CSV/XLSX), and a partly-overlapping but narrower list inside
`text_advanced_anonymizer.py` (used by the text/PDF/DOCX pipeline). They
drifted, and a fix landed in one didn't take effect in the other (the
DENTICE legal-contract gap was caused by this drift).

This module collapses both into a single declarative dictionary plus
two views:

* `JURISDICTION_PATTERNS` — full multi-country mapping consumed by
  `AnonimyzeService._get_analyzer()` for tabular files. Entries are
  `(entity_type, regex, score)` tuples grouped by ISO country code.
* `get_it_text_patterns()` — the IT subset (+ a few language-neutral
  recognisers like IBAN/EMAIL/PHONE/ADDRESS_IT) consumed by
  `AdvancedTextAnonymizer._init_presidio()` for prose extracted from
  PDFs and DOCX files. Returns the same `(name, regex, score)` shape
  the Presidio `PatternRecognizer` expects.

Adding a new pattern? Add it HERE and verify both pipelines pick it up
via `tests/test_anonimyze_patterns.py`.
"""
import re
from pathlib import Path
from typing import List, Tuple

# Pattern shape used everywhere downstream.
PatternTuple = Tuple[str, str, float]


# ──────────────────────────────────────────────────────────────────────
# Lista ISTAT 7.875 comuni italiani (filtro len>=4 per evitare FP
# enormi su nomi cortissimi tipo "Ne", "Re", "Mu").
#
# Source: matteocontrini/comuni-json (mirror autorevole dati ISTAT).
# Snapshot scaricato il 2026-05-12. Aggiornare 1-2 volte/anno con:
#   curl -sL https://raw.githubusercontent.com/matteocontrini/comuni-json/master/comuni.json \
#     | python -c "import json,sys; print('\\n'.join(sorted({c['nome'] for c in json.load(sys.stdin) if len(c['nome'])>=4}, key=lambda s:(-len(s),s))))"  \
#     > pai-premium/backend/services/data/it_comuni.txt
# ──────────────────────────────────────────────────────────────────────
_COMUNI_FILE = Path(__file__).resolve().parent / "data" / "it_comuni.txt"


def _load_comuni() -> List[str]:
    """Read the comuni list once at import time."""
    if not _COMUNI_FILE.exists():
        return []
    return [ln.strip() for ln in _COMUNI_FILE.read_text(encoding="utf-8").splitlines() if ln.strip()]


_COMUNI_LIST = _load_comuni()

# Regex alternation chunk sorted longest-first so 'Reggio nell'Emilia'
# wins over 'Reggio'. Escape each name (handles apostrophes, accents).
_COMUNI_ALTERNATION = "|".join(re.escape(n) for n in _COMUNI_LIST)

# Case-insensitive set used by downstream filters to validate that a
# single-word LOCATION span is a real Italian comune (so the garbage
# filter can bypass the "no preposition context" check for it).
IT_COMUNI_SET = frozenset(n.lower() for n in _COMUNI_LIST)

# ──────────────────────────────────────────────────────────────────────
# Country / language mapping helpers
# ──────────────────────────────────────────────────────────────────────
COUNTRY_TO_LANG = {
    "IT": "it",
    "EN": "en",
    "DE": "de",
    "FR": "fr",
    "UK": "en",
    "US": "en",
    "NEUTRAL": "en",
}

# lang → country di default per auto-detection da langdetect.
LANG_TO_DEFAULT_COUNTRY = {
    "it": "IT",
    "de": "DE",
    "fr": "FR",
    "en": "EN",  # generic English: UK+US senza forzare la disambiguazione
}


# ──────────────────────────────────────────────────────────────────────
# IT — pattern master list
# ──────────────────────────────────────────────────────────────────────
# Order matters: LEGAL_REF first (blacklist must consume the span before
# PERSON/ORG sweep it). Deterministic ID codes next. Soft NER catch-alls
# (PERSON UPPERCASE) last.
_IT_PATTERNS: List[PatternTuple] = [
    # ─── LEGAL_REF (blacklist) ─ MUST be first ─────────────────────────
    # Riferimenti normativi pubblici. Catturati per consumare lo span (così
    # PERSON/ORG non li mis-taggano), NON sostituiti — vedi LEGAL_REF skip
    # nel loop di anonimizzazione e in apply_selected().
    ("LEGAL_REF",
     r"\b(?:art(?:icolo|t|icoli)?|comma|cpv|capoverso)\.?\s+\d{1,5}(?:[\-,]\s*\d{1,5})?(?:\s*(?:bis|ter|quater|quinquies|sexies|septies|octies|novies|decies))?(?:\s+(?:cod\.?\s*(?:civ\.?|pen\.?|proc\.?\s*civ\.?|proc\.?\s*pen\.?|nav\.?)|c\.?\s*c\.?|c\.?\s*p\.?\s*c\.?|D\.?\s*Lgs\.?|D\.?\s*L\.?|D\.?\s*P\.?\s*R\.?|L\.?\s+\d+))?\b",
     0.95),
    ("LEGAL_REF", r"\bD\.?\s*(?:Lgs|P\.?\s*R|M|L)\.?\s+\d{1,4}(?:[\/\.]\d{2,4})?\b", 0.95),
    ("LEGAL_REF", r"\bL\.?\s+\d{1,4}[\/\.]\d{4}\b", 0.95),

    # ─── ID nazionali italiani ─────────────────────────────────────────
    # CF tollerante a separatori (spazi/punti/trattini/newline) tra i 3
    # segmenti anagrafici. Cattura "DNTRRT53B23F839V",
    # "DNT RRT 53B23 F839V", e "CCC SFN \n74T25 F839Y" (PDF a capo).
    ("IT_FISCAL_CODE",
     r"\b[A-Z]{3}[\s\.\-]{0,3}[A-Z]{3}[\s\.\-]{0,3}\d{2}[A-EHLMPR-T]\d{2}[\s\.\-]{0,3}[A-Z]\d{3}[A-Z]\b",
     0.99),
    ("IT_VAT_CODE", r"\b(?:IT)?\d{11}\b", 0.95),
    # CIE moderna (alfanumerica): es. CA01674SJ.
    ("IT_CIE", r"\bC[A-Z]\d{5}[A-Z]{2}\b", 0.92),
    # CIE numerica legacy (formato 9 cifre).
    ("IT_CIE", r"\b[A-Z]{2}\d{7}\s?\d{2}\b", 0.90),
    # REA: estesa a 4-7 cifre (sigla provincia + dash + 4-7 digit).
    ("IT_REA", r"\bREA\s?[A-Z]{2}[-\s]\d{4,7}\b", 0.85),
    # Tessera Sanitaria Nazionale (TS-CNS): 20 cifre sulla banda magnetica.
    # Forma precedente (TEAM retro): 8 digit + 1 letter + 2 digit.
    ("IT_TESSERA_SANITARIA", r"\b\d{8}[A-Z]\d{2}\b", 0.80),
    ("IT_TESSERA_SANITARIA", r"(?<!\w)\d{20}(?!\w)", 0.85),
    ("LICENSE_PLATE", r"\b[A-Z]{2}\s?\d{3}\s?[A-Z]{2}\b", 0.85),
    # Patente italiana: 1-2 lettere + 7 cifre + 1 lettera (es. "AT1234567A").
    # Non si sovrappone con LICENSE_PLATE (2L+3D+2L) per via dei 7 digit centrali.
    ("IT_DRIVER_LICENSE", r"\b[A-Z]{1,2}\d{7}[A-Z]\b", 0.88),
    # VIN / Numero telaio veicolo: 17 caratteri alfanumerici, esclusi I/O/Q
    # (standard ISO 3779). Es. "ZFA31200000123456".
    ("VEHICLE_VIN", r"\b[A-HJ-NPR-Z0-9]{17}\b", 0.92),

    # ─── Codice Avviamento Postale (CAP) italiano ────────────────────
    # 5 cifre. Lookahead richiede una città capitalizzata dopo per evitare
    # FP enormi su anni/codici/numeri civici. Cattura solo i 5 digit
    # (la città è gestita dal NER + lista comuni ISTAT).
    ("IT_POSTAL_CODE", r"(?<!\w)\d{5}(?=\s+[A-Z][a-zA-Zà-ÿ'\-]+)", 0.85),

    # ─── Protocolli / numeri di pratica / procedimenti ────────────────
    # "Prot. n. 4567/2024", "Protocollo 12345/2024".
    ("IT_PROT", r"\bProt(?:ocollo)?\.?\s*n?\.?\s*\d{1,8}(?:/\d{2,4})?\b", 0.90),
    # "R.G. 12345/2024", "Sent. n. 789/2024", "Proc. pen. n. 1234/2024".
    ("IT_JUDICIAL_REF",
     r"\b(?:R\.\s*G\.|Sent(?:enza)?\.?\s*n?\.?|Proc(?:edimento)?\.?\s*(?:pen(?:ale)?|civ(?:ile)?)?\.?\s*n?\.?)\s*\d{1,6}(?:/\d{2,4})?\b",
     0.92),
    # Cartelle di pagamento Agenzia Entrate Riscossione (097/AAAA/N progressivo).
    # Formato: "097 2024 00012345 678" (3+4+8+3 numeri separati da spazi).
    ("IT_CARTELLA_AE",
     r"\bCARTELLA\s+DI\s+PAGAMENTO\s+N\.?\s*\d{3}\s+\d{4}\s+\d{8}(?:\s+\d{2,4})?\b",
     0.92),

    # ─── Posizioni contributive INPS / INAIL ─────────────────────────
    # "matricola 1234567890", "INPS 1234567890" (7-11 cifre).
    ("IT_INPS",
     r"\b(?:INPS|matricola(?:\s+INPS)?|posizione\s+INPS)\s+\d{7,11}\b",
     0.88),
    # "INAIL 12300456/00" — codice ditta INAIL.
    ("IT_INAIL",
     r"\bINAIL\s+\d{5,10}(?:/\d{2,4})?\b",
     0.88),

    # ─── Polizze assicurative ────────────────────────────────────────
    # "polizza n. 1234567890", "Polizza assicurativa N. 12345".
    ("IT_INSURANCE_POLICY",
     r"\b[Pp]olizza(?:\s+(?:n\.|RCA))?\s*n?\.?\s*\d{6,15}\b",
     0.88),

    # ─── Codici diagnosi ICD-10 ─────────────────────────────────────
    # Lettera + 2 cifre + opzionale ".cifra" (es. "I21.9", "E11.9", "I10").
    # Dato sanitario sensibile (rivela la patologia → categoria speciale GDPR
    # art. 9). Score moderato perché può avere FP (codici alfanumerici a 3 char);
    # il contesto "diagnosi" o "patologia" prima rinforzerebbe ma è raro.
    ("MEDICAL_ICD", r"\b[A-Z]\d{2}(?:\.\d{1,2})?\b", 0.75),

    # ─── Riferimenti notarili ────────────────────────────────────────
    # "Rep. n. 3788", "Racc. n. 1234" — identificano univocamente un rogito.
    ("NOTAIO_REP", r"\b(?:Rep|Racc)\.?\s*(?:n\.?\s*)?\d{2,8}\b", 0.92),

    # ─── Identificativi catastali ─────────────────────────────────────
    # "foglio 86", "mappale 584", "subalterno 17", "particella 12".
    ("CATASTO", r"\b(?:foglio|mappale|subalterno|particella)\s+\d{1,6}\b", 0.88),
    # Categoria catastale: "cat. A/2", "cat. C/6 bis".
    ("CATASTO", r"\bcat\.?\s*[A-F]/\d{1,2}(?:\s*(?:bis|ter|quater))?\b", 0.90),
    # Classe catastale: "cl. 4", "classe 5".
    ("CATASTO", r"\b(?:cl\.?|classe)\s*\d{1,3}\b", 0.85),
    # Numero vani: "vani 7", "vani 5,5".
    ("CATASTO", r"\bvani\s+\d{1,3}(?:,\d{1,2})?\b", 0.85),
    # Metri quadri: "mq. 24", "mq 24,5", "m² 100".
    ("CATASTO", r"\b(?:mq|m²|m\^2)\.?\s*\d{1,5}(?:,\d{1,2})?\b", 0.85),
    # Rendita catastale: "r.c. € 560,36", "rendita catastale 96,68".
    ("CATASTO", r"\b(?:r\.?\s*c\.?|rendita\s+catastale)\s*€?\s*[\d.,]+\b", 0.92),
    # Zona censuaria: "ZC. 1", "ZC 3".
    ("CATASTO", r"\bZC\.?\s*\d{1,3}\b", 0.88),

    # ─── Importi monetari italiani ────────────────────────────────────
    # Formato IT: € 246.366,59 — separatore migliaia '.', decimale ','.
    # Richiede simbolo esplicito (€/EUR/euro) per evitare FP enormi
    # su anni, CAP, IBAN parziali, e quantità generiche.
    # `\b` non funziona col simbolo € (non è word-char Unicode): uso
    # lookbehind/lookahead `(?<!\w)`/`(?!\w)` come boundary surrogato.
    # Variante prefix: "€ 246.366,59".
    ("CURRENCY",
     r"(?<!\w)(?:€|EUR|euro)\s*\d{1,3}(?:\.\d{3})*(?:,\d{2})?(?!\w)",
     0.92),
    # Variante postfix: "246,59 €".
    ("CURRENCY",
     r"(?<!\w)\d{1,3}(?:\.\d{3})*(?:,\d{2})?\s*(?:€|EUR|euro)(?!\w)",
     0.92),

    # ─── Numeri di conto / libretto ──────────────────────────────────
    # Parola-chiave + max 80 char di qualificatori (anche su nuova riga:
    # pypdf spezza la frase tra "postale" e il numero) + "n. NNN".
    ("ACCT",
     r"\b(?:libretto|conto\s+corrente|c\/c|c\.?\s?c\.?)\b[A-Za-z\s'\n\r]{0,80}?\bn\.?\s*\d{6,20}\b",
     0.92),

    # ─── Banche italiane ─────────────────────────────────────────────
    ("ORGANIZATION",
     r"\bBANCA\s+(?:INTESA(?:\s+SANPAOLO)?|MEDIOLANUM|POPOLARE\s+(?:DI\s+|DELL'\s*)?[A-Z][A-Za-z]+|MONTE\s+DEI\s+PASCHI(?:\s+DI\s+SIENA)?|WIDIBA|FINECO|SELLA|CARIGE|GENERALI|VALSABBINA|BPER|UBI|BNL|UNICREDIT|EUROPEA|D'ITALIA|DI\s+CREDITO\s+COOPERATIVO)\b(?:\s+S\.?\s?p\.?\s?A\.?|\s+SRL|\s+SPA)?",
     0.95),
    ("ORGANIZATION",
     r"\bBANCA\s+[A-Z][A-Za-z']+(?:\s+[A-Z][A-Za-z']+){0,3}\s+(?:S\.?\s?p\.?\s?A\.?|S\.?\s?r\.?\s?l\.?|SPA|SRL|S\.?C\.?p\.?A\.?)\b",
     0.92),
    ("ORGANIZATION",
     r"\b(?:UNICREDIT|INTESA\s+SANPAOLO|BPER|BNL|FINECO|WIDIBA|SELLA|MEDIOLANUM)\b",
     0.94),
    ("ORGANIZATION", r"\bPOSTE\s+ITALIANE\b(?:\s+S\.?\s?p\.?\s?A\.?)?", 0.96),

    # ─── Sigle province italiane in parens ────────────────────────────
    # 110 codici ufficiali. Solo dentro parentesi per evitare FP nel
    # testo libero (es. "MI" non è Milano fuori contesto).
    ("LOCATION",
     r"\(\s*(?:AG|AL|AN|AO|AP|AQ|AR|AT|AV|BA|BG|BI|BL|BN|BO|BR|BS|BT|BZ|CA|CB|CE|CH|CL|CN|CO|CR|CS|CT|CZ|EN|FC|FE|FG|FI|FM|FR|GE|GO|GR|IM|IS|KR|LC|LE|LI|LO|LT|LU|MB|MC|ME|MI|MN|MO|MS|MT|NA|NO|NU|OR|PA|PC|PD|PE|PG|PI|PN|PO|PR|PT|PU|PV|PZ|RA|RC|RE|RG|RI|RM|RN|RO|SA|SI|SO|SP|SR|SS|SU|SV|TA|TE|TN|TO|TP|TR|TS|TV|UD|VA|VB|VC|VE|VI|VR|VS|VT|VV)\s*\)",
     0.90),

    # ─── Comuni italiani ISTAT (~7.875 nomi, len>=4) ────────────────────
    # Il NER ONNX (xx_ent_wiki_sm + multilang-pii-ner-ONNX) tagga bene
    # le città Mixed-Case ("Cassino", "Napoli") ma fallisce su UPPERCASE
    # ("CASSINO") tipico degli atti notarili. Lista ISTAT come fallback.
    #
    # Presidio compila i pattern con re.IGNORECASE → un singolo pattern
    # alternation copre tutte le varianti di case (Cassino/CASSINO/
    # cassino). Il caso "cassino" lowercase è scartato dal garbage
    # filter (single-word lowercase LOCATION è sempre FP in italiano).
    # I cognomi-particella ("d'ACCADIA", "DELLA VALLE") sono filtrati
    # dal garbage filter via surname-particle lookbehind.
    ("LOCATION", rf"\b(?:{_COMUNI_ALTERNATION})\b", 0.80),

    # ─── Cognomi UPPERCASE in formato anagrafico italiano ─────────────
    # COGNOME NOME, COGNOME-COMPOSTO NOME, anche con apostrofo lowercase
    # ("DENTICE d'ACCADIA ROBERTO"). Score 0.55 perché il NER fa il
    # lavoro principale; questo è un fallback per UPPERCASE-only.
    #
    # Wrap con (?-i:...) per disabilitare l'IGNORECASE che Presidio
    # applica di default: senza la wrap, [A-Z][A-Z']{2,} matcherebbe
    # qualunque parola di 3+ lettere (es. "coniuge", "presente"),
    # facendo esplodere i falsi positivi.
    ("PERSON",
     r"(?-i:\b(?:[A-Z][A-Z']{2,}|(?:DE|DEL|DELLA|DI|LO|LA|SAN|SANTA)\s+[A-Z]{3,})(?:\s+(?:d'|D'|dell'|DELL'|dall'|DALL'|sant'|SANT'|de|DE|del|DEL|della|DELLA|di|DI|la|LA|lo|LO|san|SAN|santa|SANTA)?[A-Z][A-Z']{2,}){1,3}\b)",
     0.55),
]

# Phone IT (formato locale + +39). Sta separato perché in
# `text_advanced_anonymizer` la versione preferita è più restrittiva
# (almeno 7 cifre, no match su anni/CAP isolati) — vedi `IT_TEXT_EXTRA`.
_IT_PHONE_TABULAR: PatternTuple = (
    "PHONE_NUMBER",
    r"(?:\+39|0039|39)?[\s.-]?[03]\d{1,4}[\s.-]?\d{2,4}[\s.-]?\d{2,4}(?:[\s.-]?\d{1,4})?",
    0.80,
)

# Pattern aggiuntivi che `text_advanced_anonymizer` carica oltre a
# `_IT_PATTERNS`. Sono recognisers utili per testo libero / PDF / DOCX
# ma non per file tabulari (dove i pattern numerici generici producono
# troppi falsi positivi nelle colonne numeriche).
_IT_TEXT_EXTRA: List[PatternTuple] = [
    ("IBAN_CODE", r"\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]){11,30}\b", 0.95),
    # CREDIT_CARD: 16 cifre (Visa/MC/Discover/Amex), gruppi separati da spazio o trattino.
    # Regex allineata a GLOBAL_PATTERNS (tabular). Mancava nel path free-text `/analyze`
    # (AdvancedTextAnonymizer) → carte non mascherate in TXT/DOCX/PDF. Vedi findings 2026-06-01.
    ("CREDIT_CARD", r"\b(?:4\d{3}|5[1-5]\d{2}|6011|3[47]\d{2})[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b", 0.95),
    # ADDRESS_IT: tipo via + 1-4 token capitalizzati + civico opzionale.
    ("ADDRESS_IT",
     r"(?i)\b(?:via|piazza|corso|viale|vicolo|largo|piazzale)\s+(?:dell['’]|della\s+|dei\s+|degli\s+|delle\s+|del\s+|di\s+|d['’])?[A-Z][A-Za-zÀ-ÿ'’]+(?:\s+[A-Z][A-Za-zÀ-ÿ'’]+){0,3}(?:\s*,?\s*\d{1,4}[a-zA-Z]?)?",
     0.85),
    # Telefono IT: min 7 cifre per evitare match su anni/CAP.
    ("PHONE_NUMBER",
     r"(?<!\w)(?:\+?39[\s.\-]?)?(?:0\d{1,4}|3\d{2})[\s.\-]?\d{3,4}[\s.\-]?\d{3,4}(?!\w)",
     0.90),
    ("EMAIL_ADDRESS",
     r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9][A-Za-z0-9.\-]*\.[A-Za-z]{2,}\b",
     0.98),
    # DATE_TIME: date complete (dd/mm/yyyy, dd Month yyyy, Month yyyy).
    # Singoli giorni/anni/mesi NON sono PII.
    ("DATE_TIME",
     r"\b(?:"
     r"\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}"
     r"|"
     r"\d{1,2}\s+(?:gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)(?:\s+\d{2,4})?"
     r"|"
     r"(?:gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)\s+\d{4}"
     r")\b",
     0.95),
]


# ──────────────────────────────────────────────────────────────────────
# JURISDICTION_PATTERNS — multi-country view used by AnonimyzeService
# ──────────────────────────────────────────────────────────────────────
JURISDICTION_PATTERNS = {
    "IT": _IT_PATTERNS + [_IT_PHONE_TABULAR],
    "DE": [
        ("DE_STEUER_ID", r"\b\d{2}\s?\d{3}\s?\d{3}\s?\d{3}\b", 0.90),
        ("DE_RVNR", r"\b\d{2}\s?\d{9}\b", 0.90),
        ("DE_VAT", r"\bDE\d{9}\b", 0.95),
        ("DE_POSTAL", r"\b\d{5}\b", 0.75),
    ],
    "FR": [
        ("FR_SIRET", r"\b\d{3}\s?\d{3}\s?\d{3}\s?\d{5}\b", 0.90),
        ("FR_SIREN", r"\b\d{3}\s?\d{3}\s?\d{3}\b", 0.85),
        ("FR_NIR", r"\b[1-2]\d{2}[0-9A-Z]{2}\d{2}[0-9A-Z]{3}\d{3}\d{2}\b", 0.95),
        ("FR_VAT", r"\bFR\s?[0-9A-Z]{2}\s?\d{9}\b", 0.90),
        ("FR_POSTAL", r"\b\d{5}\b", 0.75),
    ],
    "UK": [
        ("UK_NINO", r"\b[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b", 0.95),
        ("UK_NHS", r"\b\d{3}\s?\d{3}\s?\d{4}\b", 0.85),
        ("UK_PASSPORT", r"\b\d{9}\b", 0.80),
    ],
    # EN = generic English. Unione UK + US per documenti misti senza
    # forzare la disambiguazione (es. HR multinazionali).
    "EN": [
        ("UK_NINO", r"\b[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z]\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b", 0.95),
        ("UK_NHS", r"\b\d{3}\s?\d{3}\s?\d{4}\b", 0.85),
        ("UK_PASSPORT", r"\b\d{9}\b", 0.80),
        ("US_SSN", r"\b\d{3}-\d{2}-\d{4}\b", 0.95),
        ("US_ITIN", r"\b9\d{2}[-\s]\d{2}[-\s]\d{4}\b", 0.95),
        ("US_EIN", r"\b\d{2}-\d{7}\b", 0.90),
        ("US_PASSPORT", r"\b\d{9}\b", 0.85),
        ("US_DRIVERS_LICENSE", r"\b[A-Z]{1,2}\d{6,8}\b", 0.80),
        ("US_BANK_ROUTING", r"\b\d{9}\b", 0.75),
        ("US_BANK_ACCOUNT", r"\b\d{8,17}\b", 0.70),
        ("US_MEDICARE", r"\b\d{10}\b", 0.75),
        ("US_STATE_ZIP", r"\b[A-Z]{2}\s+\d{5}(?:-\d{4})?\b", 0.85),
        ("US_ADDRESS", r"\b\d{1,5}\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|St|Avenue|Ave|Boulevard|Blvd|Drive|Dr|Lane|Ln|Road|Rd|Court|Ct|Place|Pl|Way|Circle|Cir)\.?\s*,?\s*[A-Z][a-z]+\s*,?\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?", 0.80),
    ],
    "US": [
        ("US_SSN", r"\b\d{3}-\d{2}-\d{4}\b", 0.95),
        ("US_ITIN", r"\b9\d{2}[-\s]\d{2}[-\s]\d{4}\b", 0.95),
        ("US_EIN", r"\b\d{2}-\d{7}\b", 0.90),
        ("US_PASSPORT", r"\b\d{9}\b", 0.85),
        ("US_DRIVERS_LICENSE", r"\b[A-Z]{1,2}\d{6,8}\b", 0.80),
        ("US_BANK_ROUTING", r"\b\d{9}\b", 0.75),
        ("US_BANK_ACCOUNT", r"\b\d{8,17}\b", 0.70),
        ("US_MEDICARE", r"\b\d{10}\b", 0.75),
        ("US_STATE_ZIP", r"\b[A-Z]{2}\s+\d{5}(?:-\d{4})?\b", 0.85),
        ("US_ADDRESS", r"\b\d{1,5}\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|St|Avenue|Ave|Boulevard|Blvd|Drive|Dr|Lane|Ln|Road|Rd|Court|Ct|Place|Pl|Way|Circle|Cir)\.?\s*,?\s*[A-Z][a-z]+\s*,?\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?", 0.80),
    ],
    "NEUTRAL": [],
}


# ──────────────────────────────────────────────────────────────────────
# Text/PDF/DOCX view used by AdvancedTextAnonymizer
# ──────────────────────────────────────────────────────────────────────
def get_it_text_patterns() -> List[PatternTuple]:
    """Return the (name, regex, score) list for the AdvancedTextAnonymizer
    Presidio pipeline. Same IT master list as the tabular pipeline, plus
    the multi-line / address / email / phone / date recognisers tuned
    for free-text PDFs and DOCX. The IT phone variant for tabular is
    intentionally dropped — it produces too many false positives on
    numeric columns and is replaced by the stricter `_IT_TEXT_EXTRA`
    phone pattern (min 7 digits, word-boundary anchored)."""
    return list(_IT_PATTERNS) + list(_IT_TEXT_EXTRA)
