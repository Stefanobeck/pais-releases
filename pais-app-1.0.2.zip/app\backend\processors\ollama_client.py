"""
Ollama Client - AI Model Interface per PAI Premium
Supporta streaming reale con thinking blocks (<think></think>).
Dynamic Context Budget: calcola num_ctx ottimale per ogni richiesta.
"""
import asyncio
import ollama
import httpx
import json
from typing import AsyncGenerator, Dict, Any, Optional, List, Callable
import logging

from processors.context_budget import calculate_dynamic_ctx

logger = logging.getLogger(__name__)

# Valore sentinel per indicare "usa ctx dinamico"
AUTO_CTX = -1


from backend_config import settings
import ollama


# ─── Native context_length cache per modello (per evitare troncatura silente) ─
# Quando l'utente aggiunge un modello custom, catalog_service interroga
# /api/show via `get_model_context_length()` e popola questa cache. Il
# valore viene anche persistito in user_settings.json (custom_models_ctx)
# cosi' al riavvio PAIS la cache viene ri-seedata.
# `chat()` / `chat_stream()` consultano la cache prima di chiamare
# `calculate_dynamic_ctx`: se il modello ha un native_ctx noto, viene usato
# come tetto invece del default 131072 — evita di mandare 128K a un modello
# che supporta solo 8K (Ollama tronca silenziosamente).
_MODEL_CTX_CACHE: Dict[str, int] = {}
_SEEDED_FROM_SETTINGS = False


def _ensure_ctx_cache_seeded() -> None:
    """Seed _MODEL_CTX_CACHE da user_settings.json al primo accesso.
    Lazy + best-effort: errori vengono ignorati silenziosamente (cache vuota
    = comportamento legacy, niente regression)."""
    global _SEEDED_FROM_SETTINGS
    if _SEEDED_FROM_SETTINGS:
        return
    _SEEDED_FROM_SETTINGS = True
    try:
        from services import user_settings_service as uss
        cached = uss.get_custom_models_ctx()
        if isinstance(cached, dict):
            for k, v in cached.items():
                if isinstance(k, str) and isinstance(v, int) and v > 0:
                    _MODEL_CTX_CACHE[k] = v
            if _MODEL_CTX_CACHE:
                logger.info(f"Seeded model ctx cache with {len(_MODEL_CTX_CACHE)} entries")
    except Exception as e:
        logger.warning(f"Failed to seed model ctx cache: {e}")


def _effective_max_ctx(model: str, module_cap: int) -> int:
    """Combina 2 livelli per risolvere il max_ctx effettivo:

      1. **native_ctx**: limite hardware del modello (da Ollama /api/show,
         in `_MODEL_CTX_CACHE`). None se non ancora detectato (modello
         appena aggiunto, Ollama down, ecc.).
      2. **module_cap**: tetto semantico del modulo chiamante (CHAT_CTX,
         MANIPULATE_CTX, ecc.). Passato esplicitamente dal call site.

    Il piu' piccolo dei 2 vince. Se nessuno e' disponibile (caso
    degenerato, mai dovrebbe succedere), fallback 131072 legacy.

    Poi `calculate_dynamic_ctx()` riduce ulteriormente in base al peso
    del prompt corrente. Risultato finale: tetto piu' stretto possibile
    che ancora soddisfa la richiesta."""
    _ensure_ctx_cache_seeded()
    native = _MODEL_CTX_CACHE.get(model)
    candidates = [c for c in (native, module_cap) if c and c > 0]
    return min(candidates) if candidates else 131072

class OllamaClient:
    """
    Client per interazione con Ollama API.
    Bypassa la libreria ufficiale per lo streaming a causa di bug di hanging.
    """

    def __init__(self, host: str = None):
        self._explicit_host = host
        self._cached_client = None
        self._cached_host_url = None

    @property
    def host_raw(self):
        raw_host = self._explicit_host or settings.OLLAMA_HOST_URL
        return raw_host.replace("http://", "").replace("https://", "")

    @property
    def host(self):
        return f"http://{self.host_raw}"

    @property
    def client(self):
        current_host = self.host
        if self._cached_client is None or self._cached_host_url != current_host:
            self._cached_client = ollama.AsyncClient(host=current_host)
            self._cached_host_url = current_host
        return self._cached_client

    async def _ensure_model_in_cache(self, model: str, timeout_s: float = 2.0) -> None:
        """Lazy seed: se `model` non e' in `_MODEL_CTX_CACHE`, lancia un
        `get_model_context_length()` bloccante con timeout corto. Errori
        (timeout, modello mancante, Ollama down) sono silenziosi: la cache
        resta vuota per quel modello e `_effective_max_ctx` fa fallback al
        `module_cap` passato — comportamento safe, mai peggiore del legacy.

        Costo: ~200ms una sola volta per modello, ammortizzato sulle chiamate
        successive. Nessun overhead al boot di PAIS."""
        _ensure_ctx_cache_seeded()
        if not model or model in _MODEL_CTX_CACHE:
            return
        try:
            await asyncio.wait_for(
                self.get_model_context_length(model),
                timeout=timeout_s,
            )
        except asyncio.TimeoutError:
            logger.warning(f"Native ctx detect for {model} timed out ({timeout_s}s)")
        except Exception as e:
            logger.warning(f"Native ctx detect for {model} failed: {e}")

    async def get_model_context_length(self, model: str) -> Optional[int]:
        """Interroga Ollama /api/show per il context_length nativo del modello.

        Estrae `model_info.<arch>.context_length` (chiave varia per
        architettura: `llama.context_length`, `qwen2.context_length`,
        `gemma3.context_length`, ecc. — suffisso costante `.context_length`).

        Cache su successo in `_MODEL_CTX_CACHE`. Ritorna None su errore di
        rete, modello non installato, o metadati mancanti (fallback al
        comportamento legacy: 131072 hard cap).
        """
        _ensure_ctx_cache_seeded()
        if model in _MODEL_CTX_CACHE:
            return _MODEL_CTX_CACHE[model]
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    f"{self.host}/api/show",
                    json={"model": model},
                )
            if resp.status_code != 200:
                logger.warning(f"/api/show for {model} returned {resp.status_code}")
                return None
            data = resp.json()
        except Exception as e:
            logger.warning(f"Failed to query /api/show for {model}: {e}")
            return None

        info = data.get("model_info") or {}
        if not isinstance(info, dict):
            return None
        for key, value in info.items():
            if isinstance(key, str) and key.endswith(".context_length"):
                if isinstance(value, (int, float)) and value > 0:
                    ctx = int(value)
                    _MODEL_CTX_CACHE[model] = ctx
                    logger.info(f"Detected native ctx for {model}: {ctx}")
                    return ctx
        return None

    async def chat(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        num_ctx: int = AUTO_CTX,
        temperature: float = 0.1,
        max_ctx: int = 131072
    ) -> str:
        """Chat sincrona (usa ancora la libreria)."""
        if num_ctx == AUTO_CTX:
            await self._ensure_model_in_cache(model)
            effective_max = _effective_max_ctx(model, max_ctx)
            num_ctx = calculate_dynamic_ctx(messages, estimated_response_tokens=4096, max_ctx=effective_max)

        # Pre-processa i messaggi per convertire eventuali 'bytes' in base64
        processed_messages = []
        for msg in messages:
            msg_copy = msg.copy()
            if "images" in msg_copy and isinstance(msg_copy["images"], list):
                encoded_images = []
                for img in msg_copy["images"]:
                    if isinstance(img, bytes):
                        import base64
                        encoded_images.append(base64.b64encode(img).decode('utf-8'))
                    else:
                        encoded_images.append(img)
                msg_copy["images"] = encoded_images
            processed_messages.append(msg_copy)

        try:
            response = await self.client.chat(
                model=model,
                messages=processed_messages,
                options={'num_ctx': num_ctx, 'temperature': temperature}
            )
            return response['message']['content']
        except Exception as e:
            logger.error(f"Errore chat Ollama: {e}")
            raise

    async def chat_stream(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        num_ctx: int = AUTO_CTX,
        temperature: float = 0.1,
        stop_check_callback: Optional[Callable[[], bool]] = None,
        max_ctx: int = 131072,
        options: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[str, None]:
        """
        Chat Streaming ROBUSTA via HTTPX diretto.
        Supporta il passaggio di 'options' esterne (es. num_ctx, temperature).
        """
        if num_ctx == AUTO_CTX:
            # Se options contiene num_ctx, usiamo quello, altrimenti calcoliamo
            if options and "num_ctx" in options:
                num_ctx = options["num_ctx"]
            else:
                await self._ensure_model_in_cache(model)
                effective_max = _effective_max_ctx(model, max_ctx)
                num_ctx = calculate_dynamic_ctx(messages, estimated_response_tokens=8192, max_ctx=effective_max)

        # Pre-processa i messaggi per convertire eventuali 'bytes' (immagini) in base64
        processed_messages = []
        for msg in messages:
            msg_copy = msg.copy()
            if "images" in msg_copy and isinstance(msg_copy["images"], list):
                encoded_images = []
                for img in msg_copy["images"]:
                    if isinstance(img, bytes):
                        import base64
                        encoded_images.append(base64.b64encode(img).decode('utf-8'))
                    else:
                        encoded_images.append(img)
                msg_copy["images"] = encoded_images
            processed_messages.append(msg_copy)

        # Unione delle opzioni (quelle passate esplicitamente hanno la priorità)
        final_options = {"num_ctx": num_ctx, "temperature": temperature}
        if options:
            final_options.update(options)

        logger.info(f"📡 [DIRECT-HTTP] Request to {model} (ctx: {final_options.get('num_ctx')})")
        
        is_in_thought = False
        payload = {
            "model": model,
            "messages": processed_messages,
            "stream": True,
            "options": final_options
        }

        try:
            # Timeout esplicito: connect rapido (rete locale), read lungo perché
            # l'LLM può impiegare minuti a generare risposte sui PC poco potenti.
            client_timeout = httpx.Timeout(connect=10.0, read=600.0, write=30.0, pool=10.0)
            async with httpx.AsyncClient(timeout=client_timeout) as client:
                async with client.stream("POST", f"{self.host}/api/chat", json=payload) as response:
                    if response.status_code != 200:
                        err_text = await response.aread()
                        raise Exception(f"Ollama error {response.status_code}: {err_text.decode()}")

                    async for line in response.aiter_lines():
                        if not line: continue
                        if stop_check_callback and stop_check_callback():
                            logger.info("Stream stopped by user")
                            break

                        try:
                            chunk = json.loads(line)
                            if 'message' in chunk:
                                msg = chunk['message']
                                
                                # Estrazione reasoning/thinking
                                raw_thought = msg.get('thinking') or msg.get('thought') or msg.get('reasoning') or ""
                                raw_content = msg.get('content', '')
                                
                                token = ""
                                if raw_thought and not is_in_thought:
                                    token += "<think>\n"
                                    is_in_thought = True
                                
                                if raw_content and is_in_thought:
                                    token += "\n</think>\n"
                                    is_in_thought = False
                                
                                token += raw_thought + raw_content
                                if token:
                                    yield token
                            
                            if chunk.get('done'):
                                logger.info(f"✨ Stream for {model} completed successfully.")
                                break

                        except json.JSONDecodeError:
                            continue
            
            if is_in_thought:
                yield "</think>"

        except Exception as e:
            logger.error(f"💥 Critical Stream Error: {e}")
            raise

    async def generate_embedding(
        self,
        model: str,
        text: str
    ) -> Optional[List[float]]:
        """
        Genera embedding per un testo.

        Args:
            model: Modello embedding (es. "qwen3-embedding:0.6b")
            text: Testo da embeddare

        Returns:
            Lista di float (embedding vector) o None
        """
        try:
            response = await self.client.embeddings(
                model=model,
                prompt=text
            )
            return response.get('embedding')
        except Exception as e:
            logger.error(f"Errore embedding Ollama: {e}")
            return None

    async def is_available(self) -> bool:
        """Controlla se Ollama è disponibile."""
        try:
            await self.client.list()
            return True
        except:
            return False

    async def list_models(self) -> List[str]:
        """Lista modelli disponibili."""
        try:
            response = await self.client.list()
            return [model.get('name', '') for model in response.get('models', [])]
        except Exception as e:
            logger.error(f"Errore lista modelli: {e}")
            return []
